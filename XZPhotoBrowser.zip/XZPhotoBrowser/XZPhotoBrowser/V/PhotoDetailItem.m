//
//  PhotoDetailItem.m
//  XZPhotoBrowser
//
//  Created by 徐洋 on 16/8/4.
//  Copyright © 2016年 徐洋. All rights reserved.
//

#import "PhotoDetailItem.h"

@implementation PhotoDetailItem

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.detailImageView = [UIImageView new];
        [self.contentView addSubview:self.detailImageView];
        self.detailImageView.contentMode = UIViewContentModeScaleAspectFit;
        self.detailImageView.userInteractionEnabled = YES;
        self.imageViewToBackPan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(imageViewToBackPanAction:)];
    }
    return self;
}

- (void)imageViewToBackPanAction:(UIPanGestureRecognizer *)sender
{
    NSLog(@"yes");
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.detailImageView.frame = self.contentView.frame;
//    [self.detailImageView addGestureRecognizer:self.imageViewToBackPan];
}

@end
