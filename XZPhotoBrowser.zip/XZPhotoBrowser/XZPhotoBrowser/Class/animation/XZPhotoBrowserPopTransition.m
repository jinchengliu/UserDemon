//
//  XZPhotoBrowserPopTransition.m
//  XZPhotoBrowser
//
//  Created by 徐洋 on 16/8/3.
//  Copyright © 2016年 徐洋. All rights reserved.
//

#import "XZPhotoBrowserPopTransition.h"
#import "XZPhotoBrowserViewController.h"
#import "PhotoDetailViewController.h"
#import "PhotoDetailItem.h"
#import "XZPhotoBrowserItem.h"
#import "XZPhotoBrowserFlowLayout.h"

@implementation XZPhotoBrowserPopTransition

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext
{
    return 0.7f;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext
{
    PhotoDetailViewController *fromVC = (PhotoDetailViewController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    XZPhotoBrowserViewController *toVC = (XZPhotoBrowserViewController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    UIImageView *snapShotView = [UIImageView new];
    snapShotView.image = fromVC.tmpImageView.image;
    snapShotView.backgroundColor = [UIColor redColor];
    snapShotView.frame = [containerView convertRect:fromVC.tmpImageView.frame fromView:fromVC.tmpImageView.superview];
    fromVC.collectionView.hidden = YES;
    
    
    toVC.view.frame = [transitionContext finalFrameForViewController:toVC];
    
    [containerView insertSubview:toVC.view belowSubview:fromVC.view];
    [containerView addSubview:snapShotView];
    
    XZPhotoBrowserFlowLayout *flowLayout = (XZPhotoBrowserFlowLayout *)toVC.collectionView.collectionViewLayout;
    UICollectionViewLayoutAttributes *attributes = flowLayout.itemsAttributes[fromVC.selectIndex];
    UIView *tmpView = [UIView new];
    //这个颜色一定要和collectionview的背景色一样
    tmpView.backgroundColor = [UIColor whiteColor];
    
    [toVC.collectionView addSubview:tmpView];
    tmpView.frame = CGRectMake(attributes.frame.origin.x, attributes.frame.origin.y, attributes.frame.size.width, attributes.frame.size.height);
    [UIView animateWithDuration:[self transitionDuration:transitionContext] delay:0.0f usingSpringWithDamping:0.6f initialSpringVelocity:1.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        fromVC.view.alpha = 0.0f;
        snapShotView.frame = CGRectMake(attributes.frame.origin.x, attributes.frame.origin.y + 64 - toVC.collectionView.contentOffset.y, attributes.frame.size.width, attributes.frame.size.height);
    } completion:^(BOOL finished) {
        [snapShotView removeFromSuperview];
        fromVC.collectionView.hidden = NO;
        [tmpView removeFromSuperview];
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
}

@end
