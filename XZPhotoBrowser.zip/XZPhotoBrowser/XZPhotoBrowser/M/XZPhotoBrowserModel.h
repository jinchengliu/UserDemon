//
//  XZPhotoBrowserModel.h
//  XZPhotoBrowser
//
//  Created by 徐洋 on 16/8/4.
//  Copyright © 2016年 徐洋. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XZPhotoBrowserModel : NSObject
/**
 *  图片名
 */
@property (nonatomic, copy) NSString *title;
/**
 *  图片链接
 */
@property (nonatomic, copy) NSString *url;
/**
 *  原图宽度
 */
@property (nonatomic, assign) float width;
/**
 *  原图高度
 */
@property (nonatomic, assign) float height;

@end
