//
//  XZPhotoBrowserFlowLayout.h
//  XZPhotoBrowser
//
//  Created by 徐洋 on 16/7/30.
//  Copyright © 2016年 徐洋. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XZPhotoBrowserModel;

@interface XZPhotoBrowserFlowLayout : UICollectionViewFlowLayout

@property (nonatomic, copy) NSArray<XZPhotoBrowserModel *> *images;
/**
 *  列数 默认为2
 */
@property (nonatomic, assign) NSUInteger xzColumnsCount;

@property (nonatomic,strong)NSMutableArray *itemsAttributes;//保存所有列高度的数组

@end
