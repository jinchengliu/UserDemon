//
//  PhotoDetailViewController.h
//  XZPhotoBrowser
//
//  Created by 徐洋 on 16/8/4.
//  Copyright © 2016年 徐洋. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PhotoDetailDelegate <NSObject>

- (void)xzPhotoBrowserSelectIndex:(NSInteger)index;

@end

@interface PhotoDetailViewController : UIViewController

@property (nonatomic, strong) UICollectionView *collectionView;
/**
 *  数据源
 */
@property (nonatomic, copy) NSArray *dataArray;
/**
 *  当前显示的item下标
 */
@property (nonatomic, assign) NSInteger selectIndex;
/**
 *  创建一个临时的imageView,用于实现动画效果
 */
@property (nonatomic, strong) UIImageView *tmpImageView;

@property (nonatomic, assign) id<PhotoDetailDelegate> delegate;

@end
