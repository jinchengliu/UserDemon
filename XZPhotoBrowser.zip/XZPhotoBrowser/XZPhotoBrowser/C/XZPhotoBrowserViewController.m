//
//  XZPhotoBrowserViewController.m
//  XZPhotoBrowser
//
//  Created by 徐洋 on 16/8/4.
//  Copyright © 2016年 徐洋. All rights reserved.
//


#import "XZPhotoBrowserViewController.h"
#import "XZPhotoBrowserItem.h"
#import "XZPhotoBrowserFlowLayout.h"
#import "PhotoDetailViewController.h"
#import "XZPhotoBrowserPushTransition.h"
#import "XZPhotoBrowserModel.h"
#import "UIImageView+WebCache.h"

@interface XZPhotoBrowserViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UINavigationControllerDelegate, PhotoDetailDelegate>
/**
 *  数据源数组
 */
@property (nonatomic, strong) NSMutableArray *dataArray;
/**
 *  存放标识符的字典(不知道重用的解决办法,有的话可以告诉我qq:916391479)
 */
@property (nonatomic, strong) NSMutableDictionary *identifierDic;
/**
 *  自定义描述对象
 */
@property (nonatomic, strong) XZPhotoBrowserFlowLayout *flowLayout;
/**
 *  存放从plist中取出的数据
 */
@property (nonatomic, strong) NSMutableArray *plistArray;

@end

static NSString *identifier = @"identifierCell";

@implementation XZPhotoBrowserViewController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.navigationController.delegate = self;
}
/**
 *  push到详情页的时候走自定义动画
 */
- (id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
                                   animationControllerForOperation:(UINavigationControllerOperation)operation
                                                fromViewController:(UIViewController *)fromVC
                                                  toViewController:(UIViewController *)toVC{
    
    if ([toVC isKindOfClass:[PhotoDetailViewController class]]) {
        //初始化自定义push动画
        XZPhotoBrowserPushTransition *transition = [[XZPhotoBrowserPushTransition alloc]init];
        return transition;
    }else{
        return nil;
    }
}

- (void)xzPhotoBrowserSelectIndex:(NSInteger)index
{
    UICollectionViewLayoutAttributes *attributes = self.flowLayout.itemsAttributes[index];
    CGFloat bottomLine = attributes.frame.origin.y + attributes.frame.size.height + 5;
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height - 64;
    if (bottomLine > screenH) {
        self.collectionView.contentOffset = CGPointMake(0, bottomLine - screenH);
    }else{
        self.collectionView.contentOffset = CGPointMake(0, 0);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //从plist中取出数据,转为模型,存放到数组中
    NSString *path = [[NSBundle mainBundle] pathForResource:@"photos.plist" ofType:nil];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSArray *arr = dic[@"content"];
    [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        XZPhotoBrowserModel *model = [[XZPhotoBrowserModel alloc] init];
        [model setValuesForKeysWithDictionary:arr[idx]];
        [self.plistArray addObject:model];
    }];
    //初始化标识符字典
    self.identifierDic = [NSMutableDictionary dictionary];
    //将集合视图添加到view上
    [self.view addSubview:self.collectionView];
}
/**
 *  添加数据按钮
 */
- (IBAction)addAction:(UIBarButtonItem *)sender {
    if (self.dataArray.count == self.plistArray.count) return;
    [self.dataArray addObject:self.plistArray[self.dataArray.count]];
    self.flowLayout.images = self.dataArray;
    [self.collectionView reloadData];
}
/**
 *  清除所有数据按钮
 */
- (IBAction)clearAction:(UIBarButtonItem *)sender {
    //清空数据源
    [self.dataArray removeAllObjects];
    //清空标识符字典
    [self.identifierDic removeAllObjects];
    [self.offsetDictionary removeAllObjects];
    //刷新UI
    [self.collectionView reloadData];
}

#pragma mark --- 代理方法
// 设置分区内视图个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}
// 设置视图cell
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    //从标识符字典中根据key取出唯一的标识符
    NSString *fier = [self.identifierDic objectForKey:[NSString stringWithFormat:@"%@", indexPath]];
    if (fier == nil) {
        //如果不存在,创建一个唯一的标识符
        fier = [NSString stringWithFormat:@"XZPhotoBrowser%@", indexPath];
        //添加到字典中
        [self.identifierDic setValue:fier forKey:[NSString stringWithFormat:@"%@", indexPath]];
        //注册item
        [self.collectionView registerClass:[XZPhotoBrowserItem class] forCellWithReuseIdentifier:fier];
    }
    //从重用池中取出item
    XZPhotoBrowserItem *cell = [collectionView dequeueReusableCellWithReuseIdentifier:fier forIndexPath:indexPath];
    XZPhotoBrowserModel *model = self.dataArray[indexPath.row];
    [cell.photo sd_setImageWithURL:[NSURL URLWithString:model.url] placeholderImage:nil];
    [self.offsetDictionary setObject:@(cell.frame.origin.y + cell.frame.size.height + 5) forKey:[NSString stringWithFormat:@"%ld", indexPath.row]];
    return cell;
}
- (NSMutableDictionary *)offsetDictionary
{
    if (!_offsetDictionary) {
        _offsetDictionary = [NSMutableDictionary dictionary];
    }
    return _offsetDictionary;
}

// 设置分区个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
//item点击事件(push到详情)
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoDetailViewController *detail = [[PhotoDetailViewController alloc] init];
    detail.dataArray = self.dataArray;
    detail.delegate = self;
    detail.selectIndex = indexPath.row;
    [self.navigationController pushViewController:detail animated:YES];
}

#pragma mark ---- 懒加载
//集合视图
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 64) collectionViewLayout:self.flowLayout];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
    }
    return _collectionView;
}
//自定义描述对象
- (XZPhotoBrowserFlowLayout *)flowLayout
{
    if (!_flowLayout) {
        _flowLayout = [[XZPhotoBrowserFlowLayout alloc] init];
        _flowLayout.images = self.dataArray;
        _flowLayout.xzColumnsCount = 3;
    }
    return _flowLayout;
}
//数据源
- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = @[].mutableCopy;
    }
    return _dataArray;
}
//plist数据
- (NSMutableArray *)plistArray
{
    if (!_plistArray) {
        _plistArray = [NSMutableArray array];
    }
    return _plistArray;
}

@end
