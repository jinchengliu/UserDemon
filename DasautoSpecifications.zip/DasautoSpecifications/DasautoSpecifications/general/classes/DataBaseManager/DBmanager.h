//
//  DBmanager.h
//  DasautoSpecifications
//
//  Created by wangrui on 15-6-24.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "FMDatabase.h"

@interface DBmanager : NSObject

+ (DBmanager *)sharedInstance;
+ (DBmanager *)sharedInstanceWithDBName:(NSString *)dataBaseName;

- (NSMutableArray *)fecthDownloadHistory;
- (NSMutableArray *)fecthShopWithUserId:(NSString *)userId;
- (NSMutableArray *)fecthHtmlWithListName:(NSString *)listName userId:(NSString *)userId;
- (NSMutableArray *)fecthHtmlWithCarName:(NSString *)carName carYear: (NSString *)carYear userId:(NSString *)userId;
- (NSMutableArray *)fecthHtmlWithCarName:(NSString *)carName carYear: (NSString *)carYear listName:(NSString *)listName userId:(NSString *)userId;

- (void)insertHtml:(NSArray *)array;
- (void)insertShop:(NSArray *)array;
- (void)insertDownloadHistory:(NSArray *)array;

- (void)deleteShop:(NSArray *)shopArray;
- (void)deleteHtml:(NSArray *)HtmlArray;
- (void)deleteAllShopWithUserId:(NSString *)userId;
- (void)deleteAllLoginHtmlWithUserId:(NSString *)userId;

- (BOOL)isSelectedWithArray:(NSArray *)array;
@end