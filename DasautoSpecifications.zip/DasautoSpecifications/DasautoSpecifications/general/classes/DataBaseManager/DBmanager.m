//
//  DBmanager.m
//  DasautoSpecifications
//
//  Created by wangrui on 15-6-24.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

#import "DBmanager.h"


@implementation DBmanager
{
    FMDatabase *_fmdb;
}

- (instancetype)initWithDataBaseName:(NSString *)dataBaseName
{
    self = [super init];
    if (self) {
        
        NSString *path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.db",dataBaseName]];
        NSLog(@"path : %@",path);
        _fmdb = [[FMDatabase alloc] initWithPath:path];
        
        NSString *str = [[NSString alloc] init];
        if ([dataBaseName isEqualToString:@"shop"]) {
            
            str = @"create table if not exists shopAndHistory(listName,name,idOrYear,addressOrPicurl,telePhoneOrSize,isVideo,userId,spare)";
        }else {
            
            str = @"create table if not exists car(carName,carYear,isIncludeVideo,listName,titleName,resourceId,picUrl,zipSize,userId,spareName,spareList)";
        }
        if ([_fmdb open]) {
            
//            NSString *str = @"create table if not exists car(carName,carYear,isIncludeVideo,listName,titleName,resourceId,picUrl,zipSize,userId,spareName,spareList)";
            
            if (![_fmdb executeUpdate:str]) {
                
                NSLog(@"创建数据库失败");
            }
        }
        else{
            NSLog(@"数据库创建失败");
        }
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        NSString *path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"shop.db"];
        NSLog(@"shop path : %@",path);
        _fmdb = [[FMDatabase alloc] initWithPath:path];
        
        if ([_fmdb open]) {
            
            NSString *str = @"create table if not exists shopAndHistory(listName,name,idOrYear,addressOrPicurl,telePhoneOrSize,isVideo,userId,spare)";
            if (![_fmdb executeUpdate:str]) {
                
                NSLog(@"创建数据库失败");
            }
        }
        else{
            NSLog(@"数据库创建失败");
        }
    }
    return self;
}

+ (DBmanager *)sharedInstanceWithDBName:(NSString *)dataBaseName
{
    static DBmanager *manager;
    if (!manager) {
        
        manager = [[DBmanager alloc] initWithDataBaseName:dataBaseName];
    }
    
    return manager;
}

+ (DBmanager *)sharedInstance
{
    static DBmanager *manager;
    if (!manager) {
        
        manager = [[DBmanager alloc] init];
    }
    
    return manager;
}

// MARK: 查询下载记录
- (NSMutableArray *)fecthDownloadHistory {
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *sql = [NSString stringWithFormat:@"select * from shopAndHistory where listName = '%@'",@"下载历史"];
    FMResultSet *result = [_fmdb executeQuery:sql];
    while ([result next]) {
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        NSString *carName = [result stringForColumn:@"name"];
        NSString *carYear = [result stringForColumn:@"idOrYear"];
        NSString *picUrl = [result stringForColumn:@"addressOrPicurl"];
        NSString *zipSize = [result stringForColumn:@"telePhoneOrSize"];
        NSString *isIncludeVideo = [result stringForColumn:@"isVideo"];
        
        [arr addObject:carName];
        [arr addObject:carYear];
        [arr addObject:picUrl];
        [arr addObject:isIncludeVideo];
        [arr addObject:zipSize];
        [array addObject:arr];
    }
    return array;
}

// MARK:
// MARK: 查询html
- (NSMutableArray *)fecthHtmlWithCarName:(NSString *)carName carYear: (NSString *)carYear listName:(NSString *)listName userId:(NSString *)userId {
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *sql = [NSString stringWithFormat:@"select * from car where carName = '%@' and carYear = '%@' and listName = '%@' and userId = '%@'",carName,carYear,listName,userId];
    
    FMResultSet *result = [_fmdb executeQuery:sql];
    while ([result next]) {
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        NSString *carName = [result stringForColumn:@"carName"];
        NSString *carYear = [result stringForColumn:@"carYear"];
        NSString *listName = [result stringForColumn:@"listName"];
        NSString *titleName = [result stringForColumn:@"titleName"];
        NSString *resourceId = [result stringForColumn:@"resourceId"];
        
        [arr addObject:carName];
        [arr addObject:carYear];
        [arr addObject:listName];
        [arr addObject:titleName];
        [arr addObject:resourceId];
        [array addObject:arr];
    }
    return array;
}

- (NSMutableArray *)fecthHtmlWithCarName:(NSString *)carName carYear: (NSString *)carYear userId:(NSString *)userId {
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *sql = [NSString stringWithFormat:@"select * from car where carName = '%@' and carYear = '%@' and userId = '%@'",carName,carYear,userId];
    
    FMResultSet *result = [_fmdb executeQuery:sql];
    while ([result next]) {
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        NSString *carName = [result stringForColumn:@"carName"];
        NSString *carYear = [result stringForColumn:@"carYear"];
        NSString *listName = [result stringForColumn:@"listName"];
        NSString *titleName = [result stringForColumn:@"titleName"];
        NSString *resourceId = [result stringForColumn:@"resourceId"];
        
        [arr addObject:carName];
        [arr addObject:carYear];
        [arr addObject:listName];
        [arr addObject:titleName];
        [arr addObject:resourceId];
        [array addObject:arr];
    }
    return array;
}

- (NSMutableArray *)fecthHtmlWithListName:(NSString *)listName userId:(NSString *)userId {
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *sql = [NSString stringWithFormat:@"select * from car where listname = '%@' and userId = '%@'",listName,userId];
    
    FMResultSet *result = [_fmdb executeQuery:sql];
    while ([result next]) {
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        NSString *carName = [result stringForColumn:@"carName"];
        NSString *carYear = [result stringForColumn:@"carYear"];
        NSString *listName = [result stringForColumn:@"listName"];
        NSString *titleName = [result stringForColumn:@"titleName"];
        NSString *resourceId = [result stringForColumn:@"resourceId"];
        
        [arr addObject:carName];
        [arr addObject:carYear];
        [arr addObject:listName];
        [arr addObject:titleName];
        [arr addObject:resourceId];
        [array addObject:arr];
    }
    return array;
}

// MARK: 查询经销商
- (NSMutableArray *)fecthShopWithUserId:(NSString *)userId {
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *sql = [NSString stringWithFormat:@"select * from shopAndHistory where userId = '%@'",userId];
    FMResultSet *result = [_fmdb executeQuery:sql];
    while ([result next]) {
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        NSString *shopName = [result stringForColumn:@"name"];
        NSString *shopId = [result stringForColumn:@"idOrYear"];
        NSString *shopAddress = [result stringForColumn:@"addressOrPicurl"];
        NSString *telePhone = [result stringForColumn:@"telePhoneOrSize"];
        
        [arr addObject:shopName];
        [arr addObject:shopId];
        [arr addObject:shopAddress];
        [arr addObject:telePhone];
        [array addObject:arr];
    }
    return array;
}

// MARK: 添加html
- (void)insertHtml:(NSArray *)array
{
    NSString *sql = @"insert into car(carName,carYear,listName,titleName,resourceId,userId) values(?,?,?,?,?,?)";
    if (![_fmdb executeUpdate:sql,array[0],array[1],array[2],array[3],array[4],array[5]]) {
        NSLog(@"添加数据失败userId");
    }
}

/// MARK: 添加下载历史 (添加到shopAndHistroy, 永久绑定到本地) (需要设置主键, 防止重复添加)(暂时用的都是网络请求, 不存在重复添加)
- (void)insertDownloadHistory:(NSArray *)array
{
    NSString *sql = @"insert into shopAndHistory(listName,name,idOrYear,addressOrPicurl,telePhoneOrSize,isVideo) values(?,?,?,?,?,?)";
    if (![_fmdb executeUpdate:sql,array[0],array[1],array[2],array[3],array[4],array[5]]) {
        NSLog(@"添加数据失败");
    }
}

// MARK: 添加经销商
- (void)insertShop:(NSArray *)array
{
        NSString *sql = @"insert into shopAndHistory(listName,name,idOrYear,addressOrPicurl,telePhoneOrSize,userId) values(?,?,?,?,?,?)";
        if (![_fmdb executeUpdate:sql,array[0],array[1],array[2],array[3],array[4],array[5]]) {
            NSLog(@"添加数据失败userId");
        }
}

// MARK: 删除html
- (void)deleteHtml:(NSArray *)HtmlArray {
    
        NSString *sql = @"delete from car where carName = ? and carYear = ? and listname = ? and titleName = ? and resourceId = ? and userId = ?";
        if (![_fmdb executeUpdate:sql,HtmlArray[0],HtmlArray[1],HtmlArray[2],HtmlArray[3],HtmlArray[4],HtmlArray[5]]) {
            NSLog(@"删除数据失败userId");
        }
}

// MARK: 删除缓存Html(用户登录退出时删除)
- (void)deleteAllLoginHtmlWithUserId:(NSString *)userId
{
    NSString *sql = @"delete from car where userId = ?";
    if (![_fmdb executeUpdate:sql,userId]) {
        NSLog(@"删除html数据失败(用户退出)");
    }
}

// MARK: 删除缓存SHop(用户登录退出时删除)
- (void)deleteAllShopWithUserId:(NSString *)userId {
    
    NSString *sql = @"delete from shopAndHistory where userId = ?";
    
    if (![_fmdb executeUpdate:sql,userId]) {
        NSLog(@"删除经销商数据失败(用户退出)");
    }
}

// MARK: 删除经销商
- (void)deleteShop:(NSArray *)shopArray {

    NSString *sql = @"delete from shopAndHistory where listName = ? and name = ? and idOrYear = ? and addressOrPicurl = ? and telePhoneOrSize = ? and userId = ?";
    if (![_fmdb executeUpdate:sql,shopArray[0],shopArray[1],shopArray[2],shopArray[3],shopArray[4],shopArray[5]]) {
        NSLog(@"删除数据失败");
    }
}

// MARK: 判断数据是否存在收藏
- (BOOL)isSelectedWithArray:(NSArray *)array {
    
    if ([array[0] isEqualToString:@"经销商"]) {
        
        NSString *sql = @"select * from shopAndHistory where name = ? and idOrYear = ? and addressOrPicurl = ? and telePhoneOrSize = ? and userId = ?";
        FMResultSet *result = [_fmdb executeQuery:sql,array[1],array[2],array[3],array[4],array[5]];
        return [result next];
    }else {
        
        NSString *sql = @"select * from car where carName = ? and carYear = ? and listname = ? and titleName = ? and resourceId = ? and userId = ?";
        FMResultSet *result = [_fmdb executeQuery:sql,array[0],array[1],array[2],array[3],array[4],array[5]];
        return [result next];
    }
}
@end
