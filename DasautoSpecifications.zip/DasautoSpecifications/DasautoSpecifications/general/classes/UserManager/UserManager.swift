/*
*  filename: UserManager.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/20.
*  copyright: bdcluster
*/

class UserManager {
    
    var registerUser: RegisterUser!
    var userLogin: UserLogin!
    var userLogout: UserLogout!
    var favouriteSynchronize: FavouriteSynchronize!
    var favouriteQuery: FavouriteQuery!
    
    var registerUserId: Int!
    var userModel: UserModel!
    var isLogout: Bool!
    var synFavouriteSuccess: Bool!
    var resourceIdList: [Int]!
    
    init() {
        
        registerUser = RegisterUser()
        userLogin = UserLogin()
        userLogout = UserLogout()
        favouriteSynchronize = FavouriteSynchronize()
        favouriteQuery = FavouriteQuery()
    }
    
    /* 
     * 如果注册成功则返回
     * respCode string
     * memo string
     * userId string
     */
    func startRegisterUser(completionHandler: (
        responseObject: AnyObject!, error: NSError!) -> Void) {
        
        registerUser.registerUserInformation ({ (operation, responseObject, error) -> Void in
            
            //responseObject 在responseObject中取userId
            //registerUserId = responseObject...
            completionHandler(responseObject: responseObject, error: error)
        })
    }
    
    //如果注册成功后返回用户信息
    func getUserId() -> Int {
        
        return registerUserId
    }
    
    /*
    * 如果登录成功则返回
    * respCode string
    * memo string
    * token string
    * user: User(用户对象)
    */
    func startUserLogin(completionHandler: (
        responseObject: AnyObject!, error: NSError!) -> Void) {
            
            userLogin.userStartLogin ({ (operation, responseObject, error) -> Void in
                
                //responseObject 在responseObject中取user
                //userModel = responseObject...
                completionHandler(responseObject: responseObject, error: error)
            })
    }
    
    // MARK: 登录成功后返回User对象
    func getUserModel() -> UserModel {
        
        return userModel
    }
    
    /*
     * respCode string
     * memo string
     */
    func startUserLogOut(completionHandler: (
        responseObject: AnyObject!, error: NSError!) -> Void) {
            
            userLogout.userStartLogOut ({ (operation, responseObject, error) -> Void in
                
                //responseObject 在responseObject中取登出状态
                //isLogout = responseObject...
                completionHandler(responseObject: responseObject, error: error)
            })
    }
    
    //确认是否登出
    func isSuccessLogout() -> Bool {
        
        return isLogout
    }
    
    /*
    * respCode string
    * memo string
    */
    func startSynFaouriteList(completionHandler: (
        responseObject: AnyObject!, error: NSError!) -> Void) {
            
            favouriteSynchronize.synFaouriteList { (operation, responseObject, error) -> Void in
                
                //responseObject 在responseObject中取收藏同步状态
                //synFavouriteSuccess = responseObject...
                completionHandler(responseObject: responseObject, error: error)
            }
    }
    
    //确认收藏是否成功
    func isSuccessSynFavourite() -> Bool {
        
        return synFavouriteSuccess
    }
    
    /*
    * respCode string
    * memo string
    * resourceIdList [Int]
    */
    func startQueryFaouriteList(completionHandler: (
        responseObject: AnyObject!, error: NSError!) -> Void) {
            
            favouriteQuery.queryFaouriteList { (operation, responseObject, error) -> Void in
                
                //responseObject 在responseObject中取收藏列表状态
                //resourceIdList = responseObject...
                completionHandler(responseObject: responseObject, error: error)
            }
    }
    
    //返回收藏列表
    func getResourceIdList() -> [Int] {
        
        return resourceIdList
    }
}
