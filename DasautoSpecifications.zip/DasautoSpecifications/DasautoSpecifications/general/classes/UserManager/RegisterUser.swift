/*
*  filename: RegisterUser.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/20.
*  copyright: bdcluster
*/

class RegisterUser {
    
    //参数
    var params: [String: AnyObject]!
    
    var operationManager: AFOperationManager!
    
    init() {
        
        params = [String: AnyObject]()
    }
    
    //Mark: 配置参数
    func configureParams(
        userName: String,
        password: String,
        nickname: String,
        devicePlatform: Int,
        platformVersion: String) {
            
            params = [
                "userName": userName,
                "password": password,
                "nickname": nickname,
                "devicePlatform": devicePlatform,
                "platformVersion": platformVersion]
    }
    
    //Mark: 注册用户信息
    func registerUserInformation(completionHandler: (operation: AFHTTPRequestOperation!,
        responseObject: AnyObject!, error: NSError!) -> Void) {
        
        operationManager.startPostOperation(kUserRegister,
            param: params,
            withToken:false,
            success: { (
                operation: AFHTTPRequestOperation!,
                responseObject: AnyObject!) -> Void in
            
            completionHandler(operation: operation, responseObject: responseObject, error: nil)
        }) { (
            operation: AFHTTPRequestOperation!,
            error: NSError!) -> Void in
            
            completionHandler(operation: operation, responseObject: nil, error: error)
        }
    }
}