/*
*  filename: UserLogout.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/20.
*  copyright: bdcluster
*/

class UserLogout {
    
    var params: [String: AnyObject]!
    
    var operationManager: AFOperationManager!
    
    init() {
        
        params = [String: AnyObject]()
    }
    
    func configureParams(token: String) {
        
        params = [
            "token": token]
    }
    
    // MARK:用户开始等出
    func userStartLogOut(completionHandler: (operation: AFHTTPRequestOperation!,
        responseObject: AnyObject!, error: NSError!) -> Void) {
            
            operationManager.startPostOperation(kUserLogout,
                param: params,
                withToken:false,
                success: { (
                    operation: AFHTTPRequestOperation!,
                    responseObject: AnyObject!) -> Void in
                    
                    completionHandler(operation: operation, responseObject: responseObject, error: nil)
                }) { (
                    operation: AFHTTPRequestOperation!,
                    error: NSError!) -> Void in
                    
                    completionHandler(operation: operation, responseObject: nil, error: error)
            }
    }
}
