/*
*  filename: UserLogin.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/20.
*  copyright: bdcluster
*/

class UserLogin {

    //Mark: 参数
    var params: [String: AnyObject]!
    
    var operationManager: AFOperationManager!
    
    init() {
        
        params = [String: AnyObject]()
    }
    
    func configureParams(
        userName: String,
        password: String) {
        
        params = [
            "userName": userName,
            "password": password]
    }
    
    //MARK: 用户开始登录
    func userStartLogin(completionHandler: (operation: AFHTTPRequestOperation!,
        responseObject: AnyObject!, error: NSError!) -> Void) {
        
            operationManager.startPostOperation(kUserLogin,
                param: params,
                withToken:false,
                success: { (
                    operation: AFHTTPRequestOperation!,
                    responseObject: AnyObject!) -> Void in
                    
                    completionHandler(operation: operation, responseObject: responseObject, error: nil)
                }) { (
                    operation: AFHTTPRequestOperation!,
                    error: NSError!) -> Void in
                    
                    completionHandler(operation: operation, responseObject: nil, error: error)
            }
    }
}
