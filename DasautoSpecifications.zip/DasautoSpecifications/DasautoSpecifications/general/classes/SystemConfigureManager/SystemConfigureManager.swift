/*
*  filename: SystemConfigureManager.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/13.
*  copyright: bdcluster

*  update: 
   author: chenggang
   date time: 15/1/20
   /实现清理缓存功能
*/

import AudioToolbox
import AVFoundation

class SystemConfigureManager {
    
    /*
     * Property
     */
    //Mark: 音效开关状态
    var isOpen: Bool = false
    var catchSize: String = "0"
    var player: AVAudioPlayer!
    
    class var sharedInstance : SystemConfigureManager {
        
        struct Static {
            static var onceToken : dispatch_once_t = 0
            static var instance : SystemConfigureManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = SystemConfigureManager()
        }
        return Static.instance!
    }
    
    //获取NSUserDefaults
    func getUserDefaults() -> NSUserDefaults {
        
        return NSUserDefaults.standardUserDefaults()
    }
    
    func getDevicePlatform() -> Int {
        
        let platform = UIDevice().userInterfaceIdiom
        return platform.rawValue
    }
    
    func getDeviceSystemVersion() -> String {
        
        return UIDevice().systemVersion
    }
    
    func querySoundEffectSwitch() -> Bool {
        
        isOpen = self.getUserDefaults().boolForKey("kSoundEffectSwitchIsOpen")
        return isOpen
    }
    
    func setSoundEffectSwitch(open: Bool) {
        
        self.getUserDefaults().setBool(open, forKey: "kSoundEffectSwitchIsOpen")
    }
    
    // MARK: 打开音效
    func makeSoundEffect() {
        
        if self.querySoundEffectSwitch() {
            
            self.playSound()
        }
    }
    
    func playSound() {
        
        let audioPath = NSBundle.mainBundle().pathForResource("button_music", ofType: "mp3")
        let audioPathURL = NSURL(fileURLWithPath: audioPath!)
        var systemSoundId: SystemSoundID = 0
        AudioServicesCreateSystemSoundID(audioPathURL, &systemSoundId)
        AudioServicesPlaySystemSound(systemSoundId)
    }
    
    func playBackgroundSing() { //播放空音频
        
        let audioPath = NSBundle.mainBundle().pathForResource("silent", ofType: "mp3")
        let audioPathURL = NSURL(fileURLWithPath: audioPath!)
        
        let data = NSData(contentsOfURL: audioPathURL)
        
        do  {
            player = try AVAudioPlayer(data: data!)
            player.prepareToPlay()
            player.numberOfLoops = 0;
            player.play()
        } catch let error as NSError {
            print(error)
        }
    }
    
    // MARK: 返回缓存路径
    func getCachePath() -> String {
        
        let array: NSArray = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.CachesDirectory, NSSearchPathDomainMask.UserDomainMask, true)
        let cachPath: String = array[0] as! String
        return cachPath
    }
    
    // MARK: 返回视频路径
    func getDownloadVideoPath() -> String {
        
        let videoPath = NSHomeDirectory().stringByAppendingString("/Documents/").stringByAppendingString("video")
        return videoPath
    }
    
    // MARK: 获取缓存大小
    func getCacheSize() -> CGFloat {
        
        let cachPath = self.getCachePath()
        let fileManager: DSFileManager = DSFileManager.sharedInstance
        let cachSize = fileManager.folderSizeAtPath(cachPath)
        
        let strin = String(format: "%.2f", cachSize)
        let number: NSNumber = NSNumberFormatter().numberFromString(strin)!
        
        return CGFloat(number)
    }
    
    // MARK: 获取视频大小
    func getVideoSize() -> CGFloat {
        
        let videoPath = self.getDownloadVideoPath()
        let fileManager: DSFileManager = DSFileManager.sharedInstance
        let videoSize = fileManager.folderSizeAtPath(videoPath)
        
        let strin = String(format: "%.2f", videoSize)
        let number: NSNumber = NSNumberFormatter().numberFromString(strin)!
        
        return CGFloat(number)
    }
    
    // MARK: 删除缓存
    func clearCache() {
        
        let cachPath = self.getCachePath()
        self.clearAction(cachPath)
    }
    
    // MARK: 删除视频
    func clearVideo() {
        
        let videoPath = self.getDownloadVideoPath()
        self.clearAction(videoPath)
    }
    
    func getLawStatement() {
        
    }

    // MARK: 删除路径下的文件夹
    func clearAction(pathString: String) -> Void {

      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () -> Void in

        
            if NSFileManager.defaultManager().fileExistsAtPath(pathString) {
                
                Logger.info("\(pathString)")
                var error: NSError?
                do {
                    try NSFileManager.defaultManager().removeItemAtPath(pathString)
                } catch let error1 as NSError {
                    error = error1
                }
            }
        })
    }
}
