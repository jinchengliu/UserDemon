/*
*  filename: ZipPackage.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/9.
*  copyright: bdcluster
*/

//import Foundation

class XmlParaser {
    
    func parseXmlFile(path: String) -> [NSObject: AnyObject]{
        
        let data: NSData = NSData(contentsOfFile: path)!
        var error: NSError?
        var temp: [NSObject: AnyObject]!
        do {
            temp = try XMLReader.dictionaryForXMLData(data)
        } catch let error1 as NSError {
            error = error1
            temp = nil
        }
        Logger.info(temp.description)
        Logger.info("解压的车型信息")
        return temp
    }
}