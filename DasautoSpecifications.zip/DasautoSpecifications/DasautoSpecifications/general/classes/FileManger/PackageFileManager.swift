/*
*  filename: PackageFileManager.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/8.
*  copyright: bdcluster
*/
class PackageFileManager: NSObject,SSZipArchiveDelegate,RFDownloadManagerDelegate, NSCoding {
    
    //下载列表中正在操作的zip包(可能在不同的车型包之前切换)
    var currentZipPackage: ZipPackage!
    var rootFile: DasAutoDirectory!
    var packages: [ZipPackage] = [ZipPackage]()
    
    var dataArray: NSMutableArray = []
    
    class var sharedInstance : PackageFileManager {
        
        struct Static {
            
            static var onceToken : dispatch_once_t = 0
            static var instance : PackageFileManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            
            Static.instance = NSKeyedUnarchiver.unarchiveObjectWithFile(PackageFileManagerFilePath) as? PackageFileManager
            if Static.instance == nil {
                Static.instance = PackageFileManager()
                Logger.debug("未读取到数据")
            }else {
                Logger.debug("读取到数据")
            }
        }
        return Static.instance!
    }
    
    override init() {
        
        super.init()
    }
    
    // MARK:
    // MARK: NSCoder
    /**
    *  解档
    */
    required init?(coder aDecoder: NSCoder) {
        
        self.currentZipPackage = aDecoder.decodeObjectForKey("CurrentZipPackage") as? ZipPackage
        self.rootFile = aDecoder.decodeObjectForKey("RootFile") as? DasAutoDirectory
        self.packages = aDecoder.decodeObjectForKey("Packages") as! [ZipPackage]
    }
    
    /**
    *  归档
    */
    func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(self.currentZipPackage, forKey: "CurrentZipPackage")
        aCoder.encodeObject(self.rootFile, forKey: "RootFile")
        aCoder.encodeObject(self.packages, forKey: "Packages")
    }
    
    // MARK:
    // MARK: DownLoad Zip________SessionManager
    /**
    *  下载zip
    */
    func downloadZipPackage(zip: ZipPackage,completion: (response: NSURLResponse!, error: NSError!) -> Void) -> NSURLSessionDownloadTask {

        zip.state = .downloading
        zip.stateDescription = zip.state.description()
      
        let downloadTask = AFOperationManager.sharedInstance.downloadOperation(zip.urlString, zipNameString: zip.zipName ,completion: { (response, url, error) -> Void in
            
            if error == nil {
                completion(response: response, error: error)
                zip.state = .downloadCompleted
            } else  if (error.code != -999) {
                //code －999代表取消操作  -1015 ----
                zip.state = .downloadError
            }
            
             zip.stateDescription = zip.state.description()
        })

        zip.taskIdentifier = downloadTask.taskIdentifier
        
        return downloadTask
    }
    
    /**
    *  暂停下载
    */
    func pauseDownloadZipPackage(zip: ZipPackage, completion:() -> Void) {
        
        let tasks = AFOperationManager.sharedInstance.sessionManager.tasks
        for downloadTask in tasks {
            if (downloadTask as! NSURLSessionDownloadTask).taskIdentifier == zip.taskIdentifier {
                
                Logger.debug("暂停id:\(zip.taskIdentifier)")
                // 暂停下载---> 保存taskIdentifier  和 data
                downloadTask.cancelByProducingResumeData({ (data: NSData?) -> Void in
                    zip.state = .downloadPause
                    zip.stateDescription = zip.state.description()
                    zip.resumeData = data!
                })
                break
            }
        }
    }
    
    /**
    *  继续下载
    */
    func resumeDownloadZipPackage(zip: ZipPackage,  completion:(response: NSURLResponse!, error: NSError!) -> Void) {
        
        let downloadTask = AFOperationManager.sharedInstance.resumeDownOperation(zip.zipName,resumeData:zip.resumeData, completion: { (response, url, error) -> Void in
            
            if error == nil
            {
                completion(response: response, error: error)
                zip.state = .downloadCompleted
            } else if (error.code != -999) {
                //code －999代表取消操作
                zip.state = .downloadError
            }
            zip.stateDescription = zip.state.description()
        })
        
        zip.taskIdentifier = downloadTask.taskIdentifier
        zip.state = .downloading
        zip.stateDescription = zip.state.description()
    }
    
    // MARK:
    // MARK: Add or Remove Zip
    /**
    *  添加下载包
    */
    func addZipPackage(zip: ZipPackage) {
        
        packages.append(zip)
    }
    
    /**
    *  移除下载包(或者正在下载的)
    */
    func removePackage(zip: ZipPackage) {
        
        for var i = 0; i < packages.count; i++ {
            let zipPackage = packages[i] as ZipPackage
            if zipPackage.zipName == zip.zipName {
                
                packages.removeAtIndex(i)
            }
        }
        //删除下载内容zip包
        DSFileManager.sharedInstance.deleteFileAtDownload(zip.zipName)
        //删除zip包对应的解压包
        DSFileManager.sharedInstance.deleteFileAtDownload(zip.zipNameWithoutsubffix)
        
        // currentZipPackage  --- 表示正在使用的
        if self.currentZipPackage != nil {
            
            if self.currentZipPackage.zipName == zip.zipName {
                // 删除xml归档文件
                DataModel.sharedInstance.deletePackageManager()
                self.rootFile = nil
            }
        }
        DataModel.sharedInstance.savePackageManager()
    }
    
    // MARK:
    // MARK: Open or Unzip Package
    /**
    *  解压车型zip包->SSZipArchiveDelegate(同时会解析XML)
    */
    func unzippingPackage(zip: ZipPackage) {
        
        // 先判断zip状态
        if zip.state != ZipPackageDownloadState.hadUnzip {
            if zip.state ==  ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.unZipping {
               
                // 判断zip包是否已经解压
//                let download = DSFileManager.sharedInstance.getDownloadDirectory()
//                let newFilePath = download.stringByAppendingString("/"+zip.zipNameWithoutsubffix)
//                if NSFileManager.defaultManager().fileExistsAtPath(newFilePath) ==  false {
//                    do {
//                        try NSFileManager.defaultManager().createDirectoryAtPath(newFilePath, withIntermediateDirectories: true, attributes: nil)
//                    } catch _ {
//                    }
                if zip.state ==  ZipPackageDownloadState.downloadCompleted {
                    zip.state = ZipPackageDownloadState.unZipping
                    DataModel.sharedInstance.savePackageManager()
                }
//                    SSZipArchive.unzipFileAtPath(DSFileManager.sharedInstance.getFileAtDownload(zip.zipName), toDestination: newFilePath, delegate: self)
//                }
                
                let download = DSFileManager.sharedInstance.getDownloadDirectory()
                let newFilePath = download.stringByAppendingString("/"+zip.zipNameWithoutsubffix)
                do {
                    try NSFileManager.defaultManager().createDirectoryAtPath(newFilePath, withIntermediateDirectories: true, attributes: nil)
                } catch _ {
                }
                SSZipArchive.unzipFileAtPath(DSFileManager.sharedInstance.getFileAtDownload(zip.zipName), toDestination: newFilePath, delegate: self)
            }
        }else {
            self.openZipPackage(zip)
        }
    }
    
    /**
     *  获取解压包里面的xml文件, 解析xml
     */
    func openZipPackage(zip: ZipPackage) {
        
        rootFile = self.getDasAutoFile(self.parseZipPackage(zip))
        for zip in packages {
            if zip.state == ZipPackageDownloadState.isUsing {
                zip.state = ZipPackageDownloadState.hadUnzip
            }
        }
        zip.state = ZipPackageDownloadState.isUsing
        currentZipPackage = zip
        DataModel.sharedInstance.savePackageManager()
    }
    
    // MARK:
    // MARK: 解析车型包,返回车型内容数组 (该方法可能耗时,请结合GCD使用)
    func parseZipPackage(zip: ZipPackage) -> [NSObject: AnyObject]{
        
        let path = DSFileManager.sharedInstance.getFileAtDownload(zip.zipNameWithoutsubffix).stringByAppendingString("/category.xml")
        let xmlParaser = XmlParaser()
        
        return xmlParaser.parseXmlFile(path)
    }
    
    // MARK:
    // MARK: SSZipArchiveDelegate
    func zipArchiveDidUnzipArchiveAtPath(path: String!, zipInfo: unz_global_info, unzippedPath: String!) {
        
        Logger.info("++++++解压成功")
        let arr = unzippedPath.componentsSeparatedByString(downloadDirectory+"/")
        for zip in packages {
            if zip.zipNameWithoutsubffix == arr[1] {
                zip.state = ZipPackageDownloadState.hadUnzip
                DataModel.sharedInstance.savePackageManager()
                self.openZipPackage(zip)
                return
            }
        }
    }
    
    // MARK: 
    // MARK: Get DasAutoFile
    func getDasAutoFile(data: [NSObject: AnyObject]) -> DasAutoDirectory {
        
        let root = DasAutoDirectory(name: "大众凌度汽车说明书", root: nil)
        root.fileId = 0
        let rootDict = data["root"] as! [NSString: AnyObject]
        
        self.analysisAndAddQuickGuid(rootDict, root: root)                       // fileId = 1
        self.analysisAndAddRepairMaintenance(rootDict, root: root)               // fileId = 2
        self.analysisAndAddUserManual(rootDict, root: root)
        self.analysisAndAddIntellectualTechnology(rootDict, root: root)
        self.analysisAndAddLoveCarClass(rootDict, root: root)
        self.analysisAndAddEmergencyService(rootDict, root: root)
        self.analysisAndAddHotSpots(rootDict, root: root)
        self.analysisAndAddOtherRes(rootDict, root: root)
        self.analysisAndAddHtmlInterPic(rootDict, root: root)
        
        return root
    }
    
    /**
    *  解析和添加 快速指南
    */
    func analysisAndAddQuickGuid(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        var quickGuideDict = rootDict["quick-guide"] as! [NSString: AnyObject]
        let quickGuideName = quickGuideDict["name"] as! String
        let quickGuideDirectory = DasAutoDirectory(name: quickGuideName, root: root)
        root.add(quickGuideDirectory)
        
        var quickGuideResource = quickGuideDict["resource"] as! [AnyObject]
        for var i = 0; i < quickGuideResource.count; i++ {
            
            let dict = quickGuideResource[i] as! [NSObject: AnyObject]
            let leaf = self.makeLeaf(dict, root: root, isAddToArray: true)
            quickGuideDirectory.add(leaf)
        }
    }
    
    /**
    *  解析和添加 维护保养
    */
    func analysisAndAddRepairMaintenance(rootDict:[NSString: AnyObject],root:DasAutoFile){

        var repairMaintenanceDict = rootDict["repair-maintenance"] as! [NSString: AnyObject]
        let repairMaintenanceName = repairMaintenanceDict["name"] as! String
        let repairMaintenanceDirectory = DasAutoDirectory(name: repairMaintenanceName, root: root)
        root.add(repairMaintenanceDirectory)
        
        let repairMaintenanceResource: AnyObject? = repairMaintenanceDict["category"]
        if repairMaintenanceResource is [NSObject : AnyObject] {
        
            var repairMaintenanceResource = repairMaintenanceResource as! [NSObject : AnyObject]
            let name = repairMaintenanceResource["name"] as! String
            let directory: DasAutoDirectory = DasAutoDirectory(name: name, root: root)
            repairMaintenanceDirectory.add(directory)
            
            let resource: AnyObject? = repairMaintenanceResource["resource"]
            if resource is [NSObject : AnyObject] {
                
                let resource = resource as! [NSObject : AnyObject]
                let leaf = self.makeLeaf(resource, root: root, isAddToArray: true)
                directory.add(leaf)
            }else if resource is [AnyObject] {
                
                var resource = resource as! [AnyObject]
                for var i = 0; i < resource.count; i++ {
                    
                    let resourceDict = resource[i] as! [NSObject:AnyObject]
                    let leaf = self.makeLeaf(resourceDict, root: root, isAddToArray: true)
                    directory.add(leaf)
                }
            }
        }else if repairMaintenanceResource is [AnyObject] {
            
            for var i = 0; i < repairMaintenanceResource?.count; i++ {
                
                var repairMaintenanceResource = repairMaintenanceResource as! [AnyObject]
                var dict = repairMaintenanceResource[i] as! [NSObject : AnyObject]
                let name = dict["name"] as! String
                let directory: DasAutoDirectory = DasAutoDirectory(name: name, root: root)
                repairMaintenanceDirectory.add(directory)
                
                let resource: AnyObject? = dict["resource"]
                if resource is [AnyObject] {
                    
                    var resource = resource as! [AnyObject]
                    for var i = 0; i < resource.count; i++ {
                        
                        let resourceDict = resource[i] as! [NSObject:AnyObject]
                        let leaf = self.makeLeaf(resourceDict, root: root, isAddToArray: true)
                        directory.add(leaf)
                    }
                }else if resource is [NSObject: AnyObject] {
                    
                    let resource = resource as! [NSObject:AnyObject]
                    let leaf = self.makeLeaf(resource, root: root, isAddToArray: true)
                    directory.add(leaf)
                }
            }
        }
    }
    
    /**
     *  解析添加 用户手册
     */
    func analysisAndAddUserManual(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        // 第一级
        var userManualDict = rootDict["user-manual"] as! [NSString: AnyObject]
        var userManualCategoryArray = userManualDict["category"] as! [AnyObject]
        let userManualCategoryName = userManualDict["name"] as! String
        let directory: DasAutoDirectory = DasAutoDirectory(name: userManualCategoryName, root: root)
        root.add(directory)
        
        for var i = 0; i < userManualCategoryArray.count; i++ {
            
            // 第二级
            var categoryDict = userManualCategoryArray[i] as! [NSString : AnyObject]
            let categoryArray: AnyObject? = categoryDict["category"]
            let categoryName = categoryDict["name"] as! String
            let dict: DasAutoDirectory = DasAutoDirectory(name: categoryName, root: root)
            directory.add(dict)
            
            if categoryArray is [AnyObject] {
                
                var categoryArray = categoryArray as! [AnyObject]
                for var j = 0; j < categoryArray.count; j++ {
                    
                    var subCategoryDict = categoryArray[j] as! [NSString: AnyObject]
                    let subDirectoryName = subCategoryDict["name"] as! String
                    let subDirectory: DasAutoDirectory = DasAutoDirectory(name: subDirectoryName, root: root)
                    //添加三级菜单
                    dict.add(subDirectory)
                    
                    self.userManualForThirdDirectory(subCategoryDict, root: root, subDirectory: subDirectory)
                }
            }else if categoryArray is [NSObject : AnyObject] {
                
                let categoryArray = categoryArray as! [NSObject : AnyObject]
                var subCategoryDict = categoryArray as! [NSString: AnyObject]
                let subDirectoryName = subCategoryDict["name"] as! String
                let subDirectory: DasAutoDirectory = DasAutoDirectory(name: subDirectoryName, root: root)
                //添加三级菜单
                dict.add(subDirectory)
                
                self.userManualForThirdDirectory(subCategoryDict, root: root, subDirectory: subDirectory)
            }
         }
    }
    
    func userManualForThirdDirectory(subCategoryDict:[NSObject: AnyObject],root: DasAutoFile, subDirectory: DasAutoDirectory) {
        
        let userManualResource: AnyObject? = subCategoryDict["resource"]
        if userManualResource is [NSObject : AnyObject] {
            
            var dict = userManualResource as! [NSObject : AnyObject]
            let directory = self.makeLeafUser(dict, root: root)
            subDirectory.add(directory)
            
            let html: AnyObject? = dict["html5InnerResFolders"]
            if html != nil {
                
                let htmlInnDict = dict["html5InnerResFolders"] as! [String: AnyObject]
                self.userManualForHtml5InnerResFolder(htmlInnDict, root: root, directory: directory)
            }
        }else if userManualResource is [AnyObject] {
            
            var userManualResource = userManualResource as! [AnyObject]
            for var k = 0; k < userManualResource.count; k++ {
                
                var dict = userManualResource[k] as! [NSObject: AnyObject]
                let directory = self.makeLeafUser(dict, root: root)
                subDirectory.add(directory)
                
                let html: AnyObject? = dict["html5InnerResFolders"]
                if html != nil {
                    
                    let htmlInnDict = dict["html5InnerResFolders"] as! [String: AnyObject]
                    self.userManualForHtml5InnerResFolder(htmlInnDict, root: root, directory: directory)
                }
            }
        }
    }
    
    func userManualForHtml5InnerResFolder(htmlInnDict:[NSObject: AnyObject],root: DasAutoFile, directory: DasAutoFileDirectory) {
        
        let htmlInn: AnyObject? = htmlInnDict["html5InnerRes"]
        if htmlInn is [AnyObject] {
            
            var htmlInn = htmlInn as! [AnyObject]
            for var i = 0; i < htmlInn.count; i++ {
                
                let htmlInnDict = htmlInn[i] as! [NSObject:AnyObject]
                let leaf =  self.makeLeaf(htmlInnDict, root: root, isAddToArray: false)
                directory.add(leaf)
            }
        }else if htmlInn is [NSObject:AnyObject]{
            
            let htmlInnDict = htmlInn as! [NSObject:AnyObject]
            let leaf =  self.makeLeaf(htmlInnDict, root: root, isAddToArray: false)
            directory.add(leaf)
        }
    }
    
    /**
     *  解析和添加 视频介绍
     */
    func analysisAndAddIntellectualTechnology(rootDict:[NSString: AnyObject],root:DasAutoFile) {
     
        let videoInfoDict: AnyObject? = rootDict["video-info"]
        if videoInfoDict == nil {
            
            let videoInfoDirectory = DasAutoDirectory(name: "视频介绍", root: root)
            root.add(videoInfoDirectory)
        }else {
            
            var videoInfoDict = rootDict["video-info"] as! [NSString: AnyObject]
            let videoInfoName = "视频介绍"
            let videoInfoDirectory = DasAutoDirectory(name: videoInfoName, root: root)
            root.add(videoInfoDirectory)
            
            let videoInfoCategoryDict: AnyObject? = videoInfoDict["video-info"]
            if videoInfoCategoryDict is [NSObject: AnyObject] {
                
                var videoInfoCategoryDict = videoInfoDict["video-info"] as! [NSObject: AnyObject]
                
                let directory = self.makeLeafUser(videoInfoCategoryDict, root: root)
                var nameDict = videoInfoCategoryDict["name"] as! [String: AnyObject]
                let name = nameDict["text"] as! String
                if name == "更换车轮" {                 // 搜索  不添加更换车轮
                    
                    directory.doNotSearch = "true"
                }
                videoInfoDirectory.add(directory)
                
                let refRes = videoInfoCategoryDict["ref-res"] as? [NSObject: AnyObject]
                if refRes != nil {
                    
                    self.videoInfoForUserManusl(refRes!,root: root,directory: directory)
                }
            }else if videoInfoCategoryDict is [AnyObject] {
                
                for var i = 0; i < videoInfoCategoryDict?.count; i++ {
                    
                    var videoInfoCategoryDict = videoInfoCategoryDict as! [AnyObject]
                    var dict = videoInfoCategoryDict[i] as! [NSObject : AnyObject]
                    
                    let directory = self.makeLeafUser(dict, root: root)
                    var nameDict = dict["name"] as! [String: AnyObject]
                    let name = nameDict["text"] as! String
                    if name == "更换车轮" {                  // 搜索  不添加更换车轮
                        
                        directory.doNotSearch = "true"
                    }
                    videoInfoDirectory.add(directory)
                    
                    let refRes = dict["ref-res"] as? [NSObject: AnyObject]
                    if refRes != nil {
                        
                        self.videoInfoForUserManusl(refRes!,root: root,directory: directory)
                    }
                }
            }
        }
    }
    
    func videoInfoForUserManusl(refRes:[NSObject: AnyObject],root: DasAutoFile, directory: DasAutoFileDirectory) {
        
        let res: AnyObject? = refRes["res"]
        if res is [AnyObject] {
            
            for var i = 0; i < (res as! [AnyObject]).count; i++ {
                
                let dict = (res as! [AnyObject])[i] as! [NSObject:AnyObject]
                let leaf = self.makeLeaf(dict, root: root, isAddToArray: false)
                
                directory.add(leaf)
            }
        }else if res is [NSObject:AnyObject] {
            
            let dict = res as! [NSObject:AnyObject]
            let leaf = self.makeLeaf(dict, root: root, isAddToArray: false)
            
            directory.add(leaf)
        }
    }
    
    /**
     *  解析和添加 爱车课堂
     */
    func analysisAndAddLoveCarClass(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        var carClassDict = rootDict["car-class"] as! [NSString: AnyObject]
        let carClassName = carClassDict["name"] as! String
        let carClassDirectory = DasAutoDirectory(name: carClassName, root: root)
        root.add(carClassDirectory)
        
        let carClassCategoryDict: AnyObject? = carClassDict["resource"]
        if carClassCategoryDict is [NSObject: AnyObject] {
            
            let carClassCategoryDict = carClassCategoryDict as! [NSObject: AnyObject]
            let leaf = self.makeLeaf(carClassCategoryDict, root: root, isAddToArray: true)
            carClassDirectory.add(leaf)
        }else if carClassCategoryDict is [AnyObject] {
            
            for var i = 0; i < carClassCategoryDict?.count; i++ {
                
                var carClassCategoryDict = carClassCategoryDict as! [AnyObject]
                let dict = carClassCategoryDict[i] as! [NSObject : AnyObject]
                let leaf = self.makeLeaf(dict, root: root, isAddToArray: true)
                carClassDirectory.add(leaf)
            }
        }
    }

    /**
     *  解析和添加 应急服务
     */
    func analysisAndAddEmergencyService(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        var emergencyServiceDict = rootDict["emergency-service"] as! [NSString: AnyObject]
        let emergencyServiceName = emergencyServiceDict["name"] as! String
        let emergencyServiceDirectory = DasAutoDirectory(name: emergencyServiceName, root: root)
        root.add(emergencyServiceDirectory)
        
        // 常见问题
        let emergencyServiceCategoryDict: AnyObject? = emergencyServiceDict["category"]
        if emergencyServiceCategoryDict is [NSObject: AnyObject] {
          
            var emergencyServiceCategoryDict = emergencyServiceCategoryDict as! [NSObject: AnyObject]
            let dictName = emergencyServiceCategoryDict["name"] as! String
            let emergencySerDirectory: DasAutoDirectory = DasAutoDirectory(name: dictName, root: root)
            let id = emergencyServiceCategoryDict["id"] as! String
            emergencySerDirectory.resourceId = id
            emergencyServiceDirectory.add(emergencySerDirectory)
            
            var resourceSpotArray = emergencyServiceCategoryDict["resource"] as! [AnyObject]
            for var i = 0; i < resourceSpotArray.count; i++ {
                
                let spotDict = resourceSpotArray[i] as! [NSObject:AnyObject]
                let leaf = self.makeLeaf(spotDict, root: root, isAddToArray: true)
                emergencySerDirectory.add(leaf)
            }
        }else if emergencyServiceCategoryDict is [AnyObject] {
            
            for var i = 0; i < emergencyServiceCategoryDict?.count; i++ {
                
                var emergencyServiceCategoryDict = emergencyServiceCategoryDict as! [AnyObject]
                var dict = emergencyServiceCategoryDict[i] as! [NSObject: AnyObject]
                let name = dict["name"] as! String
                let emergencySerDirectory: DasAutoDirectory = DasAutoDirectory(name: name, root: root)
                
                let id = dict["id"] as! String
                emergencySerDirectory.resourceId = id
                emergencyServiceDirectory.add(emergencySerDirectory)
                
                var resourceSpotArray = dict["resource"] as! [AnyObject]
                for var i = 0; i < resourceSpotArray.count; i++ {
                    
                    let spotDict = resourceSpotArray[i] as! [NSObject:AnyObject]
                    let leaf = self.makeLeaf(spotDict, root: root, isAddToArray: true)
                    emergencySerDirectory.add(leaf)
                }
            }
        }
        
        // 指示灯
        let emergencyServiceResourceDict: AnyObject? = emergencyServiceDict["resource"]
        if emergencyServiceResourceDict is [NSObject: AnyObject] {
            
            let emergencyServiceResourceDict = emergencyServiceResourceDict as! [NSObject: AnyObject]
            let leaf = self.makeLeaf(emergencyServiceResourceDict, root: root, isAddToArray: true)
            emergencyServiceDirectory.add(leaf)
        }else if emergencyServiceResourceDict is [AnyObject] {
            
            for var i = 0; i < emergencyServiceResourceDict?.count; i++ {
                
                var emergencyServiceResourceDict = emergencyServiceResourceDict as! [AnyObject]
                let dict = emergencyServiceResourceDict[i] as! [NSObject : AnyObject]
                let leaf = self.makeLeaf(dict, root: root, isAddToArray: true)
                emergencyServiceDirectory.add(leaf)
            }
        }
    }
    
    /**
     *  解析和添加 热点图
     */
    func analysisAndAddHotSpots(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        var carouselInterDict = rootDict["carousel-inter-pic"] as! [NSString : AnyObject]
        let interPicArray: AnyObject? = carouselInterDict["inter-pic"]
        let interPicName = "热点图片"
        let interPicDirectory = DasAutoDirectory(name: interPicName, root: root)
        root.add(interPicDirectory)
        
        if interPicArray is [AnyObject] {
            
            var interPicArray = interPicArray as! [AnyObject]
            for var i = 0; i < interPicArray.count; i++ {
                
                var dict = interPicArray[i] as! [NSObject : AnyObject]
                let dictName = dict["name"] as! String
                let interPicLeaf: DasAutoDirectory = DasAutoDirectory(name: dictName, root: root)
                
                let isOverview = dict["is-overview"] as! String
                interPicLeaf.isOverview = isOverview
                
                let picFile = dict["pic-file"] as! String
                interPicLeaf.picFile = picFile
                
                let id = dict["id"] as! String
                interPicLeaf.resourceId = id
                interPicDirectory.add(interPicLeaf)
                
                var hotSpotArray = dict["hotspots"] as! [AnyObject]    //---change--
                for var i = 0; i < hotSpotArray.count; i++ {
                   
                   // 生成多个目录（DasAutoDirectory）
                    let hotSpotDirectory: DasAutoDirectory = DasAutoDirectory(name: "热点", root: root)
                    interPicLeaf.add(hotSpotDirectory)
                    
                    let spotDict = hotSpotArray[i] as! NSDictionary

                    var keysArray = spotDict.allKeys
                    
                    for var i = 0 ; i < keysArray.count ; i++
                    {
                        if keysArray[i].isEqualToString("id") {
                            
                            let resourceIdArray: AnyObject? = spotDict["id"]
                            if resourceIdArray is [AnyObject] {
                                
                                var resourceIdArray = resourceIdArray as! [AnyObject]
                                var resourceIdDict = resourceIdArray[1] as! [String: AnyObject]
                                let resourceId = resourceIdDict["text"] as! String
                                hotSpotDirectory.resourceId = resourceId
                            }else if resourceIdArray is [NSString :AnyObject] {
                                
                                var resourceIdArray = resourceIdArray as! [NSString :AnyObject]
                                let resourceId = resourceIdArray["text"] as! String
                                hotSpotDirectory.resourceId = resourceId
                            }
                        }else if keysArray[i].isEqualToString("hotspot-x") {
                            
                            var hotSpotXDict = spotDict["hotspot-x"] as! [String: AnyObject]
                            let hotSpotX = hotSpotXDict["text"] as! String
                            hotSpotDirectory.hotSpotX = hotSpotX
                            
                            
                        }else if keysArray[i].isEqualToString("hotspot-y") {
                            var hotSpotYDic = spotDict["hotspot-y"] as! [String: AnyObject]
                            let hotSpotY = hotSpotYDic["text"] as! String
                            hotSpotDirectory.hotSpotY = hotSpotY
                        }
                    }
                    
                    let detailDic = spotDict["details"] as! NSDictionary
                    let d: AnyObject? = detailDic["detail"]
                    if d is [AnyObject] {
                        
                        let detailDic = detailDic["detail"] as! NSArray
                        for var i = 0; i < detailDic.count; i++     //对应多个
                        {
                            let dic = detailDic[i] as! NSDictionary
                            // 每个目录可以对应多个leaf
                            let leaf = self.makeLeaf(dic as [NSObject : AnyObject], root: root, isAddToArray: false)
                            hotSpotDirectory.add(leaf)
                        }
                    }else if d is [NSObject: AnyObject] {
                        
                        let leaf = self.makeLeaf(d as! [NSObject : AnyObject], root: root, isAddToArray: false)
                        hotSpotDirectory.add(leaf)
                    }
                }
            }
        }else if interPicArray is [NSObject : AnyObject] {
            
            var interPicDict = interPicArray as! [NSObject : AnyObject]
            let dictName = interPicDict["name"] as! String
            let interPicLeaf: DasAutoDirectory = DasAutoDirectory(name: dictName, root: root)
            let picFile = interPicDict["pic-file"] as! String
            interPicLeaf.picFile = picFile
            let isOverview = interPicDict["is-overview"] as! String
            interPicLeaf.isOverview = isOverview
            let id = interPicDict["id"] as! String
            interPicLeaf.resourceId = id
            interPicDirectory.add(interPicLeaf)
            
            var hotSpotArray = interPicDict["hotspots"] as! [AnyObject]
            for var i = 0; i < hotSpotArray.count; i++ {
                
                let spotDict = hotSpotArray[i] as! [NSObject:AnyObject]
                let leaf = self.makeLeaf(spotDict, root: root, isAddToArray: true)
                interPicLeaf.add(leaf)
            }
        }
    }
    
    /**
     *  解析和添加 otherRes
     */
    func analysisAndAddOtherRes(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        var otherResDict = rootDict["otherRes"] as! [NSObject : AnyObject]
        let otherResName = "otherRes"
        let otherResDirectory = DasAutoDirectory(name: otherResName, root: root)
        root.add(otherResDirectory)
        
        let otherResResourceDict: AnyObject? = otherResDict["resource"]
        if otherResResourceDict is [NSObject: AnyObject] {
            
            var otherResResourceDict = otherResResourceDict as! [NSObject: AnyObject]
//            var fileDirectory =  self.makeLeaf(otherResResourceDict, root: root, isAddToArray: false)
            let fileDirectory = self.makeLeafUser(otherResResourceDict, root: root)
            fileDirectory.doNotSearch = "true"
            otherResDirectory.add(fileDirectory)
            
            let resFolders: AnyObject? = otherResResourceDict["html5InnerResFolders"]
            if resFolders != nil {
                
                let htmlInnDict = otherResResourceDict["html5InnerResFolders"] as! [String: AnyObject]
                self.userManualForHtml5InnerResFolder(htmlInnDict, root: root, directory: fileDirectory)
            }
        }else if otherResResourceDict is [AnyObject] {
            
            for var i = 0; i < otherResResourceDict?.count; i++ {
                
                var otherResResourceDict = otherResResourceDict as! [AnyObject]
                var dict = otherResResourceDict[i] as! [NSObject : AnyObject]
                let fileDirectory = self.makeLeafUser(dict, root: root)
                fileDirectory.doNotSearch = "true"
                otherResDirectory.add(fileDirectory)
                let resFolders: AnyObject? = dict["html5InnerResFolders"]
                if resFolders != nil {
                    
                    let htmlInnDict = dict["html5InnerResFolders"] as! [String: AnyObject]
                    self.userManualForHtml5InnerResFolder(htmlInnDict, root: root, directory: fileDirectory)
                }
            }
        }
    }
    
    /**
     *  解析和添加 用户手册热点图
     */
    func analysisAndAddHtmlInterPic(rootDict:[NSString: AnyObject],root:DasAutoFile) {
        
        var carouselInterDict = rootDict["html5-inter-pic"] as! [NSString : AnyObject]
        let interPicArray: AnyObject? = carouselInterDict["inter-pic"]
        let interPicName = "交互图"
        let interPicDirectory = DasAutoDirectory(name: interPicName, root: root)
        root.add(interPicDirectory)
        
        if interPicArray is [AnyObject] {
            
            var interPicArray = interPicArray as! [AnyObject]
            for var i = 0; i < interPicArray.count; i++ {
                
                var dict = interPicArray[i] as! [NSObject : AnyObject]
                let dictName = dict["name"] as! String
                let interPicLeaf: DasAutoDirectory = DasAutoDirectory(name: dictName, root: root)
                
                let isOverview = dict["is-overview"] as! String
                interPicLeaf.isOverview = isOverview
                
                let picFile = dict["pic-file"] as! String
                interPicLeaf.picFile = picFile
                
                let id = dict["id"] as! String
                interPicLeaf.resourceId = id
                interPicDirectory.add(interPicLeaf)
                
                var hotSpotArray = dict["hotspots"] as! [AnyObject]    //---change--
                for var i = 0; i < hotSpotArray.count; i++ {
                    
                    // 生成多个目录（DasAutoDirectory）
                    let hotSpotDirectory: DasAutoDirectory = DasAutoDirectory(name: "热点", root: root)
                    interPicLeaf.add(hotSpotDirectory)
                    
                    let spotDict = hotSpotArray[i] as! NSDictionary
                    
                    var keysArray = spotDict.allKeys
                    
                    for var i = 0 ; i < keysArray.count ; i++
                    {
                        if keysArray[i].isEqualToString("id") {
                            
                            let resourceIdArray: AnyObject? = spotDict["id"]
                            if resourceIdArray is [AnyObject] {
                                
                                var resourceIdArray = resourceIdArray as! [AnyObject]
                                var resourceIdDict = resourceIdArray[1] as! [String: AnyObject]
                                let resourceId = resourceIdDict["text"] as! String
                                hotSpotDirectory.resourceId = resourceId
                            }else if resourceIdArray is [NSString :AnyObject] {
                                
                                var resourceIdArray = resourceIdArray as! [NSString :AnyObject]
                                let resourceId = resourceIdArray["text"] as! String
                                hotSpotDirectory.resourceId = resourceId
                            }
                        }else if keysArray[i].isEqualToString("hotspot-x") {
                            
                            var hotSpotXDict = spotDict["hotspot-x"] as! [String: AnyObject]
                            let hotSpotX = hotSpotXDict["text"] as! String
                            hotSpotDirectory.hotSpotX = hotSpotX
                            
                            
                        }else if keysArray[i].isEqualToString("hotspot-y") {
                            var hotSpotYDic = spotDict["hotspot-y"] as! [String: AnyObject]
                            let hotSpotY = hotSpotYDic["text"] as! String
                            hotSpotDirectory.hotSpotY = hotSpotY
                        }
                    }
                    
                    let detailDic = spotDict["details"] as! NSDictionary
                    let d: AnyObject? = detailDic["detail"]
                    if d is [AnyObject] {
                        
                        let detailDic = detailDic["detail"] as! NSArray
                        for var i = 0; i < detailDic.count; i++     //对应多个
                        {
                            let dic = detailDic[i] as! NSDictionary
                            // 每个目录可以对应多个leaf
                            let leaf = self.makeLeaf(dic as [NSObject : AnyObject], root: root, isAddToArray: false)
                            hotSpotDirectory.add(leaf)
                        }
                    }else if d is [NSObject: AnyObject] {
                        
//                        var nameDict: AnyObject? = dict["name"]
//                        var leaf: DasAutoFileLeaf = DasAutoFileLeaf(name: name, root: root)
                        let leaf = self.makeLeaf(d as! [NSObject : AnyObject], root: root, isAddToArray: false)
                        hotSpotDirectory.add(leaf)
                    }
                }
            }
        }else if interPicArray is [NSObject : AnyObject] {
            
            var interPicDict = interPicArray as! [NSObject : AnyObject]
            let dictName = interPicDict["name"] as! String
            let interPicLeaf: DasAutoDirectory = DasAutoDirectory(name: dictName, root: root)
            let picFile = interPicDict["pic-file"] as! String
            interPicLeaf.picFile = picFile
            let isOverview = interPicDict["is-overview"] as! String
            interPicLeaf.isOverview = isOverview
            let id = interPicDict["id"] as! String
            interPicLeaf.resourceId = id
            interPicDirectory.add(interPicLeaf)
            
            var hotSpotArray = interPicDict["hotspots"] as! [AnyObject]
            for var i = 0; i < hotSpotArray.count; i++ {
                
                let spotDict = hotSpotArray[i] as! [NSObject:AnyObject]
                let leaf = self.makeLeaf(spotDict, root: root, isAddToArray: true)
                interPicLeaf.add(leaf)
            }
        }
    }

    // MARK:通用配置叶子节点方法
    func makeLeaf(dict: [NSObject: AnyObject], root: DasAutoFile,isAddToArray: Bool) -> DasAutoFileLeaf{
        
        let dictionary = dict as NSDictionary
        let keysArray = dictionary.allKeys as NSArray
        
        let nameDict: AnyObject? = dict["name"]
        var name: String!
        if nameDict != nil {
            
            var nameDict = dict["name"] as! [String: AnyObject]
            name = nameDict["text"] as! String
        }else {
            
            name = "没有简介"
        }
        let leaf: DasAutoFileLeaf = DasAutoFileLeaf(name: name, root: root)
        
        for var i = 0 ; i < keysArray.count ; i++ {
            
            if keysArray[i].isEqualToString("id") {
                
                let resourceIdArray: AnyObject? = dict["id"]
                if resourceIdArray is [AnyObject] {
                   
                    var resourceIdArray = resourceIdArray as! [AnyObject]
                    var resourceIdDict = resourceIdArray[1] as! [String: AnyObject]
                    let resourceId = resourceIdDict["text"] as! String
                    leaf.resourceId = resourceId
                }else if resourceIdArray is [NSString :AnyObject] {
                    
                    var resourceIdArray = resourceIdArray as! [NSString :AnyObject]
                    let resourceId = resourceIdArray["text"] as! String
                    leaf.resourceId = resourceId
                }
            }else if keysArray[i].isEqualToString("name") {
                
                var descDict = dict["name"] as! [String: AnyObject]
                let desc = descDict["text"] as! String
                leaf.desc = desc
            }else if keysArray[i].isEqualToString("video-file") {
                
                var videoFileDict = dict["video-file"] as! [String: AnyObject]
                let videoFile = videoFileDict["text"] as! String
                leaf.videoFile = videoFile
            }else if keysArray[i].isEqualToString("pic-file") {
                
                var picFileDict = dict["pic-file"] as! [String: AnyObject]
                let picFile = picFileDict["text"] as! String
                leaf.picFile = picFile
            }else if keysArray[i].isEqualToString("resource-id") {
                
                var refResourceIdDict = dict["resource-id"] as! [String: AnyObject]
                let refResourceId = refResourceIdDict["text"] as! String
                leaf.refResourceId = refResourceId
            }else if keysArray[i].isEqualToString("res_index") {
                
                var resIndexDict = dict["res_index"] as! [String: AnyObject]
                let resIndex = resIndexDict["text"] as! String
                leaf.resIndex = resIndex
            }else if keysArray[i].isEqualToString("detailPicUrl") {
                var detailPicUrlDic = dict["detailPicUrl"] as! [String: AnyObject]
                let detailPicUrl = detailPicUrlDic["text"] as! String
                leaf.detailPicUrl = detailPicUrl
            }else if keysArray[i].isEqualToString("detailDesc") {
                
                let detailDescDic:AnyObject? = dict["detailDesc"]
                if detailDescDic != nil
                {
                    var detailDescDic = dict["detailDesc"] as! [String: AnyObject]
                   if detailDescDic["text"] != nil
                    {
                      let detailDesc = detailDescDic["text"] as! String
                      leaf.detailDesc = detailDesc
                    }
                }
            }
            else if keysArray[i].isEqualToString("play-time") {
                var playTimeDic = dict["play-time"] as! [String: AnyObject]
                let playTime = playTimeDic["text"] as! String
                leaf.playTime = playTime
            }else if keysArray[i].isEqualToString("hotspot-x") {
                
                var hotSpotXDict = dict["hotspot-x"] as! [String: AnyObject]
                let hotSpotX = hotSpotXDict["text"] as! String
                leaf.hotSpotX = hotSpotX
            }else if keysArray[i].isEqualToString("hotspot-y") {
                var hotSpotYDic = dict["hotspot-y"] as! [String: AnyObject]
                let hotSpotY = hotSpotYDic["text"] as! String
                leaf.hotSpotY = hotSpotY
            }
        }
        if isAddToArray == false {
            
            leaf.doNotSearch = "true"                   // 用来标签不被搜索
        }
        dataArray.addObject(leaf)
        
        return leaf
    }
    
    func makeLeafUser(dict: [NSObject: AnyObject], root: DasAutoFile) -> DasAutoFileDirectory {
        
        let dict = dict as NSDictionary
        let keysArray = dict.allKeys as NSArray
        let nameDict: AnyObject? = dict["name"]
        var name: String!
        if nameDict != nil {
            
            var nameDict = dict["name"] as! [String: AnyObject]
            name = nameDict["text"] as! String
        }
        let directory: DasAutoFileDirectory = DasAutoFileDirectory(name: name, root: root)
        
        for var i = 0 ; i < keysArray.count ; i++ {
            
            if keysArray[i].isEqualToString("id") {
                
                let resourceIdArray: AnyObject? = dict["id"]
                if resourceIdArray is [AnyObject] {
                    
                    var resourceIdArray = resourceIdArray as! [AnyObject]
                    var resourceIdDict = resourceIdArray[1] as! [String: AnyObject]
                    let resourceId = resourceIdDict["text"] as! String
                    directory.resourceId = resourceId
                }else if resourceIdArray is [NSString :AnyObject] {
                    
                    var resourceIdArray = resourceIdArray as! [NSString :AnyObject]
                    let resourceId = resourceIdArray["text"] as! String
                    directory.resourceId = resourceId
                }
            }else if keysArray[i].isEqualToString("name") {
                
                var descDict = dict["name"] as! [String: AnyObject]
                let desc = descDict["text"] as! String
                directory.desc = desc
            }else if keysArray[i].isEqualToString("res_index") {
                
                var resIndexDict = dict["res_index"] as! [String: AnyObject]
                let resIndex = resIndexDict["text"] as! String
                directory.resIndex = resIndex
            }else if keysArray[i].isEqualToString("video-id") {
                
                var videoIdDict = dict["video-id"] as! [String: AnyObject]
                let videoId = videoIdDict["text"] as! String
                directory.videoId = videoId
            }else if keysArray[i].isEqualToString("video-file") {
                
                var videoInfoDict = dict["video-file"] as! [String: AnyObject]
                let videoInfo = videoInfoDict["text"] as! String
                directory.videoFile = videoInfo
            }else if keysArray[i].isEqualToString("pic-file") {
                
                var picFielDict = dict["pic-file"] as! [String: AnyObject]
                let picFile = picFielDict["text"] as! String
                directory.picFile = picFile
            }else if keysArray[i].isEqualToString("play-time") {
                
                var playTimeDict = dict["play-time"] as! [String: AnyObject]
                let playTime = playTimeDict["text"] as! String
                directory.playTime = playTime
            }else if keysArray[i].isEqualToString("inter-pic-id") {
                
                var interPicIdDict = dict["inter-pic-id"] as! [String: AnyObject]
                let interPicId = interPicIdDict["text"] as! String
                directory.interPicId = interPicId
            }
        }
        return directory
    }
    
    /**
    *  去掉所有的叶子节点
    */
    func removeAllLeaf(dasFile: DasAutoFile) {
        
        for var i = 0; i < dasFile.children.count; i++ {
            
            let das = dasFile.children[i] as DasAutoFile
            if das.children.count == 0 {
                
                i = i - 1
                dasFile.remove(das)
            } else {
                
                self.removeAllLeaf(das)
            }
        }
    }
    
    /**
    *  遍历所有的叶子节点
    */
    func getleafFromAllLeaf(dataArray:NSMutableArray, resouceIdArray: NSArray) -> [DasAutoFile] {
        
        var array: [DasAutoFile] = [DasAutoFile]()
        for var i = 0; i < dataArray.count; i++ {
            
            let das = dataArray[i] as! DasAutoFileLeaf
            
            for var j = 0; j < resouceIdArray.count; j++ {
                
                if das.refResourceId == resouceIdArray[j] as? NSString {
                    
                    array.append(das)
                }
            }
        }
        return array
    }
    
}