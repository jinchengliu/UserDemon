/*
*  filename: ZipPackage.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/8.
*  copyright: bdcluster
*/

enum ZipPackageDownloadState {
    
    case downloadStart        // 开始下载
    case downloading          // 下载中
    case downloadPause        // 暂停下载
    case downloadError        // 下载失败
    case downloadCompleted    // 下载完成(但是还没有解压)
    case unZipping            // 正在解压
    case hadUnzip             // 已经解压
    case isUsing              // 应用中
    case None
    
    func description() -> String {
        
        switch self {
            
        case .downloadStart:
            
            return "StartDownload"
        case .downloading:
            
            return "Downloading"
        case .downloadPause:
            
            return "DownloadPause"
        case .downloadError:
            
            return "DownloadError"
        case .downloadCompleted:
            
            return "DownloadCompleted"
        case .hadUnzip:
            
            return "HadUnzip"
        case .unZipping:
            
            return "UnZipping"
        case .isUsing:
            
            return "IsUsing"
        default:
            
            return "None"
        }
    }
    
    static func getStateWithDescription(description: String) -> ZipPackageDownloadState {
        
        if description == "StartDownload" {
            
            return ZipPackageDownloadState.downloadStart
        }else if description == "Downloading" {
            
            return ZipPackageDownloadState.downloading
        }else if description == "DownloadCompleted" {
            
            return ZipPackageDownloadState.downloadCompleted
        }else if description == "DownloadError" {
            
            return ZipPackageDownloadState.downloadError
        }else if description == "DownloadPause" {
            
            return ZipPackageDownloadState.downloadPause
        }else if description == "UnZipping" {
            
            return ZipPackageDownloadState.unZipping
        }else if description == "HadUnzip" {
            
            return ZipPackageDownloadState.hadUnzip
        }else if description == "IsUsing" {
            
            return ZipPackageDownloadState.isUsing
        }else{
            
            return ZipPackageDownloadState.None
        }
    }
}

class ZipPackage: NSObject, NSCoding {
    
    var urlString: String!                // zip下载地址
    var zipName: String!                  // Zip包名字
    var zipNameWithoutsubffix: String!    // Zip包名字没有.zip后缀
    var zipSize: String!                  // Zip包大小
    var carName: String!                  // 车型名称
    var carProductYear: String!           // 年款
    
    var isIncludeVideo: String!           // 是否包含视频
    var carStyle: String!                 // 车型编号
    var picUrl: String!                   // picUrl
//    var hasUNZip = false                  // 后期添加到ZipPackageDownloadState里面
    
    // 下载任务列表
    var taskIdentifier: Int!
    // operation文件大小
    var operationAllSize: Int64!
    var resumeData: NSData!
    
    var state: ZipPackageDownloadState!
    dynamic var stateDescription: String!

    //urlString: 车型包下载的url地址
    init(urlString: String, zipSize: String, carName: String, carProductYear: String, carStyle: String, picUrl: String, isIncludeVideo: String!) {
        
        //super.init()
        self.urlString = urlString
        let index = carProductYear.startIndex.advancedBy(4)
        let newProductYear = carProductYear.substringToIndex(index)    //截取字符串, 获得数字
        
        let convertedString = carName.mutableCopy() as! NSMutableString
        CFStringTransform(convertedString, nil, kCFStringTransformMandarinLatin, false)
        CFStringTransform(convertedString, nil, kCFStringTransformStripDiacritics, false)
        let newConvertedString = convertedString as NSString
        let newCarName = newConvertedString.stringByReplacingOccurrencesOfString(" ", withString: "")
        self.zipName = newCarName + newProductYear + isIncludeVideo + ".zip"
        self.zipNameWithoutsubffix = (self.zipName as NSString).stringByDeletingPathExtension
        self.isIncludeVideo = isIncludeVideo
        self.carProductYear = carProductYear
        self.carStyle = carStyle
        self.zipSize = zipSize
        self.carName = carName
        self.picUrl = picUrl
        
        state = .downloadStart
        stateDescription = self.state.description()
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        self.zipNameWithoutsubffix = aDecoder.decodeObjectForKey("ZipNameWithoutsubffix") as? String
        self.isIncludeVideo = aDecoder.decodeObjectForKey("isIncludeVideo") as? String
        self.carProductYear = aDecoder.decodeObjectForKey("CarProductYear") as? String
        self.urlString = aDecoder.decodeObjectForKey("ZipURLString") as? String
        self.carStyle = aDecoder.decodeObjectForKey("CarStyle") as? String
        self.zipName = aDecoder.decodeObjectForKey("ZipName") as? String
        self.zipSize = aDecoder.decodeObjectForKey("ZipSize") as? String
        self.carName = aDecoder.decodeObjectForKey("CarName") as? String
        self.picUrl = aDecoder.decodeObjectForKey("picUrl") as? String
        
        self.state = ZipPackageDownloadState.getStateWithDescription(aDecoder.decodeObjectForKey("ZipPackageDownloadState") as! String)
        if aDecoder.decodeObjectForKey("TaskIdentifier") != nil {
            self.taskIdentifier = Int((aDecoder.decodeObjectForKey("TaskIdentifier") as! NSNumber).integerValue)
        }
        if aDecoder.decodeObjectForKey("OperationAllSize") != nil {
            self.operationAllSize = Int64((aDecoder.decodeObjectForKey("OperationAllSize") as! NSNumber).longLongValue)
        }
        self.resumeData = aDecoder.decodeObjectForKey("ResumeData") as? NSData
        self.stateDescription = aDecoder.decodeObjectForKey("StateDescription") as? String
    }
    
    func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(zipNameWithoutsubffix, forKey: "ZipNameWithoutsubffix")
        aCoder.encodeObject(isIncludeVideo, forKey: "isIncludeVideo")
        aCoder.encodeObject(carProductYear, forKey: "CarProductYear")
        aCoder.encodeObject(urlString, forKey: "ZipURLString")
        aCoder.encodeObject(carStyle, forKey: "CarStyle")
        aCoder.encodeObject(zipName, forKey: "ZipName")
        aCoder.encodeObject(zipSize, forKey: "ZipSize")
        aCoder.encodeObject(carName, forKey: "CarName")
        aCoder.encodeObject(picUrl, forKey: "picUrl")
        aCoder.encodeObject(state.description(), forKey: "ZipPackageDownloadState")
        if taskIdentifier != nil {
            aCoder.encodeObject(NSNumber(integer: taskIdentifier), forKey: "TaskIdentifier")
        }
        if operationAllSize != nil {
            
            aCoder.encodeObject(NSNumber(longLong: operationAllSize), forKey: "OperationAllSize")
        }
        aCoder.encodeObject(resumeData, forKey: "ResumeData")
        aCoder.encodeObject(stateDescription, forKey: "StateDescription")
    }
}