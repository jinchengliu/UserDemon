/*
*  filename: DSFileManager.swift
*  product name: DasautoSpecifications
*  
   使用方法:
   var file: DSFileManager = DSFileManager()
   file.createFile("test")
   file.removeFile("test")
   file.isExist("test")
*
*  author: cp
*  date time: 14/12/5.
*  copyright: bdcluster
*/

//import Foundation

class DSFileManager {

    var fileManager: NSFileManager!
    //默认是Documents路径 可修改
    //如果想获取Documents, 直接返回即可
    var documentURL: NSURL!
    var documentPath: String!
    
    class var sharedInstance : DSFileManager {
        
        struct Static {
            static var onceToken : dispatch_once_t = 0
            static var instance : DSFileManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = DSFileManager()
        }
        return Static.instance!
    }
    
    init() {

        fileManager = NSFileManager()
        documentURL = try? fileManager.URLForDirectory(NSSearchPathDirectory.DocumentDirectory, inDomain: NSSearchPathDomainMask.UserDomainMask, appropriateForURL: nil, create: true)
        documentPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0]
    }
    
    /**
    *  创建文件
    */
    func createFile(name: String) -> Bool {
        let url: NSURL! = NSURL(string: name, relativeToURL: documentURL)
        if let path = url.path {
            var success: Bool
            if !fileManager.fileExistsAtPath(path) {
                do {
                    try fileManager.createDirectoryAtURL(url!, withIntermediateDirectories: true, attributes: nil)
                    if name == "video" {
                        // 特殊处理_下载的视频不能备份到iCloud
                        Util.addSkipBackupAttributeToItemAtUrl(url)
                    }
                    success = true
                } catch _ {
                    success = false
                }
            }else {
                success = true
            }
            return success
        }
        else {
            return false
        }
    }
    
    /**
     *  删除
     */
    func removeFileAtDocuments(name: String) -> Bool {
        let url: NSURL! = NSURL(string: name, relativeToURL: documentURL)
        var success: Bool
        do {
            try fileManager.removeItemAtURL(url!)
            success = true
        } catch _ {
            success = false
        }
        return success
    }
    
    /**
    *  重命名
    */
    func rename(src: String, dest: String) -> Bool {
        let srcUrl: NSURL! = NSURL(string: src, relativeToURL: documentURL)
        let destUrl: NSURL! = NSURL(string: dest, relativeToURL: documentURL)
        var success: Bool
        do {
            try fileManager.moveItemAtURL(srcUrl, toURL: destUrl)
            success = true
        } catch let error as NSError {
            NSErrorPointer().memory = error
            success = false
        }
        return success
    }
    
    /**
    *  判断Documents目录下是否存在
    */
    func isExistAtDocument(name: String) -> Bool{
        let url: NSURL! = NSURL(string: name, relativeToURL: documentURL)
        if url.path != nil {
            let success = fileManager.fileExistsAtPath(url.path!)
            return success
        }
        return false
    }
    
    /**
    *  根据路径判断
    */
    func isExist(path: String) -> Bool {
        
        if path.characters.count <= 0 {
            return false
        }
        return fileManager.fileExistsAtPath(path)
    }
    
     /**
     *  文件大小
     */
    func getFileSize(file: String) -> Int64 {
        
        var attribute = try! fileManager.attributesOfItemAtPath(file)
        let sizeNumber = attribute[NSFileSize] as! NSNumber
        return sizeNumber.longLongValue
    }
    
    /**
    *  遍历文件夹获得文件夹大小，返回多少KB
    */
    func folderSizeAtPath(folderPath: String) -> CFloat {
        
        var folderSize: CLongLong = 0
        if self.isExist(folderPath) {
            let array: NSArray! = try? self.subpathsOfDirectoryAtPath(folderPath)
            for var i = 0 ; i < array.count ; i++ {
                let filePath = (folderPath as NSString).stringByAppendingPathComponent(array[i] as! String)
                folderSize += self.getFileSize(filePath)
            }
            
            
            return CFloat(CFloat(folderSize)/1024.0/1024.0)
        }else {
            
            
            return 0
        }
    }
    
    /**
    *  返回缓存路径下所有的
    */
    func subpathsOfDirectoryAtPath(path: String) throws -> [AnyObject] {
        
        return try fileManager.subpathsOfDirectoryAtPath(path)
    }
    
    /**
    *  返回Documents路径
    */
    func getDocumentsDirectory() -> String {
        
        let documents = (NSHomeDirectory() as NSString).stringByAppendingPathComponent("Documents")
        return documents
    }
    
    /**
    *  返回下载目录路径
    */
    func getDownloadDirectory() -> String{
        
        let download = (self.getDocumentsDirectory() as NSString).stringByAppendingPathComponent(downloadDirectory)
        return download
    }
    
    /**
    *  返回下载目录下的文件
    */
    func getFileAtDownload(name: String) -> String {
        
        return (self.getDownloadDirectory() as NSString).stringByAppendingPathComponent(name)
    }
    
    /**
    *  返回图片路径
    */
    func getImagePath(name: String) -> String {
        
        return (self.getDownloadDirectory() as NSString).stringByAppendingPathComponent(name)
    }
    
    /**
    *  在download目录下创建新的文件夹 download/temp/,返回目录
    */
    func createDirectoryAtDownload(directory: String) -> String{
        
        self.createFile((downloadDirectory as NSString).stringByAppendingPathComponent(directory))
        return (self.getDownloadDirectory() as NSString).stringByAppendingPathComponent(directory)
    }
    
    /**
    *  删除download目录下的文件 主要用来删除download下的zip文件
    */
    func deleteFileAtDownload(name: String) -> Bool {
        
        do {
            try fileManager.removeItemAtPath(self.getFileAtDownload(name))
            return true
        } catch _ {
            return false
        }
    }
    
    /**
    *  根据文件路径删除文件
    */
    func deleteFileWith(filePath: String) -> Bool {
        
        do {
            try fileManager.removeItemAtPath(filePath)
            return true
        } catch _ {
            return false
        }
    }
    
    /**
    *  返回说明书正文路径
    */
    func getFilePathAboutSpecification(leaf: DasAutoFile) -> String {
        
        let downloadDir = self.getDownloadDirectory() as NSString
        return downloadDir.stringByAppendingPathComponent(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/html/" + leaf.resIndex + ".html")
    }
    
    /**
    *  返回壁纸图片路径
    */
    func getWallPaperPath(imageName: String) -> String {
        
        let downloadDir = self.getDownloadDirectory() as NSString
        return downloadDir.stringByAppendingPathComponent(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/wallpaper/" + imageName)
    }
    
    /**
    *  返回视频路径
    */
    func getVidoPath(leaf: DasAutoFileLeaf) -> String {
        
        let downloadDir = self.getDownloadDirectory() as NSString
        return downloadDir.stringByAppendingPathComponent(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + leaf.videoFile)
    }
}