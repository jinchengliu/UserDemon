/*
*  filename: ThemeLabel.swift
*  product name: DasautoSpecifications
*
*  author: cp
*  date time: 14/11/25.
*  copyright: bdcluster
*/

import UIKit

class ThemeLabel: UILabel {
    
    var colorName: String!
    var notificationCeter: NSNotificationCenter = NSNotificationCenter.defaultCenter()
    
    required init?(coder aDecoder: NSCoder) {
        
        //fatalError("init(coder:) has not been implemented")
        super.init(coder: aDecoder)
    }
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeColor()
    }
    
    convenience init(colorName: String) {
        
         self.init()
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeColor()
    }
    
    override func awakeFromNib() {
        
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        self.loadThemeColor()
    }
    
    func themeNotification(notification: NSNotification) {
        
        self.loadThemeColor()
    }
    
    func loadThemeColor() {
        if self.colorName != nil {
            
            let textColor: UIColor = ThemeManager.sharedInstance.getColorWithName(fontName: self.colorName)
            self.textColor = textColor
        }
    }
    
    deinit {
        notificationCeter.removeObserver(self, name: kThemeDidChangeNotification, object: nil)
    }
    
}
