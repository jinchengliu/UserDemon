/*
*  filename: ThemeButton.swift
*  product name: DasautoSpecifications
*  使用方法
   先为imageName 属性赋值
   然后调用 loadThemeImage 方法
*  author: cp
*  date time: 14/11/25.
*  copyright: bdcluster
*/

import UIKit

class ThemeButton: UIButton {
    var imageName: String!
    var highligtImageName: String!
    var notificationCeter: NSNotificationCenter = NSNotificationCenter.defaultCenter()

    override init(frame: CGRect) {
        
        super.init(frame: frame)
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeImage()
    }
    
    convenience init(imageName: String, highligtImageName: String) {
        
        self.init()
        self.imageName = imageName
        self.highligtImageName = highligtImageName
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeImage()
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeImage()
    }
    
    func loadThemeImage() {
    
        let themeManager: ThemeManager = ThemeManager.sharedInstance
        if self.imageName != nil {
            let image = themeManager.getThemeImage(self.imageName)
            self.setImage(image, forState: UIControlState.Normal)
        }
        if self.highligtImageName != nil {
            let highligtImage = themeManager.getThemeImage(self.highligtImageName)
            self.setImage(highligtImage, forState: UIControlState.Highlighted)
        }
    }
    
    func themeNotification(notification: NSNotification) {
        
        self.loadThemeImage()
    }
    
    deinit {
        
        notificationCeter.removeObserver(self, name: kThemeDidChangeNotification, object: nil)
    }
}
