/*
*  filename: ThemeImageView.swift
*  product name: DasautoSpecifications
*
*  author: cp
*  date time: 14/11/25.
*  copyright: bdcluster
*/

import UIKit

class ThemeImageView: UIImageView {
    
    var imageName: String!
    var notificationCeter: NSNotificationCenter = NSNotificationCenter.defaultCenter()
    
    override init(frame: CGRect) {

        super.init(frame: frame)
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        //fatalError("init(coder:) has not been implemented")
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        
        notificationCeter.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeImage()
    }
    
    func loadThemeImage() {
        if self.imageName != nil {
            let image: UIImage = ThemeManager.sharedInstance.getThemeImage(self.imageName)
            self.image = image;
        }
    }
    
    func themeNotification(notification: NSNotification) {
        self.loadThemeImage()
    }
    
    deinit {
        notificationCeter.removeObserver(self, name: kThemeDidChangeNotification, object: nil)
    }
}
