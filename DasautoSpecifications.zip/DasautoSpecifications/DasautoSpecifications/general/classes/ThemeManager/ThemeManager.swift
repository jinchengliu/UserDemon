/*
 *  filename: ThemeManager.swift
 *  product name: DasautoSpecifications
 *  var themes = ThemeManager.sharedInstance.themesConfig.allKeys
 *  var theme = themes[i]
 *   ThemeManager.sharedInstance.themeName = theme
 *  NSNotificationCenter.defaultCenter().postNotificationName(kThemeDidChangeNotification, object: nil)
    NSUserDefaults.standardUserDefaults().setObject(theme, forKey: kThemeName)
    NSUserDefaults.standardUserDefaults().synchronize()
 *  author: cp
 *  date time: 14/11/7.
 *  copyright: bdcluster
 */

import Foundation
import UIKit

class ThemeManager {
    
    var themesConfig: NSDictionary!
    var fontConfig: NSDictionary!
    var themeName: String = "default"
    
    class var sharedInstance : ThemeManager {
    
    struct Static {
        
        static var onceToken : dispatch_once_t = 0
        static var instance : ThemeManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = ThemeManager()
        }
        return Static.instance!
    }
    
    func configureInitThemesPath() {
        
        let filePathOptional = NSBundle.mainBundle().pathForResource("theme", ofType: "plist")
        
        if let filePath = filePathOptional {
            themesConfig = NSDictionary(contentsOfFile: filePath)
        }
    }
    
    func configureInitFont() {
        
        let fontConfigPathOptional = NSBundle.mainBundle().pathForResource("fontColor", ofType: "plist")
        if let fontConfigPath = fontConfigPathOptional {
            fontConfig = NSDictionary(contentsOfFile: fontConfigPath)
        }
    }
    
    func getThemePath() -> String {
        
        let resourcePath = NSBundle.mainBundle().resourcePath
        if themeName == "default" && resourcePath != nil {
            return resourcePath!;
        }
        
        //: Skins/blue
        let subPath = themesConfig![themeName] as! String
        let path = resourcePath?.stringByAppendingString("/"+subPath)
        return path!;
    }
    
    func getThemeImage(imageName: String) -> UIImage! {
        
        if themeName == "default" {
            let imageDefault = UIImage(named: imageName)
            return imageDefault!
        }
        
        let path = self.getThemePath() as NSString
        var imagePath = path.stringByAppendingPathComponent(path as String)
        imagePath = imagePath.stringByAppendingString("/"+imageName)
        let image = UIImage(contentsOfFile: imagePath)
        return image;
    }
    
    //颜色值
    func getColorWithName(fontName fontName: String) ->UIColor! {
        
        if fontName.characters.count > 0 {
            let rgb: String = fontConfig![fontName] as! String
            var rgbs: Array = rgb.componentsSeparatedByString(",") as Array
            
            if (rgbs.count == 3) {
                let r: Float = (rgbs[0] as NSString).floatValue;
                let g: Float = (rgbs[1] as NSString).floatValue;
                let b: Float = (rgbs[2] as NSString).floatValue;
                let color:UIColor = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1.0)
                return color;
            }
        }
        
        return nil
    }

}
