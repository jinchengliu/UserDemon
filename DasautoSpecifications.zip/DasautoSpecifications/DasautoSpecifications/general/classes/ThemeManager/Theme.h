/*
 *  filename: DasautoSpecifications.h
 *  product name: DasautoSpecifications
 *
 *  author: cp
 *  date time: 14/11/7.
 *  copyright: bdcluster
 */

#ifndef DasautoSpecifications_Theme_h
#define DasautoSpecifications_Theme_h

//更主题的通知
#define kThemeDidChangeNotification "kThemeDidChangeNotification"
#define kThemeName "kThemeName"

#endif
