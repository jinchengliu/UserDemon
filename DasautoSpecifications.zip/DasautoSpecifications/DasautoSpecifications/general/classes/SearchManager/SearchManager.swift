/*
*  filename: SearchManager.swift
*  product name: DasautoSpecifications
*  author: cp

用法:

var searchManager = SearchManager()
let files = searchManager.searchByKey("检查", fileId: 2)
if files.count > 0 {
    for var i = 0; i < files.count; i++ {
        var dasf = files[i] as DasAutoFile
        Logger.info(dasf.name)
    }
}

*  date time: 14/12/13.
*  copyright: bdcluster
*/

class SearchManager {
    
    //TODO请添加拼音匹配
    var result: [DasAutoFile]!
    var root: DasAutoDirectory!
    var packageManager: PackageFileManager!
    var car4sshops: [Car4sshopModel]!
    
    class var sharedInstance : SearchManager {
        
        struct Static {
            static var onceToken : dispatch_once_t = 0
            static var instance : SearchManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = SearchManager()
        }
        return Static.instance!
    }
    
    init() {
        
        packageManager = PackageFileManager.sharedInstance
        root = packageManager.rootFile
    }
    
    func searchByKey(key: String, fileId: Int) -> [DasAutoFile] {
        
        //找到需要搜索的目录信息
        if fileId != 0 {
            
            root.findFileWithFileId(fileId)
            let targetDasAutoFile = root.result
            targetDasAutoFile.findFileWithKey(key)
            result = root.searchResult
            return result
        }else {
            
            root.findFileWithKeyAndFileId(key, fileId: 4)
            result = root.searchResult
            return result
        }
    }
    
    func searchByKey(key: String, carshops: [Car4sshopModel]) -> [Car4sshopModel]{
        
        return car4sshops
    }
}
