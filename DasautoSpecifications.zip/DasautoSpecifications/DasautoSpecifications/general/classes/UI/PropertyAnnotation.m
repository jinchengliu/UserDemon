//
//  PropertyAnnotation.m
//  houseApp
//
//  Created by mac on 13-6-4.
//  Copyright (c) 2013年 Plusing Advesting Co., LTD. All rights reserved.
//

#import "PropertyAnnotation.h"
#import "NSArray+ExtraMethod.h"

@implementation PropertyAnnotation

- (void)dealloc
{
    //DLog(@"property annotation is deallocating");
}

- (NSString *)title
{
    return self.data[@"name"];
}

- (NSString *)subtitle
{
    return @"";
}

- (NSNumber *)pid
{
    return self.data[@"id"];
}

- (NSString *)name
{
    return self.data[@"name"];
}

- (NSNumber *)minArea
{
    NSArray *types = self.data[@"type_info"];
    NSNumber *minTmp = @(NSIntegerMax);
    for (NSDictionary *type in types) {
        if ([minTmp integerValue] > [type[@"minsquare"] integerValue]) {
            minTmp = type[@"minsquare"];
        }
    }
    return minTmp;
}

- (NSNumber *)maxArea
{
    NSArray *types = self.data[@"type_info"];
    NSNumber *maxTmp = nil;
    for (NSDictionary *type in types) {
        if ([maxTmp integerValue] < [type[@"minsquare"] integerValue]) {
            maxTmp = type[@"maxsquare"];
        }
    }
    return maxTmp;
}

- (CGFloat)averagePrice
{
    NSArray *types = self.data[@"type_info"];
    CGFloat total = 0;
    for (NSDictionary *type in types) {
        total += [type[@"maxtotalprice"] doubleValue] + [type[@"mintotalprice"] doubleValue];
    }
    CGFloat avg = total / [types count] / 2;
    return avg;
}

- (BOOL)discount
{
    return [self.data[@"is_discount"] boolValue];
}

- (NSUInteger)typeCount
{
    return [[self.data objectForKey:@"type_info"] count];
}

- (NSUInteger)status
{
    return [[self.data objectForKey:@"status"]integerValue];
}

- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate
{
    _coordinate = newCoordinate;
}

- (NSDictionary *)getTypeDetailWithIndex:(NSInteger)index
{
    if ([self.data isKindOfClass:[NSDictionary class]]) {
        return [[self.data objectForKey:@"type_info"] objectSafetyAtIndex:index];
    }
    return nil;
}

@end
