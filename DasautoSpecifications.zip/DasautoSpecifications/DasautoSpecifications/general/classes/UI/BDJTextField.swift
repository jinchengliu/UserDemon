
//
//  BDJTextField.swift
//  House
//
//  Created by chenpan on 14-10-15.
//  Copyright (c) 2014年 bojia. All rights reserved.
//

import UIKit

class BDJTextField: UITextField {

    override init() {
        super.init()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.leftViewMode = UITextFieldViewMode.Always
    }
    
    override func leftViewRectForBounds(bounds: CGRect) -> CGRect {
        var rect = CGRect(x: 5, y: 3, width: 20, height: 20)
        return rect
    }
    
    override func textRectForBounds(bounds: CGRect) -> CGRect {
        return CGRectInset(bounds , 30 , 0 );
    }
    
    override func editingRectForBounds(bounds: CGRect) -> CGRect {
        return CGRectInset(bounds , 30 , 0 );
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect)
    {
        // Drawing code
    }
    */
    
    /*
    //开始编辑closure
    func shouldBeginEditing(() ->BDJTextField) {
        
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        println("textFieldShouldBeginEditing")
        
        return true
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        println("textFieldDidBeginEditing")
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        println("textFieldShouldEndEditing")
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        println("textFieldDidEndEditing")
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        println("===============================")
        println("string = \(string),textField = \(textField.text),rangeString = \(NSStringFromRange(range))")
        
        var str:String = "ASDSDFAS"
        var range = NSMakeRange(0,1)
        //        func NSMakeRange(loc: Int, len: Int) -> NSRange
        //
        //        func NSMaxRange(range: NSRange) -> Int
        //
        //        func NSLocationInRange(loc: Int, range: NSRange) -> Bool
        //
        //        func NSEqualRanges(range1: NSRange, range2: NSRange) -> Bool
        //
        //        func NSUnionRange(range1: NSRange, range2: NSRange) -> NSRange
        //        func NSIntersectionRange(range1: NSRange, range2: NSRange) -> NSRange
        //        func NSStringFromRange(range: NSRange) -> String!
        //        func NSRangeFromString(aString: String!) -> NSRange
        
        println("===============================")
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        println("textFieldShouldReturn")
        return true
    }
    */
}
