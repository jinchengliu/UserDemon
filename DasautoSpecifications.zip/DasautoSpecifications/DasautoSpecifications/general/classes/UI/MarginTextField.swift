//
//  MarginTextField.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-10.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class MarginTextField: UITextField {

    var leftMargin: CGFloat?
    
    override init(frame: CGRect) {
        
        leftMargin = 0.0
        super.init(frame: frame)
    }

    required init?(coder aDecoder: NSCoder) {
        
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:private function
    override func textRectForBounds(bounds: CGRect) -> CGRect {
        var newBounds: CGRect = bounds
        newBounds.origin.x = bounds.origin.x + leftMargin!
        newBounds.size.width = bounds.size.width - 2*leftMargin!
        return newBounds
    }
    
    override func editingRectForBounds(bounds: CGRect) -> CGRect {
        var newBounds: CGRect = bounds
        newBounds.origin.x = bounds.origin.x + leftMargin!
        newBounds.size.width = bounds.size.width - 2*leftMargin!
        return newBounds
    }
    
    // MARK:public function
    func setLeftMargin(leftMargin: CGFloat) {
        
        self.leftMargin = leftMargin
    }
}