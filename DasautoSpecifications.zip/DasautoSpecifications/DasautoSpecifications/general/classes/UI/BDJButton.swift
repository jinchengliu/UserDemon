//
//  BDJButton.swift
//  House
//
//  Created by chenpan on 14-10-16.
//  Copyright (c) 2014年 bojia. All rights reserved.
//

import UIKit

class BDJButton: UIButton {

    override func titleRectForContentRect(contentRect: CGRect) -> CGRect {
        return CGRectInset(contentRect, CGRectGetWidth(contentRect)/3, CGRectGetHeight(contentRect)/5)
    }
    
    
    
//    override func imageRectForContentRect(contentRect: CGRect) -> CGRect {
//        
//    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect)
    {
        // Drawing code
    }
    */

}
