//
//  PropertyAnnotation.h
//  houseApp
//
//  Created by mac on 13-6-4.
//  Copyright (c) 2013年 Plusing Advesting Co., LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface PropertyAnnotation : NSObject <MKAnnotation>

@property (nonatomic, strong) id data;
@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;

- (NSNumber *)pid;
- (NSString *)name;
- (NSNumber *)minArea;
- (NSNumber *)maxArea;
- (CGFloat)averagePrice;
- (BOOL)discount;
- (NSUInteger)typeCount;
- (NSUInteger)status;

- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate;
- (NSDictionary *)getTypeDetailWithIndex:(NSInteger)index;

@end
