//
//  PlusBordLabel.swift
//  House
//
//  Created by 博加 on 14-10-19.
//  Copyright (c) 2014年 bojia. All rights reserved.
//

import UIKit

class PlusBordLabel: UILabel {

    override func awakeFromNib() {
        //super.init(coder: aDecoder)
        self.layer.cornerRadius = 3
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor(red: 141/255.0, green: 141/255.0, blue: 141/255.0, alpha: 1.0).CGColor
        self.textColor = UIColor(red: 141/255.0, green: 141/255.0, blue: 141/255.0, alpha: 1.0)
        self.textAlignment = NSTextAlignment.Center
        self.font = UIFont.systemFontOfSize(9)
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
        override func drawRect(rect: CGRect)
        {
        // Drawing code
        }
    */

}