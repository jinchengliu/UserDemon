#import "RADataObject.h"


@implementation RADataObject


- (id)initWithName:(NSString *)name describe:(NSString *)describe resouceId:(NSString *)resouceId fileId:(NSNumber *)fileId children:(NSMutableArray *)children
{
  self = [super init];
  if (self) {
      self.resouceId = resouceId;
      self.fielId = fileId;
      self.describe = describe;
    self.children = children;
    self.name = name;
  }
  return self;
}

+ (id)dataObjectWithName:(NSString *)name describe:(NSString *)describe resouceId:(NSString *)resouceId fileId:(NSNumber *)fileId children:(NSMutableArray *)children
{
  return [[self alloc] initWithName:name describe:describe resouceId:resouceId fileId:fileId children:children];
}

@end