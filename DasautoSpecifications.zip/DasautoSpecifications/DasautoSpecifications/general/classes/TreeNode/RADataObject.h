#import <Foundation/Foundation.h>
//#import "DasautoSpecifications-swift.h"

@class DasAutoFile;
@interface RADataObject : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *resouceId;
@property (strong, nonatomic) NSString *describe;
@property (strong, nonatomic) NSNumber *fielId;
@property (strong, nonatomic) NSMutableArray *children;
@property (strong, nonatomic) DasAutoFile *dasautoFile;


//- (id)initWithName:(NSString *)name describe:(NSString *)describe childrens:(NSMutableArray *)array;
//
//+ (id)dataObjectWithName:(NSString *)name describe:(NSString *)describe childrens:(NSMutableArray *)childrens;

- (id)initWithName:(NSString *)name describe:(NSString *)describe resouceId:(NSString *)resouceId fileId:(NSNumber *)fileId children:(NSMutableArray *)children;

+ (id)dataObjectWithName:(NSString *)name describe:(NSString *)describe resouceId:(NSString *)resouceId fileId:(NSNumber *)fileId children:(NSMutableArray *)children;

@end
