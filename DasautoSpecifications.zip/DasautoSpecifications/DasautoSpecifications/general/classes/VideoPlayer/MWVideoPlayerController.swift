/*
*  filename: MWVideoPlayerController.swift
*  product name: DasautoSpecifications
*
*  author: wangrui
*  date time: 14/12/09.
*  copyright: bdcluster
*/

import UIKit
import AVFoundation

class MWVideoPlayerController: UIViewController, UIGestureRecognizerDelegate {

    var player: AVPlayer?
    var playerItem: AVPlayerItem?
    var playerLayer: AVPlayerLayer?
    
    var controlView: UIView?
    var playOrPasueButton: UIButton?
    var progressTimer: NSTimer?
    var progressLabel: UILabel?
    var allTimeLabel: UILabel?
    var progessSlider: UISlider?
    var enLargeButton: UIButton?
    var volumeImageView: UIButton?
    
    var navigationBar: UIView!
    var titleLabel: UILabel!
    var backButton: UIButton!
    var volumeSliderView: UIView!
    
    var sliderValue: Float = 40
    var hiddenStatus = false
    var hasAppearSlider: Bool = false
    var isControlViewAppear: Bool?
    var autoHideTimer: NSTimer?
    
    var fileUrl: NSURL?                              //创建此视图控制器之前需要对fileUrl赋值
    var allTime: String!                             // 播放时长
    var videoUrl: String!                            // 无视频版的下载视频的url
    var titleName: String!
    var userPause: Bool = false
    
    var currentZip: ZipPackage!                      // 正在使用的zip包
    var videoDowloadUrl:String?                     //无视频版视频下载地址
    var progrossHUD: MBProgressHUD!
    var percent:String!
    var downloadTask: NSURLSessionDownloadTask!
    var index:String!
    var endDisplayButton:UIButton!
    var whetherPortrate:Bool!                       //是否竖屏
    
    //有视频版
    var dataArray: NSArray!
    var leaf: DasAutoFile!
    var listName: String!
    
    //无视频版
    var listArray:NSArray!
    var endDisplayButtonHasAppear = false
    var buttonMaintain:CGMutablePathRef!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "home", name: UIApplicationWillResignActiveNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "active", name: UIApplicationDidBecomeActiveNotification, object: nil)
        self.view.backgroundColor = UIColor.blackColor()
        currentZip = PackageFileManager.sharedInstance.currentZipPackage
        if fileUrl != nil {
            
            self.configureAVPlayerLayer()
            self.addControlView()
            
        }else {    //无视频版
            
            if AFNetworkReachabilityManager.sharedManager().reachable == true {
                
                let manger:DSFileManager = DSFileManager.sharedInstance
                let videoFile = manger.getDocumentsDirectory().stringByAppendingString("/video/")
                let path:String = videoFile.stringByAppendingString(currentZip.zipNameWithoutsubffix + "video" + index + ".mp4")
                
                if manger.isExist(path) { //  如果已下载
                    fileUrl = NSURL.fileURLWithPath(path)
                    
                    self.configureAVPlayerLayer()
                    self.addControlView()
                    self.player?.play()
                    
                }else {
                    if self.videoDowloadUrl != nil {
                        if self.downloadTask == nil {
                            self.addControlView()
                            self.downloadVideoFromNetwork()
                        }
                    }
                }
            }else {
                // 网络不可用
            }
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        if videoUrl == nil {
        
            self.player?.play()
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.hidden = true
        self.navigationController?.interactivePopGestureRecognizer!.enabled = false
        if whetherPortrate != true {
            
            UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        self.endDisplayButtonDisAppear()
        UIApplication.sharedApplication().setStatusBarHidden(false, withAnimation: UIStatusBarAnimation.None)
        self.navigationController?.navigationBar.hidden = false
        self.navigationItem.hidesBackButton = true
        if videoUrl == nil {
            
            self.pause()
        }
        if self.videoDowloadUrl != nil {
            self.pause()
        }
        //---change--
        if self.downloadTask != nil {
            self.downloadTask.cancelByProducingResumeData({ (data:NSData?) -> Void in
                
                let userDefalut = NSUserDefaults.standardUserDefaults()
                userDefalut.setObject(data, forKey: self.videoDowloadUrl!)
                userDefalut.synchronize()
                
            })
        }
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidDisappear(animated)
        
        if let _ = self.navigationController?.viewControllers {
            
            return
        }
        
        NSNotificationCenter.defaultCenter().removeObserver(self)
        self.player?.replaceCurrentItemWithPlayerItem(nil)
        self.playerItem = nil
        self.playerLayer = nil
        self.player = nil
        self.progressTimer?.invalidate()
        self.progressTimer = nil
        self.autoHideTimer?.invalidate()
        self.autoHideTimer = nil
        Logger.info("disappear  MV")
    }
    
    deinit {
        
        NSNotificationCenter.defaultCenter().removeObserver(self)
        self.player?.replaceCurrentItemWithPlayerItem(nil)
        self.playerItem = nil
        self.playerLayer = nil
        self.player = nil
        self.progressTimer?.invalidate()
        self.progressTimer = nil
        self.autoHideTimer?.invalidate()
        self.autoHideTimer = nil
        Logger.info("deinit  MV")
    }
    
    override func prefersStatusBarHidden() -> Bool {
        
        return hiddenStatus
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func shouldAutorotate() -> Bool {
        
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        
        return UIInterfaceOrientationMask.Portrait
    }
    
    func home() {
        
        self.pause()
    }
    
    func active() {
        
        self.play()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  configurePlayer
    */
    func configurePlayer() {
        self.playerItem = AVPlayerItem(URL: fileUrl!)
        self.player = AVPlayer(playerItem: self.playerItem!)
        self.playerLayer = AVPlayerLayer(player: self.player)
        self.playerLayer?.videoGravity = AVLayerVideoGravityResizeAspect
        // 播放视图的大小
        self.playerLayer?.frame = CGRectMake(0, CGRectGetHeight(UIScreen.mainScreen().bounds) / 3, CGRectGetWidth(UIScreen.mainScreen().bounds), CGRectGetHeight(UIScreen.mainScreen().bounds) / 3)
        self.playerLayer?.backgroundColor = UIColor.blackColor().CGColor
        self.view.layer.addSublayer(self.playerLayer!)
    }
    
    /**
    *  配置播放器
    */
    func configureAVPlayerLayer() {

        self.configurePlayer()
        self.progressTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("progressTimerHanlder:"), userInfo: nil, repeats: true)
        
        let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("tapGestureHanlder:"))
        self.view.addGestureRecognizer(tapGesture)
    }
    
    /**
    *  配置控制视图
    */
    func addControlView() {
        
        if self.controlView == nil {
            
            self.controlView = UIView(frame: CGRectMake(0, CGRectGetHeight(self.view.bounds)-60, CGRectGetWidth(self.view.bounds), 60))
            self.controlView?.backgroundColor = UIColor(red:0.86, green:0.86, blue:0.86, alpha:1).colorWithAlphaComponent(0.5)
            self.view.addSubview(self.controlView!)
            
            let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("controlViewClicked:"))
            self.controlView!.addGestureRecognizer(tapGesture)
            
            let panGesture:UIPanGestureRecognizer = UIPanGestureRecognizer(target: self, action: Selector("controlViewPaned:"))
            self.controlView!.addGestureRecognizer(panGesture)
    
            // 播放、暂停按钮
            self.playOrPasueButton = UIButton(frame: CGRectMake(-5, 0, 60, 60))
//            self.playOrPasueButton?.hitTestEdgeInsets = UIEdgeInsetsMake(-20, -20, -20, 0)
            self.playOrPasueButton?.imageEdgeInsets = UIEdgeInsetsMake(20, 20, 20, 20)
            self.playOrPasueButton?.setImage(UIImage(named: "play"), forState: UIControlState.Normal)
            self.playOrPasueButton?.setImage(UIImage(named: "stop"), forState: UIControlState.Selected)
            self.playOrPasueButton?.addTarget(self, action: Selector("playOrPause:"), forControlEvents: .TouchUpInside)
            self.playOrPasueButton?.selected = true
            self.controlView?.addSubview(self.playOrPasueButton!)
            
            self.volumeImageView = UIButton(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 36 - 10 - 30, 16, 30, 28))
            self.volumeImageView!.setImage(UIImage(named: "sound"), forState: UIControlState.Normal)
            self.volumeImageView!.imageEdgeInsets = UIEdgeInsetsMake(6, 3, 6, 4)
            self.volumeImageView!.addTarget(self, action: "onVolumeImageViewTapGesture:", forControlEvents: UIControlEvents.TouchUpInside)
            self.controlView?.addSubview(self.volumeImageView!)
            
            // 横竖屏按钮
            self.enLargeButton = UIButton(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 36, 15, 30, 30))
            self.enLargeButton?.setImage(UIImage(named: "enLarge"), forState: UIControlState.Normal)
            self.enLargeButton?.imageEdgeInsets = UIEdgeInsetsMake(5, 2, 5, 8)
            self.enLargeButton?.addTarget(self, action: "onEnLargeButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            self.controlView?.addSubview(self.enLargeButton!)
            
            // 进度条
            self.progessSlider = UISlider(frame: CGRectMake(38, 26, CGRectGetWidth(self.view.bounds) - 36 - 33 - 100 - 38, 10))
            self.progessSlider?.minimumTrackTintColor = UIColor.redColor()
            self.progessSlider?.value = 0.0
            self.progessSlider?.thumbRectForBounds(CGRectMake(-20, -20, -20, -20), trackRect: CGRectMake(-20, -20, -20, -20), value: 0)
            self.progessSlider?.setThumbImage(UIImage(named: "roundSLider.png"), forState: .Normal)
            self.progessSlider?.addTarget(self, action: Selector("touchDownProgressSlider:"), forControlEvents: UIControlEvents.TouchDown)
            self.progessSlider?.addTarget(self, action: Selector("dragInsideProgressSlider:"), forControlEvents: UIControlEvents.ValueChanged)
            self.progessSlider?.addTarget(self, action: Selector("TouchUpInsideProgressSlider:"), forControlEvents: UIControlEvents.TouchUpInside)
            self.controlView?.addSubview(self.progessSlider!)
            
            // 显示播放时间label
            self.progressLabel = UILabel(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 36 - 33 - 100, 15,42, 30))
            self.progressLabel?.font = UIFont.systemFontOfSize(15)
            self.progressLabel?.textAlignment = NSTextAlignment.Right
            self.progressLabel?.text = "00:00"
            self.controlView?.addSubview(self.progressLabel!)
            
            // 显示总共时间label
            self.allTimeLabel = UILabel(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 34 - 33 - 60, 15, 50, 30))
            self.allTimeLabel?.font = UIFont.systemFontOfSize(15)
            self.allTimeLabel?.textAlignment = NSTextAlignment.Left
            self.allTimeLabel?.text = "/"  + allTime
            self.controlView?.addSubview(self.allTimeLabel!)
            
            // 导航条
            self.navigationBar = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(UIScreen.mainScreen().bounds), 64))
            self.navigationBar.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.5)
            self.view.addSubview(self.navigationBar)
            
            backButton = UIButton(frame: CGRectMake(0, 20, 44, 44))
            backButton.setImage(UIImage(named: "iconBack" + themeColor), forState: UIControlState.Normal)
            backButton.imageEdgeInsets = UIEdgeInsetsMake(10, 13, 10, 13)
            backButton.addTarget(self, action: "close", forControlEvents: UIControlEvents.TouchUpInside)
            self.navigationBar.addSubview(backButton)
            
            titleLabel = UILabel(frame: CGRectMake(44, 20 + 12, 200, 20))
            titleLabel.text = titleName
            titleLabel.textAlignment = NSTextAlignment.Left
            titleLabel.textColor = UIColor.whiteColor()
            self.navigationBar.addSubview(titleLabel)
            
            whetherPortrate = true
        }
        self.isControlViewAppear = true
        self.autoHideTimer = NSTimer.scheduledTimerWithTimeInterval(8, target: self, selector: Selector("hideControlView"), userInfo: nil, repeats: false)
    }
    
/**
 *  配置音量slider
 */
func configureSlider() {
    
    if hiddenStatus == false {
        
        volumeSliderView = UIView(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 36 - 10 - 20 - 40, CGRectGetHeight(self.view.bounds) - 100, 80, 40))
        volumeSliderView.transform = CGAffineTransformMakeRotation(CGFloat(-M_PI_2))
    }else {
        
        volumeSliderView = UIView(frame: CGRectMake( 40, CGRectGetHeight(self.view.bounds) - 40 - 46, 80, 40))
    }
    
    let volumeSlider = UISlider(frame: CGRectMake(0, 5, 80, 40))
    volumeSlider.setThumbImage(UIImage(named: "roundSLider.png"), forState: .Normal)
    volumeSlider.minimumTrackTintColor = UIColor.redColor()
    volumeSlider.userInteractionEnabled = true
    volumeSlider.minimumValue = 0
    volumeSlider.maximumValue = 80
    volumeSlider.value = sliderValue
    volumeSlider.addTarget(self, action: "volumeSliderValueChanged:", forControlEvents: UIControlEvents.ValueChanged)
    self.volumeSliderView.addSubview(volumeSlider)
    self.view.addSubview(volumeSliderView)
}
    
    /**
     *  create endDisplayButton
     */
    func createButton()
    {
        self.pause()
        
        if endDisplayButtonHasAppear == false {
            endDisplayButton = UIButton(frame: CGRectMake(0,0,self.view.frame.size.width,44))
            endDisplayButtonHasAppear = true
            
            self.view.addSubview(endDisplayButton)
            self.view.bringSubviewToFront(endDisplayButton)
        }
        endDisplayButton.center = self.view.center
        endDisplayButton.tag = 222
        endDisplayButton.backgroundColor = UIColor.whiteColor()
        endDisplayButton.setImage(UIImage(named: "rightArrow" + themeColor), forState: UIControlState.Normal)
        endDisplayButton.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        endDisplayButton.addTarget(self, action: "clickAction:", forControlEvents: UIControlEvents.TouchUpInside)
        endDisplayButton.titleEdgeInsets = UIEdgeInsetsMake(3, 0, 3, 18)
        endDisplayButton.imageEdgeInsets = UIEdgeInsetsMake(8, self.view.frame.size.width-12, 8, 8)
        endDisplayButton.titleLabel?.font = UIFont.systemFontOfSize(15)
        endDisplayButton.titleLabel?.textAlignment = NSTextAlignment.Right
        endDisplayButton.titleLabel?.numberOfLines = 0
        endDisplayButton.userInteractionEnabled = true
        
        if listArray != nil {
            if listArray.count > 0 {
                let dict = listArray[0] as! NSDictionary
                endDisplayButton.setTitle(dict.objectForKey("name") as? String, forState: UIControlState.Normal)
            }
        }else {
            endDisplayButton.setTitle(leaf.name, forState: UIControlState.Normal)
        }
        
        if whetherPortrate == false {
            endDisplayButton.transform = CGAffineTransformMakeRotation(CGFloat(M_PI_2))
            let rect:CGRect = CGRectMake(0, 0, 44,self.view.frame.size.height)
            endDisplayButton.frame = rect
            endDisplayButton.center = self.view.center
            
            endDisplayButton.imageEdgeInsets = UIEdgeInsetsMake(8, self.view.frame.size.height-12, 8, 8)
        }
    }
    
    /**
    *  显示控制视图
    */
    func showControlView() {
        
        if self.controlView != nil {
            
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                
                self.controlView!.alpha = 1
                self.navigationBar.alpha = 1
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.isControlViewAppear = true
                        self.autoHideTimer = NSTimer.scheduledTimerWithTimeInterval(8, target: self, selector: Selector("hideControlView"), userInfo: nil, repeats: false)
                    }
            })
        }
    }
    
    /**
    *  隐藏控制视图
    */
    func hideControlView() {
        
        if self.controlView != nil {
            
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                
                self.controlView!.alpha = 0
                if self.hasAppearSlider == true {
                    
                    self.volumeSliderView.removeFromSuperview()
                }
                self.navigationBar.alpha = 0
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.isControlViewAppear = false
                        self.hasAppearSlider = false
                    }
            })
        }
    }
    
    /**
     *  移除endDisplayButton
     */
    func endDisplayButtonDisAppear() {
        
        if endDisplayButtonHasAppear == true {
            
            self.endDisplayButton.removeFromSuperview()
            self.endDisplayButton = nil
            
            endDisplayButtonHasAppear = false
        }
    }
    
    // MARK:
    // MARK: refresh Frame
    /**
    *  竖屏时UI的frame
    */
    func setUIFrameAtPoritate() {
        
        whetherPortrate = true
        
        // 状态栏
        hiddenStatus = false
        self.setNeedsStatusBarAppearanceUpdate()
        
        UIApplication.sharedApplication().setStatusBarHidden(false, withAnimation: UIStatusBarAnimation.None)
        
        let w = CGRectGetWidth(self.view.bounds)
        let h = CGRectGetHeight(self.view.bounds)
        
        self.playerLayer?.transform = CATransform3DIdentity
        self.playerLayer?.transform = CATransform3DMakeRotation(CGFloat(M_PI * 2), 0, 0, 1)
        self.playerLayer?.frame = CGRectMake(0, h / 3, w, h / 3)
        
        self.navigationBar.transform = CGAffineTransformIdentity
        self.navigationBar.transform = CGAffineTransformRotate(self.navigationBar.transform, CGFloat(0))
        self.navigationBar.frame = CGRectMake(0, 0, w, 64)
            
        self.controlView?.transform = CGAffineTransformIdentity
        self.controlView?.transform = CGAffineTransformRotate(self.controlView!.transform, CGFloat(0))
        self.controlView?.frame = CGRectMake(0, h - 60, w, 60)

        self.volumeImageView?.frame = CGRectMake(w - 36 - 10 - 30, 16, 30, 28)
        
        self.enLargeButton?.frame = CGRectMake(w - 36, 15, 30, 30)
        self.enLargeButton?.setImage(UIImage(named: "enLarge"), forState: UIControlState.Normal)
//        self.enLargeButton?.selected = false
        self.progessSlider?.frame = CGRectMake(38, 26, w - 36 - 33 - 100 - 38, 10)
        self.progressLabel?.frame = CGRectMake(w - 36 - 33 - 100, 15,42, 30)
        self.allTimeLabel?.frame = CGRectMake(w - 34 - 33 - 60, 15, 50, 30)
        self.titleLabel.frame = CGRectMake(40, 20 + 12, 200, 20)
        self.backButton.frame = CGRectMake(0, 20, 44, 44)
        self.controlView?.userInteractionEnabled = true
        self.playOrPasueButton?.frame = CGRectMake(-5, 0, 60, 60)
        
        if endDisplayButton != nil {
            self.endDisplayButton.transform = CGAffineTransformIdentity
            let rect:CGRect = CGRectMake(0, 0, w,44)
            endDisplayButton.frame = rect
            endDisplayButton.center = self.view.center
            endDisplayButton.imageEdgeInsets = UIEdgeInsetsMake(8, w - 12, 8, 8)
        }
    }
    
    /**
    *  横屏时UI的frame
    */
    func setUIFrameAtLandRight() {
        
        whetherPortrate = false
        // 状态栏
        hiddenStatus = true
        self.setNeedsStatusBarAppearanceUpdate()
        
        UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
        
        self.playerLayer?.transform = CATransform3DIdentity
        self.playerLayer?.transform = CATransform3DMakeRotation(CGFloat(M_PI_2), 0, 0, 1)
        self.playerLayer?.frame = CGRectMake(0, 0, CGRectGetWidth(UIScreen.mainScreen().bounds),CGRectGetHeight(UIScreen.mainScreen().bounds))
        
        let w = CGRectGetWidth(self.view.bounds)
        let h = CGRectGetHeight(self.view.bounds)
        self.controlView?.frame = CGRectMake(30 - h / 2, h / 2 - 30, h, 60)
        self.controlView?.transform = CGAffineTransformIdentity
        self.controlView?.transform = CGAffineTransformRotate(self.controlView!.transform, CGFloat(M_PI_2))
        self.progessSlider?.thumbRectForBounds(CGRectMake(-50, -50, -50, -50), trackRect: CGRectMake(-50, -50, -50, -50), value: 0)
        
        
        self.navigationBar.frame = CGRectMake(w - h / 2 - 22, h / 2 - 22, h, 44)
        self.navigationBar?.transform = CGAffineTransformRotate(self.navigationBar!.transform, CGFloat(M_PI_2))

        self.volumeImageView?.frame = CGRectMake(h - 36 - 10 - 30, 16, 30, 28)
        
        self.enLargeButton?.frame = CGRectMake(h - 36-3, 15, 30, 30)
        self.enLargeButton?.setImage(UIImage(named: "enSmall"), forState: UIControlState.Normal)
        self.progessSlider?.frame = CGRectMake(48, 26, h - 36 - 33 - 100 - 38-10, 10)
        self.playOrPasueButton!.frame = CGRectMake(5, 0, 60, 60)
        
        self.progressLabel?.frame = CGRectMake(h - 36 - 33 - 100, 15,42, 30)
        self.allTimeLabel?.frame = CGRectMake(h - 34 - 33 - 60, 15, 50, 30)
        self.titleLabel.frame = CGRectMake(40, 12, 200, 20)
        self.backButton.frame = CGRectMake(0, 0, 44, 44)
        

        if endDisplayButton != nil {
            endDisplayButton.transform = CGAffineTransformMakeRotation(CGFloat(M_PI_2))
            let rect:CGRect = CGRectMake(0, 0, 44,h)
            endDisplayButton.frame = rect
            endDisplayButton.center = self.view.center
            
            endDisplayButton.imageEdgeInsets = UIEdgeInsetsMake(8,CGRectGetHeight(UIScreen.mainScreen().bounds)-12, 8, 8)
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    func close(){
        
        self.endDisplayButtonDisAppear()
        self.navigationController?.popViewControllerAnimated(true)
    }
    /**
    *  选中横竖屏
    */
    func onEnLargeButtonClicked(sender: UIButton) {
     
        if hasAppearSlider == true {
            
            self.volumeSliderView.removeFromSuperview()
            hasAppearSlider = false
        }
        if sender.selected == false {
            
            self.setUIFrameAtLandRight()
        }else {
            
            self.setUIFrameAtPoritate()
        }
        sender.selected = !sender.selected
    }
    
    /**
    *  选中播放或者暂停
    */
    func playOrPause(sender: UIButton) {
        
        if sender.selected {
            
            //暂停
            self.pause()
        }else {
            
            //播放
            self.play()
        }
    }
    
    /**
     *  播放
     */
    func play() {
        
        if self.player != nil {
            
            self.playOrPasueButton?.selected = true
            self.player?.play()
            self.progressTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("progressTimerHanlder:"), userInfo: nil, repeats: true)
            
            if endDisplayButtonHasAppear == true {
                
                self.endDisplayButtonDisAppear()
                
                self.playerLayer?.removeFromSuperlayer()
                
                self.player?.replaceCurrentItemWithPlayerItem(nil)
                self.playerItem = nil
                self.playerLayer = nil
                self.player = nil
                
                self.configurePlayer()       //重新生成
                self.view.layer.insertSublayer(self.playerLayer!, atIndex: 0)
                
                if whetherPortrate == false {
                    self.playerLayer?.transform = CATransform3DMakeRotation(CGFloat(M_PI_2), 0, 0, 1)
                    self.playerLayer?.frame = CGRectMake(0, 0, CGRectGetWidth(UIScreen.mainScreen().bounds),CGRectGetHeight(UIScreen.mainScreen().bounds))
                    
                }
                self.play()
            }
        }
    }
    
    /**
     *  暂停
     */
    func pause() {
        
        if self.player != nil {
            
            self.playOrPasueButton?.selected = false
            self.player?.pause()
            self.progressTimer?.invalidate()
            
            if self.view.window != nil {
                
                self.endDisplayButtonDisAppear()
            }
        }
        Logger.info("pause  MV")
    }
    
    /**
     *  选中 endDisplayButton
     */
    func clickAction(sender:UIButton) {
        
        self.endDisplayButtonDisAppear()
        self .configureLeaf()
    }
    
    /**
    *  选中音量
    */
    func onVolumeImageViewTapGesture(sender:UIButton)
    {
        if hasAppearSlider == true {
            
            volumeSliderView.removeFromSuperview()
        }else {
            
            self.configureSlider()
        }
        hasAppearSlider = !hasAppearSlider
    }
    
    // MARK:
    // MARK: TapGesture
    /**
    *  点击页面
    */
    func tapGestureHanlder(tapGesture: UITapGestureRecognizer) {
        
        if self.isControlViewAppear == true {
            
            self.hideControlView()
        }else {
            
            if self.autoHideTimer != nil {
                
                self.autoHideTimer?.invalidate()
            }
            self.showControlView()
        }
    }
    
    // MARK:
    // MARK: UISlider Actions
    /**
    *  音量slider的响应事件
    */
    func volumeSliderValueChanged(slider: UISlider) {
        
        self.autoHideTimer?.fireDate = NSDate(timeIntervalSinceNow: 2) as NSDate
        sliderValue = slider.value
        self.player?.volume = sliderValue / 80
    }
    
    /**
    *  视频播放进度条方法
    */
    func touchDownProgressSlider(sender: UISlider) {
        
        self.autoHideTimer?.invalidate()
    }
    
    func dragInsideProgressSlider(sender: UISlider) {
        
        let duration: CMTime = self.player!.currentItem!.duration
        let time = CMTimeGetSeconds(CMTimeMakeWithSeconds(Float64(Float(CMTimeGetSeconds(duration)) * sender.value), Int32(CMTimeGetSeconds(duration))))
        
        self.progressLabel?.text = self.getCurrentTime(time)
    }
    
    func TouchUpInsideProgressSlider(sender: UISlider) {
        
        self.progressTimer?.invalidate()    //---change---
        
        let duration: CMTime = self.player!.currentItem!.duration
        self.player?.currentItem!.seekToTime(CMTimeMakeWithSeconds(Float64(Float(CMTimeGetSeconds(duration)) * sender.value), Int32(CMTimeGetSeconds(duration))))
        self.play()
        self.autoHideTimer = NSTimer.scheduledTimerWithTimeInterval(8, target: self, selector: Selector("hideControlView"), userInfo: nil, repeats: false)
    }
    
    // MARK:
    // MARK: Get Current Time
    func getCurrentTime(time:Float64)->String
    {
        if time < 1.0 {
            
            return "0.0"
        }
        //更改进度显示
        var minute: Float64! = 0
        var extraSecons:Float64! = 0
        
        let c:String = String(format: "%.f", time)
        if Int(c) > 59 {
            minute = time / 60
            extraSecons = time % 60
        }
        
        if minute > 0 {
            
            if minute >= 10 {
                
                if extraSecons >= 10 {
                    return String(format: "%.f", minute) + ":" + String(format: "%.f", extraSecons)
                }else {
                    return String(format: "%.f", minute) + ":" + "0" + String(format: "%.f", extraSecons)
                }
            }else {
                
                //--change--
                let s:String = String(format: "%.f", extraSecons)
                let c:String = String(format: "%.f", time)
                if Int(s) > 9 {
                    if Int(s) == 60 {
                        return "0\(Int(c)!/60)" + ":"+"00"
                    }else {
                        return "0\(Int(c)!/60)" + ":" + String(format: "%.f", extraSecons)
                    }
                }else if extraSecons < 1 {
                    
                    return "0\(Int(c)!/60)" + ":" + "0" + "0"
                }else {
                    return "0\(Int(c)!/60)" + ":" + "0" + String(format: "%.f", extraSecons)
                }
            }
        }else {
            
            //--change--
            let s:String = String(format: "%.f", time)
            if Int(s) > 9 {
                return "00:" + String(format: "%.f", time)
            }else {
                return "00:0" + String(format: "%.f", time)
            }
        }
    }
    
    // MARK:
    // MARK:NSTimerr Hanlder
    func progressTimerHanlder(timer: NSTimer) {
        
        var currentSecond: Float64 = CMTimeGetSeconds(self.player!.currentItem!.currentTime())-1       //--change--
        self.progessSlider?.value = Float( currentSecond / CMTimeGetSeconds(self.player!.currentItem!.duration))
        if currentSecond < 1.0 {
            
            currentSecond = 0.0
        }
        //更改进度显示
        var minute: Float64! = 0
        var extraSecons:Float64! = 0
        
        //---change--
        let c:String = String(format: "%.f", currentSecond)
         if Int(c) > 59 {
            minute = currentSecond / 60
            extraSecons = currentSecond % 60
         }
        
        if minute > 0 {
            
            if minute >= 10 {
                
                if extraSecons >= 10 {
                    
                    self.progressLabel?.text = String(format: "%.f", minute) + ":" + String(format: "%.f", extraSecons)
                }else {
                    
                    self.progressLabel?.text = String(format: "%.f", minute) + ":" + "0" + String(format: "%.f", extraSecons)
                }
            }else {
                
                //--change--
                let s:String = String(format: "%.f", extraSecons)
                let c:String = String(format: "%.f", currentSecond)

                if Int(s) > 9 {
                    if Int(s) == 60 {
                        self.progressLabel?.text = "0\(Int(c)!/60)" + ":"+"00"
                    }else {
                        self.progressLabel?.text = "0\(Int(c)!/60)" + ":" + String(format: "%.f", extraSecons)
                    }
                }else if extraSecons < 1 {
                    
                     self.progressLabel?.text = "0\(Int(c)!/60)" + ":" + "0" + "0"
                 }else {
                   self.progressLabel?.text = "0\(Int(c)!/60)" + ":" + "0" + String(format: "%.f", extraSecons)
                }
            }
        }else {
            
            //--change--
            let s:String = String(format: "%.f", currentSecond)
            
            if Int(s) > 9 {
                 self.progressLabel?.text = "00:" + String(format: "%.f", currentSecond)
            }else {
                self.progressLabel?.text = "00:0" + String(format: "%.f", currentSecond)
            }
        }
        
        Logger.info((self.progressLabel?.text!)!)
        //判断是否播放完毕
       self.judgeWhetherEnd()
    }
    
    func judgeWhetherEnd() {
        //播放完毕-退出
        let aa:AnyObject? = self.progressLabel?.text!.componentsSeparatedByString(":")
        let bb:AnyObject? = allTime.componentsSeparatedByString(":")
        
        var arr1:NSArray
        var arr2:NSArray
        if aa != nil && bb != nil {
            arr1 = aa as! NSArray
            arr2 = bb as! NSArray
        
            if Int((arr1[0] as! String)) != nil {
                if Int((arr1[0] as! String))! == Int((arr2[0] as! String))! {
                    
                    if (Int((arr1[1] as! String))!-Int((arr2[1] as! String))! == 0) || (Int((arr1[1] as! String))!-Int((arr2[1] as! String))! == 1) || (Int((arr1[1] as! String))!-Int((arr2[1] as! String))! == -1) {
                        self.createButton()
                    }else {
                        self.endDisplayButtonDisAppear()
                    }
                }else {
                    self.endDisplayButtonDisAppear()
                }
            }
        }
    }
    
    // MARK:
    // MARK: LoadData
    /**
    *   网络下载视频
    */
    func downloadVideoFromNetwork() {
        
        if self.progrossHUD == nil {
            self.progrossHUD = MBProgressHUD()
            self.view.insertSubview(progrossHUD, aboveSubview: self.view)
            self.view.insertSubview(backButton, aboveSubview: progrossHUD)
            self.progrossHUD.dimBackground = false
            
            let
            tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("tapGestureHanlder:"))
            self.progrossHUD.addGestureRecognizer(tapGesture)
        }
        self.progrossHUD.show(true)
        progrossHUD.labelColor = UIColor.blackColor()
        progrossHUD.color = UIColor.grayColor()
        
        let userDefalut = NSUserDefaults.standardUserDefaults()
        let d:NSData? = userDefalut.dataForKey(self.videoDowloadUrl!)
        if d != nil {
            
            self.downloadTask = AFOperationManager.sharedInstance.resumeDownOperation2(d, videoName:currentZip.zipNameWithoutsubffix + "video" + self.index + ".mp4",completion: { (response, url, error) -> Void in
                
                if error == nil {
                    // 下载完成应该移除暂停时保存的resumeData  --  下个版本修改
//                    userDefalut.removeObjectForKey(self.videoDowloadUrl!)
                    
                    
                    //下载完播放
                    let manger:DSFileManager = DSFileManager.sharedInstance
                    let videoFile = manger.getDocumentsDirectory().stringByAppendingString("/video/")
                
                    let path:String = videoFile.stringByAppendingString(self.currentZip.zipNameWithoutsubffix + "video" + self.index + ".mp4")
                    self.fileUrl = NSURL.fileURLWithPath(path)
                    
                    self.configureAVPlayerLayer()
                    self.view.layer.insertSublayer(self.playerLayer!, atIndex: 0)
                    self.player?.play()
                } else {
                    
                    let label = UILabel(frame: CGRectMake(0, 0, self.view.bounds.width, 44))
                    label.text = "加载视频失败"
                    label.textColor = UIColor.whiteColor()
                    label.center = self.view.center
                    label.textAlignment = NSTextAlignment.Center
                    self.view.addSubview(label)
                    self.view.bringSubviewToFront(label)
                    
                    self.progrossHUD.hide(true)
                    self.controlView?.userInteractionEnabled = false
                    self.enLargeButton?.userInteractionEnabled = false
               }
            })
        }else {
            
          self.downloadTask = AFOperationManager.sharedInstance.downloadOperation2(self.videoDowloadUrl!, zipNameString: currentZip.zipNameWithoutsubffix + "video" + index + ".mp4") { (response, url, error) -> Void in
                
                if error == nil {
                    
                    let manger:DSFileManager = DSFileManager.sharedInstance
                    let videoFile = manger.getDocumentsDirectory().stringByAppendingString("/video/")
                    let path:String = videoFile.stringByAppendingString(self.currentZip.zipNameWithoutsubffix + "video" + self.index + ".mp4")
                    
                    self.fileUrl = NSURL.fileURLWithPath(path)
                  
                    self.configureAVPlayerLayer()
                    self.view.layer.insertSublayer(self.playerLayer!, atIndex: 0)
                    self.player?.play()
                }else {

                    let label = UILabel(frame: CGRectMake(0, 0, self.view.bounds.width, 44))
                    label.text = "加载视频失败"
                    label.textColor = UIColor.whiteColor()
                    label.center = self.view.center
                    label.textAlignment = NSTextAlignment.Center
                    self.view.addSubview(label)
                    self.view.bringSubviewToFront(label)
                    
                    self.progrossHUD.hide(true)
                
                    self.controlView?.userInteractionEnabled = false
                    self.enLargeButton?.userInteractionEnabled = false
                }
            }
        }

        AFOperationManager.sharedInstance.sessionManager.setDownloadTaskDidWriteDataBlock({ (session: NSURLSession!, task: NSURLSessionDownloadTask!, real: Int64, total: Int64, totalBytesExpectedToWrite: Int64) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in

                if self.downloadTask.taskIdentifier == task.taskIdentifier {
                    
                    self.percent = (total * 100 / totalBytesExpectedToWrite).description
                    self.percent = self.percent+"%"
                    self.updatePercent(self.percent)
                }
            })
        })
    }
    
    func updatePercent(percent:String)
    {
         self.progrossHUD.labelText = "正在下载视频"+percent
        if percent == "100%"
        {
            self.progrossHUD.hide(true)
            self.progrossHUD.removeFromSuperview()
            
            self.backButton.removeFromSuperview()
            self.navigationBar.addSubview(self.backButton)
            
        }
        Logger.info("percent=\(percent)")
    }
    
    // MARK: 
    // MARK: 遍历获取用户手册leaf
    func configureLeaf()
    {
        if listArray != nil {
            if listArray.count > 0 {
                //  无视频版本
                let dict = listArray[0] as! NSDictionary
                let n = dict.objectForKey("id") as! NSNumber
                let resourcesId = n.description
                
                //遍历
                self.TraversalMethods(resourcesId)
            }
        }else {
            // 有视频版本
            let childrenLeaf: DasAutoFile! = self.leaf
            let resourcesId  = childrenLeaf.resourceId
            
            //遍历
            self.TraversalMethods(resourcesId)
        }
    }
    
    func TraversalMethods(resourcesId:String) {
        //遍历
        var a:NSArray = NSArray()
        var sendLeaf:DasAutoFile!
        
        // 用户手册
        sendLeaf = self.searchLeafFromUserManualWithResourceId(resourcesId)
        if sendLeaf == nil {
            
            PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
            let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
            
            for var i = 0; i < directory.children.count; i++
            {
                
                let file = directory.children[i] as DasAutoFile
                if file.resourceId == resourcesId
                {
                    sendLeaf = file
                    
                }
            }
        }
        
        if sendLeaf.children.count != 0 {
            
            a = sendLeaf.children
        }
        
        let htmlPage: HtmlDetaiController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("HtmlDetaiStoryboardID") as! HtmlDetaiController
        
        htmlPage.leaf = sendLeaf
        htmlPage.listName = "用户手册"
        
        if a.count > 0 {
            htmlPage.dataArray = a
        }else {
            htmlPage.dataArray = nil
        }
        
        if sendLeaf.videoId != nil  {
            
            htmlPage.fileUrl = fileUrl
        }
        
        self.navigationController?.pushViewController(htmlPage, animated: true)
    }

    func searchLeafFromUserManualWithResourceId(resourcesId: String) -> DasAutoFile? {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(3)
        let manualDirectory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
        var resultLeaf: DasAutoFile!
        for var i = 0; i < manualDirectory.children.count; i++ {
            
            let file = manualDirectory.children[i] as DasAutoFile
            for var i = 0; i < file.children.count; i++ {
                
                let childrenFile = file.children[i] as DasAutoFile
                for var i = 0; i < childrenFile.children.count; i++ {
                    
                    let leaf = childrenFile.children[i] as DasAutoFile
                    if leaf.resourceId == resourcesId {
                        
                        resultLeaf = leaf
                        return resultLeaf
                    }
                }
            }
        }
        
        return resultLeaf
    }
    
    //画出热点
    func drawHotField()
    {
        let width:CGFloat = self.view.bounds.size.width
        let height:CGFloat = self.view.bounds.size.height

        self.buttonMaintain = CGPathCreateMutable()
        
        if self.whetherPortrate == true
        {
            CGPathMoveToPoint(buttonMaintain,nil, 38, height-60)
            CGPathAddLineToPoint(buttonMaintain, nil, width-170,  height-60)
            CGPathAddLineToPoint(buttonMaintain, nil, width-170,  height)
            CGPathAddLineToPoint(buttonMaintain, nil, 38, height)
            CGPathCloseSubpath(self.buttonMaintain)
        }else
        {
            CGPathMoveToPoint(buttonMaintain,nil, 60, 65)
            CGPathAddLineToPoint(buttonMaintain, nil, 60,  height-150)
            CGPathAddLineToPoint(buttonMaintain, nil, 0,  height-150)
            CGPathAddLineToPoint(buttonMaintain, nil, 0,65 )
            CGPathCloseSubpath(self.buttonMaintain)
        }
        Logger.info("pathPoint:  \(self.buttonMaintain)")
    }
    // 点击
    func controlViewClicked(tapGesture:UITapGestureRecognizer)
    {
        self.drawHotField()
        Logger.info("tap:---------------")
        let tapPoint:CGPoint = tapGesture.locationInView(self.view)

        if CGPathContainsPoint(self.buttonMaintain,nil,tapPoint,false) == true
        {
             var currentX = tapPoint.x
             var percent = (currentX-38)/self.progessSlider!.frame.size.width
            
            if self.whetherPortrate != true
            {
                currentX = tapPoint.y
                percent = (currentX-65)/self.progessSlider!.frame.size.width
            }

            let duration: CMTime = self.player!.currentItem!.duration
            var currentSecond: Float64 = CMTimeGetSeconds(duration)
            currentSecond = currentSecond * Float64(percent)
            self.progessSlider?.value = Float( currentSecond / CMTimeGetSeconds(self.player!.currentItem!.duration))
            self.player?.currentItem!.seekToTime(CMTimeMakeWithSeconds(Float64(Float(CMTimeGetSeconds(duration)) * self.progessSlider!.value), Int32(CMTimeGetSeconds(duration))))
            self.progressLabel?.text = self.getCurrentTime(currentSecond)
            
            self.judgeWhetherEnd()
        }
    }
    
    //滑动
    func controlViewPaned(panGesture:UIPanGestureRecognizer)
    {
        self.drawHotField()
        let tapPoint:CGPoint = panGesture.locationInView(self.view)
        
        if panGesture.state == UIGestureRecognizerState.Began || panGesture.state == UIGestureRecognizerState.Changed
        {
            if CGPathContainsPoint(self.buttonMaintain,nil,tapPoint,false) == true
            {
                var currentX = tapPoint.x
                var percent = (currentX-38)/self.progessSlider!.frame.size.width
                
                if self.whetherPortrate != true
                {
                    currentX = tapPoint.y
                    percent = (currentX-65)/self.progessSlider!.frame.size.width
                }

                let duration: CMTime = self.player!.currentItem!.duration
                var currentSecond: Float64 = CMTimeGetSeconds(duration)
                currentSecond = currentSecond * Float64(percent)
                self.progessSlider?.value = Float( currentSecond / CMTimeGetSeconds(self.player!.currentItem!.duration))
                self.player?.currentItem!.seekToTime(CMTimeMakeWithSeconds(Float64(Float(CMTimeGetSeconds(duration)) * self.progessSlider!.value), Int32(CMTimeGetSeconds(duration))))
                self.progressLabel?.text = self.getCurrentTime(currentSecond)
                
                self.judgeWhetherEnd()
            }
        }
    }
    
}
