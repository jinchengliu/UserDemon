//
//  SearchHistoryManager.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-24.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

let SearchHistoryFilePath: String = "\(NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString)/SearchHistory.plist"

class SearchHistoryManager: NSObject {
   
    private var _searchHistories: NSMutableArray?
    var searchHistories: NSArray? { get { return self._searchHistories } }
    
    // MARK:
    // MARK:life cycle
    class var sharedInstance : SearchHistoryManager {
        
        struct Static {
            static var onceToken : dispatch_once_t = 0
            static var instance : SearchHistoryManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = SearchHistoryManager()
        }
        return Static.instance!
    }
    
    override init() {
        super.init()
        var loadedHistories: NSArray?
        loadedHistories = self.loadSearchHistoryFromLocal()
        if loadedHistories != nil {
            self._searchHistories = NSMutableArray(array: loadedHistories!)
        }
    }
    
    // MARK: 
    // MARK:private function
    ///读取搜索历史
    private func loadSearchHistoryFromLocal() -> NSArray? {
        return NSArray(contentsOfFile: SearchHistoryFilePath)
    }
    
    ///保存搜索历史
    private func saveSearchHistory() {
        if self._searchHistories != nil {
            let ret = self._searchHistories?.writeToFile(SearchHistoryFilePath, atomically: true)
            if ret == true {
                Logger.debug("存储成功")
            }else {
                Logger.debug("存储失败")
            }
        }
    }
    
    // MARK:public function
    ///插入搜索关键字
    func insertKey(key: String) {
        if self._searchHistories == nil {
            self._searchHistories = NSMutableArray()
        }
        if self._searchHistories?.containsObject(key) == true {
            self._searchHistories?.removeObject(key)
        }
        self._searchHistories?.insertObject(key, atIndex: 0)
        self.saveSearchHistory()
    }
    
    ///删除某一条记录
    func removeKey(key: String) {
        self._searchHistories?.removeObject(key)
        self.saveSearchHistory()
    }
    
    ///清空搜索历史
    func clearSearchHistory() {
        _searchHistories = nil
        var error: NSError?
        do {
            try NSFileManager().removeItemAtPath(SearchHistoryFilePath)
        } catch let error1 as NSError {
            error = error1
        }
        if error != nil {
            Logger.error("删除搜索历史记录文件失败，失败原因: \(error?.localizedDescription)")
        }
    }
}
