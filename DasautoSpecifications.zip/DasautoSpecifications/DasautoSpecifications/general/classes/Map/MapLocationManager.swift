//
//  MapLocationManager.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-18.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

@objc protocol MapLocationManagerDelegate {
    optional func didUpdateUserLocation(userLocation: BMKUserLocation)
    optional func didMoveMapViewCenterTo(location: CLLocationCoordinate2D)
}

class MapLocationManager: NSObject, BMKLocationServiceDelegate, BMKGeoCodeSearchDelegate {
   
    private var locationService: BMKLocationService!
    private var geoCodeSearch: BMKGeoCodeSearch!
    
    dynamic var locationProvinceName: String?       //添加dynamic，以便使用kvo监听
    var currentLocation: BMKUserLocation!
    var mapLocationManagerDelegate: MapLocationManagerDelegate?
    
    // MARK:  
    class var sharedInstance : MapLocationManager {
        
        struct Static {
            
            static var onceToken : dispatch_once_t = 0
            static var instance : MapLocationManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            
            Static.instance = MapLocationManager()
        }
        return Static.instance!
    }
    
    override init() {
        
        super.init()
        self.locationService = BMKLocationService()
        self.geoCodeSearch = BMKGeoCodeSearch()
    }
    
    // MARK:public function
    func openLocationService() {
        
        self.locationService.delegate = self
        self.geoCodeSearch.delegate = self
        self.locationService.startUserLocationService()
    }
    
    func closeLocationService() {
        
        self.locationService.delegate = nil
        self.geoCodeSearch.delegate = nil
        self.locationService.stopUserLocationService()
    }
    
    func getGeoCodeWithAddress(address: String, city: String) {
        
        let geoCodeOption: BMKGeoCodeSearchOption = BMKGeoCodeSearchOption()
        geoCodeOption.address = address
        geoCodeOption.city = city
        self.geoCodeSearch.geoCode(geoCodeOption)
    }
    
    // MARK:BMKLocationServiceDelegate
    func didUpdateUserHeading(userLocation: BMKUserLocation!) {
        
    }
    
    //2.6.0更新
    func didUpdateBMKUserLocation(userLocation: BMKUserLocation!) {
        
        if self.currentLocation == nil {
            
              self.reverseGeoCodeBySystemSDK(userLocation)
//            self.reverseGeoCodeByBaiDuSDK(userLocation.location)
        }
        if let delegate = self.mapLocationManagerDelegate {
            delegate.didUpdateUserLocation!(userLocation)
            self.currentLocation = userLocation
        }
    }
    
/**
 *  使用系统的SDK经行地理反编码_比较好用
 */
func reverseGeoCodeBySystemSDK(userLocation: BMKUserLocation) {
    
    let geo:CLGeocoder = CLGeocoder()
    
    // 地理反编码
    geo.reverseGeocodeLocation(userLocation.location, completionHandler: { (markArr, error) -> Void in
        
        if error == nil {
            self.currentLocation = userLocation
            if let arr = markArr {
                let one: CLPlacemark = arr.first!
                if  let dic = one.addressDictionary {
                    
                    self.locationProvinceName = dic["City"] as? String
                    print((dic as NSDictionary).allKeys)
                    print(dic["City"])
                }
            }
        }else {
            self.currentLocation = nil
        }
    })
}
    
    /**
     *  使用百度SDK经行地理反编码_暂时弃用
     */
    func reverseGeoCodeByBaiDuSDK(location: CLLocation) {
        
        let reverseGeoCodeOption = BMKReverseGeoCodeOption()
        reverseGeoCodeOption.reverseGeoPoint = location.coordinate
        let flag = self.geoCodeSearch.reverseGeoCode(reverseGeoCodeOption)
        if !flag {
            self.currentLocation = nil
        }
    }
    
    // MARK:BMKGeoCodeSearchDelegate
    func onGetReverseGeoCodeResult(searcher: BMKGeoCodeSearch!, result: BMKReverseGeoCodeResult!, errorCode error: BMKSearchErrorCode) {
            
        if result.addressDetail.province != nil {
            
            self.locationProvinceName = result.addressDetail.province
        }else {
            Logger.warn("反地理编码失败")
        }
    }

    func onGetGeoCodeResult(searcher: BMKGeoCodeSearch!, result: BMKGeoCodeResult!, errorCode error: BMKSearchErrorCode) {
        
        self.mapLocationManagerDelegate?.didMoveMapViewCenterTo!(result.location)
    }
}
