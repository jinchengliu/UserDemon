//
//  Car4sshopAnnotation.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class Car4sshopAnnotation:BMKPointAnnotation
{

        var object: AnyObject
    
        init( object: AnyObject)
        {
 
            self.object = object

        }
}

