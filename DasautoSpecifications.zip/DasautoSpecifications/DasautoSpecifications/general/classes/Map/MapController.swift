//
//  MapController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit


class MapController: DasautoController, UITextFieldDelegate, BMKMapViewDelegate, MapLocationManagerDelegate ,BMKGeoCodeSearchDelegate{
    
    var searchTextField: MarginTextField!
    var mapView: BMKMapView!
    var locationManager: MapLocationManager!
    var car4sshopListManager: Car4sshopListManager?
    
    var kvo: KeyValueObserver?
    var annotationArray: NSMutableArray!
    var provinces: NSMutableArray!
    var car4sshops: NSArray?
    var firstSearch = true
    var index: Int = 0
    
    var geoArray:NSMutableArray!
    var trueOrFalse:Bool = false
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            self.mapViewWillAppearWithNet()
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        self.mapView.viewWillDisappear()
        self.locationManager.mapLocationManagerDelegate = nil
        self.mapView.delegate = nil
        self.locationManager.closeLocationService()
        self.kvo = nil
        
        for var i = 0;i < self.geoArray.count; i++
        {
            let geocodesearch = self.geoArray[i] as! BMKGeoCodeSearch
            geocodesearch.delegate = nil
        }
    }
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.geoArray = NSMutableArray()
        
        self.configureTitle("附近的维修中心")
        self.addBackBarButtonItem()
        self.addSearchView()
        
        self.addMapView()
        self.locationManager = MapLocationManager.sharedInstance
        self.car4sshopListManager = Car4sshopListManager.sharedInstance
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    override func showProgressHUDMessage(message: String) {
        
        progressHUD = MBProgressHUD()
        progressHUD.labelText = message
        progressHUD.showAnimated(true) { () -> Void in
            NSThread.sleepForTimeInterval(2)
        }
        Util.getKeyWindow().addSubview(progressHUD)
    }
    /**
    *  置搜索页面
    */
    func addSearchView() {
        
        let searchView: UIView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 65))
        searchView.backgroundColor = UIColor.whiteColor()
        let searchBgImageView: UIImageView = UIImageView(frame: searchView.bounds)
        searchBgImageView.image = UIImage(named: "search_bg")
        
        searchTextField = MarginTextField(frame: CGRectMake(30, 15, CGRectGetWidth(self.view.bounds) - 30 - 70, 35))
        searchTextField.clearButtonMode = UITextFieldViewMode.WhileEditing
        searchTextField.font = UIFont.systemFontOfSize(14)
        searchTextField.layer.borderColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.5).CGColor
        searchTextField.layer.borderWidth = 1
        searchTextField.setLeftMargin(10)
        searchTextField.delegate = self
        searchTextField.returnKeyType = UIReturnKeyType.Done
        searchTextField.placeholder = "请输入地址查询"
        searchTextField.textAlignment = NSTextAlignment.Center
        searchView.addSubview(searchBgImageView)
        searchView.addSubview(searchTextField)
        
        let listButton: ThemeButton = ThemeButton(frame: CGRectMake(CGRectGetMaxX(searchTextField!.frame) + 15, 18, 29, 29))
        listButton.hitTestEdgeInsets = UIEdgeInsetsMake(-10, -10, -10, -10)
        listButton.setImage(UIImage(named: "map" + themeColor), forState: .Normal)
        listButton.addTarget(self, action: Selector("onListButtonClicked:"), forControlEvents: .TouchUpInside)
        searchView.addSubview(listButton)
        self.view.addSubview(searchView)
    }
    
    /**
     *  添加地图视图
     */
    func addMapView() {
        
        if self.mapView == nil
        {
            self.mapView = BMKMapView(frame: CGRectMake(0, 65, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) - 64 - 65))
            self.view.addSubview(self.mapView!)
        }
        self.mapView.showMapScaleBar = true
        self.mapView.showsUserLocation = true
        self.mapView.zoomLevel = 12
        self.mapView.delegate = self;   //----change By News--
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
    *  选中列表视图
    */
    func onListButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  获取附近的地址名
    */
    func getCar4sshopListFromLocation() {
        
        let nonDictionary = NSDictionary()
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kProvList, param: nonDictionary, withToken:false,success: { (operation, responseObject) -> Void in
            
            let responseDictionary: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if responseDictionary != nil {
                
                let responseArray = responseDictionary?.objectForKey("provinceList") as! NSArray
                self.provinces = NSMutableArray(capacity: responseArray.count)
                for loadProvinceItem in responseArray {
                    
                    let provinceItem: ProvinceModel = ProvinceModel(JSONDic: loadProvinceItem as! NSDictionary)
                    self.provinces!.addObject(provinceItem)
                }
                
                for model in self.provinces {
                    
                    let mod = model as! ProvinceModel
                    if mod.provName == self.locationManager.locationProvinceName {
                        
                        self.car4sshopListManager?.currentProvince = ProvinceModel(JSONDic: ["provId": mod.provId!, "provName": mod.provName!])
                        self.getCar4sshopListFromCurrentSelectedProvince()
                        return
                    }
                }
            }
            }) { (operation, error) -> Void in
                
                self.car4sshopListManager?.currentProvince = ProvinceModel(JSONDic: ["provId": "31", "provName": "上海市"])
                self.getCar4sshopListFromCurrentSelectedProvince()
        }
    }
    
    /**
    *  mapViewWillAppearWithNet 
    */
    func mapViewWillAppearWithNet() {

        self.mapView.viewWillAppear()
        self.mapView.delegate = self
        self.kvo = KeyValueObserver(source: self.locationManager, keyPath: "locationProvinceName", options: .New) {
            (kvo, change) in
            
            self.getCar4sshopListFromLocation()
        }
        
        self.locationManager.mapLocationManagerDelegate = self
        self.locationManager.openLocationService()
        if self.car4sshopListManager?.currentProvince != nil {
            
            self.getCar4sshopListFromCurrentSelectedProvince()
            
            // 通过地理搜索  获取经纬度
            let searchOption = BMKGeoCodeSearchOption()
            searchOption.address = self.car4sshopListManager?.currentProvince?.provName
            
            let searchAddress = BMKGeoCodeSearch()
            searchAddress.delegate = self
            searchAddress.geoCode(searchOption)
            
            self.geoArray.addObject(searchAddress)
        }else if self.locationManager.locationProvinceName != nil {
            
            Logger.info("***************   :\(self.locationManager.locationProvinceName)")
            self.getCar4sshopListFromLocation()
            //如果当前为定位模式，将地图中心设为当前定位坐标。
            self.mapView.setCenterCoordinate(self.locationManager.currentLocation.location.coordinate, animated: true)
        }
    }
    
    /**
    *  获取4s店
    */
    func getCar4sshopListFromCurrentSelectedProvince() {
        
        self.showProgressHUDMessage("正在加载")
        self.car4sshopListManager?.getCar4sshopListForCurrentProvince({ (success, car4sshops) -> Void in
            if success {
                
                self.car4sshops = car4sshops
                self.annotationArray = NSMutableArray(capacity: self.car4sshops!.count)
                for car4sshop in car4sshops! {
                    
                    let searchOption = BMKGeoCodeSearchOption()
                    searchOption.address = (car4sshop as! Car4sshopModel).address
                    let searchAddress = BMKGeoCodeSearch()
                    searchAddress.delegate = self
                    searchAddress.geoCode(searchOption)
                    
                    self.geoArray.addObject(searchAddress)
                }
                
                self.firstSearch = false
            }
        })
    }
    
    // MARK: 
    // MARK: MapLocationManagerDelegate
    func didUpdateUserLocation(userLocation: BMKUserLocation) {
        
        self.mapView.updateLocationData(userLocation)

        // 设当前位置为中心点
        if trueOrFalse == false
        {
            self.mapView.setCenterCoordinate(userLocation.location.coordinate, animated: true)
            trueOrFalse = true
        }
    }
    
    func didMoveMapViewCenterTo(location: CLLocationCoordinate2D) {
        
        self.mapView.zoomLevel = 15
        self.mapView.setCenterCoordinate(location, animated: true)
    }
    
    // MARK: BMKGeoCodeSearchDelegate
    func onGetGeoCodeResult(searcher: BMKGeoCodeSearch!, result: BMKGeoCodeResult!, errorCode error: BMKSearchErrorCode)
    {
        
        if firstSearch == true {
            
            if result != nil {
               
                if index < self.car4sshops?.count
                {
                    
                    let carModel: Car4sshopModel = self.car4sshops?.objectAtIndex(index) as! Car4sshopModel
                    let aa:Car4sshopAnnotation = Car4sshopAnnotation(object: carModel)
                    aa.coordinate = result.location
                    aa.title = carModel.name!
                    aa.subtitle = carModel.address!
                    self.mapView.addAnnotation(aa)
                }
            }
            index++
        }else {
           
            if result != nil {
                
                firstSearch = true
                self.mapView.setCenterCoordinate(result.location, animated: false)
            }
        }
    }
    
    /**
    *  设置中心点
    */
    func handleTapGesture(tapGesture: UITapGestureRecognizer) {
        
        let  touchPoint:CGPoint = tapGesture.locationInView(self.mapView)
        let touchMapCoordinate:CLLocationCoordinate2D  = self.mapView.convertPoint(touchPoint, toCoordinateFromView: self.mapView)
        
        self.mapView.setCenterCoordinate(touchMapCoordinate, animated: true)

    }

    // MARK:BMKMapViewDelegate
    func mapView(mapView: BMKMapView!, viewForAnnotation annotation: BMKAnnotation!) -> BMKAnnotationView! {
        
        Logger.info("subTitle  :\(annotation.coordinate.latitude)")
        let annotationID: String = "Car4sshopAnnotationID"
        if annotation is BMKPointAnnotation
                {
                    var annotatinView :BMKPinAnnotationView!
                    if annotatinView == nil
                    {
                        annotatinView = BMKPinAnnotationView(annotation: annotation, reuseIdentifier: annotationID)
                    }
                    
                    annotatinView.image = UIImage(named: "artBoard")
                    
                    let image:UIImage = UIImage(named: "rightArrow_red")!
                    let rightView:UIImageView = UIImageView(image:image)
                    annotatinView.rightCalloutAccessoryView = rightView
                    
                    annotatinView.tintColor = UIColor.redColor()
                    annotatinView.canShowCallout = true
                    annotatinView.enabled = true
        
                    return annotatinView
                }
        return nil
    }
    
    /**
    *  点击大头针
    */
    func mapView(mapView: BMKMapView!, didSelectAnnotationView view: BMKAnnotationView!) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.mapView.setCenterCoordinate(view.annotation.coordinate, animated: true)
        print("设置中心点")
    }
    
    func mapView(mapView: BMKMapView!, onClickedMapBlank coordinate: CLLocationCoordinate2D) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.mapView.setCenterCoordinate(coordinate, animated: true)
    }
    
    /**
     *  点击气泡的方法
     */
    func mapView(mapView: BMKMapView!, annotationViewForBubble view: BMKAnnotationView!) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if view.annotation != nil && view.annotation is BMKPointAnnotation {
            
            
            let car4sshopModel: Car4sshopModel = (view.annotation as! Car4sshopAnnotation).object as! Car4sshopModel
            let car4sshopDetailController: Car4sshopDetailController = Car4sshopDetailController(car4sshopModel: car4sshopModel)
            
            self.navigationController?.pushViewController(car4sshopDetailController, animated: true)
        }
    }
    
    // MARK: UITextfieldDelagte
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        let searchVC: SearchCar4sshopListController = SearchCar4sshopListController()
        searchVC.searchSource = self.car4sshops
        self.navigationController?.pushViewController(searchVC, animated: true)
        return false
    }
    
}
