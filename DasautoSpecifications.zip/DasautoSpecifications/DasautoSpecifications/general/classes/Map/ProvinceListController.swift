//
//  ProvinceListController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class ProvinceListController: DasautoController, UITableViewDelegate, UITableViewDataSource {

    var listTableView: UITableView!
    var provinces: NSMutableArray!
    var provinceKeys: NSArray!                     // 省份关键字数组，拼音首字母
    var provinceValues: NSArray!                   // 省份数组，对应省份关键字
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("省份列表")
        self.addBackBarButtonItem()
        self.configureTableView()
        if self.provinces != nil {
            
            //按首字母排序
            let sorter = NSSortDescriptor(key: "letter", ascending: true)
            let sortDescriptors: NSArray = NSArray(object: sorter)
            provinces.sortUsingDescriptors(sortDescriptors as! [NSSortDescriptor])
            let provinceDictionary: NSDictionary = self.sortByFirstLetterWithProvinces(provinces)
            self.provinceKeys = provinceDictionary.objectForKey("sectionKeys") as! NSArray
            self.provinceValues = provinceDictionary.objectForKey("sectionValues") as! NSArray
            self.listTableView.reloadData()
        }else {
            
            if AFNetworkReachabilityManager.sharedManager().reachable == true {
                
                self.loadProvinceListFromServer()
            }else {
                
                self.showRendView("网络不可用", isSuccess: false)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置tableView
    */
    func configureTableView() {
        
        self.listTableView = UITableView(frame: self.view.bounds)
        self.listTableView.frame.size.height = self.listTableView.frame.size.height - 64
        self.listTableView.delegate = self
        self.listTableView.dataSource = self
        self.listTableView.sectionIndexColor = color
        self.view.addSubview(self.listTableView)
        
        self.setExtraCellLineHidden(self.listTableView)
    }
    
    private func setExtraCellLineHidden(tableView: UITableView) {
        
        let view: UIView = UIView()
        view.backgroundColor = UIColor.clearColor()
        tableView.tableFooterView = view
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回 
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  网络请求加载省份列表
    */
    private func loadProvinceListFromServer() {
        
        self.showProgressHUDMessage("正在加载")
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kProvList, param: NSDictionary(), withToken:false,success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            let responseDictionary: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if responseDictionary != nil {
                
                let responseArray = responseDictionary?.objectForKey("provinceList") as! NSArray
                let provinces: NSMutableArray = NSMutableArray(capacity: responseArray.count)
                for loadProvinceItem in responseArray {
                    
                    let provinceItem: ProvinceModel = ProvinceModel(JSONDic: loadProvinceItem as! NSDictionary)
                    provinces.addObject(provinceItem)
                }
                
                //按首字母排序
                let sorter = NSSortDescriptor(key: "letter", ascending: true)
                let sortDescriptors: NSArray = NSArray(object: sorter)
                provinces.sortUsingDescriptors(sortDescriptors as! [NSSortDescriptor])
                let provinceDictionary: NSDictionary = self.sortByFirstLetterWithProvinces(provinces)
                self.provinceKeys = provinceDictionary.objectForKey("sectionKeys") as! NSArray
                self.provinceValues = provinceDictionary.objectForKey("sectionValues") as! NSArray
                self.listTableView.reloadData()
            }
        }) { (operation, error) -> Void in
            
            self.hideProgressHUD()
        }
    }
    
    //MARK: 根据拼音首字母分类
    private func sortByFirstLetterWithProvinces(provinces: NSArray) -> NSDictionary {
        
        let sectionHeadKeys: NSMutableArray = NSMutableArray()
        var checkValueAtIndex: Bool = false
        let groupForSection: NSMutableArray = NSMutableArray(capacity: provinces.count)
        var tmpGroup: NSMutableArray?
        for province in provinces {
            let tmpProvince: ProvinceModel = province as! ProvinceModel
            let provinceNameLetter: String = tmpProvince.letter!
            let firstLetter: String = provinceNameLetter.substringToIndex(provinceNameLetter.startIndex.advancedBy(1))
            
            if sectionHeadKeys.containsObject(firstLetter.uppercaseString) == false {
                sectionHeadKeys.addObject(firstLetter.uppercaseString)
                tmpGroup = nil
                checkValueAtIndex = false
            }
            
            if sectionHeadKeys.containsObject(firstLetter.uppercaseString) == true {
                
                if tmpGroup == nil {
                    
                    tmpGroup = NSMutableArray(capacity: provinces.count)
                }
                
                tmpGroup?.addObject(tmpProvince)
                if checkValueAtIndex == false {
                    
                    groupForSection.addObject(tmpGroup!)
                    checkValueAtIndex = true
                }
            }
        }
        return [ "sectionKeys" : sectionHeadKeys , "sectionValues" : groupForSection]
    }

    // MARK: 
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return self.provinceKeys == nil ? 1 : self.provinceKeys.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.provinceValues == nil ? 0 : (self.provinceValues.objectAtIndex(section) as! NSArray).count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let identifier: String = "provinceCell"
        var cell: UITableViewCell?
        cell = tableView.dequeueReusableCellWithIdentifier(identifier)
        if cell == nil {
            
            cell = UITableViewCell(style: .Default, reuseIdentifier: identifier)
            cell?.selectionStyle = UITableViewCellSelectionStyle.None
        }
        
        let province: ProvinceModel = (self.provinceValues.objectAtIndex(indexPath.section) as! NSArray).objectAtIndex(indexPath.row) as! ProvinceModel
        cell?.textLabel!.text = province.provName
        
        return cell!
    }
    
    /**
    *  添加字母索引
    */
    func sectionIndexTitlesForTableView(tableView: UITableView) -> [String]? {
        
        if self.provinceKeys != nil {
             return (self.provinceKeys as! [String])
        }else {
            return nil
        }
    }
    
    /**
    *  添加字母索引点击方法
    */
    func tableView(tableView: UITableView, sectionForSectionIndexTitle title: String, atIndex index: Int) -> Int {
        
        tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: 0, inSection: index), atScrollPosition: UITableViewScrollPosition.Top, animated: true)
        return index
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return self.provinceKeys == nil ? nil : self.provinceKeys.objectAtIndex(section) as? String
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let province: ProvinceModel = (self.provinceValues.objectAtIndex(indexPath.section) as! NSArray).objectAtIndex(indexPath.row) as! ProvinceModel
        Car4sshopListManager.sharedInstance.currentProvince = province
        self.navigationController?.popViewControllerAnimated(true)
    }
}
