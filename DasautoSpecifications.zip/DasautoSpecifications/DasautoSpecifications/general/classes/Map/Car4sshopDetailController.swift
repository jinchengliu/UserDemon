//
//  Car4sshopDetailController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-22.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class Car4sshopDetailController: DasautoController, BMKMapViewDelegate ,BMKGeoCodeSearchDelegate{

    var mapView: BMKMapView!
    var nameLabel: ThemeLabel!
    var addressLabel: ThemeLabel!
    
    var telLabel: ThemeLabel!
    var navigationButton: UIButton!
    var telButton: UIButton!
    
    var favouriteButton: UIButton!
    var buttonState: Bool!
    var car4sshopModel: Car4sshopModel!
    var coordinate2D: CLLocationCoordinate2D!
    
    // MARK:
    // MARK: Life Cycle
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        
        fatalError("init(coder:) has not been implemented")
    }
    
    convenience init(car4sshopModel: Car4sshopModel) {
        
        self.init()
        self.car4sshopModel = car4sshopModel
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.addBackBarButtonItem()
        self.addRightNavigationItemAboutFavourite()
        self.configureTitle("4S店详情")
        self.configureUI()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  configure UI
    */
    func configureUI() {
        
        let wdh = CGRectGetWidth(UIScreen.mainScreen().bounds)
        let hgt = CGRectGetHeight(UIScreen.mainScreen().bounds)
        self.nameLabel = ThemeLabel(frame: CGRectMake(20, 20, wdh - 40, 30))
        self.nameLabel.text = self.car4sshopModel.name
        self.nameLabel.textColor = UIColor.blackColor()
        self.nameLabel.textAlignment = NSTextAlignment.Center
        self.view.addSubview(self.nameLabel)
        
        self.mapView = BMKMapView(frame: CGRectMake(20, CGRectGetMaxY(self.nameLabel.frame) + 10, wdh - 40, (wdh - 40) / 2))
        self.mapView.layer.borderColor = UIColor.grayColor().CGColor
        self.mapView.layer.borderWidth = 1
        self.mapView.zoomEnabledWithTap = true
        self.mapView.zoomEnabled = true
        self.mapView.scrollEnabled = true
        self.mapView.zoomLevel = 17
        self.mapView.delegate = self
        self.view.addSubview(self.mapView)
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            // 通过地理搜索  获取经纬度
            let searchOption = BMKGeoCodeSearchOption()
            
            var province = "上海";
            if Car4sshopListManager.sharedInstance.currentProvince != nil
            {
                province = Car4sshopListManager.sharedInstance.currentProvince!.provName!
            }
            searchOption.address = province.stringByAppendingString(car4sshopModel.address!)
            let searchAddress = BMKGeoCodeSearch()
            searchAddress.delegate = self
            searchAddress.geoCode(searchOption)
        }else {
            self.showRendView("当前网络不可用", isSuccess: false)
        }
        
        let addressImageView = UIImageView(frame: CGRectMake(20, CGRectGetMaxY(self.mapView.frame) + 23, 14, 14))
        addressImageView.image = UIImage(named: "annotationImage")
        self.view.addSubview(addressImageView)
        
        self.addressLabel = ThemeLabel(frame: CGRectMake(40, CGRectGetMaxY(self.mapView.frame) + 20, wdh - 60, 20))
        self.addressLabel.text = self.car4sshopModel.address
        self.addressLabel.textColor = UIColor(red: 140/255, green: 140/255, blue: 139/255, alpha: 1.0)
        self.addressLabel.textAlignment = NSTextAlignment.Left
        self.addressLabel.font = UIFont.systemFontOfSize(15)
        self.view.addSubview(self.addressLabel)
        
        let telImageView = UIImageView(frame: CGRectMake(20, CGRectGetMaxY(self.addressLabel.frame) + 13, 14, 14))
        telImageView.image = UIImage(named: "phoneImage")
        self.view.addSubview(telImageView)
        self.telLabel = ThemeLabel(frame: CGRectMake(40, CGRectGetMaxY(self.addressLabel.frame) + 10, wdh - 60, 20))
        self.telLabel.text = self.car4sshopModel.linkTel
        self.telLabel.textColor = UIColor(red: 140/255, green: 140/255, blue: 139/255, alpha: 1.0)
        self.telLabel.textAlignment = NSTextAlignment.Left
        self.telLabel.font = UIFont.systemFontOfSize(15)
        self.view.addSubview(self.telLabel)
        
        self.telButton = UIButton(frame: CGRectMake(18, hgt - 50 - 20 - 64, wdh - 36, 50))
        self.telButton.setBackgroundImage(UIImage(named: "submitButton"), forState: UIControlState.Normal)
        self.telButton.setTitle("拨打4S店电话", forState: .Normal)
        self.telButton.titleLabel?.font = UIFont.systemFontOfSize(15)
        self.view.addSubview(self.telButton)
        self.telButton.addTarget(self, action: Selector("dail"), forControlEvents: .TouchUpInside)
        
        self.navigationButton = ThemeButton(frame: CGRectMake(18, CGRectGetMinY(self.telButton.frame) - 10 - 50 , wdh - 36, 50))
        self.navigationButton.setBackgroundImage(UIImage(named: "submitButton"), forState: UIControlState.Normal)
        self.navigationButton.setTitle("导航到4S店", forState: .Normal)
        self.navigationButton.titleLabel?.font = UIFont.systemFontOfSize(15)
        self.view.addSubview(self.navigationButton)
        self.navigationButton.addTarget(self, action: Selector("navigation"), forControlEvents: .TouchUpInside)
        
        self.setButtonTitleColor(self.telButton)
        self.setButtonTitleColor(self.navigationButton)
    }
    
    /**
    *  添加收藏按钮
    */
    func addRightNavigationItemAboutFavourite() {
        
        favouriteButton = UIButton(frame: CGRectMake(0, 0, 21, 21))
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate_selected.png"), forState: UIControlState.Normal)
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate" + themeColor), forState: UIControlState.Selected)
        favouriteButton.addTarget(self, action: Selector("onFavouriteBarButtonItemClciked:"), forControlEvents: UIControlEvents.TouchUpInside)
        favouriteButton.selected = DBmanager.sharedInstance().isSelectedWithArray(["经销商",car4sshopModel.name!,car4sshopModel.id!,car4sshopModel.address!,car4sshopModel.linkTel!,kUserId])
        buttonState = favouriteButton.selected
        
        let favouriteBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: favouriteButton)
        self.navigationItem.rightBarButtonItem = favouriteBarButtonItem
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        if favouriteButton.selected != buttonState {
            
            if kUserId != "noLogin" {
                
                let type = favouriteButton.selected ? 0 : 1
                self.favoriteShopCollectionAddOrDel(car4sshopModel.id!, type: type)
            }else {
                
                self.navigationController?.popViewControllerAnimated(true)
            }
        }else {
            
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    /**
    *  选中收藏
    */
    func onFavouriteBarButtonItemClciked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if favouriteButton.selected {
            
            DBmanager.sharedInstance().deleteShop(["经销商",car4sshopModel.name!,car4sshopModel.id!,car4sshopModel.address!,car4sshopModel.linkTel!,kUserId])
        } else {
            
            DBmanager.sharedInstance().insertShop(["经销商",car4sshopModel.name!,car4sshopModel.id!,car4sshopModel.address!,car4sshopModel.linkTel!,kUserId])
        }
        favouriteButton.selected = !favouriteButton.selected
    }
 
    /**
    *  选中拨打电话
    */
    func dail() {
        
        let title = "4S店服务热线_" + self.car4sshopModel!.linkTel!
        let customAlertView = CustomAlertView(messageTitle: title, sureTitle: "phone", cancelTitle: "取消", delegate: self)
        customAlertView.show()
    }
    
    /**
    *  选中导航
    */
    func navigation() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        
        if coordinate2D == nil
        {
            self.showRendView("尚未获取到坐标", isSuccess: false)
            return
        }
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if UIApplication.sharedApplication().canOpenURL(NSURL(string: "baidumap://map/")!) {
                
                //调用百度导航
                let urlString: String = "baidumap://map/direction?origin=\(MapLocationManager.sharedInstance.currentLocation.location.coordinate.latitude),\(MapLocationManager.sharedInstance.currentLocation.location.coordinate.longitude)&destination=\(coordinate2D.latitude),\(coordinate2D.longitude)&mode=driving"
                UIApplication.sharedApplication().openURL(NSURL(string: urlString)!)
            }else {
                
                //调用系统地图导航
                let currentLocation: MKMapItem = MKMapItem.mapItemForCurrentLocation()
                let toLocation: MKMapItem = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2DMake(coordinate2D.latitude, coordinate2D.longitude), addressDictionary: nil))
                toLocation.name = self.car4sshopModel.name
                MKMapItem.openMapsWithItems([currentLocation, toLocation], launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving, MKLaunchOptionsShowsTrafficKey: NSNumber(bool: true)])
            }
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
            return
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  收藏经销商
    */
    func favoriteShopCollectionAddOrDel(shopId: String,type: Int) {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            let userDict: NSDictionary = ["userId": Int(kUserId)!,"fourshopId":shopId,"type":type]
            AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kShopCollectionAddOrDel, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
                
                let mutableDic: NSMutableDictionary? = responseObject as? NSMutableDictionary
                if mutableDic != nil {
                    
                    let respCode = mutableDic?.objectForKey("respCode") as! String
                    if respCode == "020003" {
                        
                        DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                        DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                        kUserId = "noLogin"
                        NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
                        NSUserDefaults.standardUserDefaults().synchronize()
                        self.showRendView("账号失效, 请重新登录!", isSuccess: false)
                        
                        let aboutController: AboutController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
                        aboutController.hasRightBarButtonItem = false
                        aboutController.pushToControllerName = "BackToListController"
                        self.navigationController?.pushViewController(aboutController, animated: true)
                    }
                    else {
                        Logger.info(".............: \(respCode)")
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                }else {
                    
                    self.navigationController?.popViewControllerAnimated(true)
                }
                }) { (operation, error) -> Void in
                    
                    self.navigationController?.popViewControllerAnimated(true)
                    Logger.info("_____________\(error)")
            }
        }else {
            
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    
    // MARK:
    // MARK: CustomAlertViewDelegate
    override func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        
        let telUrl: NSURL = NSURL(string: "telprompt://\(self.car4sshopModel!.linkTel!)")!
        if UIApplication.sharedApplication().canOpenURL(telUrl) {
            
            UIApplication.sharedApplication().openURL(telUrl)
        }
    }
    
    // MARK: BMKGeoCodeSearchDelegate
    func onGetGeoCodeResult(searcher: BMKGeoCodeSearch!, result: BMKGeoCodeResult!, errorCode error: BMKSearchErrorCode) {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            Logger.info("result=\(result)")
            if result != nil {
                coordinate2D = result.location as CLLocationCoordinate2D
                self.mapView.setCenterCoordinate(coordinate2D, animated: false)
                
                let aa:BMKPointAnnotation = BMKPointAnnotation();
                aa.coordinate = result.location
                self.mapView.setCenterCoordinate(result.location, animated: false)
                aa.title = car4sshopModel.name
                aa.subtitle = car4sshopModel.address!
                self.mapView.addAnnotation(aa)
                self.mapView.delegate = self
            }
         }
    }

    
    // MARK: BMKMapViewDelegate
    func mapView(mapView: BMKMapView!, viewForAnnotation annotation: BMKAnnotation!) -> BMKAnnotationView! {
       
        let annotationID: String = "Car4sshopDetailAnnotationD"
        if annotation is BMKPointAnnotation {
            var annotatinView :BMKPinAnnotationView!
            if annotatinView == nil {
                annotatinView = BMKPinAnnotationView(annotation: annotation, reuseIdentifier: annotationID)
            }
            
            annotatinView.image = UIImage(named: "artBoard")
            annotatinView.tintColor = UIColor.redColor()
            annotatinView.canShowCallout = true
            annotatinView.enabled = true
            
            return annotatinView
        }
        return nil
    }
    
    func mapView(mapView: BMKMapView!, didSelectAnnotationView view: BMKAnnotationView!) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
    }
}
