//
//  Car4sshopListManager.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class Car4sshopListManager: NSObject {
 
    private var car4sshopListForProvince: NSMutableDictionary = NSMutableDictionary()
    var currentProvince: ProvinceModel?
    
    class var sharedInstance : Car4sshopListManager {
        
        struct Static {
            
            static var onceToken : dispatch_once_t = 0
            static var instance : Car4sshopListManager? = nil
        }
        
        dispatch_once(&Static.onceToken) {
            
            Static.instance = Car4sshopListManager()
        }
        return Static.instance!
    }
    
    // MARK: 
    // MARK: 清除当前选择省份信息
    func removeSelectedProvice() {
        
        self.currentProvince = nil
    }
    
    // MARK: 根据当前选择省份获取4S店列表
    func getCar4sshopListForCurrentProvince(completionHandler: (success: Bool, car4sshops: NSArray?) -> Void) {
        
        var car4sshopList: NSArray?
        car4sshopList = car4sshopListForProvince.objectForKey(self.currentProvince!) as? NSArray
        if car4sshopList == nil {
            
            Util.getCar4sshopListWithCityName(self.currentProvince!.provId!, completionHandler: { (success, car4sshops) -> Void in
                
                if success {
                    
                    self.car4sshopListForProvince.setObject(car4sshops! , forKey: self.currentProvince!)
                    completionHandler(success: true, car4sshops: car4sshops!)
                }else {
                    
                    completionHandler(success: true, car4sshops: nil)
                }
            })
        }else {
            
            completionHandler(success: true, car4sshops: car4sshopList!)
        }
    }
}
