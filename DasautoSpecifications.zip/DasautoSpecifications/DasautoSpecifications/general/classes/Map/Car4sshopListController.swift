//
//  Car4sshopListController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

enum SearchCar4sshopListControllerState {
    
    case Normal
    case Result
}

class Car4sshopListController: DasautoController, UITableViewDataSource, UITableViewDelegate, MapLocationManagerDelegate, UITextFieldDelegate {

    var searchHistoryTableView: UITableView!
    var searchResultTableView: UITableView!
    var agencyTableView: UITableView!
    
    var searchTextField: MarginTextField!
    var currentProvinceButton: ThemeButton!
    var locationManager: MapLocationManager!
    
    var car4sshopListManager: Car4sshopListManager!
    var locationKvo: KeyValueObserver?
    
    var provinces: NSMutableArray?
    var searchResult: NSArray?
    var car4sshops: NSArray?
    
    // 控制器状态
    private var state: SearchCar4sshopListControllerState!
    let agencyTag: Int = 10001
    let searchTag: Int = 10002
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        
        if self.car4sshopListManager.currentProvince != nil {
            
            self.currentProvinceButton.setTitle(self.car4sshopListManager.currentProvince?.provName, forState: .Normal)
            self.getCar4sshopListFromCurrentSelectedProvince()
            
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("handleTextFieldChanged:"), name: UITextFieldTextDidChangeNotification, object: nil)
        self.configureCurrentButtonFrame()
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("查找上海大众汽车经销商")
        self.car4sshopListManager = Car4sshopListManager.sharedInstance
        self.locationManager = MapLocationManager.sharedInstance
        self.locationManager.mapLocationManagerDelegate = nil
        self.addBackBarButtonItem()
        self.addSearchResultTableView()
        self.addAgencyTableView()
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            self.addSearchView("定位中")
            self.loadProvinceListFromServer()
        }else {
            
            self.addSearchView("定位失败")
            self.showRendView("当前网络不可用,定位失败", isSuccess: false)
        }
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UITextFieldTextDidChangeNotification, object: nil)
        self.locationManager.closeLocationService()
        self.locationKvo = nil
        self.hideProgressHUD()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    func handleTextFieldChanged(notification: NSNotification) {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if searchTextField?.text == "" {
                
                self.setNormalState()
            }else {
                
                self.search()
            }
        }
    }
    
    // MARK:
    // MARK: Configure Views
    override func showProgressHUDMessage(message: String) {
        progressHUD = MBProgressHUD()
        progressHUD.labelText = message
        progressHUD.show(true)
        self.view.addSubview(progressHUD)
    }
    /**
    *  配置搜索视图
    */
    func addSearchView(title: String) {
        
        let searchView: UIView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 65))
        searchView.backgroundColor = UIColor.whiteColor()
        let searchBgImageView: UIImageView = UIImageView(frame: searchView.bounds)
        searchBgImageView.image = UIImage(named: "search_bg")
        
        let lineView = UIView(frame: CGRectMake(0, 64, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red:0.85, green:0.85, blue:0.85, alpha:1)
        
        currentProvinceButton = ThemeButton(frame: CGRectMake(15, 15, 80, 35))
        currentProvinceButton.setImage(UIImage(named: "dropListButton" + themeColor), forState: .Normal)
        currentProvinceButton.titleLabel?.textAlignment = NSTextAlignment.Center
        currentProvinceButton.imageEdgeInsets = UIEdgeInsetsMake(0, 80 - 25, 0, -35)
        currentProvinceButton.titleEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 10)
        currentProvinceButton.setTitle(title, forState: .Normal)
        currentProvinceButton.setTitleColor(color, forState: .Normal)
        currentProvinceButton.titleLabel!.font = UIFont.systemFontOfSize(17)
        currentProvinceButton.addTarget(self, action: Selector("onCurrentProvinceButtonClicked:"), forControlEvents: .TouchUpInside)
        
        searchTextField = MarginTextField(frame: CGRectMake(CGRectGetMaxX(currentProvinceButton!.frame) + 10, 15, CGRectGetWidth(self.view.bounds) - 80 - 15 - 70, 35))
        searchTextField.clearButtonMode = UITextFieldViewMode.WhileEditing
        searchTextField.font = UIFont.systemFontOfSize(14)
        searchTextField.layer.borderColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.5).CGColor
        searchTextField.layer.borderWidth = 1
        searchTextField.setLeftMargin(10)
        searchTextField.delegate = self
        searchTextField.returnKeyType = UIReturnKeyType.Done
        searchTextField.placeholder = "请输入地址查询"
        searchTextField.textAlignment = NSTextAlignment.Center
        searchView.addSubview(lineView)
        searchView.addSubview(currentProvinceButton)
        searchView.addSubview(searchTextField)
        
        let mapButton: ThemeButton = ThemeButton(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 29 - 10, 18, 39, 29))
        mapButton.setImage(UIImage(named: "list" + themeColor), forState: .Normal)
        mapButton.imageEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 5)
        mapButton.addTarget(self, action: Selector("onMapButtonClicked:"), forControlEvents: .TouchUpInside)
        searchView.addSubview(mapButton)
        
        self.view.addSubview(searchView)
    }
    
    /**
     *  添加搜索结果tableView
     */
    func addSearchResultTableView() {
        
        searchResultTableView = UITableView(frame: CGRectMake(0, 65, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds) - 65-64))
        searchResultTableView.tag = searchTag
        searchResultTableView.delegate = self
        searchResultTableView.dataSource = self
        self.view.addSubview(searchResultTableView)
        self.setExtraCellLineHidden(searchResultTableView)
    }
    
    /**
     *  配置tableView
     */
    func addAgencyTableView() {
        
        self.agencyTableView = UITableView(frame: CGRectMake(0, 65, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) - 65 - 64))
        self.agencyTableView.separatorStyle = UITableViewCellSeparatorStyle.None
        self.agencyTableView.tag = agencyTag
        self.agencyTableView.dataSource = self
        self.agencyTableView.delegate = self
        self.view.addSubview(self.agencyTableView)
        self.setExtraCellLineHidden(self.agencyTableView)
        
    }
    
    func setExtraCellLineHidden(tableView: UITableView) {
        
        let view: UIView = UIView()
        view.backgroundColor = UIColor.clearColor()
        tableView.tableFooterView = view
    }
    
    /**
    *  configure currentButton frame
    */
    func configureCurrentButtonFrame() {
        
        let provName = self.car4sshopListManager.currentProvince?.provName
        var buttonWidth: CGFloat!
        if provName == nil {
            
            buttonWidth = 80
        }else {
            
            buttonWidth = CGFloat((provName!).characters.count) * 21
        }
        currentProvinceButton.frame = CGRectMake(15, 15, buttonWidth, 35)
        currentProvinceButton.imageEdgeInsets = UIEdgeInsetsMake(0, buttonWidth - 25, 0, -35)
        searchTextField.frame = CGRectMake(CGRectGetMaxX(currentProvinceButton!.frame) + 10, 15, CGRectGetWidth(self.view.bounds) - buttonWidth - 15 - 70, 35)
    }
    
    /**
    *  配置搜索框内容
    */
    func search() {
        
        self.setResultState()
        if car4sshops != nil {
            
            let predicate: NSPredicate = NSPredicate(format: "(SELF.name CONTAINS %@) OR (SELF.letter CONTAINS %@)", argumentArray: [searchTextField.text!, searchTextField.text!])
            searchResult = car4sshops?.filteredArrayUsingPredicate(predicate)
        }
        self.searchResultTableView.reloadData()
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中最近省份
     */
    func onCurrentProvinceButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if self.provinces != nil
            {
                
                let provinceListController: ProvinceListController = ProvinceListController()
                provinceListController.provinces = self.provinces
                self.navigationController?.pushViewController(provinceListController, animated: true)
            }else {
                
                let provinceListController: ProvinceListController = ProvinceListController()
                self.navigationController?.pushViewController(provinceListController, animated: true)
            }
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    /**
     *  选中地图模式
     */
    func onMapButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            let mapController: MapController = MapController()
            self.navigationController?.pushViewController(mapController, animated: true)
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  网络请求加载省份列表
    */
    func loadProvinceListFromServer() {
        
        self.showProgressHUDMessage("正在定位")
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kProvList, param: NSDictionary(), withToken:false,success: { (operation, responseObject) -> Void in
            
            let responseDictionary: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if responseDictionary != nil {
                
                let responseArray = responseDictionary?.objectForKey("provinceList") as! NSArray
                self.provinces = NSMutableArray(capacity: responseArray.count)
                for loadProvinceItem in responseArray {
                    
                    let provinceItem: ProvinceModel = ProvinceModel(JSONDic: loadProvinceItem as! NSDictionary)
                    self.provinces!.addObject(provinceItem)
                }
                self.openLocation()
            }
            }) { (operation, error) -> Void in
                
                self.hideProgressHUD()
                self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    // MARK:
    // MARK: Configure SearchCar4sshopListControllerState
    /**
    *  设置搜索历史状态
    */
    func setNormalState() {
        
        self.state = SearchCar4sshopListControllerState.Normal
        self.agencyTableView.hidden = false
        self.searchResultTableView.hidden = true
        self.agencyTableView.reloadData()
    }
    
    /**
    *  设置搜索结果状态
    */
    func setResultState() {
        
        self.state = SearchCar4sshopListControllerState.Result
        self.agencyTableView.hidden = true
        self.searchResultTableView.hidden = false
    }
    
    // MARK:
    // MARK: Open Location Service
    /**
    *  开始定位
    */
    func openLocation() {
        
        self.locationManager.openLocationService()
        // 定位失败
        
        // 添加监听，当获取到定位信息则更新显示
        self.locationKvo = KeyValueObserver(source: self.locationManager, keyPath: "locationProvinceName", options: .New) {
            (kvo, change) in
            
            self.getCar4sshopListFromLocation()
        }
        if self.locationManager.locationProvinceName != nil {
            
            self.getCar4sshopListFromLocation()
        }
    }
    
    /**
    *  根据定位获取4s店列表
    */
    func getCar4sshopListFromLocation() {
        
        self.hideProgressHUD()
        self.currentProvinceButton.setTitle(self.locationManager.locationProvinceName, forState: .Normal)
        var provId: String!
        for provinceItem in provinces! {
            
            let provName = (provinceItem as! ProvinceModel).provName
            if provName == self.locationManager.locationProvinceName {
                
                provId = (provinceItem as! ProvinceModel).provId
            }
        }
        self.car4sshopListManager.currentProvince = ProvinceModel(JSONDic: ["provId": provId, "provName": self.locationManager.locationProvinceName!])
        self.getCar4sshopListFromCurrentSelectedProvince()
    }
    
    /**
    *  获取4S店
    */
    func getCar4sshopListFromCurrentSelectedProvince() {
        
        self.car4sshopListManager.getCar4sshopListForCurrentProvince({ (success, car4sshops) -> Void in
            if success {
                
                self.car4sshops = car4sshops
                self.agencyTableView.reloadData()
                
                //---change---省份切换后搜索相应切换
                if self.car4sshops !=  nil {
                   if self.searchTextField.text!.characters.count > 0 {
                      self.search()
                   }
                }
            }else {
                
                Logger.info("获取4S列表失败")
            }
        })
    }
    
    // MARK: 
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView.tag == agencyTag {
            
            return (self.car4sshops != nil) ? self.car4sshops!.count : 0
        }else if tableView.tag == searchTag {
            
            return (self.searchResult != nil) ? self.searchResult!.count : 0
        }
        
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var identifier: String!
        if tableView.tag == agencyTag {
            
            identifier = "car4sshopCell"
        }else if tableView.tag == searchTag {
            
            identifier = "resultCar4sshopCell"
        }
        var cell: UITableViewCell?
        cell = tableView.dequeueReusableCellWithIdentifier(identifier)
        if cell == nil {
            
            cell = UITableViewCell(style: .Default, reuseIdentifier: identifier)
            let accessoryView = UIImageView(frame: CGRectMake(0, 0, 10, 15))
            accessoryView.image = UIImage(named: "rightArrow" + themeColor)
            cell?.accessoryView = accessoryView
        }
        
        var car4sshopModel: Car4sshopModel!
        if tableView.tag == agencyTag {
            
            car4sshopModel = self.car4sshops?.objectAtIndex(indexPath.row) as! Car4sshopModel
        }else if tableView.tag == searchTag {
            
            car4sshopModel = self.searchResult?.objectAtIndex(indexPath.row) as! Car4sshopModel
        }
        
        cell?.textLabel!.text = car4sshopModel.name
        let lineView = UIView(frame: CGRectMake(0, 43, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red:0.85, green:0.85, blue:0.85, alpha:1)
        cell?.addSubview(lineView)
        
        return cell!
    }
    
    // UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        var car4sshopModel: Car4sshopModel!
        if tableView.tag == agencyTag {
            
            car4sshopModel = self.car4sshops?.objectAtIndex(indexPath.row) as! Car4sshopModel
        }else if tableView.tag == searchTag {
            
            car4sshopModel = self.searchResult?.objectAtIndex(indexPath.row) as! Car4sshopModel
        }
        
        let car4sshopDetailController: Car4sshopDetailController = Car4sshopDetailController(car4sshopModel: car4sshopModel)
        self.navigationController?.pushViewController(car4sshopDetailController, animated: true)
    }
    
    // MARK: UITextFieldDelegate
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        if textField.text!.isEmpty
        {
            textField.placeholder = "请输入地址查询"
        }
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        textField.placeholder = ""
    }
    
    // MARK: ProvinceListControllerDelegate
    func didSelectedProvince(currentSelectedProvince: ProvinceModel) {
        
        self.currentProvinceButton.setTitle(currentSelectedProvince.provName, forState: .Normal)
        self.car4sshopListManager.currentProvince = currentSelectedProvince
        self.getCar4sshopListFromCurrentSelectedProvince()
    }
}
