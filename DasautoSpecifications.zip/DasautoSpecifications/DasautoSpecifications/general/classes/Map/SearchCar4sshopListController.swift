//
//  SearchCar4sshopListController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-23.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit


class SearchCar4sshopListController: DasautoController, UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate {
    
    var searchHistoryTableView: UITableView!
    var searchResultTableView: UITableView!
    var searchTextField: MarginTextField!
    var clearButton: UIButton!
    var state: SearchCar4sshopListControllerState!
    var searchResult: NSArray?
    let historyTag: Int = 10001
    let resultTag: Int = 10002
    var searchSource: NSArray?
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("handleTextFieldChanged:"), name: UITextFieldTextDidChangeNotification, object: nil)
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UITextFieldTextDidChangeNotification, object: nil)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.configureTitle("搜索附近的4S维修中心")
        self.addSearchView()
        
        self.addSearchHistoryTableView()
        self.addSearchResultTableView()
        self.setHistoryState()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: NSNotificationCenter
    /**
    *  控制搜索框文本变化方法
    */
    func handleTextFieldChanged(notification: NSNotification) {
        
        if searchTextField?.text == "" {
            
            self.setHistoryState()
        }else {
            
            self.search()
        }
    }
    
    /**
     *  搜索搜索框内容
     */
    private func search() {
        
        self.setResultState()
        if searchSource != nil {
            
            let predicate: NSPredicate = NSPredicate(format: "(SELF.name CONTAINS %@) OR (SELF.letter CONTAINS %@)", argumentArray: [searchTextField.text!, searchTextField.text!])
            searchResult = searchSource?.filteredArrayUsingPredicate(predicate)
        }
        self.searchResultTableView.reloadData()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  添加搜索框界面
    */
    private func addSearchView() {
        
        let searchBgImageView: UIImageView = UIImageView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 65))
        searchBgImageView.backgroundColor = UIColor.whiteColor()
        searchBgImageView.image = UIImage(named: "search_bg")
        
        searchTextField = MarginTextField(frame: CGRectMake(30, 15, CGRectGetWidth(self.view.bounds) - 100, 35))
        searchTextField.font = UIFont.systemFontOfSize(14)
        searchTextField.layer.borderColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.5).CGColor
        searchTextField.layer.borderWidth = 1
        searchTextField.setLeftMargin(10)
        searchTextField.delegate = self
        searchTextField.returnKeyType = UIReturnKeyType.Done
        searchTextField.placeholder = "请输入关键字"
        searchTextField.textAlignment = NSTextAlignment.Center
        
        clearButton = UIButton(frame: CGRectMake(CGRectGetMaxX(searchTextField!.frame) + 5, 15, 40, 35))
        clearButton?.addTarget(self, action: Selector("clearSearchText"), forControlEvents: .TouchUpInside)
        clearButton?.setImage(UIImage(named: "clear"), forState: .Normal)
        
        self.view.addSubview(searchBgImageView)
        self.view.addSubview(searchTextField!)
        self.view.addSubview(clearButton!)
    }
    
    /**
     *  添加搜索历史界面
     */
    func addSearchHistoryTableView() {
        
        searchHistoryTableView = UITableView(frame: CGRectMake(0, 65, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds) - 65 - 64))
        searchHistoryTableView.tag = historyTag
        searchHistoryTableView.delegate = self
        searchHistoryTableView.dataSource = self
        self.view.addSubview(searchHistoryTableView)
        self.setExtraCellLineHidden(searchHistoryTableView)
    }
    
    /**
     *  添加搜索结果界面
     */
    func addSearchResultTableView() {
        
        searchResultTableView = UITableView(frame: CGRectMake(0, 65, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds) - 65 - 64))
        searchResultTableView.tag = resultTag
        searchResultTableView.delegate = self
        searchResultTableView.dataSource = self
        self.view.addSubview(searchResultTableView)
        self.setExtraCellLineHidden(searchResultTableView)
    }
    
    private func setExtraCellLineHidden(tableView: UITableView) {
        
        let view: UIView = UIView()
        view.backgroundColor = UIColor.clearColor()
        tableView.tableFooterView = view
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中清除搜索
     */
    func clearSearchText() {
        
        self.searchTextField.text = ""
        self.searchTextField.resignFirstResponder()
        self.setHistoryState()
        
        if self.searchTextField.text!.isEmpty {
            self.searchTextField.placeholder = "请输入关键字"
        }
    }
    
    // MARK:
    // MARK: 设置 SearchCar4sshopListControllerState
    /**
    *  设置搜索历史状态
    */
    private func setHistoryState() {
        
        self.state = SearchCar4sshopListControllerState.Normal
        self.searchHistoryTableView.hidden = false
        self.searchResultTableView.hidden = true
        self.searchHistoryTableView.reloadData()
    }
    
    /**
    *  设置搜索结果状态
    */
    private func setResultState() {
        
        self.state = SearchCar4sshopListControllerState.Result
        self.searchHistoryTableView.hidden = true
        self.searchResultTableView.hidden = false
    }
    
    // MARK: 
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView.tag == historyTag {
            
            let searchHitories: NSArray? = SearchHistoryManager.sharedInstance.searchHistories
            return (searchHitories != nil) ? searchHitories!.count : 0
        }else if tableView.tag == resultTag {
            
            return (searchResult != nil) ? searchResult!.count : 0
        }else{
            
            return 0
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var identifier: String!
        if tableView.tag == historyTag {
            
            identifier = "historyCellIdentifier"
        }else if tableView.tag == resultTag {
            
            identifier = "resultCellIdentifier"
        }
        var cell: UITableViewCell?
        cell = tableView.dequeueReusableCellWithIdentifier(identifier)
        if cell == nil {
            
            cell = UITableViewCell(style: .Default, reuseIdentifier: identifier)
        }
        
        if tableView.tag == historyTag {
            
            cell?.accessoryType = UITableViewCellAccessoryType.None
            cell?.textLabel!.text = SearchHistoryManager.sharedInstance.searchHistories?.objectAtIndex(indexPath.row) as? String
        }else if tableView.tag == resultTag {
            
            cell?.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
            let car4sshopModel: Car4sshopModel = searchResult?.objectAtIndex(indexPath.row) as! Car4sshopModel
            cell?.textLabel!.text = car4sshopModel.name
        }
        
        return cell!
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if tableView.tag == historyTag {
            
            self.searchTextField.text = SearchHistoryManager.sharedInstance.searchHistories?.objectAtIndex(indexPath.row) as? String
            SearchHistoryManager.sharedInstance.insertKey(self.searchTextField.text!)
            self.search()
        }else if tableView.tag == resultTag {
            
            let car4sshopModel: Car4sshopModel = searchResult?.objectAtIndex(indexPath.row) as! Car4sshopModel
            let car4sshopDetailController: Car4sshopDetailController = Car4sshopDetailController(car4sshopModel: car4sshopModel)
            self.navigationController?.pushViewController(car4sshopDetailController, animated: true)
        }
    }
    
    func tableView(tableView: UITableView, titleForDeleteConfirmationButtonForRowAtIndexPath indexPath: NSIndexPath) -> String? {
        
        return "删除"
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        
        if tableView.tag == historyTag {
            return true
        }else {
            return false
        }
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if editingStyle == UITableViewCellEditingStyle.Delete {
            SearchHistoryManager.sharedInstance.removeKey(SearchHistoryManager.sharedInstance.searchHistories!.objectAtIndex(indexPath.row) as! String)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
            self.searchHistoryTableView.reloadData()
        }
    }
    
    // MARK: UITextFiledDelegate
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        if textField.text != "" {
            SearchHistoryManager.sharedInstance.insertKey(textField.text!)
            self.search()
            textField.resignFirstResponder()
        }
        return true
    }
    
     func textFieldDidBeginEditing(textField: UITextField) {
        textField.placeholder = ""
    }
}
