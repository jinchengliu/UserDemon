/*
*  filename: HotSpotViewController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/04.
*  copyright: bdcluster
*/

import UIKit
import AVFoundation

class HotSpotViewController: DasautoController, UIScrollViewDelegate, iCarouselDelegate, iCarouselDataSource{
    
    var mainScrollView: UIScrollView!
    var leftImageView: UIImageView!
    var rightImageView: UIImageView!
    
    var backButton: ThemeButton?
    var iCarouselView: iCarousel!
    var hotButton: UIButton!
    var enLargeButton: UIButton!
    
    var directory: DasAutoFile!
    var indexLeaf: DasAutoFile!
    var fildId: Int = 7
    
    var indexLeafArray:NSMutableArray!
    
    var orientation: UIInterfaceOrientation!
    var hiddenStatus = true
    var hotSpotName: String!
    var hotButtonAppear = false
    
    var count: Int!
    var w: CGFloat!
    var h: CGFloat!
    
    var progrossHUD = MBProgressHUD()
    var index:Int!
    var imageView:UIImageView!
    var isPoritate:Bool!
    var hasSpotView:Bool = false
    var whetherFormAR:String!
    var fromARIndex:String!
    var  whetherFromQuickGuide:String!
    var  quickGuideName:String!
    var mutableArray:NSMutableArray!
    
    // MARK:
    // MARK:Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        
        UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewDidAppear(animated: Bool) {
        
    }
    
    func loadImage(leaf:DasAutoFile) {
        self.configureDirectory()
        
        for(var i=0;i<self.directory.children.count;i++)
        {
            let file:DasAutoFile = self.directory.children[i]
            
            if self.quickGuideName != nil
            {
                if self.quickGuideName == file.name
                {

                    self.mutableArray = NSMutableArray(array: self.directory.children)
                    mutableArray.exchangeObjectAtIndex(0, withObjectAtIndex: i)
//                    self.directory.children = NSArray(array: self.mutableArray) as! [DasAutoFile]
                }
            }
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        w = CGRectGetWidth(self.view.bounds)
        h = CGRectGetHeight(self.view.bounds)
        
        self.view.backgroundColor = UIColor.blackColor()
        self.configureDirectory()
        self.configureHotSpotBackButton()
        self.configureWhetherFullScreenButton()
        
        //--change--
        let rOne:NSThread = NSThread(target: self, selector: "configureScrollView", object: nil)
        rOne.start()
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        UIApplication.sharedApplication().setStatusBarHidden(false, withAnimation: UIStatusBarAnimation.None)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func shouldAutorotate() -> Bool {
        
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        
       return UIInterfaceOrientationMask.Portrait
    }
 
    // MARK:
    // MARK: Configure Directory
    /**
    *  获取热点图片
    */
    func configureDirectory() {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.fildId)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as DasAutoFile
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置滚动视图(竖屏)
    */
    func configureScrollView() {
        
        progrossHUD.show(true)
        progrossHUD.labelText = "正在加载"
        progrossHUD.labelColor = UIColor.blackColor()
        progrossHUD.color = UIColor.grayColor()
        self.view.insertSubview(progrossHUD, aboveSubview: self.view)
        
        mainScrollView = UIScrollView(frame: CGRectMake(0, 0, w, w  * 9 / 16))   // (9 / 16)图片的高宽比
        mainScrollView.bounces = false
        mainScrollView.delegate = self
        mainScrollView.scrollEnabled = false
        mainScrollView.pagingEnabled = true
        mainScrollView.clipsToBounds = false
        mainScrollView.center = self.view.center
        mainScrollView.showsHorizontalScrollIndicator = false
        mainScrollView.showsHorizontalScrollIndicator = false
        self.view.addSubview(mainScrollView)
        
        imageView = UIImageView(frame: CGRectMake(0, 0, mainScrollView.frame.size.width, mainScrollView.frame.size.height))
        // ---change--- 之前手势是添加在imageView
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onImageViewTapGesture:"))
        imageView.userInteractionEnabled = true
        mainScrollView.addSubview(imageView)
        
        count = self.directory.children.count //    (1-------9)
        
        for file in self.directory.children {
            
//            var f = file as DasAutoFile
            Logger.info(file.name)
        }
        
        var leaf = self.directory.children[0] as DasAutoFile
        
        //---change--
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true" {
                leaf = self.mutableArray[0] as! DasAutoFile
            }
        }
        
        if self.whetherFormAR != nil  {
            if self.whetherFormAR == "true" {
                leaf = self.directory.children[Int(self.fromARIndex)!] as DasAutoFile
            }
        }
        
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        imageView.image = image
        
        for var j = 0; j < leaf.children.count; j++ {
            
            let childrenLeaf = leaf.children[j] as DasAutoFile
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let hotSpotButton = UIButton(frame: CGRectMake(w / size!.width * x - 15 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30))
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }
        index = 0
        isPoritate = true
        
         // 添加左右点击按钮视图
        leftImageView = UIImageView(frame: CGRectMake(2, (h - 45) / 2, 45, 45))
        leftImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onLeftImgeViewTapGesture:"))
        leftImageView.userInteractionEnabled = true
        leftImageView.image = UIImage(named: "beforeImage")
        self.view.addSubview(leftImageView)
        
        rightImageView = UIImageView(frame: CGRectMake(w - 47, (h - 45) / 2, 45, 45))
        rightImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onRightImgeViewTapGesture:"))
        rightImageView.userInteractionEnabled = true
        rightImageView.image = UIImage(named: "nextImage")
        self.view.addSubview(rightImageView)
        
        //---change--
        let rTwo:NSThread = NSThread(target: self, selector: "configureICarouselView", object: nil)
        rTwo.start()
    }
    
    /**
    *  配置iCarouselView
    */
    func configureICarouselView() {
        
        iCarouselView = iCarousel(frame: CGRectMake(0, h - 70, self.view.bounds.size.width, 50))
        iCarouselView.delegate = self
        iCarouselView.dataSource = self
        iCarouselView.type = iCarouselTypeRotary
        self.view.addSubview(iCarouselView)
        iCarouselView.hidden = false
        
        progrossHUD.hide(true)
    }
    
    /**
    *  配置返回按钮
    */
    func configureHotSpotBackButton() {
        
        self.backButton = ThemeButton(frame: CGRectMake(10, 20, 48, 48))
        self.backButton?.setImage(UIImage(named: "hotBack" + themeColor), forState: .Normal)
        self.backButton?.addTarget(self, action: Selector("dismissController:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(self.backButton!)
    }
    
    /**
     *  Configure Custom AlertView
     */
    func customAlertViewAppear() {
        
        let label = UILabel(frame: CGRectMake(0, 0, 200, 50))
        label.layer.cornerRadius = 5
        label.layer.masksToBounds = true
        label.backgroundColor = UIColor.grayColor()
        label.textColor = UIColor.whiteColor()
        label.textAlignment = NSTextAlignment.Center
        label.center = self.view.center
        label.text = "没有资源"
        label.hidden = true
        self.view.insertSubview(label, aboveSubview: self.mainScrollView)
        UIView.animateWithDuration(2.5, animations: { () -> Void in
            
            label.hidden = false
            }) { (complete) -> Void in
                
                UIView.animateWithDuration(2, animations: { () -> Void in
                    
                    label.alpha = 0
                    }, completion: { (complete) -> Void in
                        
                        label.removeFromSuperview()
                })
        }
    }
    
    /**
    *  配置切屏按钮
    */
    func configureWhetherFullScreenButton() {
        enLargeButton = UIButton(frame: CGRectMake(w - 43, 20, 40, 40))
        enLargeButton.setImage(UIImage(named: "cellPhone"), forState: UIControlState.Normal)
        enLargeButton.imageEdgeInsets = UIEdgeInsetsMake(10, 7, 10, 13)
        enLargeButton.addTarget(self, action: "onEnLargeButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(enLargeButton)
    }
    
    /**
     *  removeSpotView
     */
    func removeSpotView()
    {
        if hasSpotView == true {
            let spotView:AnyObject? = imageView.viewWithTag(12344321)
            if spotView != nil {
                spotView!.removeFromSuperview()
                hasSpotView = false
            }
        }
    }
    
    /**
     *  removeHotButtonFromSuperView
     */
    func removeHotButtonFromSuperView() {
        
        if hotButtonAppear == true {
            hotButton.removeFromSuperview()
            hotButtonAppear = false
        }
    }
    
    /**
    *  移除hotButton
    */
    func removeHotSpotButtonFromSuperView() {
        
        let spotView:AnyObject? = imageView.viewWithTag(12344321)
        if spotView != nil {
            spotView!.removeFromSuperview()
        }
        
        for button in imageView.subviews {
            if button is UIButton {
                (button as! UIButton).removeFromSuperview()
            }
        }
    }
    
    // MARK:
    // MARK: Refresh Frame
    /**
    *  横屏时UI的frame
    */
    func setUIFrameAtLandRight() {

        isPoritate   = false
        iCarouselView.hidden = true
        
        self.view.layer.transform = CATransform3DMakeRotation(CGFloat(M_PI_2), 0, 0, 1)
        self.view.layer.frame = CGRectMake(0, 0, CGRectGetWidth(UIScreen.mainScreen().bounds),CGRectGetHeight(UIScreen.mainScreen().bounds))
        
        enLargeButton.frame = CGRectMake(h - 50, 10, 40, 40)
        enLargeButton.imageEdgeInsets = UIEdgeInsetsMake(8, 5, 8, 11)
        leftImageView.frame = CGRectMake(10, (w - 45) / 2, 45, 45)
        rightImageView.frame = CGRectMake(h - 55, (w - 45) / 2, 45, 45)
        
        self.view.insertSubview(backButton!, aboveSubview: mainScrollView)
        self.view.insertSubview(enLargeButton, aboveSubview: mainScrollView)
        self.view.insertSubview(leftImageView, aboveSubview: mainScrollView)
        self.view.insertSubview(rightImageView, aboveSubview: mainScrollView)
        mainScrollView.frame = CGRectMake(0, 0, h, w)
        imageView.frame = CGRectMake(0, 0, mainScrollView.frame.size.width, mainScrollView.frame.size.height)
        
        var leaf = self.directory.children[index] as DasAutoFile
        
        //--change--
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true" {
                leaf = self.mutableArray[index] as! DasAutoFile
            }
        }
        
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        
        self.removeHotSpotButtonFromSuperView()
        for var j = 0; j < leaf.children.count; j++ {
            
            let childrenLeaf = leaf.children[j] as DasAutoFile
            
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let a = h/w
            
            let hotSpotButton = UIButton(frame: CGRectMake((w / size!.width * x - 15)*a+10 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y-15, 30, 30))
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }

        iCarouselView.frame = CGRectMake((h - 85 * 3) / 2, w - 70, 85 * 3, 50)
    }
    
    /**
    *  竖屏时UI的frame
    */
     func setUIFrameAtPoritate()
     {
        isPoritate = true
        iCarouselView.hidden = false
        
        self.view.layer.transform = CATransform3DIdentity
        self.view.layer.frame = CGRectMake(0, 0, w,h)
        
        enLargeButton.frame = CGRectMake(w - 43, 10, 40, 40)
        enLargeButton.imageEdgeInsets = UIEdgeInsetsMake(10, 7, 10, 13)
        leftImageView.frame = CGRectMake(2, (h - 45) / 2, 45, 45)
        rightImageView.frame = CGRectMake(w - 47, (h - 45) / 2, 45, 45)
        
        iCarouselView.frame = CGRectMake((w - 85 * 3) / 2, h - 70, 85 * 3, 50)
        mainScrollView.frame = CGRectMake(0, 0, w, w  * 9 / 16)
        mainScrollView.center = self.view.center
        imageView.frame = CGRectMake(0, 0, mainScrollView.frame.size.width, mainScrollView.frame.size.height)
        
        var leaf = self.directory.children[index] as DasAutoFile
        //---change--
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true" {
                leaf = self.mutableArray[index] as! DasAutoFile
            }
        }
        
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        imageView.image = image
        
        self.removeHotSpotButtonFromSuperView()
        for var j = 0; j < leaf.children.count; j++ {

            let childrenLeaf = leaf.children[j] as DasAutoFile
            
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let hotSpotButton = UIButton(frame: CGRectMake(w / size!.width * x - 15 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30))
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }
     }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    func dismissController(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    /**
    *  选中切屏
    */
    func onEnLargeButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        // 横竖切换
        if sender.selected == true {
            
            self.setUIFrameAtPoritate()
            
        }else {
            
            self.setUIFrameAtLandRight()
        }
        sender.selected = !sender.selected
    }
    
    /**
    *  点击显示热点button的方法(传值)
    */
    func onHtoSpotViewButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if indexLeaf != nil
        {
            let htmlVC = HotSpotHtmlController()
            htmlVC.leaf = self.indexLeaf
            self.presentViewController(htmlVC, animated: true, completion: nil)
        }else if self.indexLeafArray.count > 0
        {
            let htmlVC = HotSpotHtmlController()
            //            var le = indexLeafArray[sender.tag-1234] as! DasAutoFile
            htmlVC.leaf = indexLeafArray[sender.tag-1234] as! DasAutoFile
            self.presentViewController(htmlVC, animated: true, completion: nil)
        }
        else {
            self.customAlertViewAppear()
        }
    }
    
    /**
    *  选中热点Button
    */
    func onHotSpotButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let frame = sender.frame
        let resId = String(sender.tag)
        var refResId: String!
        var index = "no"
        var name: String!
        
        self.indexLeafArray  = NSMutableArray()
        /*
        
        self.directory.children.count = 9       9张图片
        var leaf = self.directory.children[i]   每张图片 leaf表示
        leaf.children.count=2                   2个热点
        childrenLeaf = leaf.children[1]         单个热点   可能对应多条数据
        
        */
        for var i = 0; i < count; i++
        {
            var leaf = self.directory.children[i] as DasAutoFile
            //--change--
            if self.whetherFromQuickGuide != nil
            {
                if self.whetherFromQuickGuide == "true"
                {
                    leaf = self.mutableArray[i] as! DasAutoFile
                }
            }

            for var j = 0; j < leaf.children.count; j++
            {
                
                let childrenLeaf = leaf.children[j] as DasAutoFile
                if resId == childrenLeaf.resourceId
                {
                    if childrenLeaf.children.count == 1
                    {
                        let le = childrenLeaf.children[0] as DasAutoFile
                        name = (childrenLeaf.children[0] as DasAutoFile).name
                        refResId = le.refResourceId
                    }else
                    {
                        for var i = 0; i < childrenLeaf.children.count; i++
                        {
                            name = (childrenLeaf.children[i] as DasAutoFile).name
                            let le = childrenLeaf.children[i] as DasAutoFile
                            refResId = le.refResourceId
                            self.indexLeafArray.addObject(le)
                        }
                    }
                }
            }
        }
        
        //判断长度
        var cnt:CGFloat
        if indexLeafArray.count > 0 {
            
            var temp:CGFloat = 0
            for var k = 0; k < indexLeafArray.count; k++ {
                let l = CGFloat(((indexLeafArray[k] as! DasAutoFile).name as NSString).length)
                
                if l > temp {
                    temp = l
                }
            }
            cnt = temp
            if cnt > 15 {
                cnt = 14
            }
            
        }else {
            cnt = CGFloat((name as NSString).length)
            if cnt > 15 {
                cnt = 14
            }
        }
        
        if indexLeafArray.count > 0 {
            if hasSpotView == true {
                self.removeSpotView()
            }
            if hotButtonAppear == true {
                self.removeHotButtonFromSuperView()
            }
            indexLeaf = nil
            
            let spotView:UIView = UIView(frame: CGRectMake(frame.origin.x + 15 - (cnt * 20 + 20) / 2, frame.origin.y - 28, cnt * 20 + 20, CGFloat(32*indexLeafArray.count)))
            spotView.tag = 12344321
            spotView.backgroundColor = UIColor.clearColor()
            imageView.addSubview(spotView)
            spotView.userInteractionEnabled = true
            spotView.layer.cornerRadius = 5.0
            spotView.layer.masksToBounds = true
            
            for var k = 0; k < indexLeafArray.count; k++ {
                let resindex = (indexLeafArray[k] as! DasAutoFile).resIndex
                let singleName = (indexLeafArray[k] as! DasAutoFile).name
                let button = UIButton(frame: CGRectMake(0, CGFloat(32*(k)), cnt * 20 + 20, 32))
                button.backgroundColor = UIColor.whiteColor()
                button.setImage(UIImage(named: "rightArrow" + themeColor), forState: UIControlState.Normal)
                button.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
                button.addTarget(self, action: "onHtoSpotViewButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
                button.setTitle(singleName, forState: UIControlState.Normal)
                button.titleEdgeInsets = UIEdgeInsetsMake(3, 0, 3, 18)
                button.imageEdgeInsets = UIEdgeInsetsMake(8, cnt * 20 + 2, 8, 8)
                button.titleLabel?.font = UIFont.systemFontOfSize(15)
                button.titleLabel?.textAlignment = NSTextAlignment.Right
                button.titleLabel?.numberOfLines = 0
                button.userInteractionEnabled = true
                button.tag = 1234+k
                spotView.addSubview(button)
            }
            for var k = 0; k < indexLeafArray.count; k++ {
                if k != indexLeafArray.count-1 {
                    let line:UIView = UIView(frame: CGRectMake(0,CGFloat(32*(k+1)),cnt * 20 + 20, 0.5))
                    line.alpha = 0.7
                    line.backgroundColor = UIColor.grayColor()
                    spotView.addSubview(line)
                    spotView.bringSubviewToFront(line)
                }
            }
            hasSpotView = true
        }else {
            if hasSpotView == true {
                self.removeSpotView()
            }
            if hotButtonAppear == true {
                self.removeHotButtonFromSuperView()
            }
            
            hotButton = UIButton(frame: CGRectMake(frame.origin.x + 15 - (cnt * 20 + 20) / 2, frame.origin.y - 28, cnt * 20 + 20, 32))
            hotButton.backgroundColor = UIColor.whiteColor()
            hotButton.setImage(UIImage(named: "rightArrow" + themeColor), forState: UIControlState.Normal)
            hotButton.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
            hotButton.addTarget(self, action: "onHtoSpotViewButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotButton.setTitle(name, forState: UIControlState.Normal)
            hotButton.titleEdgeInsets = UIEdgeInsetsMake(3, 0, 3, 18)
            hotButton.imageEdgeInsets = UIEdgeInsetsMake(8, cnt * 20 + 2, 8, 8)
            hotButton.titleLabel?.font = UIFont.systemFontOfSize(15)
            hotButton.titleLabel?.textAlignment = NSTextAlignment.Right
            hotButton.titleLabel?.numberOfLines = 0
            hotButton.userInteractionEnabled = true
            hotButton.layer.cornerRadius = 5
            hotButton.layer.masksToBounds = true
            imageView.addSubview(hotButton)
            
            hotButtonAppear = true
        }
        
        if name != "没有简介" {
            // 用户手册
            PackageFileManager.sharedInstance.rootFile.findFileWithFileId(3)
            let userManualFile = PackageFileManager.sharedInstance.rootFile.result as DasAutoFile
            for var i = 0; i < userManualFile.children.count; i++ {
                
                let manualLeaf = userManualFile.children[i] as DasAutoFile
                for var j = 0; j < manualLeaf.children.count; j++ {
                    
                    let childrenLeaf = manualLeaf.children[j] as DasAutoFile
                    for var k = 0; k < childrenLeaf.children.count; k++ {
                        
                        let leaf = childrenLeaf.children[k] as DasAutoFile
                        if indexLeafArray.count > 0
                        {
                            for var k = 0; k < indexLeafArray.count; k++
                            {
                                let file = indexLeafArray[k] as! DasAutoFile
                                if file.refResourceId != nil {
                                    
                                    if file.refResourceId == leaf.resourceId
                                    {
                                        
                                        indexLeafArray.replaceObjectAtIndex(k, withObject: leaf)
                                    }
                                }
                            }
                        }else
                        {
                            if refResId == leaf.resourceId
                            {
                                
                                indexLeaf = leaf
                                index = leaf.resIndex
                            }
                        }
                    }
                }
            }
        }else {
            
            indexLeaf = nil
            index = "yes"
        }
        
        if index == "no" {
            
            // otherRes
            PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
            let hotSpotH5File = PackageFileManager.sharedInstance.rootFile.result as DasAutoFile
            
            for var i = 0; i < hotSpotH5File.children.count; i++ {
                let leaf = hotSpotH5File.children[i] as DasAutoFile
                if indexLeafArray.count > 0 {
                    for var k=0;k<indexLeafArray.count;k++ {
                        let file = indexLeafArray[k] as! DasAutoFile
                        if file.refResourceId != nil {
                            
                            if file.refResourceId == leaf.resourceId {
                                indexLeafArray.replaceObjectAtIndex(k, withObject: leaf)
                            }
                        }
                    }
                }else {
                    if refResId == leaf.resourceId {
                        index = leaf.resIndex
                        indexLeaf = leaf
                    }
                }
            }
            
            // 应急服务
            PackageFileManager.sharedInstance.rootFile.findFileWithFileId(6)
            let emergencyFile = PackageFileManager.sharedInstance.rootFile.result as DasAutoFile
            
            for var i = 0; i < emergencyFile.children.count; i++ {
                let leaf = emergencyFile.children[i] as DasAutoFile
                if leaf.resourceId != nil {
                    
                    if indexLeafArray.count > 0 {
                        for var k=0;k<indexLeafArray.count;k++ {
                            let file = indexLeafArray[k] as! DasAutoFile
                            if file.refResourceId != nil {
                                
                                if file.refResourceId == leaf.resourceId {
                                    indexLeafArray.replaceObjectAtIndex(k, withObject: leaf)
                                }
                            }
                        }
                    }else {
                        if refResId == leaf.resourceId {
                            index = leaf.resIndex
                            indexLeaf = leaf
                        }
                    }
                }
            }
        }
        
        //快速指南
        for var k = 0; k < indexLeafArray.count; k++ {
            let resindex = (indexLeafArray[k] as! DasAutoFile).resIndex
            if resindex == nil {
                PackageFileManager.sharedInstance.rootFile.findFileWithFileId(1)
                let hotSpotH5File = PackageFileManager.sharedInstance.rootFile.result as DasAutoFile
                
                for var i = 0; i < hotSpotH5File.children.count; i++ {
                    let leaf = hotSpotH5File.children[i] as DasAutoFile
                    if indexLeafArray.count > 0 {
                        for var k=0;k<indexLeafArray.count;k++ {
                            let l = indexLeafArray[k] as! DasAutoFile
                            
                            if l.refResourceId != nil {
                                if l.refResourceId == leaf.resourceId {
                                    indexLeafArray.replaceObjectAtIndex(k, withObject: leaf)
                                }
                            }
                        }
                    }else {
                        if refResId == leaf.resourceId {
                            
                            index = leaf.resIndex
                            indexLeaf = leaf
                        }
                    }
                }
            }
        }
    }
    
    // MARK:
    // MARK: UITapGestureRecognizer
    /**
    *  点击imageView
    */
    func onImageViewTapGesture(tapGesture: UITapGestureRecognizer) {
        
        self.removeHotButtonFromSuperView()
        self.removeSpotView()
    }
    
    /**
     *  点击rightImageView
     */
    func onRightImgeViewTapGesture(tapGesture: UITapGestureRecognizer) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        count = self.directory.children.count
        if index < count-1 {
            index = index+1
            self.iCarouselView.scrollToItemAtIndex(index, animated: true)
        }else {
            index = 0
            self.iCarouselView.scrollToItemAtIndex(0, animated: true)
        }
        
        var leaf = self.directory.children[index] as DasAutoFile
        //---change---
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true" {
                leaf = self.mutableArray[index] as! DasAutoFile
            }
        }
        
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        imageView.image = image
        
        self.removeHotSpotButtonFromSuperView()
        for var j = 0; j < leaf.children.count; j++ {
            
            let childrenLeaf = leaf.children[j] as DasAutoFile
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let hotSpotButton = UIButton()
            if isPoritate == true
            {
                hotSpotButton.frame = CGRectMake(w / size!.width * x - 15 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }else
            {
                let a = h/w
                hotSpotButton.frame = CGRectMake((w / size!.width * x - 15)*a+10 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }
            
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }
    }
    
    /**
     *  点击leftImageView
     */
    func onLeftImgeViewTapGesture(tapGesture: UITapGestureRecognizer) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        count = self.directory.children.count
        if index > 0
        {
            index = index-1
            self.iCarouselView.scrollToItemAtIndex(index, animated: true)
        }else
        {
            index = count-1
            self.iCarouselView.scrollToItemAtIndex(count-1, animated: true)
        }
        
        var leaf = self.directory.children[index] as DasAutoFile
        //---change--
        if self.whetherFromQuickGuide != nil
        {
            if self.whetherFromQuickGuide == "true"
            {
                leaf = self.mutableArray[index] as! DasAutoFile
            }
        }
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        imageView.image = image
        
        self.removeHotSpotButtonFromSuperView()
        
        for var j = 0; j < leaf.children.count; j++
        {
            
            let childrenLeaf = leaf.children[j] as DasAutoFile
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let hotSpotButton = UIButton()
            if isPoritate == true
            {
                hotSpotButton.frame = CGRectMake(w / size!.width * x - 15 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }else
            {
                let a = h/w
                hotSpotButton.frame = CGRectMake((w / size!.width * x - 15)*a+10 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }
            
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }
    }
    
    // MARK: 
    // MARK: iCarouselDataSource
    func numberOfItemsInCarousel(carousel: iCarousel!) -> UInt {
        
        return UInt(count)
    }
    
    func numberOfPlaceholdersInCarousel(carousel: iCarousel!) -> UInt {
        
        return 0
    }
    
    func numberOfVisibleItemsInCarousel(carousel: iCarousel!) -> UInt {
        
        return 3
    }
    
    func carousel(carousel: iCarousel!, viewForItemAtIndex index: UInt) -> UIView! {

        let imageView = UIImageView(frame: CGRectMake(0, 0, 112, 63))

        var leaf = self.directory.children[Int(index)] as DasAutoFile
        //--change--
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true" {
                leaf = self.mutableArray[Int(index)] as! DasAutoFile
            }
        }
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        imageView.image = UIImage(contentsOfFile: path)
        
        return imageView
    }

    func carouselItemWidth(carousel: iCarousel!) -> CGFloat {
        
        return 112+200
    }
    
    // MARK: iCarouselDelegate
    func carousel(carousel: iCarousel!, transformForItemView view: UIView!, withOffset offset: CGFloat) -> CATransform3D {
        
        view.alpha = 1.0 - fmin(fmax(offset, 0.0), 1.0)
        var transform: CATransform3D = CATransform3DIdentity
        transform.m34 = self.iCarouselView.perspective
        transform = CATransform3DRotate(transform, CGFloat(M_PI / 8.0), 0, 1.0, 0)
        
        return CATransform3DTranslate(transform, 0.0, 0.0, offset * iCarouselView.itemWidth)
    }
    
    func carouselShouldWrap(carousel: iCarousel!) -> Bool {
        
        return true
    }
 
    func carouselDidEndDragging(carousel: iCarousel!, willDecelerate decelerate: Bool) {
        
        iCarouselView.reloadData()
    }
   
   func carouselDidEndScrollingAnimation(carousel: iCarousel!) {

        var leaf = self.directory.children[carousel.currentItemIndex] as DasAutoFile
        //--change--
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true" {
                leaf = self.mutableArray[carousel.currentItemIndex] as! DasAutoFile
            }
        }

        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        imageView.image = image
        
        self.removeHotSpotButtonFromSuperView()
        
        for var j = 0; j < leaf.children.count; j++ {
            
            var hotspotX:String!
            var hotspotY:String!
            var resourceId:String!
            
            let childrenLeaf = leaf.children[j] as! DasAutoDirectory
            
            hotspotX = childrenLeaf.hotSpotX as String
            hotspotY = childrenLeaf.hotSpotY as String
            resourceId = childrenLeaf.resourceId
           
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let hotSpotButton = UIButton()
            if isPoritate == true
            {
                hotSpotButton.frame = CGRectMake(w / size!.width * x - 15 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }else
            {
                let a = h/w
                hotSpotButton.frame = CGRectMake((w / size!.width * x - 15)*a+10 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }
            
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
       }
    
       self.index = carousel.currentItemIndex
    }
    
    func carousel(carousel: iCarousel!, didSelectItemAtIndex index: Int) {
        
        Logger.info("\(index)")
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        var leaf = self.directory.children[index] as DasAutoFile
        if self.whetherFromQuickGuide != nil {
            if self.whetherFromQuickGuide == "true"
            {
                leaf = self.mutableArray[index] as! DasAutoFile
            }
        }

        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + leaf.picFile)
        let image = UIImage(contentsOfFile: path)
        let size = image?.size
        imageView.image = image
        
        self.removeHotSpotButtonFromSuperView()
        
        for var j = 0; j < leaf.children.count; j++ {
            
            let childrenLeaf = leaf.children[j] as DasAutoFile
            
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let hotSpotButton = UIButton()
            if isPoritate == true {
                hotSpotButton.frame = CGRectMake(w / size!.width * x - 15 , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }else {
                let a = h/w
                hotSpotButton.frame = CGRectMake((w / size!.width * x - 15)*a , CGRectGetHeight(self.mainScrollView.frame) / size!.height * y - 15, 30, 30)
            }

            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }

        self.index = index
    }
}
