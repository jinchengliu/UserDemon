/*
*  filename: HotSpotScrollView.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/04.
*  copyright: bdcluster
*/

import UIKit

//scrollView scale parameter
let kMinZoomScale: CGFloat = 1.0
let kMaxZoomScale: CGFloat = 3.0
//detailView arrow parameter
let kArrowWidth: CGFloat = 8
let kArrowHeight: CGFloat = 8
//remove detail view timer duration
let kRemoveDetailViewDuration: NSTimeInterval = 8.0
//hot spot button width and height
let kHotSpotButtonWidthAndHeight: CGFloat = 18

class HotSpotScrollView: UIScrollView, UIScrollViewDelegate {
    
    init(frame: CGRect, image: UIImage, hotSpotModels: NSArray) {
        super.init(frame: frame)
        self.clipsToBounds = true
        self.minimumZoomScale = kMinZoomScale
        self.maximumZoomScale = kMaxZoomScale
        self.delegate = self
//        self.autoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight
        
        var hotSpotImageView: HotSpotImageView = HotSpotImageView(frame: CGRectMake(0, 0, CGRectGetWidth(frame), CGRectGetHeight(frame)), image: image, hotSpotModels: hotSpotModels)
        self.addSubview(hotSpotImageView)
    }
    
    required init(coder aDecoder: NSCoder) {
        
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:UIScrollViewDelegate
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        for subView in scrollView.subviews {
            if subView is HotSpotImageView {
                return subView as? UIView
            }
        }
        return nil
    }
}

class HotSpotImageView: UIImageView {
    
    init(frame: CGRect,image: UIImage, hotSpotModels: NSArray) {
        super.init(frame: frame)
        self.userInteractionEnabled = true
        self.image = image
        self.contentMode = UIViewContentMode.ScaleAspectFill
        for hotSpotModel in hotSpotModels {
            self.addHotSpotWithModel(hotSpotModel as HotSpotModel)
        }
    }
    
    //添加热点
    func addHotSpotWithModel(hotSpotModel: HotSpotModel) {
        var hotSpotButton: HotSpotButton = HotSpotButton(frame: CGRectMake(0, 0, kHotSpotButtonWidthAndHeight, kHotSpotButtonWidthAndHeight))
        hotSpotButton.hotSpotModel = hotSpotModel
        let x: CGFloat = CGFloat(hotSpotModel.x!.floatValue)
        let y: CGFloat = CGFloat(hotSpotModel.y!.floatValue)
        hotSpotButton.center = CGPointMake(x, y)
        hotSpotButton.backgroundColor = UIColor.redColor()
        hotSpotButton.layer.cornerRadius = kHotSpotButtonWidthAndHeight/2
        hotSpotButton.addTarget(self, action: Selector("showDetailView:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.addSubview(hotSpotButton)
    }
    
    //显示详情view
    func showDetailView(hotSpotButton: HotSpotButton) {
        let x: CGFloat = CGFloat(hotSpotButton.hotSpotModel!.x!.floatValue)
        let y: CGFloat = CGFloat(hotSpotButton.hotSpotModel!.y!.floatValue)
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            (self.superview as HotSpotScrollView).setZoomScale(2, animated: false)
            (self.superview as HotSpotScrollView).contentOffset = CGPointMake(x*2 - CGRectGetWidth(self.superview!.frame)/2, y*2 - CGRectGetHeight(self.superview!.frame)/2)
        })
        var detailView: HotSpotPopupView = HotSpotPopupView(description: hotSpotButton.hotSpotModel!.label!, filePath: hotSpotButton.hotSpotModel!.pointPath!)
        detailView.frame.origin.x = x - CGRectGetWidth(detailView.bounds)/2
        detailView.frame.origin.y = y - CGRectGetHeight(detailView.bounds)
        self.addSubview(detailView)
        
        detailView.layer.transform = CATransform3DMakeScale(0.8, 0.8, 0.5)
        UIView.animateWithDuration(0.3, animations: { () -> Void in
            detailView.layer.transform = CATransform3DMakeScale(1.1, 1.1, 1.1)
        }) { (completetion) -> Void in
            if completetion {
                UIView.animateWithDuration(0.2, animations: { () -> Void in
                    detailView.layer.transform = CATransform3DIdentity
                }, completion: { (completetion) -> Void in
                    if completetion {
                    }
                })
            }
        }

        NSTimer.scheduledTimerWithTimeInterval(kRemoveDetailViewDuration, target: self, selector: Selector("removeDetailView:"), userInfo: ["obj" : detailView], repeats: false)
    }
    
    //移除详情view
    func removeDetailView(timer: NSTimer) {
        var obj: UIView = timer.userInfo?.objectForKey("obj") as UIView
        UIView.animateWithDuration(0.5, animations: { () -> Void in
            obj.alpha = 0.0
        }) { (completetion) -> Void in
            if completetion {
                obj.removeFromSuperview()
            }
        }
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

/*
 *
 *  热点按钮，添加到HotSpotImageView上
 *
 */

class HotSpotButton: UIButton {
    
    var hotSpotModel: HotSpotModel?
    var timer: NSTimer?
    var isPlusPlus: Bool!        //判断alpha是＋＋还是－－
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.alpha = 0.7
        self.isPlusPlus = false
        timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: Selector("gradientEffectHandler"), userInfo: nil, repeats: true)
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func gradientEffectHandler() {
        if (self.alpha - 0.7) < 0.0000001 && (self.alpha - 0.7) > -0.0000001 {
            isPlusPlus = false
        }else if (self.alpha - 0.2) < 0.000001 && (self.alpha - 0.2) > -0.000001{
            isPlusPlus = true
        }
        
        if isPlusPlus == true {
            self.alpha+=0.05
        }else {
            self.alpha-=0.05
        }
    }
    
    deinit {
        timer?.invalidate()
        timer = nil
    }
}

/*
 *
 *  点击HotSpotButton按钮显示的详情页
 *
 */

class HotSpotPopupView: UIView {
    var descriptionLabel: UILabel?
    var detailButton: UIButton?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init(description: String, filePath: String) {
        super.init()
        self.backgroundColor = UIColor.clearColor()
        self.clipsToBounds = true
        let kHotSpotDetailViewHeight: CGFloat = 30
        var attrs: NSDictionary = NSDictionary(objectsAndKeys: UIFont(name: "Farah", size: 10)!,NSFontAttributeName)
        var descriptionRect: CGRect = NSString(string: description).boundingRectWithSize(CGSizeMake(100, 20), options: NSStringDrawingOptions.TruncatesLastVisibleLine, attributes: attrs, context: nil)
        descriptionLabel = UILabel(frame: CGRectMake(5, (kHotSpotDetailViewHeight - 20 - kArrowHeight)/2, descriptionRect.size.width, 20))
        descriptionLabel?.font = UIFont(name: "Farah", size: 10)
        descriptionLabel?.text = description
        descriptionLabel?.numberOfLines = 1
        self.addSubview(descriptionLabel!)
        
        let topPadding: CGFloat = 3.0
        detailButton = UIButton(frame: CGRectMake(CGRectGetMaxX(descriptionLabel!.frame) + 5, topPadding, kHotSpotDetailViewHeight - kArrowHeight - topPadding*2, kHotSpotDetailViewHeight - kArrowHeight - topPadding*2))
        detailButton?.setImage(UIImage(named: "info"), forState: .Normal)
        self.addSubview(detailButton!)
        
        self.layer.cornerRadius = 2
        self.frame = CGRectMake(0, 0, CGRectGetMaxX(detailButton!.frame) + 5, kHotSpotDetailViewHeight)
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:drawrect
    override func drawRect(rect: CGRect) {
        var context: CGContextRef = UIGraphicsGetCurrentContext()
        var radius: CGFloat = self.layer.cornerRadius
        var arrowWidth: CGFloat = kArrowWidth
        var arrowHeight: CGFloat = kArrowHeight
        
        var minx: CGFloat = CGRectGetMinX(self.bounds)
        var midx: CGFloat = CGRectGetMidX(self.bounds)
        var maxx: CGFloat = CGRectGetMaxX(self.bounds)
        var miny: CGFloat = CGRectGetMinY(self.bounds)
        var midy: CGFloat = CGRectGetMidY(self.bounds)
        var maxy: CGFloat = CGRectGetMaxY(self.bounds)
        
        CGContextMoveToPoint(context, midx - arrowWidth/2, maxy - arrowHeight);
        CGContextAddArcToPoint(context, minx, maxy - arrowHeight, minx, (maxy - arrowHeight)/2, radius)
        CGContextAddArcToPoint(context, minx, miny, midx, miny, radius)
        CGContextAddArcToPoint(context, maxx, miny, maxx, (maxy - arrowHeight)/2, radius)
        CGContextAddArcToPoint(context, maxx, maxy - arrowHeight, midx + arrowWidth/2, maxy - arrowHeight, radius)
        
        CGContextMoveToPoint(context, midx + arrowWidth/2, maxy - arrowHeight);
        CGContextAddLineToPoint(context, midx, maxy)
        CGContextAddLineToPoint(context, midx - arrowWidth/2, maxy - arrowHeight)
        
        CGContextClosePath(context);
        UIColor.whiteColor().setFill()
        CGContextDrawPath(context, kCGPathFill)
    }
}