//
//  HotSpotHtmlController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/5/20.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class HotSpotHtmlController: DasautoController, UIWebViewDelegate,UITableViewDelegate,UITableViewDataSource,ALMoviePlayerControllerDelegate{

    var webView: UIWebView!
    var grayBackView: UIView!
    var listButton: UIButton!
    var tableView: UITableView!
    
    var topView:UIView!
    var topLabel:InsetsLabel!
    var topButton:UIButton!
    var topImage:UIImageView!
    var progrossHUD = MBProgressHUD()
    
    
    var dataArray: NSArray!
    var request: NSURLRequest!
    var leaf: DasAutoFile!
    
    var numberWebPage = 0
    var hasRefresh = false
    
    var listName: String!
    var leafArray: NSMutableArray!
    var taskArray: NSMutableArray!
    
    var fileUrl:NSURL!   //根绝videoID判断是否有fileUrl
    var moviePlayer:ALMoviePlayerController!
    var topImageView:UIImageView!
    
    var sendLeaf:DasAutoFile!
    var downloadTask: NSURLSessionDownloadTask!
    
    var moviePlayerHeight: CGFloat!
    var listButtonHeight: CGFloat!
    var wdh: CGFloat!
    var hgt: CGFloat!
    
    var whetherFormAR:String!
    var videoId: String!
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        
        if self.whetherFormAR != "true" {
            let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
            let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
            self.webView.loadRequest(request!)
        }
    }
    override func viewDidAppear(animated: Bool) {
        
        if self.whetherFormAR != nil {
            if self.whetherFormAR == "true" {
                self.configureWebView()
                let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
                let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
                self.webView.loadRequest(request!)
                
                self.shouldConfigureVideoPlayer()
            }
        }
        if self.moviePlayer != nil {
            
            self.moviePlayer.pause()
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        self.configureNavigationBar()
        taskArray = NSMutableArray()
        leafArray = NSMutableArray()
        self.configureListButton()
        if self.whetherFormAR != "true" {
            self.configureWebView()
            self.shouldConfigureVideoPlayer()
        }
    }
    
    deinit {
        
        if self.downloadTask != nil {
            self.downloadTask.cancel()
        }
        
        if self.moviePlayer != nil {
            self.moviePlayer.stop()
            self.moviePlayer.delegate = nil
            self.moviePlayer = nil
        }
        
        Logger.info("deinit")
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置webView
    */
    func configureWebView() {
        
        leafArray.addObject(leaf)
        webView = UIWebView(frame: CGRectMake(0, 64, wdh, hgt - 64))
        webView.delegate = self
        self.view.addSubview(webView)
    }
    
    /**
    *  配置navigationBar
    */
    func configureNavigationBar() {
        
        wdh = CGRectGetWidth(self.view.bounds)
        hgt = CGRectGetHeight(self.view.bounds)
        
        self.navigationItem.title = leaf.name
        let navigationBar = UINavigationBar(frame: CGRectMake(0, 20, wdh, 44))
        navigationBar.barTintColor = UIColor.whiteColor()
        navigationBar.pushNavigationItem(navigationItem, animated: true)
        self.view.addSubview(navigationBar)
        
        let lineView = UIView(frame: CGRectMake(0, 43, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red: 223.0/255, green: 223.0/255, blue: 223.0/255, alpha: 1.0)
        navigationBar.addSubview(lineView)
        
        self.addBackBarButtonItem()
    }
    
    /**
    *  配置listButton
    */
    func configureListButton() {
        
        listButton = UIButton(frame: CGRectMake(0, hgt - 40, wdh, 40))
        listButton.setBackgroundImage(UIImage(named: "buttonList"), forState: UIControlState.Normal)
        listButton.setBackgroundImage(UIImage(named: "buttonListOn"), forState: UIControlState.Selected)
        listButton.addTarget(self, action: "onListButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        listButton.hidden = false
        self.view.addSubview(listButton)
    }
    
    /**
    *  配置tableView
    */
    func configureTableView() {
        
        grayBackView = UIView(frame: CGRectMake(0, 0, wdh, hgt - 40))
        grayBackView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onGrayBackViewTapGesture:"))
        grayBackView.backgroundColor = UIColor.grayColor()
        grayBackView.alpha = 0.66
        self.view.addSubview(grayBackView)
        
        let tableViewHeigth: CGFloat = CGFloat(dataArray.count * 44)
        if tableViewHeigth < CGRectGetHeight(self.grayBackView.bounds) {
            
            tableView = UITableView(frame: CGRectMake(0, CGRectGetHeight(self.grayBackView.bounds) - tableViewHeigth, CGRectGetWidth(self.view.bounds), tableViewHeigth))
        }else {
            
            tableView = UITableView(frame: CGRectMake(0, 20, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.grayBackView.bounds) - 20))
        }
        tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        tableView.dataSource = self
        tableView.delegate = self
        self.view.addSubview(tableView)
    }
    
    /**
     *  配置alertButton
     */
    func configureAlertView() {
        
        let alertButton = UIButton(frame: CGRectMake(0, 0, 200, 75))
        alertButton.setBackgroundImage(UIImage(named: "alertBackImage"), forState: UIControlState.Normal)
        alertButton.center = self.view.center
        
        self.view.addSubview(alertButton)
        
        let label = UILabel(frame: CGRectMake(0, 0, 200, 75))
        label.textAlignment = NSTextAlignment.Center
        label.textColor = UIColor.whiteColor()
        label.text = "网络连接失败!"
        alertButton.addSubview(label)
        
        UIView.animateWithDuration(3, animations: { () -> Void in
            
            alertButton.hidden = false
            }) { (complete) -> Void in
                
                UIView.animateWithDuration(2, animations: { () -> Void in
                    
                    alertButton.alpha = 0
                    }, completion: { (complete) -> Void in
                        
                        alertButton.removeFromSuperview()
                })
        }
    }
    
    
    
    /**
    *  配置视频播放器
    */
    func configureVideoPlayer(url:NSURL)
    {
        if self.moviePlayer == nil {
            
            let height = wdh*220/320
            
            self.moviePlayer = ALMoviePlayerController(frame: CGRectMake(0, 64, wdh, height))
            self.moviePlayer.view.alpha = 1
            self.moviePlayer.delegate = self
            
            let movieControls:ALMoviePlayerControls = ALMoviePlayerControls(moviePlayer: self.moviePlayer, style: ALMoviePlayerControlsStyleDefault)
            movieControls.timeRemainingDecrements = true
            movieControls.fadeDelay = 5.0
            movieControls.barHeight = 50
            movieControls.seekRate = 5.0
            
            self.moviePlayer.controls = movieControls
            self.view.addSubview(self.moviePlayer.view)
            
            self.moviePlayer.stop()
            self.moviePlayer.contentURL = url
            
            self.createTopView()
        }else {
            
            self.moviePlayer.stop()
            self.moviePlayer.contentURL = url
            self.moviePlayer.controls.isAppear = true
        }
        
        // ---change--
        for progross in self.moviePlayer.controls.subviews {
            
            if progross is MBProgressHUD {
                
                self.progrossHUD.removeFromSuperview()
                return
            }
        }
    }
    
    func configureVideoPlayer2(urlString:String) {
        
        moviePlayerHeight = wdh*220/320
        if self.moviePlayer == nil {
            
            let height = wdh*220/320
            self.moviePlayer = ALMoviePlayerController(frame: CGRectMake(0, 64, wdh, height))
            self.moviePlayer.delegate = self
            
            let movieControls:ALMoviePlayerControls = ALMoviePlayerControls(moviePlayer: self.moviePlayer, style: ALMoviePlayerControlsStyleDefault)
            movieControls.timeRemainingDecrements = true
            movieControls.fadeDelay = 5.0
            movieControls.barHeight = 50
            movieControls.seekRate = 5.0
            
            self.moviePlayer.controls = movieControls
            self.moviePlayer.controls.isAppear = false
            self.moviePlayer.controls.buttonClicked = {
                
                //   ---change---
                self.didLoadVideo(urlString)
            }
            self.moviePlayer.controls.bottomBar.alpha = 1.0
            self.view.addSubview(self.moviePlayer.view)
            
            self.createTopView()
            webView.frame = CGRectMake(0, 64 + moviePlayerHeight, wdh, hgt - 64 - listButtonHeight - moviePlayerHeight)
        }else {
            
            self.moviePlayer.contentURL = nil
            self.moviePlayer.controls.isAppear = false
            self.moviePlayer.controls.buttonClicked = {
                
                self.didLoadVideo(urlString)
            }
            self.moviePlayer.stop()
            self.moviePlayer.controls.bottomBar.alpha = 1.0
        }
        
        let videoID = self.leaf.videoId
        for progross in self.moviePlayer.controls.subviews {
            
            if progross is MBProgressHUD {
                
                self.progrossHUD.removeFromSuperview()
            }
        }
        
        if taskArray.count != 0 {
            
            for var i = 0; i < taskArray.count; i++ {
                
                let dict = taskArray[i] as! NSDictionary
                for key in dict.allKeys {
                    
                    let keyString = key as! String
                    if keyString == videoID {
                        
                        if urlString == "false" {
                            
                            self.progrossHUD.show(true)
                            self.progrossHUD.labelColor = UIColor.blackColor()
                            self.progrossHUD.color = UIColor.grayColor()
                            
                            self.moviePlayer.controls.addSubview(self.progrossHUD)
                        }
                        return
                    }
                }
            }
        }
    }
    
    func didLoadVideo(urlString: String) {
        
        if urlString != "false" {
            
            self.downloadVideo(urlString)
        }else {
            
            for progross in self.moviePlayer.controls.subviews {
                
                if progross is MBProgressHUD {
                    
                    return
                }
            }
            if self.taskArray.count != 0 {
                
                for var i = 0; i < self.taskArray.count; i++ {
                    
                    let dict = self.taskArray[i] as! NSDictionary
                    for key in dict.allKeys {
                        
                        let videoId = key as! String
                        if videoId == self.videoId {
                            
                            self.progrossHUD.show(true)
                            self.progrossHUD.labelColor = UIColor.blackColor()
                            self.progrossHUD.color = UIColor.grayColor()
                            self.progrossHUD.removeFromSuperview()
                            self.moviePlayer.controls.addSubview(self.progrossHUD)
                            return
                        }
                    }
                }
            }
        }
    }
    
    /**
    *  -----添加顶部视图 点击收缩----
    */
    func createTopView() {
        if self.topView == nil{
            
            self.topView = UIView(frame: CGRectMake(0, 64, wdh, 44))
        }
        self.topView.backgroundColor = UIColor.grayColor()
        self.view.addSubview(self.topView)
        self.topView.hidden = true
        
        if self.topLabel == nil
        {
            self.topLabel = InsetsLabel(frame: CGRectMake(0, 0, wdh, self.topView.bounds.size.height))
        }
        self.topLabel.text = "点击展开视频"
        self.topLabel.font = UIFont.systemFontOfSize(18)
        self.topLabel.drawTextInRect(UIEdgeInsetsInsetRect(self.topLabel.bounds, UIEdgeInsetsMake(0, 20, 0, 20)))
        self.topLabel.textColor = UIColor.whiteColor()
        self.topLabel.insets = UIEdgeInsetsMake(0, 20, 0, 0)
        self.topView.addSubview(self.topLabel)
        
        if self.topButton == nil
        {
            self.topButton = UIButton(frame: CGRectMake(wdh-60, 64, 50, 50))
        }
        self.topButton.imageEdgeInsets = UIEdgeInsetsMake(10, 10, 10, 10)
        self.topButton.setImage(UIImage(named: "topButtonImage"), forState: UIControlState.Normal)
        self.topButton.addTarget(self, action: "clickTopButton:", forControlEvents: UIControlEvents.TouchUpInside)
        self.topButton.selected = false
        self.view.addSubview(self.topButton)
        
        let width = UIScreen.mainScreen().bounds.size.width;
        let height = width*220/320
        if self.topImage == nil
        {
            self.topImage = UIImageView(frame: CGRectMake(0, height + 64, wdh, 40))
        }
        var image:UIImage = UIImage(named: "topImageView")!
        image = image.stretchableImageWithLeftCapWidth(4, topCapHeight: 4)
        self.topImage.image = image
        self.view.addSubview(self.topImage)
        
    }
    
    /**
     *  隐藏tableView
     */
    func listTableViewDisappear() {
        
        grayBackView.removeFromSuperview()
        tableView.removeFromSuperview()
        listButton.selected = false
    }
    
    /**
    *  配置交互图
    */
    func createImageWidget(path:String,leaf:DasAutoFile)
    {
        let image = UIImage(contentsOfFile: path)
        let imageWidth = image?.size.width
        let imageHeight = image?.size.height
        
        moviePlayerHeight = wdh * imageHeight!/imageWidth!
        if topImageView == nil {
            
            topImageView = UIImageView(frame: CGRectMake(0, 64, wdh,moviePlayerHeight))
            topImageView.image = image
            self.view.addSubview(topImageView)
            topImageView.userInteractionEnabled = true
            let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("handleTapGesture"))
            
            topImageView.addGestureRecognizer(tapGesture)
            let enlargeButton:UIButton = UIButton(frame:CGRectMake( CGRectGetWidth(UIScreen.mainScreen().bounds) - 46, moviePlayerHeight - 40, 46, 30))
            enlargeButton.setImage(UIImage(named: "enLarge"), forState: UIControlState.Normal)
            enlargeButton.imageEdgeInsets = UIEdgeInsetsMake(5, 2, 5, 8)
            enlargeButton.addTarget(self, action: "handleTapGesture", forControlEvents: UIControlEvents.TouchUpInside)
            topImageView.addSubview(enlargeButton)
        }
    }

    /**
    *  刷新webView
    */
    func refreshWebView() {
        
        numberWebPage--
        hasRefresh = false
//        self.webView.goBack()
        leaf = leafArray[numberWebPage] as! DasAutoFile
        let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
        let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
        self.webView.loadRequest(request!)
        
        self.configureTitle(leaf.name)
    }
    
    // MARK:
    // MARK: UIWebView Load Request
    /**
    *  webView加载数据
    */
    func webViewLoadRequestWithDasautoFileLeaf(fileLeaf: DasAutoFile) {
        
        hasRefresh = false
        leafArray.addObject(leaf)
        
        self.configureTitle(leaf.name)
        let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
        let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
        self.webView.loadRequest(request!)
        
        self.shouldConfigureVideoPlayer()
    }
    
    
    /**
    *  判断是否有内嵌视频
    */
    func shouldConfigureVideoPlayer() {
        
        if leaf.children.count != 0 {
            
            dataArray = leaf.children
            listButton.hidden = false
            listButtonHeight = 40
        }else {
            
            listButton.hidden = true
            listButtonHeight = 0
        }
        
        //  判断有无视频
        if leaf.videoId != nil {
            
            videoId = leaf.videoId
            if (topButton != nil) {
                if topButton.selected {
                    
                    moviePlayerHeight = 30
                }else {
                    moviePlayerHeight = wdh*220/320
                }
            }else {
                moviePlayerHeight = wdh*220/320
            }
            
            // 完整版
            let zip = PackageFileManager.sharedInstance.currentZipPackage
            if zip.isIncludeVideo == "true" {
                
                fileUrl = self.traversalMethods(leaf.videoId)
                self.configureVideoPlayer(fileUrl!)
            }else {
                
                let manger:DSFileManager = DSFileManager.sharedInstance
                let videoFile = manger.getDocumentsDirectory().stringByAppendingString("/video/")
                let path:String = videoFile.stringByAppendingString(zip.zipNameWithoutsubffix + "video" + self.leaf.videoId + ".mp4")
                
                if manger.isExist(path) {   //  如果已下载
                    fileUrl = NSURL.fileURLWithPath(path)
                    self.configureVideoPlayer(fileUrl)
                }else {
                    // ----   change ----- 判断 数组中是否已经下载
                    let videoID = self.leaf.videoId
                    if taskArray.count == 0 {
                        
                        self.loadCarVideoList(videoID)
                    }else {
                        
                        for var i = 0; i < taskArray.count; i++ {
                            
                            let dict = taskArray[i] as! NSDictionary
                            for key in dict.allKeys {
                                
                                let keyString = key as! String
                                if keyString == videoID {
                                    
                                    self.configureVideoPlayer2("false")
                                    return
                                }
                            }
                        }
                        self.loadCarVideoList(videoID)
                    }
                }
            }
        }else {
            
            if self.moviePlayer != nil {
                
                self.moviePlayer.stop()
                self.moviePlayer.delegate = nil
                self.moviePlayer.view.removeFromSuperview()
                self.moviePlayer = nil
                
                self.removeTopView()
                moviePlayerHeight = 0
            }
        }
        
        //---是否创建图片
        if leaf.interPicId != nil {
            
            self.searchLeafFromInterPic(leaf.interPicId)
        }else {
            
            if self.moviePlayer == nil {
                
                moviePlayerHeight = 0
            }
            if topImageView != nil
            {
                topImageView.removeFromSuperview()
                topImageView = nil
            }
        }
        
        webView.frame = CGRectMake(0, 64 + moviePlayerHeight, wdh, hgt - 64 - listButtonHeight - moviePlayerHeight)
    }
    
    // MARK:
    // MARK: Get Video Path
    /**
    *  遍历视频介绍获取视频路径
    */
    func traversalMethods(videoId: String) -> NSURL {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(4)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        var videoFile: String!
        for var i = 0; i < directory.children.count; i++
        {
            
            let file = directory.children[i] as DasAutoFile
            if file.resourceId == videoId {
                
                videoFile = file.videoFile
            }
        }
        
        let urlPath = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/video/" + videoFile)
        let url = NSURL.fileURLWithPath(urlPath)
        return url
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  请求视频列表
    */
    func loadCarVideoList(videoId: String) {
        
        let zip = PackageFileManager.sharedInstance.currentZipPackage
        let userDict: NSDictionary = ["carModel": zip.carName, "carYear": zip.carProductYear]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCarVideoList, param: userDict, withToken:false,success: { (operation, responseObject) -> Void in
            
            let mutableDict: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDict != nil {
                
                let respCode = mutableDict?.objectForKey("respCode") as! String
                if respCode == "000000" {
                    
                    let responseArray = mutableDict?.objectForKey("carVideoList") as! NSArray
                    for videoList in responseArray {
                        
                        let dict = videoList as! NSDictionary
                        if ((dict.objectForKey("id") as! NSNumber).description) == videoId {
                            
                            let loadUrl = dict.objectForKey("videoUrl") as! String
                            
                            self.configureVideoPlayer2(loadUrl)
                        }
                    }
                }
            }
            }) { (operation, error) -> Void in
            
               self.loadVideoError()
        }
    }
    
    /**
     *  下载视频
     */
    func downloadVideo(urlString:String) {
        
        self.progrossHUD.show(true)
        self.progrossHUD.labelColor = UIColor.blackColor()
        self.progrossHUD.color = UIColor.grayColor()
        self.progrossHUD.removeFromSuperview()
        self.moviePlayer.controls.addSubview(self.progrossHUD)
        
        
        let crtZip = PackageFileManager.sharedInstance.currentZipPackage
        downloadTask = AFOperationManager.sharedInstance.downloadOperation2(urlString, zipNameString: crtZip.zipNameWithoutsubffix + "video" + self.leaf.videoId + ".mp4")
            { (response, url, error) -> Void in
                
                if error == nil {
                    self.loadVideoSuccess()
                }else {
                    self.loadVideoError()
                }
        }
        
        // --- change ---   添加下载的videoId  和 taskIdentifier
        let dict = [self.videoId : downloadTask.taskIdentifier]
        taskArray.addObject(dict)
        
        AFOperationManager.sharedInstance.sessionManager.setDownloadTaskDidWriteDataBlock({ (session: NSURLSession!, task: NSURLSessionDownloadTask!, real: Int64, total: Int64, totalBytesExpectedToWrite: Int64) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                if self.videoId != nil {
                    
                    for var i = 0; i < self.taskArray.count; i++ {
                        
                        let dictionary = self.taskArray[i] as! NSDictionary        // 取出数组中的dict
                        let value = dictionary.objectForKey(self.videoId) as? Int  // 存放数组中的 taskIdentifier
                        if value != nil {
                            
                            if value == task.taskIdentifier {
                                
                                Logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \(task.taskIdentifier)")
                                var percent = (total * 100 / totalBytesExpectedToWrite).description
                                percent = percent+"%"
                                self.updatePercent(percent)
                                return
                            }
                        }
                    }
                }
            })
        })
    }
    
    /**
     *  下载成功
     */
    func loadVideoSuccess() {
        
        let crtZip = PackageFileManager.sharedInstance.currentZipPackage
        if self.leaf.videoId != nil {
            
            let manger:DSFileManager = DSFileManager.sharedInstance
            let videoFile = manger.getDocumentsDirectory().stringByAppendingString("/video/")
            let path:String = videoFile.stringByAppendingString(crtZip.zipNameWithoutsubffix + "video" + self.leaf.videoId + ".mp4")
            
            self.fileUrl = NSURL.fileURLWithPath(path)
            
            // ---change--- 移除任务字典
            if self.taskArray.count != 0 {
                
                for var i = 0; i < self.taskArray.count; i++ {
                    
                    let dict = self.taskArray[i] as! NSDictionary
                    for key in dict.allKeys {
                        
                        let keyString = key as! String
                        if keyString == self.videoId {
                            
                            if self.moviePlayer != nil {
                                
                                self.moviePlayer.contentURL = self.fileUrl
                                self.moviePlayer.stop()
                            }
                            self.taskArray.removeObjectAtIndex(i)
                            return
                        }
                    }
                }
            }
        }
    }
    
    /**
     *  下载失败
     */
    func loadVideoError() {
        
        if self.moviePlayer != nil {
            
            self.moviePlayer.stop()
            // ---change--- 移除任务字典
            if self.taskArray.count != 0 {
                
                for var i = 0; i < self.taskArray.count; i++ {
                    
                    let dict = self.taskArray[i] as! NSDictionary
                    for key in dict.allKeys {
                        
                        let keyString = key as! String
                        if keyString == self.videoId {
                            
                            self.taskArray.removeObjectAtIndex(i)
                        }
                    }
                }
            }
            for progross in self.moviePlayer.controls.subviews {
                
                if progross is MBProgressHUD {
                    
                    (progross as! MBProgressHUD).labelText = "视频加载失败"
                    (progross as! MBProgressHUD).labelColor = UIColor.blackColor()
                    self.configureAlertView()
                    return
                }
            }
            self.progrossHUD.show(true)
            self.progrossHUD.labelColor = UIColor.blackColor()
            self.progrossHUD.color = UIColor.grayColor()
            self.progrossHUD.removeFromSuperview()
            self.progrossHUD.labelText = "视频加载失败"
            self.moviePlayer.controls.addSubview(self.progrossHUD)
            
            self.configureAlertView()
        }else {
            
            self.configureAlertView()
        }
    }
        
    /**
    *  下载进度
    */
    func updatePercent(percent:String)
    {
        self.progrossHUD.labelText = "正在下载视频"+percent
        if percent == "100%"
        {
            self.progrossHUD.hide(true)
            self.progrossHUD.removeFromSuperview()
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        if numberWebPage == 0 {
            
            self.dismissViewControllerAnimated(true, completion: nil)
        }else {
            
            leafArray.removeObjectAtIndex(numberWebPage)
            self.refreshWebView()
            self.shouldConfigureVideoPlayer()
        }
    }

    /**
    *  选中listButton
    */
    func onListButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if sender.selected {
            
            grayBackView.removeFromSuperview()
            tableView.removeFromSuperview()
        }else {
            
            self.configureTableView()
        }
        sender.selected = !sender.selected
    }
    
    /**
     *  选中topButton
     */
    func clickTopButton(sender:UIButton) {
        if sender.selected != true {
            moviePlayerHeight = 30
            self.moviePlayer.pause()
            self.topView.hidden = false
            self.moviePlayer.view.hidden = true
            self.topButton.imageView?.transform = CGAffineTransformMakeRotation(CGFloat(M_PI))
            self.topImage.hidden = true
        }else {
            moviePlayerHeight = wdh*220/320
            self.moviePlayer.view.hidden = false
            self.moviePlayer.pause()
            self.topView.hidden = true
            self.topButton.imageView?.transform = CGAffineTransformIdentity
            self.topImage.hidden = false
        }
        webView.frame = CGRectMake(0, 64 + moviePlayerHeight, wdh, hgt - 64 - listButtonHeight - moviePlayerHeight)
        sender.selected = !sender.selected
    }
    
    // MARK:
    // MARK: UITapGestureRecognizer
    /**
    *  点击灰色背景视图的手势方法
    */
    func onGrayBackViewTapGesture(tapGes: UITapGestureRecognizer) {
        
        self.listTableViewDisappear()
    }
    
    /**
    *  点击交互图
    */
    func handleTapGesture()
    {
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let controller:HtmlSpotImageController = HtmlSpotImageController()
        controller.leaf = self.sendLeaf
        
        hasRefresh = false
        self.presentViewController(controller, animated: true, completion: nil)
    }
    
    // MARK:
    // MARK:UIWebViewDelegate
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        
    }
    
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        if hasRefresh == true {
            
            let urlString = request.URL!.absoluteString
            let arr = urlString.componentsSeparatedByString("#")
            if arr.count == 1 {
                
                var array: [String] = urlString.componentsSeparatedByString("html/")
                if array.count != 1 {
                    
                    let separatedString = array[1] as String
                    let indexArray = separatedString.componentsSeparatedByString(".")
                    let resIndex = indexArray[0]         // 获取resIndex
                    
                    var ground = indexArray[1]
                    var array = ground.componentsSeparatedByString("ground=")
                    if array.count != 1 {
                        
                        var groundArray = array[1].componentsSeparatedByString("&")
                        ground = groundArray[0]          // 获取listName
                    }
                    
                    leaf = self.getLeafFromOtherResWithResIndex(resIndex)
                    self.webViewLoadRequestWithDasautoFileLeaf(leaf)
                    numberWebPage++
                }
            }else {
                // ---- change ----
                hasRefresh = true
            }
            
            return true
        }
        
        hasRefresh = true
        return true
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        
        // 修改webView的字体大小
        let fontStr = "document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= " + kHtmlFontSize
        self.webView.stringByEvaluatingJavaScriptFromString(fontStr)
    }
    
    // MARK: UITableViewDataSource
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dataArray.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let identifer = "listCellIdentifer"
        var cell = tableView.dequeueReusableCellWithIdentifier(identifer)
        if cell == nil  {
            
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: identifer)
        }
        
        let data: AnyObject? = dataArray[indexPath.row] as AnyObject
        if data is RATreeNodeInfo {
            
            cell?.textLabel!.text = ((data as! RATreeNodeInfo).item as! RADataObject).name
        }else if data is RADataObject {
            
            cell?.textLabel!.text = (data as! RADataObject).name
        }else  if data is DasAutoFileLeaf {
            
            cell?.textLabel!.text = (data as! DasAutoFileLeaf).name
        }
        cell?.textLabel!.font = UIFont.systemFontOfSize(16)
        let lineView = UIView(frame: CGRectMake(0, 43, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red:0.8, green:0.8, blue:0.8, alpha:1)
        cell?.addSubview(lineView)
        
        
        let rightImageView = UIImageView(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 25, 14, 10, 15))
        rightImageView.image = UIImage(named: "rightArrow" + themeColor)
        cell?.addSubview(rightImageView)
        return cell!
    }
    
    // UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        
        let data: AnyObject? = dataArray[indexPath.row] as AnyObject
        var file: DasAutoFile!
        if data is RATreeNodeInfo {
            
            file = ((data as! RATreeNodeInfo).item as! RADataObject).dasautoFile as DasAutoFile
        }else if data is RADataObject {
            
            file = (data as! RADataObject).dasautoFile as DasAutoFile
        }else if data is DasAutoFileLeaf {
            
            file = data as! DasAutoFileLeaf
        }
        
        leaf = self.getLeafFromOtherResWithResIndex(file.resIndex)
        self.webViewLoadRequestWithDasautoFileLeaf(leaf)
        numberWebPage++
        self.listTableViewDisappear()
    }
    
    // MARK:
    // MARK: ALMoviePlayerControllerDelegate
    func moviePlayerWillMoveFromWindow() {
        
        let a:NSArray = self.view.subviews
        if !a.containsObject(self.moviePlayer.view)
        {
            self.view.addSubview(self.moviePlayer.view)
        }
        
        let width = UIScreen.mainScreen().bounds.size.width;
        let height = width*220/320
        self.moviePlayer.setFrame(CGRectMake(0, 64, width, height))
        
        self.createTopView()
    }
    
    func movieTimedOut() {
        Logger.info("MOVIE TIMED OUT")
    }
    
    func removeTopView()
    {
        if self.topView != nil  {
            self.topView.removeFromSuperview()
        }
        if self.topButton != nil {
            self.topButton.removeFromSuperview()
        }
        if self.topImage != nil {
            self.topImage.removeFromSuperview()
        }
    }
    
    // MARK:
    // MARK: Search DasAutoFile
    /**
    *  遍历交互图获取对应的leaf
    */
    func searchLeafFromInterPic(interPicId: String)
    {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(9)
        let directory = PackageFileManager.sharedInstance.rootFile.result as DasAutoFile
        for var i = 0; i < directory.children.count; i++ {
            
            let file = directory.children[i] as DasAutoFile
            if file.resourceId == interPicId
            {
                
                let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + file.picFile)
                self.sendLeaf = file
                self .createImageWidget(path, leaf: file)
            }
        }
    }
    
    /**
    *  从应急服务里面搜索获取leaf
    */
    func getLefFromEmergencyServiceWithResIndex(resIndex: String) -> DasAutoFile {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(6)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
        //        let leaf: DasAutoFile!
        for var i = 0; i < directory.children.count; i++ {
            
            let dir = directory.children[i] as DasAutoFile
            if dir.resIndex == nil {
                
                for var j = 0; j < dir.children.count; j++ {
                    
                    let file = dir.children[j] as DasAutoFile
                    if file.resIndex == resIndex {
                        
                        return file
                    }
                }
            }else {
                
                if dir.resIndex == resIndex {
                    
                    return dir
                }
            }
        }
        //        return leaf
        return PackageFileManager.sharedInstance.rootFile
    }
    
    /**
     *  从userManual里面搜索获取leaf
     */
    func getLeafFromUserManaulWithResIndex(resIndex: String) -> DasAutoFile {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(3)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
        var leaf: DasAutoFile!
        for var i = 0; i < directory.children.count; i++ {
            
            let file = directory.children[i] as DasAutoFile
            for var i = 0; i < file.children.count; i++ {
                
                let fileChildren = file.children[i] as DasAutoFile
                for var i = 0; i < fileChildren.children.count; i++ {
                    
                    let leaf = fileChildren.children[i] as DasAutoFile
                    if leaf.resIndex != nil
                    {
                        if leaf.resIndex == resIndex {
                            return leaf
                        }
                    }
                    for var i = 0; i < leaf.children.count; i++ {
                        
                        let leafChildren = leaf.children[i] as DasAutoFile
                        
                        if leafChildren.resIndex != nil
                        {
                            if leafChildren.resIndex == resIndex {
                                
                                return leafChildren
                            }
                        }
                        for var i = 0; i < leafChildren.children.count; i++ {
                            
                            let le = leafChildren.children[i] as DasAutoFile
                            
                            if le.resIndex != nil
                            {
                                if le.resIndex == resIndex {
                                    
                                    return le
                                }
                            }
                        }
                    }
                }
            }
        }
        leaf = self.getLefFromEmergencyServiceWithResIndex(resIndex)
        return leaf
    }
    
    /**
    *  从otherRes里面搜索获取leaf
    */
    func getLeafFromOtherResWithResIndex(resIndex: String) -> DasAutoFile {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
        var leaf: DasAutoFile!
        for var i = 0; i < directory.children.count; i++ {
            
            let directoryChildren = directory.children[i] as DasAutoFile
            if directoryChildren.resIndex == resIndex {
                
                return directoryChildren
            }
        }
        
        leaf = self.getLeafFromUserManaulWithResIndex(resIndex)
        return leaf
    }
}
