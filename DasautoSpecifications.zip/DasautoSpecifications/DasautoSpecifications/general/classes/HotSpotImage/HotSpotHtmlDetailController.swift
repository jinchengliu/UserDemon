//
//  HotSpotHtmlDetailController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/5/20.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class HotSpotHtmlDetailController: DasautoController , UIWebViewDelegate{

    var webView: UIWebView!
    var favouriteButton: UIButton!
    
    var leaf: DasAutoFile!
    var request: NSURLRequest!
    var titleString: String!
    
    // MARK: 生命周期
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.webView.loadRequest(request)
    }
    
    override func viewDidLoad() {
        
        /*
        弃用
        */
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        self.configureNavigationBar()
        self.configureWebView()
    }
    
//    override func shouldAutorotate() -> Bool {
//        
//        return false
//    }
//    
//    override func preferredInterfaceOrientationForPresentation() -> UIInterfaceOrientation {
//        
//        return UIInterfaceOrientation.Portrait
//    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK: 配置webView
    func configureWebView() {
        
        webView = UIWebView(frame: CGRectMake(0, 64, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds) - 64))
        webView.delegate = self
        self.view.addSubview(webView)
    }
    
    func configureNavigationBar() {
        
        let navigationBar = UINavigationBar(frame: CGRectMake(0, 20, CGRectGetWidth(self.view.bounds), 44))
        navigationBar.barTintColor = UIColor.whiteColor()
        navigationBar.pushNavigationItem(self.navigationItem, animated: true)
        
        let lineView = UIView(frame: CGRectMake(0, 43, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red: 223.0/255, green: 223.0/255, blue: 223.0/255, alpha: 1.0)
        navigationBar.addSubview(lineView)
        self.view.addSubview(navigationBar)
        
        self.addBackBarButtonItem()
//        self.addRightNavigationItemAboutFavourite()
    }
    
    // MARK:添加返回按钮
    func addBackarButtonItem() {
        
        var tintColor: UIColor!
        if themeColor == "_red" {
            
            tintColor = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }else if themeColor == "_blue" {
            
            tintColor = UIColor(red: 0, green: 0.56, blue: 0.84, alpha: 1.0)
        }else {
            
            tintColor = UIColor(red: 0.82, green: 0.67, blue: 0.5, alpha: 1.0)
        }
        let backBarButtonItem: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconBack_red"), style: UIBarButtonItemStyle.Plain, target: self, action: Selector("onBackBarButtonItemClciked:"))
        backBarButtonItem.tintColor = tintColor
        
        self.navigationItem.leftBarButtonItem = backBarButtonItem
    }
    
    // MARK: 添加收藏视图
    func addRightNavigationItemAboutFavourite() {
        
        favouriteButton = UIButton(frame: CGRectMake(0, 0, 21, 21))
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate_selected.png"), forState: UIControlState.Normal)
        favouriteButton.addTarget(self, action: Selector("onFavouriteBarButtonItemClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        let favouriteBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: favouriteButton)
        self.navigationItem.rightBarButtonItem = favouriteBarButtonItem
    }
    
    // MARK: 点击返回按钮的方法
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: 点击收藏按钮的方法
    func onFavouriteBarButtonItemClicked(sender: UIButton) {
        
        if favouriteButton.selected {
            
        } else {
            
        }
        favouriteButton.selected = !favouriteButton.selected
    }
    
    // MARK: webView的代理方法
    func webViewDidFinishLoad(webView: UIWebView) {
        
        titleString = webView.stringByEvaluatingJavaScriptFromString("document.title")
        self.navigationItem.title = titleString
        // MARK: 修改webView的字体大小
        let fontStr = "document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= " + kHtmlFontSize
        self.webView.stringByEvaluatingJavaScriptFromString(fontStr)
    }
}
