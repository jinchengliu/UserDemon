/*
*  filename: HotSpotModel.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/04.
*  copyright: bdcluster
*/


import UIKit

class HotSpotModel: BaseModel {
   
    // MARK:properties
    var id: NSNumber?
    var x: NSNumber?
    var y: NSNumber?
    var label: String?
    var pointPath: String?
    
    // MARK:description
    func description() {
        Logger.info("HotSpotModel: id=\(id),x=\(x),y=\(y),label=\(label),pointPath=\(pointPath)")
    }
}