/*
*  filename: DasAutoFileLeaf.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/9.
*  copyright: bdcluster
*/

import Foundation

class DasAutoFileLeaf: DasAutoFile {
    
    override func findFileWithFileId(fileId: Int) {
        
        if self.fileId == fileId {
            
            self.root.result = self
            return
        }
    }

    override func findFileWithKey(key: String) {
        
        if self.desc != nil {
            
            let nameRange = self.name.rangeOfString(key)
            let descRange = self.desc.rangeOfString(key)
            
            let pingyingName = ChineseToPinyin.pinyinFromChiniseString(self.name)
            let pingyingDesc = ChineseToPinyin.pinyinFromChiniseString(self.desc)
            let pingyingNameRange = pingyingName.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            let pingyingDescRange = pingyingDesc.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            
            if nameRange != nil || descRange != nil || pingyingNameRange != nil || pingyingDescRange != nil {
                
                self.root.searchResult.append(self)
            }
        }
    }
    
    override func findFileWithKeyAndFileId(key: String, fileId: Int) {
        
        if self.desc != nil && self.fileId != 4 {
            
            Logger.info("fileDirectory:  \(self.fileId)")
            let nameRange = self.name.rangeOfString(key)
            let descRange = self.desc.rangeOfString(key)
            
            let pingyingName = ChineseToPinyin.pinyinFromChiniseString(self.name)
            let pingyingDesc = ChineseToPinyin.pinyinFromChiniseString(self.desc)
            let pingyingNameRange = pingyingName.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            let pingyingDescRange = pingyingDesc.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            
            if nameRange != nil || descRange != nil || pingyingNameRange != nil || pingyingDescRange != nil {
                
                self.root.searchResult.append(self)
            }
        }
    }
}