/*
*  filename: DasAutoDirectory.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/9.
*  copyright: bdcluster
*/

import Foundation

class DasAutoDirectory: DasAutoFile {
        
    override func add(file: DasAutoFile) {
        children.append(file)
        
        //假设一层最多有100个子目录或者叶子节点
        for (index, value) in children.enumerate() {
            
            value.fileId = self.fileId*100+(index+1)
        }
    }
    
    override func addLeafNoAutoSetFileId(file: DasAutoFile) {
        
        children.append(file)
    }
    
    override func remove(file: DasAutoFile) {
        
        for (index, value) in children.enumerate() {
            
            if file.fileId == value.fileId {
                
                children.removeAtIndex(index)
            }
        }
    }

    override func findFileWithFileId(fileId: Int) {
        
        if fileId == self.fileId {
            
            self.root.result = self
            return
        }
        if children != nil {
            
            for (index, value) in children.enumerate() {
                
                value.findFileWithFileId(fileId)
            }
        }
    }

    override func findFileWithKey(key: String) {
        
        for var i = 0; i < self.children.count; i++ {
            
            let dasFile = self.children[i] as DasAutoFile
            if dasFile.doNotSearch == nil {
            
                dasFile.findFileWithKey(key)
            }
        }
    }
    
    override func findFileWithKeyAndFileId(key: String,fileId: Int) {
        
        
        for var i = 0; i < self.children.count; i++ {
            
            let dasFile = self.children[i] as DasAutoFile
            if self.fileId != 4 {
                
                if dasFile.doNotSearch == nil {
                    
                    dasFile.findFileWithKeyAndFileId(key,fileId: 4)
                }
            }
        }
    }
}