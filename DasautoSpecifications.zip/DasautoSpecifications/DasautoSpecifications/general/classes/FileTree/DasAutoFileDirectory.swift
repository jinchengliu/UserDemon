//
//  DasAutoFileDirectory.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/7/6.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import Foundation

//  重写添加搜索的方法  ----  防止用户手册和视频介绍搜索出错(参考解析)
class DasAutoFileDirectory: DasAutoFile {
    
    override func add(file: DasAutoFile) {
        children.append(file)
        
        //假设一层最多有100个子目录或者叶子节点
        for (index, value) in children.enumerate() {
            
            value.fileId = self.fileId*100+(index+1)
        }
    }
    
    override func addLeafNoAutoSetFileId(file: DasAutoFile) {
        
        children.append(file)
    }
    
    override func remove(file: DasAutoFile) {
        
        for (index, value) in children.enumerate() {
            
            if file.fileId == value.fileId {
                
                children.removeAtIndex(index)
            }
        }
    }
   
    override func findFileWithFileId(fileId: Int) {
        
        if self.fileId == fileId {
            
            self.root.result = self
            return
        }
    }
    
    override func findFileWithKey(key: String) {
        
        if self.desc != nil {
            
            let nameRange = self.name.rangeOfString(key)
            let descRange = self.desc.rangeOfString(key)
            
            let pingyingName = ChineseToPinyin.pinyinFromChiniseString(self.name)
            let pingyingDesc = ChineseToPinyin.pinyinFromChiniseString(self.desc)
            let pingyingNameRange = pingyingName.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            let pingyingDescRange = pingyingDesc.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            
            if nameRange != nil || descRange != nil || pingyingNameRange != nil || pingyingDescRange != nil {
                
                self.root.searchResult.append(self)
            }
        }
    }
    
    override func findFileWithKeyAndFileId(key: String, fileId: Int) {
        
        if self.desc != nil && self.fileId != 4 {
            
            Logger.info("fileDirectory:  \(self.fileId)")
            let nameRange = self.name.rangeOfString(key)
            let descRange = self.desc.rangeOfString(key)
            
            let pingyingName = ChineseToPinyin.pinyinFromChiniseString(self.name)
            let pingyingDesc = ChineseToPinyin.pinyinFromChiniseString(self.desc)
            
            let pingyingNameRange = pingyingName.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            let pingyingDescRange = pingyingDesc.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            
            if nameRange != nil || descRange != nil || pingyingNameRange != nil || pingyingDescRange != nil {
                
                self.root.searchResult.append(self)
            }
        }
    }
}
