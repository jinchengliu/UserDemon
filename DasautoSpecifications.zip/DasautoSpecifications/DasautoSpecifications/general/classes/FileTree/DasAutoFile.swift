/*
*  filename: DasAutoFile.swift
*  product name: DasautoSpecifications
*  author: cp
*  date time: 14/12/9.
*  copyright: bdcluster
*/

import Foundation

class DasAutoFile: NSObject, NSCoding{
    
    var fileId: Int!             // 虚拟文件id
    var name: String!            // 节点名
    var desc: String!            // 节点描述
    var videoFile: String!       // 视频文件路径
    var picFile: String!         // 图片文件路径
    
    var videoId: String!
    var resourceId: String!
    var refResourceId: String!
    var interPicId: String!
    
    var resIndex: String!        // HTML5
    var playTime: String!        // 播放时长
    
    var isOverview: String!      //
    var hotSpotX: String!        // 热点图x
    var hotSpotY: String!        // 热点图y
    
    var detailPicUrl: String!
    var detailDesc: String!
    
    var doNotSearch: String!                          // 不进行搜索
    var children: [DasAutoFile]!         //子节点s
    var result: DasAutoFile!             //查找结果节点
    var searchResult: [DasAutoFile]!     //搜索结果集合
    var root: DasAutoFile!               //当前节点的根节点
    
    // MARK:
    // MARK: discard
    
    init(name: String, root: DasAutoFile!) {
        
        self.name = name
        children = [DasAutoFile]()
        searchResult = [DasAutoFile]()
        self.root = root
    }
    
    // MARK:
    // MARK: NSCoding
    /**
    *  解挡
    */
    required init?(coder aDecoder: NSCoder) {
        
        self.fileId = Int((aDecoder.decodeObjectForKey("FileID") as! NSNumber).integerValue)
        self.name = aDecoder.decodeObjectForKey("Name") as? String
        self.desc = aDecoder.decodeObjectForKey("Desc") as? String
        self.videoFile = aDecoder.decodeObjectForKey("VideoFile") as? String
        self.picFile = aDecoder.decodeObjectForKey("PicFile") as? String
        self.resourceId = aDecoder.decodeObjectForKey("ResourceID") as? String
        self.interPicId = aDecoder.decodeObjectForKey("interPicId") as? String
        self.videoId = aDecoder.decodeObjectForKey("videoId") as? String
        self.doNotSearch = aDecoder.decodeObjectForKey("doNotSearch") as? String
        self.refResourceId = aDecoder.decodeObjectForKey("RefResourceID") as? String
        self.children = aDecoder.decodeObjectForKey("Children") as? [DasAutoFile]
        self.result = aDecoder.decodeObjectForKey("Result") as? DasAutoFile
        self.searchResult = aDecoder.decodeObjectForKey("SearchResult") as? [DasAutoFile]
        self.root = aDecoder.decodeObjectForKey("Root") as? DasAutoFile
        self.resIndex = aDecoder.decodeObjectForKey("ResIndex") as? String
        self.playTime = aDecoder.decodeObjectForKey("playTime") as? String
        self.detailPicUrl = aDecoder.decodeObjectForKey("detailPicUrl") as? String
        self.detailDesc = aDecoder.decodeObjectForKey("detailDesc") as? String
        self.hotSpotX = aDecoder.decodeObjectForKey("hotSpotX") as? String
        self.hotSpotY = aDecoder.decodeObjectForKey("hotSpotY") as? String
        self.isOverview = aDecoder.decodeObjectForKey("isOverview") as? String
    }
    
    /**
    *  归档
    */
    func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(NSNumber(integer: self.fileId), forKey: "FileID")
        aCoder.encodeObject(self.name, forKey: "Name")
        aCoder.encodeObject(self.desc, forKey: "Desc")
        aCoder.encodeObject(self.videoFile, forKey: "VideoFile")
        aCoder.encodeObject(self.picFile, forKey: "PicFile")
        aCoder.encodeObject(self.resourceId, forKey: "ResourceID")
        aCoder.encodeObject(self.doNotSearch, forKey: "doNotSearch")
        aCoder.encodeObject(self.interPicId, forKey: "interPicId")
        aCoder.encodeObject(self.videoId, forKey: "videoId")
        aCoder.encodeObject(self.refResourceId, forKey: "RefResourceID")
        aCoder.encodeObject(self.children, forKey: "Children")
        aCoder.encodeObject(self.result, forKey: "Result")
        aCoder.encodeObject(self.searchResult, forKey: "SearchResult")
        aCoder.encodeObject(self.root, forKey: "Root")
        aCoder.encodeObject(self.resIndex, forKey: "ResIndex")
        aCoder.encodeObject(self.detailDesc, forKey: "detailDesc")
        aCoder.encodeObject(self.detailPicUrl, forKey: "detailPicUrl")
        aCoder.encodeObject(self.playTime, forKey: "playTime")
        aCoder.encodeObject(self.hotSpotX, forKey: "hotSpotX")
        aCoder.encodeObject(self.hotSpotY, forKey: "hotSpotY")
        aCoder.encodeObject(self.isOverview, forKey: "isOverview")
    }

    func add(file: DasAutoFile) {
        //nothing
    }
    
    func addLeafNoAutoSetFileId(file: DasAutoFile) {
        //nothing
    }
    
    func remove(file: DasAutoFile) {
        //nothing
    }
    
    func findFileWithFileId(fileId: Int) {
        //nothing
    }
    
    func findFileWithKey(key: String) {
        //nothing
    }
    
    func findFileWithKeyAndFileId(key: String,fileId: Int) {
        //nothing  --   用于全局搜索排除搜索 视频介绍
    }
}