//
//  FavouriteManager.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-23.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class FavouriteManager: NSObject {

    class var sharedInstance : FavouriteManager {
        
        struct Static {
            
            static var onceToken : dispatch_once_t = 0
            static var instance : FavouriteManager? = nil
        }
        
        dispatch_once(&Static.onceToken) {

            Static.instance = FavouriteManager()
        }
        return Static.instance!
    }
    
    //MARK: 每次页面返回的时候调用。。同步收藏
    func favouritePost() {

        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if kUserId != "noLogin" {
                
                var listArray = ["快速指南",
                                 "维护保养",
                                 "用户手册",
                                 "智能技术",
                                 "爱车课堂",
                                 "应急服务"]
                var appColumnNameArray = ["quick",
                                          "maintain",
                                          "manual",
                                          "video",
                                          "carclass",
                                          "emergency"]
                var resourceIdListArray = NSMutableArray()
                
                var zip = PackageFileManager.sharedInstance.currentZipPackage
                for var i = 0; i < listArray.count; i++ {
                    
                    var htmlArray = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(zip.carName, carYear: zip.carProductYear, listName: listArray[i], userId: kUserId)
                    for var j = 0; j < htmlArray.count; j++ {
                        
                        var type = appColumnNameArray[i] as String
                        var array = htmlArray[j] as! NSArray
                        
                        var id = array[2] as! String
                        var resourceName = array[1] as! String
                        var list = ["carResourceId":id,"resourceType":type,"carResourceName":resourceName]
                        Logger.info("list : \(list)")
                        resourceIdListArray.addObject(list)
                        
                    }
                }
                
                var userDict: NSDictionary = ["userId": kUserId.toInt()!,"carModel": zip.carName,"carYear":zip.carProductYear,"resourceIdList": resourceIdListArray]
                var token = NSUserDefaults.standardUserDefaults().objectForKey("userToken") as! String
                
                AFOperationManager.sharedInstance.requestManager.requestSerializer = AFJSONRequestSerializer()
                AFOperationManager.sharedInstance.requestManager.requestSerializer.setValue(token, forHTTPHeaderField: "token")
                AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionSyn, param: userDict, success: { (operation, responseObject) -> Void in
                    
                    var mutableDic =  responseObject as? NSMutableDictionary
                    if mutableDic != nil {
                        
                        var respCode = mutableDic?.objectForKey("respCode") as! String
                        if respCode == "020003" {
                            
                            // 显示账号已经在其他地方登录 登录退出  提醒要不要重新登录  跳转到登录页
                            Logger.info("html上传失败 :\(respCode)")
                        }
                    }
                }) { (operation, error) -> Void in
                        
                        Logger.info("_____________\(error)")
                }
            }
        }
    }
    
    // MARK: 查询html收藏
    func queryResourceCollectionList() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if kUserId != "noLogin" {
                
                var zip = PackageFileManager.sharedInstance.currentZipPackage
                var userDict: NSDictionary = ["userId": kUserId.toInt()!,"carModel": zip.carName,"carYear": zip.carProductYear]
                var token = NSUserDefaults.standardUserDefaults().objectForKey("userToken") as! String
                
                AFOperationManager.sharedInstance.requestManager.requestSerializer = AFJSONRequestSerializer()
                AFOperationManager.sharedInstance.requestManager.requestSerializer.setValue(token, forHTTPHeaderField: "token")
                AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionList, param: userDict, success: { (operation, responseObject) -> Void in
                    
                    var mutableDic = responseObject as? NSMutableDictionary
                    var respCode = mutableDic?.objectForKey("respCode") as! String
                    if respCode == "020003" {
                        
                        // 显示账号已经在其他地方登录 登录退出  提醒要不要重新登录  跳转到登录页
                        Logger.info("html上传失败 :\(respCode)")
                    }
                    }) { (operation, error) -> Void in
                        
                        Logger.info("_____________\(error)")
                }
            }
        }
    }
    
    // MARK: 查询4S经销商
    func queryShopCollectionList() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if kUserId != "noLogin" {
                
                var userDict: NSDictionary = ["userId": kUserId.toInt()!]
                var token = NSUserDefaults.standardUserDefaults().objectForKey("userToken") as! String
                
                AFOperationManager.sharedInstance.requestManager.requestSerializer = AFJSONRequestSerializer()
                AFOperationManager.sharedInstance.requestManager.requestSerializer.setValue(token, forHTTPHeaderField: "token")
                AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionList, param: userDict, success: { (operation, responseObject) -> Void in
                    
                    var mutableDic = responseObject as? NSMutableDictionary
                    if mutableDic != nil {
                        
                        var list = mutableDic?.objectForKey("collections") as! NSArray
                        Logger.info("shopCollectionList\(list)")
                    }
                    }) { (operation, error) -> Void in
                        
                        Logger.info("_____________\(error)")
                }
            }
        }
    }
    
    // MARK: 上传用户行为
    func addCarUserAction() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
        
            var actionList = NSMutableArray()
            var deviceUUID = UIDevice.currentDevice().identifierForVendor.UUIDString
            var appColumnIdArray = ["NMC000",
                                    "NMC001",
                                    "NMC002",
                                    "NMC003",
                                    "NMC004",
                                    "NMC005",
                                    "NMC006"]
            var appColumnNameArray = ["AR",
                                      "quick",
                                      "maintain",
                                      "manual",
                                      "video",
                                      "carclass",
                                      "emergency"]
            
            var userDefault = NSUserDefaults.standardUserDefaults()
            for var i = 0; i < 7; i++ {
                
                var id = appColumnIdArray[i] as String
                var name = appColumnNameArray[i] as String
                var key = name + "Count"
                var count = userDefault.objectForKey(key) as? Int
                if count == nil {
                    
                    count = 0
                }
                var list = ["deviceId":deviceUUID,"appColumnId":id,"appColumnName":name,"count":count!]
                actionList.addObject(list)
            }
            
            var userDict: NSDictionary = ["actions": actionList]
            AFOperationManager.sharedInstance.requestManager.requestSerializer = AFJSONRequestSerializer()
            
            AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserActionAdd, param: userDict, success: { (operation, responseObject) -> Void in
                
                var mutableDic = responseObject as? NSMutableDictionary
                if mutableDic != nil {
                    
                    var memo = mutableDic?.objectForKey("memo") as! String
                    Logger.info("mome\(memo)")
                }
            }) { (operation, error) -> Void in
                    
                    Logger.info("_____________\(error)")
            }
        }
    }
}
