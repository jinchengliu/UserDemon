/*
 *  filename: HTTPRequestOperationManager.swift
 *  product name: DasautoSpecifications
 *
 *  author: cp
 *  date time: 14/11/5.
 *  copyright: bdcluster
 */

#ifndef House_httpNetwork_h
#define House_httpNetwork_h

//#define HttpBaseUrl "http://10.11.32.5:8080/cms-web"              // 测试环境
#define HttpBaseUrl "http://222.73.113.5:8201/cms-web"            // 生产环境

#define kUserLogin "/api/cms/user/login"
#define kUserLogout "/api/cms/user/logout"
#define kUserRegister "/api/cms/user/register"

#define kUserUpdatePassword "/api/cms/user/pwd/upd"
#define kUserMessageList "/api/caruser/message/list"
#define kUserMessageDelete "/api/caruser/message/del"
#define kUserForgetPassword "/api/cms/user/pwd/forget"

#define kUserActionAdd "/api/caruser/action/add"
#define kUserDownloadBind "/api/caruser/download/bind"
#define kUserDownloadBindList "/api/caruser/download/bind/list"

#define kCarList "/api/car/list"
#define kProvList "/api/base/prov/list"
#define kCarVideoList "/api/car/video/list"
#define kCar4sShopList "/api/car/4sshop/list"
#define kCarClassPicture "/api/carclass/rootpic/download"

#define kCollectionSyn "/api/caruser/resource/collection/sync"
#define kCollectionList "/api/caruser/resource/collection/list"
#define kShopCollectionList "/api/caruser/4sshop/collection/list"
#define kShopCollectionAddOrDel "/api/caruser/4sshop/collection/addOrDel"

#define kFeedBackAdd "/api/caruser/feedback/add"
#define kAppVersionCheck "/api/app/version/check"
#define kResourceOfflineDownload "/api/car/resource/offline/download"
#define kResourceOfflineVersionCheck "/api/car/resource/offline/version/check"

#endif