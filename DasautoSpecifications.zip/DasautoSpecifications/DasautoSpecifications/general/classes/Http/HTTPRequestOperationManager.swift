/*
 *  filename: HTTPRequestOperationManager.swift
 *  product name: DasautoSpecifications
 *
 *  author: cp
 *  date time: 14/11/5.
 *  copyright: bdcluster
 */

import Foundation

class HTTPRequestOperationManager: AFHTTPRequestOperationManager {
    
    var offset: Int = 0
    var limit: Int = 10
    var loading: Bool = false
    
    required init(coder aDecoder: NSCoder) {
        super.init()
    }
    
    override init(baseURL: NSURL? = NSURL(string: HttpBaseUrl)) {
        super.init(baseURL: baseURL)
        self.responseSerializer.acceptableContentTypes = NSSet(object: "text/html") as Set<NSObject>
    }
    
    func handleResponseData(data: AnyObject!) -> Bool {
        if data.isKindOfClass(NSDictionary) {
            if data["status"] as! String == "OK" {
                return true
            }
            return false
        } else {
            return false
        }
    }
}