/*
 *  filename: HTTPRequestOperationManager.swift
 *  product name: DasautoSpecifications
 *
 *  author: cp
 *  date time: 14/11/18.
 *  copyright: bdcluster
 */

//zip文件下载后的存放目录
let downloadDirectory = "download"
let downloadVideoDirectory = "video"

class AFOperationManager {
    
    //requestManager 每发送一个请求都加入到request的NSOperationQueue
    var requestManager: AFHTTPRequestOperationManager = AFHTTPRequestOperationManager()
    var sessionManager: AFURLSessionManager! // 下载会话
    var reachabilityManager: AFNetworkReachabilityManager! //网络监测
    var fileManager: DSFileManager!
    
    var offset: Int = 0
    var limit: Int = 10
    
    class var sharedInstance : AFOperationManager {
        
        struct Static {
            static var onceToken : dispatch_once_t = 0
            static var instance : AFOperationManager? = nil
        }
        dispatch_once(&Static.onceToken) {
            Static.instance = AFOperationManager()
        }
        return Static.instance!
    }
    
    init() {
        
        let configuration: NSURLSessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration()
        sessionManager = AFURLSessionManager(sessionConfiguration: configuration)
        fileManager = DSFileManager()
    }
    
    // MARK:
    // MARK: AFHTTPRequestOperationManager
    /**
    *  post请求
    */
    func startPostOperation(url: String, param: AnyObject!, withToken:Bool, success: (operation: AFHTTPRequestOperation!, responseObject: AnyObject!) -> Void, failure: (operation:AFHTTPRequestOperation!, error: NSError!) -> Void) -> AFHTTPRequestOperation! {
        if withToken {
            self.configureRequestSerializerWithToken()
        }
        else {
            self.configureRequestSerializer()
        }
        return requestManager.POST(url, parameters: param, success: { (operation: AFHTTPRequestOperation!, responseObject: AnyObject!) -> Void in
            
            success(operation: operation,responseObject: responseObject)
        }, failure: { (operation:AFHTTPRequestOperation!, error: NSError!) -> Void in
            
            failure(operation: operation, error: error)
        })
    }
    
    /**
     *  get请求
     */
    func startGetOperation(url: String, param: AnyObject!, success: (operation: AFHTTPRequestOperation!, responseObject: AnyObject!) -> Void, failure: (operation:AFHTTPRequestOperation!, error: NSError!) -> Void) -> AFHTTPRequestOperation!{
        
        self.configureRequestSerializer()
        return requestManager.GET(url, parameters: param, success: { (operation: AFHTTPRequestOperation!, responseObject: AnyObject!) -> Void in
            
                success(operation: operation,responseObject: responseObject)
            }) { (operation: AFHTTPRequestOperation!, error: NSError!) -> Void in
                
                failure(operation: operation, error: error)
        }
    }
    /**
     *  配置RequestSerializer
     */
    func configureRequestSerializer() {
        requestManager.requestSerializer = AFJSONRequestSerializer()
    }
    /**
     *  配置RequestSerializer并且设置HTTPHeader
     */
    func configureRequestSerializerWithToken() {
        requestManager.requestSerializer = AFJSONRequestSerializer()
        let token = NSUserDefaults.standardUserDefaults().objectForKey("userToken") as! String
        requestManager.requestSerializer.setValue(token, forHTTPHeaderField: "token")
    }
    
    // MARK:
    // MARK: AFURLSessionManager
    /**
    *  下载
    */
    func downloadOperation(urlString: String, zipNameString: String, completion: (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void) -> NSURLSessionDownloadTask {
        
        let url: NSURL = NSURL(string: urlString)!
        let request: NSURLRequest = NSURLRequest(URL: url)
        let downloadFile = (downloadDirectory as NSString).stringByAppendingPathComponent(zipNameString)
        self.fileManager.createFile(downloadDirectory)

        let downloadTask: NSURLSessionDownloadTask = sessionManager.downloadTaskWithRequest(request, progress: nil, destination: { (url: NSURL!, response: NSURLResponse!) -> NSURL! in
        
            return NSURL(string: downloadFile, relativeToURL: self.fileManager.documentURL)
            
            }, completionHandler: { (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void in
                
                completion(response: response, url: url, error: error)
        })
        
        downloadTask.resume()
        
        return downloadTask
    }
    
    /**
     *  继续下载
     */
    func resumeDownOperation(zipNameString: String,resumeData: NSData!,completion: (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void) -> NSURLSessionDownloadTask{

        let downloadTask: NSURLSessionDownloadTask = sessionManager.downloadTaskWithResumeData(resumeData, progress: nil, destination: { (url: NSURL!, response: NSURLResponse!) -> NSURL! in
            
                let downloadFile = (downloadDirectory as NSString).stringByAppendingPathComponent(zipNameString)
                return NSURL(string: downloadFile, relativeToURL: self.fileManager.documentURL)
            }, completionHandler: { (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void in
                
                if error == nil {
                    
                    Logger.info("complete")
                }
                completion(response: response, url: url, error: error)
        })
        
        downloadTask.resume()
        return downloadTask
    }
    
    // MARK: 
    // MARK: ---change--
    func downloadOperation2(urlString: String, zipNameString: String, completion: (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void) -> NSURLSessionDownloadTask
    {
        
        let url: NSURL = NSURL(string: urlString)!
        let request: NSURLRequest = NSURLRequest(URL: url)
        let downloadFile = (downloadVideoDirectory as NSString).stringByAppendingPathComponent(zipNameString)
        self.fileManager.createFile(downloadVideoDirectory)
        Logger.info("path2= \(NSURL(string: downloadFile, relativeToURL: self.fileManager.documentURL))")
        
        let downloadTask: NSURLSessionDownloadTask = sessionManager.downloadTaskWithRequest(request, progress: nil, destination: { (url: NSURL!, response: NSURLResponse!) -> NSURL! in
            
            
            return NSURL(string: downloadFile, relativeToURL: self.fileManager.documentURL)
            
            }, completionHandler: { (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void in
                
                completion(response: response, url: url, error: error)
        })
        
        downloadTask.resume()
        
        return downloadTask
    }
    
    
    func resumeDownOperation2(resumeData: NSData!,videoName:String,completion: (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void) -> NSURLSessionDownloadTask{
        
        let downloadTask: NSURLSessionDownloadTask = sessionManager.downloadTaskWithResumeData(resumeData, progress: nil, destination: { (url: NSURL!, response: NSURLResponse!) -> NSURL! in
            
            let downloadFile = (downloadVideoDirectory as NSString).stringByAppendingPathComponent(videoName)
            return NSURL(string: downloadFile, relativeToURL: self.fileManager.documentURL)
            }, completionHandler: { (response: NSURLResponse!, url: NSURL!, error: NSError!) -> Void in
                
                if error == nil {
                    
                    Logger.info("complete")
                }
                completion(response: response, url: url, error: error)
        })
        
        downloadTask.resume()
        return downloadTask
    }
}