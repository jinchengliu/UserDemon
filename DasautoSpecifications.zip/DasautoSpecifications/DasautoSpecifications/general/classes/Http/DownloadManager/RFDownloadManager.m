
#import "RFDownloadManager.h"
#import "AFNetworking.h"
#import "RFRuntime.h"
#import "dout.h"

@interface RFDownloadManager ()

@property (RF_STRONG, atomic) NSMutableSet *requrestURLs;
@property (RF_STRONG, atomic) NSMutableArray *requrestOperationsDownloading;
@property (RF_STRONG, atomic) NSMutableArray *requrestOperationsQueue;
@property (RF_STRONG, atomic) NSMutableArray *requrestOperationsPaused;
@property (assign, readwrite, nonatomic) BOOL isDownloading;
@property dispatch_queue_t concurrent_queue;

@end

@implementation RFDownloadManager

@synthesize delegate = _delegate;
@synthesize isDownloading = _isDownloading;
@synthesize maxRunningTaskCount = _maxRunningTaskCount;
@synthesize shouldResume = _shouldResume;
@synthesize requrestURLs = _requrestURLs;
@synthesize requrestOperationsDownloading = _requrestOperationsDownloading;
@synthesize requrestOperationsQueue = _requrestOperationsQueue;
@synthesize requrestOperationsPaused = _requrestOperationsPaused;

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@: %p, downloading:%@, queue:%@, paused:%@>", [self class], self, self.requrestOperationsDownloading, self.requrestOperationsQueue, self.requrestOperationsPaused];
}

#pragma mark - 下载中的队列
- (NSArray *)downloadingOperations {
    return [self.requrestOperationsDownloading copy];
}
#pragma mark - 等待中的队列
- (NSArray *)operationsInQueue {
    return [self.requrestOperationsQueue copy];
}
#pragma mark - 暂停中的队列
- (NSArray *)pausedOperations {
    return [self.requrestOperationsPaused copy];
}
- (int)requrestURLsCount{
    return (int)[self.requrestURLs count];
}

- (NSMutableArray *)operations {
    
    @synchronized(self){
        
        NSMutableArray *total = [NSMutableArray arrayWithArray:self.requrestOperationsDownloading];
        [total addObjectsFromArray:self.requrestOperationsQueue];
        [total addObjectsFromArray:self.pausedOperations];
        
        NSMutableArray *results =[[NSMutableArray alloc] init];
        
        //过滤掉不在下载中的请求
        for (RFFileDownloadOperation *opertion in total) {
            if ([self.requrestURLs containsObject:opertion.request.URL]) {
                [results addObject:opertion];
            }
        }
        
        return results;
    }
}

- (void)clearAll{
    [self.requrestOperationsQueue removeAllObjects];
    [self.requrestOperationsDownloading removeAllObjects];
    [self.requrestOperationsPaused removeAllObjects];
    [self.requrestURLs removeAllObjects];
}

- (void)setMaxRunningTaskCount:(uint)maxRunningTaskCount {
    
    if (_maxRunningTaskCount != maxRunningTaskCount) {
        [self willChangeValueForKey:@keypath(self, maxRunningTaskCount)];
        int diffCount = self.downloadingOperations.count - maxRunningTaskCount;
        if (diffCount > 0) {
            for (int i = diffCount; i > 0; i--) {
                RFFileDownloadOperation *operation = [self.downloadingOperations lastObject];
                [self pauseOperation:operation];
            }
        }
        else {
            for (int i = diffCount; i > 0; i--) {
                [self startNextQueuedOperation];
            }
        }
        _maxRunningTaskCount = maxRunningTaskCount;
        [self didChangeValueForKey:@keypath(self, maxRunningTaskCount)];
    }
}

#pragma mark -
- (RFDownloadManager *)init {
    self = [super init];
    if (self) {
        _isDownloading = NO;
        _requrestURLs = [NSMutableSet set];
        _requrestOperationsQueue = [NSMutableArray array];
        // 设置最大下载个数
        _requrestOperationsDownloading = [NSMutableArray arrayWithCapacity:5];
        _requrestOperationsPaused = [NSMutableArray array];
        _shouldResume = YES;
    }
    return self;
}

- (RFDownloadManager *)initWithDelegate:(id<RFDownloadManagerDelegate>)delegate {
    self = [self init];
    if (self) {
        self.delegate = delegate;
    }
    return self;
}

+ (instancetype)sharedInstance {
	static RFDownloadManager *sharedInstance = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        sharedInstance = [[self alloc] init];
    });
	return sharedInstance;
}

#pragma mark -
- (RFFileDownloadOperation *)addURL:(NSURL *)url fileStorePath:(NSString *)destinationFilePath {
    
    @synchronized(self){
        if ([self.requrestURLs containsObject:url]) {
            dout_warning(@"RFDownloadManager: the url already existed. %@", url);
            return nil;
        }
        
        RFFileDownloadOperation *downloadOperation = [[RFFileDownloadOperation alloc] initWithRequest:[NSURLRequest requestWithURL:url] targetPath:destinationFilePath shouldResume:self.shouldResume shouldCoverOldFile:YES];
        if (downloadOperation == nil) {
            return nil;
        }
        [self setupDownloadOperation:downloadOperation];
        
        if (![self.requrestOperationsQueue containsObject:downloadOperation]) {
           [self.requrestOperationsQueue addObject:downloadOperation];
        }
        
        [self.requrestURLs addObject:url];
        
        return downloadOperation;
    }
}

- (RFFileDownloadOperation *)addURL:(NSURL *)url fileStorePath:(NSString *)destinationFilePath fileInfo:(NSString *)fileInfoObject{

    @synchronized(self){
        
        // 判断url  是否存在
        if ([self.requrestURLs containsObject:url]) {
            dout_warning(@"RFDownloadManager: the url already existed. %@", url);
            NSLog(@"RFDownloadManager: the url already existed. %@", url);
            return nil;
        }
        
        NSMutableURLRequest *urlreques=  [NSMutableURLRequest requestWithURL:url];
        
        RFFileDownloadOperation *downloadOperation = [[RFFileDownloadOperation alloc] initWithRequest:urlreques targetPath:destinationFilePath shouldResume:YES shouldCoverOldFile:YES];
        if (downloadOperation == nil) {
            return nil;
        }
        [self setupDownloadOperation:downloadOperation];
        [self.requrestOperationsQueue addObject:downloadOperation];
        [self.requrestURLs addObject:url];
        
        return downloadOperation;
    }
}
- (RFFileDownloadOperation *)findOperationWithURL:(NSURL *)url {
    RFFileDownloadOperation *operation = nil;
    
#define _RFDownloadManagerFindOperationInSet(RequrestOperations)\
    for (operation in RequrestOperations) {\
        if ([operation.request.URL.path isEqualToString:url.path]) {\
            return operation;\
        }\
    }
    
    _RFDownloadManagerFindOperationInSet(self.requrestOperationsDownloading)
    _RFDownloadManagerFindOperationInSet(self.requrestOperationsQueue)
    _RFDownloadManagerFindOperationInSet(self.requrestOperationsPaused)
#undef _RFDownloadManagerFindOperationInSet
    return nil;
}

#pragma mark- 初始化下载队列
- (void)setupDownloadOperation:(RFFileDownloadOperation *)downloadOperation {
    
    __weak RFFileDownloadOperation *aOperation = downloadOperation;
    //默认取消时删除临时文件
    aOperation.deleteTempFileOnCancel = YES;
    
    [aOperation setProgressiveDownloadProgressBlock:^(RFFileDownloadOperation *operation) {
        if ([self.delegate respondsToSelector:@selector(RFDownloadManager:operationStateUpdate:)]) {
            [self.delegate RFDownloadManager:self operationStateUpdate:operation];
        }
    }];
    
    [aOperation setCompletionBlockWithSuccess:^(RFFileDownloadOperation *operation, id responseObject) {
        [self onFileDownloadOperationComplete:operation success:YES];
        
    } failure:^(RFFileDownloadOperation *operation, NSError *error) {
        
        NSLog(@"下载失败：%@  --cookis",error);
        
        if (error.code !=NSURLErrorCancelled) {
            NSLog(@"下载失败：%@  --cookis",error);
            
//            if (operation.response.statusCode >299&&operation.response.statusCode<308) {
//                NSString *location=[operation.response.allHeaderFields objectForKey:@"Location"];
//                TTDEBUGLOG(@"下载重新定向：%@",location);
//            }else{
                operation.error = [[NSError alloc] initWithDomain:error.description code:error.code userInfo:error.userInfo];
                operation.errorCode = error.code;
                [self onFileDownloadOperationComplete:operation success:NO];
//            }
            
        }
        else{
            NSString *temp =[operation tempPath]; 
            NSLog(@"delege temp file：%@",temp);
            if([[NSFileManager defaultManager] fileExistsAtPath:temp isDirectory:NO]) {
                BOOL isYes=[[NSFileManager defaultManager] removeItemAtPath:temp error:nil];
                NSLog(@"cancel is Success :%d",isYes);
            }
        }
       
    }];
}

- (void)onFileDownloadOperationComplete:(RFFileDownloadOperation *)operation success:(BOOL)success {
    
    [self.requrestOperationsDownloading removeObject:operation];
    [self.requrestURLs removeObject:operation.request.URL];
    [self.requrestOperationsQueue removeObject:operation];
    [self.requrestOperationsPaused removeObject:operation];
    
    if (success) {
 
        if ([self.delegate respondsToSelector:@selector(RFDownloadManager:operationCompleted:)]) {
        
            dispatch_async(dispatch_get_main_queue(), ^{

                [self.delegate RFDownloadManager:self operationCompleted:operation];
            });
        }
    }else {
        
        if ([self.delegate respondsToSelector:@selector(RFDownloadManager:operationFailed:)]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.delegate RFDownloadManager:self operationFailed:operation];
            });
        }
    }
    
    // 开启下一个
    [self startNextQueuedOperation];
}

- (void)onFileDownLoadOperationStateChange :(RFFileDownloadOperation *)operation state:(RFFileDownloadState)states{
    
    if ([self.delegate respondsToSelector:@selector(RFDownloadManager:operationstateChange: state:)]) {

        dispatch_async(dispatch_get_main_queue(), ^{
            [self.delegate RFDownloadManager:self operationstateChange:operation state:states];
        });
    }
}

#pragma mark - Queue Manage
- (void)startAll {
    // Paused => Queue
    
    @synchronized(self)
    {
        [self.requrestOperationsQueue addObjectsFromArray:self.requrestOperationsPaused];
        [self.requrestOperationsPaused removeAllObjects];
        
        // Queue => Start
        while (self.requrestOperationsDownloading.count < _maxRunningTaskCount) {
            RFFileDownloadOperation *operation = [self.requrestOperationsQueue firstObject];
            if (!operation)
                break;
            [self startOperation:operation];
        }
        
        // 发送剩下的等待下载---的消息
        for (RFFileDownloadOperation *operation in self.requrestOperationsQueue) {
            [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithWaitDownload];
        }
    }
}

- (void)pauseAll {
    RFFileDownloadOperation *operation;
    // Downloading => Pause
    while ((operation = [self.requrestOperationsDownloading lastObject])) {
        [self pauseOperation:operation];
    }
    
    // Queue => Pause
    @synchronized(self)
    {
        [self.requrestOperationsPaused addObjectsFromArray:self.requrestOperationsQueue];
        [self.requrestOperationsQueue removeAllObjects];
        
        // 发送剩下的暂停下载---的消息
        for (RFFileDownloadOperation *operation in self.requrestOperationsPaused) {
            [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithPaused];
        }
    }
}

- (void)cancelAll {
    
    RFFileDownloadOperation *operation;
    while ((operation = [self.requrestOperationsPaused lastObject])) {
        [self canncelAllOpertion:operation];
    }
    while ((operation = [self.requrestOperationsQueue lastObject])) {
        [self canncelAllOpertion:operation];
    }
    while ((operation = [self.requrestOperationsDownloading lastObject])) {
        [self canncelAllOpertion:operation];
    }
    
     [self clearAll];
}

// 优化取消所有的操作，
- (void)canncelAllOpertion:(RFFileDownloadOperation *)operation{
    
    if (!operation) {
        dout_warning(@"RFDownloadManager > cancelOperation: operation is nil")
        return;
    }
    [operation cancel];
    
    
    @synchronized(self)
    {
        [self.requrestURLs removeObject:operation.request.URL];
        [self.requrestOperationsDownloading removeObject:operation];
        [self.requrestOperationsQueue removeObject:operation];
        [self.requrestOperationsPaused removeObject:operation];
        
        [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithCannel];
    }
   
    
}
- (void)startNextQueuedOperation {
    if (self.requrestOperationsQueue.count > 0 && self.requrestOperationsDownloading.count < self.maxRunningTaskCount) {
        RFFileDownloadOperation *operationNext = [self.requrestOperationsQueue firstObject];
        [self startOperation:operationNext];
    }
    
   
}


// Note: 这些方法本身会管理队列
- (void)startOperation:(RFFileDownloadOperation *)operation {
    if (!operation) {
        dout_warning(@"RFDownloadManager > startOperation: operation is nil")
        return;
    }
    
    @synchronized(self)
    {
        [self.requrestOperationsPaused removeObject:operation];
        
        if (self.requrestOperationsDownloading.count < self.maxRunningTaskCount) {
            // 开始下载
            if ([operation isPaused]) {
                [operation resume];
            }
            else {
                [operation start];
            }

            [self.requrestOperationsDownloading addObject:operation];
            [self.requrestOperationsQueue removeObject:operation];
            
            [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithDownloading];
        }
        else {
            // 加入到等待队列
            
            if (![self.requrestOperationsQueue containsObject:operation]) {
                [self.requrestOperationsQueue addObject:operation];
                [self.requrestOperationsDownloading removeObject:operation];
            }
            
           [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithWaitDownload];
        }
    }
    
}


- (void)pauseOperation:(RFFileDownloadOperation *)operation {
    if (!operation) {
        dout_warning(@"RFDownloadManager > pauseOperation: operation is nil")
        return;
    }
    
    @synchronized(self)
    {
        if (![operation isPaused]) {
            [operation pause];
        }

        if (![self.requrestOperationsPaused containsObject:operation]) {
            [self.requrestOperationsPaused addObject:operation];
        };
        [self.requrestOperationsQueue removeObject:operation];
        [self.requrestOperationsDownloading removeObject:operation];
        
         [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithPaused];
        
        [self startNextQueuedOperation];
    }
    
}

- (void)cancelOperation:(RFFileDownloadOperation *)operation {
   
    
    @synchronized(self)
    {
        if (!operation) {
            dout_warning(@"RFDownloadManager > cancelOperation: operation is nil")
            return;
        }
        
        [operation cancel];
        NSString *temppath=[operation tempPath];
        NSFileManager* fileManager = [NSFileManager defaultManager];
        NSError* error = nil;
        BOOL success = [fileManager removeItemAtPath:temppath error:&error];
        if (success || error) {
            NSLog(@"：删除缓存成功");
        }else{
            NSLog(@"：删除缓存失败 error：%@",error);
        }
        [operation cancel];
        [self.requrestURLs removeObject:operation.request.URL];
        [self.requrestOperationsDownloading removeObject:operation];
        [self.requrestOperationsQueue removeObject:operation];
        [self.requrestOperationsPaused removeObject:operation];

        [self onFileDownLoadOperationStateChange:operation state:RFFileDownloadWithCannel];
        
        [self startNextQueuedOperation];
    }
    
}

- (void)startOperationWithURL:(NSURL *)url {
    [self startOperation:[self findOperationWithURL:url]];
}

- (void)pauseOperationWithURL:(NSURL *)url {
    [self pauseOperation:[self findOperationWithURL:url]];
}

- (void)cancelOperationWithURL:(NSURL *)url {
    [self cancelOperation:[self findOperationWithURL:url]];
}

- (BOOL)isDownloading
{
    if ([self.requrestOperationsDownloading count] > 0) {
        return YES;
    }else{
        return NO;
    }
}

@end

