
#import "RFFileDownloadOperation.h"
#import "AFURLConnectionOperation.h"
#include <fcntl.h>
#include <unistd.h>
#import "NSFileManager+RFKit.h"
#import "NSString+RFKit.h"
#import "dout.h"

@interface AFURLConnectionOperation (AFInternal)
@property (RF_STRONG, nonatomic) NSURLRequest *request;
@property (readonly, nonatomic) long long totalBytesRead;

@end

@interface RFFileDownloadOperation()
@property (RF_STRONG, nonatomic) NSError *fileError;
@property (RF_STRONG, nonatomic) NSTimer *stausRefreshTimer;
@property (assign, readwrite) float transmissionSpeed;
@property (RF_STRONG, nonatomic) NSString *tempPath;
@property (assign) long long totalContentLength;
@property (assign, nonatomic) long long totalBytesReadPerDownload;
@property (assign, nonatomic) long long lastTotalBytesReadPerDownload;
@property (assign) long long offsetContentLength;       // override
@property (copy, nonatomic) void (^progressiveDownloadProgressBlock)(RFFileDownloadOperation *operation);
@end


@implementation RFFileDownloadOperation
@synthesize targetPath = _targetPath;
@synthesize shouldResume = _shouldResume;
@synthesize shouldOverwriteOldFile = _shouldOverwriteOldFile;
@synthesize fileError = _fileError;
@synthesize stausRefreshTimer = _stausRefreshTimer;
@synthesize transmissionSpeed = _transmissionSpeed;
@synthesize tempPath = _tempPath;
@synthesize totalContentLength = _totalContentLength;
@synthesize totalBytesReadPerDownload = _totalBytesReadPerDownload;
@synthesize lastTotalBytesReadPerDownload = _lastTotalBytesReadPerDownload;
@synthesize progressiveDownloadProgressBlock = _progressiveDownloadProgressBlock;
//@synthesize fileInfo = _fileInfo;
@synthesize error = _error;
@synthesize errorCode = _errorCode;


- (NSString *)debugDescription {
    NSString *status = self.isFinished? @"isFinished" : (self.isPaused? @"isPaused" : (self.isExecuting? @"isExecuting" : @"Unexpected"));
    return [NSString stringWithFormat:@"%@: status: %@, speed: %f, %lld/%lld", [self.request.URL lastPathComponent], status, self.transmissionSpeed, self.bytesDownloaded, self.bytesFileSize];
}

- (id)initWithRequest:(NSURLRequest *)urlRequest targetPath:(NSString *)targetPath {
    return [self initWithRequest:urlRequest targetPath:targetPath shouldResume:YES shouldCoverOldFile:YES];
}

- (id)initWithRequest:(NSURLRequest *)urlRequest targetPath:(NSString *)targetPath shouldResume:(BOOL)shouldResume shouldCoverOldFile:(BOOL)shouldOverwriteOldFile {
    
    NSParameterAssert(urlRequest != nil && targetPath.length > 0);
    if (!(self = [super initWithRequest:urlRequest])) {
        return nil;
    }
        
    // Check target path
    NSString *destinationPath = nil;
    
    // We assume that at least the directory has to exist on the targetPath
    BOOL isDirectory;
    if(![[NSFileManager defaultManager] fileExistsAtPath:targetPath isDirectory:&isDirectory]) {
        isDirectory = NO;
    }
    // If targetPath is a directory, use the file name we got from the urlRequest.
    if (isDirectory) {
        NSString *fileName = [urlRequest.URL lastPathComponent];
        RFAssert(fileName.length > 0, @"Cannot decide file name.");
        destinationPath = [NSString pathWithComponents:@[targetPath, fileName]];
    }
    else {
        destinationPath = targetPath;
    }
    
    self.shouldOverwriteOldFile = shouldOverwriteOldFile;
    if (!shouldOverwriteOldFile && [[NSFileManager defaultManager] fileExistsAtPath:destinationPath]) {
        NSLog(@"RFFileDownloadOperation: File already exist, and cover option was off.");
        return nil;
    }
    
    _targetPath = destinationPath;
    
    // Download is saved into a temporal file and remaned upon completion___ changed just return _targetPath
    NSString *tempPath = [self tempPath];
    
    // Do we need to resume the file?
    _shouldResume = shouldResume;
    BOOL isResuming = [self updateByteStartRangeForRequest];
    
    // Try to create/open a file at the target location
//    if (!isResuming) {
//        int fileDescriptor = open([tempPath UTF8String], O_CREAT | O_EXCL | O_RDWR, 0666);
//        if (fileDescriptor > 0) close(fileDescriptor);
//    }
    
    self.outputStream = [NSOutputStream outputStreamToFileAtPath:tempPath append:YES];
    if (!self.outputStream) {
        return nil;
    }
    // Give the object its default completionBlock.
    [self setCompletionBlockWithSuccess:nil failure:nil];
    
    // Set defalut value  刷新频率
    _stausRefreshTimeInterval = 1;
    
    return self;
}

// Updates the current request to set the correct start-byte-range.
- (BOOL)updateByteStartRangeForRequest {
    BOOL isResuming = NO;
    if (self.shouldResume) {
        unsigned long long downloadedBytes = [[NSFileManager defaultManager] fileSizeForPath:_targetPath];
        if (downloadedBytes > 1) {
            NSMutableURLRequest *mutableURLRequest = [self.request mutableCopy];
            NSString *requestRange = [NSString stringWithFormat:@"bytes=%llu-", downloadedBytes];
            [mutableURLRequest setValue:requestRange forHTTPHeaderField:@"Range"];
            self.request = mutableURLRequest;
            isResuming = YES;
        }
    }
    return isResuming;
}


- (void)dealloc {
    
    
//    [super setCompletionBlock:nil];
//    dout(@"dealloc: %@", self);
}

#pragma mark - Control
- (void)start {
    double delayInSeconds = 0.01;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void) {
        [super start];
        [self activeStausRefreshTimer];

    });
}

- (void)resume {
    [super resume];
    [self activeStausRefreshTimer];
}

- (void)pause {
    [super pause];
    [self deactiveStausRefreshTimer];
    [self updateByteStartRangeForRequest];
}

- (void)cancel {
    [super cancel];
    [self deactiveStausRefreshTimer];
}
// 开始刷新
- (void)activeStausRefreshTimer {
    if (!self.stausRefreshTimer) {
        self.stausRefreshTimer = [NSTimer scheduledTimerWithTimeInterval:self.stausRefreshTimeInterval target:self selector:@selector(stausRefresh) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:self.stausRefreshTimer forMode:NSDefaultRunLoopMode];
        self.transmissionSpeed = 0;
    }
}

// 停止刷新数据
- (void)deactiveStausRefreshTimer {
    if (self.stausRefreshTimer) {
        [self.stausRefreshTimer invalidate];
        self.stausRefreshTimer = nil;
        
        self.transmissionSpeed = 0;
    }
}

- (void)stausRefresh {
    self.transmissionSpeed = (self.totalBytesReadPerDownload - self.lastTotalBytesReadPerDownload)/self.stausRefreshTimeInterval;
    self.lastTotalBytesReadPerDownload = self.totalBytesReadPerDownload;
    if (self.transmissionSpeed < 0) {
        dout_float(self.lastTotalBytesReadPerDownload)
        dout_float(self.totalBytesReadPerDownload)
        self.transmissionSpeed = 0;
        
    }
    _dout_float(self.transmissionSpeed)
}

#pragma mark - Path

+ (NSString *)cacheFolder {

    
//    fix Create cacheFolder if it does not exist(https://github.com/steipete/AFDownloadRequestOperation/commit/6efe448017f9c15def19932233b04aea96c2d040)
    NSFileManager *filemgr = [NSFileManager new];
    static NSString *cacheFolder;
    
    if (!cacheFolder) {
        NSString *cacheDir = NSTemporaryDirectory();
        cacheFolder = [cacheDir stringByAppendingPathComponent:kAFNetworkingIncompleteDownloadFolderName];
    }
    
    // ensure all cache directories are there
    NSError *error = nil;
    if(![filemgr createDirectoryAtPath:cacheFolder withIntermediateDirectories:YES attributes:nil error:&error]) {
        cacheFolder = nil;
    }
    return cacheFolder;

}

- (NSString *)tempPath {
//    NSString *tempPath = nil;
//    if (self.targetPath) {
//        NSString *md5URLString = [NSString MD5String:self.targetPath];
//        tempPath = [[[self class] cacheFolder] stringByAppendingPathComponent:md5URLString];
//    }
    return self.targetPath;
}

- (BOOL)deleteTempFileWithError:(NSError **)error {
    NSFileManager *fileManager = [NSFileManager new];
    BOOL success = YES;
    @synchronized(self) {
        NSString *tempPath = [self tempPath];
        if ([fileManager fileExistsAtPath:tempPath]) {
            success = [fileManager removeItemAtPath:[self tempPath] error:error];
        }
    }
    return success;
}

- (void)setProgressiveDownloadCallbackQueue:(dispatch_queue_t)progressiveDownloadCallbackQueue {
    if (progressiveDownloadCallbackQueue != _progressiveDownloadCallbackQueue) {
        if (_progressiveDownloadCallbackQueue) {
#if !OS_OBJECT_USE_OBJC
            dispatch_release(_progressiveDownloadCallbackQueue);
#endif
            _progressiveDownloadCallbackQueue = NULL;
        }
        
        if (progressiveDownloadCallbackQueue) {
#if !OS_OBJECT_USE_OBJC
            dispatch_retain(progressiveDownloadCallbackQueue);
#endif
            _progressiveDownloadCallbackQueue = progressiveDownloadCallbackQueue;
        }
    }
}



#pragma mark - AFURLRequestOperation

- (void)setCompletionBlockWithSuccess:(void (^)(RFFileDownloadOperation *operation, id responseObject))success
                              failure:(void (^)(RFFileDownloadOperation *operation, NSError *error))failure
{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-retain-cycles"
    self.completionBlock = ^ {
        
        NSError *localError = nil;
        if([self isCancelled]) {
            // should we clean up? most likely we don't.
            if (self.isDeletingTempFileOnCancel) {
                [self deleteTempFileWithError:&localError];
                if (localError) {
                    _fileError = localError;
                }
            }
            
            // loss of network connections = error set, but not cancel
        }else if(!_error) {
            // move file to final position and capture error
            @synchronized(self) {
//                NSFileManager *fileManager = [NSFileManager new];
//                if (self.shouldOverwriteOldFile) {
//                    [fileManager removeItemAtPath:_targetPath error:&localError]; // avoid "File exists" error
//                    _fileError = localError;
//                }
//                [fileManager moveItemAtPath:[self tempPath] toPath:_targetPath error:&localError];
//                if (localError) {
//                    _fileError = localError;
//                }
            }
        }
        
        NSLog(@"download error:%@",self.fileError);
        if (_error) {
            if (failure) {
                dispatch_async(self.failureCallbackQueue ?: dispatch_get_main_queue(), ^{
                    failure(self, _error);
                });
            }
        } else {
            if (success) {
                NSFileManager *fm = [NSFileManager new];
                if ([fm fileSizeForPath:_targetPath]) {
                    dispatch_async(self.successCallbackQueue ?: dispatch_get_main_queue(), ^{
                        success(self, _targetPath);
//                        [self cancel];
                    });
                }else{
                    NSError *error =[[NSError alloc] initWithDomain:@"下载文件为空" code:NSURLErrorNetworkConnectionLost userInfo:nil];
                    self.fileError = error;
    
                    NSLog(@"file is empty.");
                }
            }
        }
        [self deactiveStausRefreshTimer];
    };
#pragma clang diagnostic pop
}

- (NSError *)error {
    return self.fileError ? self.fileError : [super error];
}

// Avoid errors when resuming a fully downloaded file by accepte 416.
+ (NSIndexSet *)acceptableStatusCodes {
	NSMutableIndexSet *acceptableStatusCodes = [NSMutableIndexSet indexSetWithIndexesInRange:NSMakeRange(200, 100)];
	[acceptableStatusCodes addIndex:416];
	
	return acceptableStatusCodes;
}


- (long long)bytesDownloaded {
    return self.totalBytesReadPerDownload + self.offsetContentLength;
}

- (long long)bytesFileSize {
    return self.totalContentLength;
}

#pragma mark - NSURLConnectionDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [super connection:connection didReceiveResponse:response];
    
    // Check if we have the correct response
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    if (![httpResponse isKindOfClass:[NSHTTPURLResponse class]]) {
        return;
    }
    
    NSLog(@"didReceiveResponse:%ld",(long)httpResponse.statusCode);
    // Check for valid response to resume the download if possible
    long long totalContentLength = self.response.expectedContentLength;
    long long fileOffset = 0;
    if(httpResponse.statusCode == 206) {
        NSString *contentRange = [httpResponse.allHeaderFields valueForKey:@"Content-Range"];
        if ([contentRange hasPrefix:@"bytes"]) {
            NSArray *bytes = [contentRange componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" -/"]];
            if ([bytes count] == 4) {
                fileOffset = [bytes[1] longLongValue];
                totalContentLength = [bytes[3] longLongValue]; // If this is *, it's converted to 0
            }
        }
    }else if (httpResponse.statusCode != 200){
        return;
    }
    self.totalBytesReadPerDownload = 0;
    self.lastTotalBytesReadPerDownload = 0;
    self.offsetContentLength = fmaxl(fileOffset, 0);
    self.totalContentLength = totalContentLength;
    
    // begin  ----2014-11-20 10:08:30
    // Truncate cache file to offset provided by server.
    // Using self.outputStream setProperty:@(_offsetContentLength) forKey:NSStreamFileCurrentOffsetKey]; will not work (in contrary to the documentation)
    NSString *tempPath = [self tempPath];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    if ([fileManager fileSizeForPath:tempPath] != _offsetContentLength) {
        [self.outputStream close];
        BOOL isResuming = _offsetContentLength > 0;
        if (isResuming) {
            NSFileHandle *file = [NSFileHandle fileHandleForWritingAtPath:tempPath];
            [file truncateFileAtOffset:_offsetContentLength];
            [file closeFile];
        }
        self.outputStream = [NSOutputStream outputStreamToFileAtPath:tempPath append:isResuming];
        [self.outputStream open];
    }
    // end
    // [self.outputStream setProperty:@(self.offsetContentLength) forKey:NSStreamFileCurrentOffsetKey];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data  {
    // Don't write to output stream if any error occurs
//    || ![self hasAcceptableContentType]
//    if (![self hasAcceptableStatusCode]) {
//        return;
//    }
    [super connection:connection didReceiveData:data];
    
    // Track custom bytes read because totalBytesRead persists between pause/resume.
    self.totalBytesReadPerDownload += [data length];

    if (self.progressiveDownloadProgressBlock) {
        self.progressiveDownloadProgressBlock(self);
    }
}

- (void)connection:(NSURLConnection __unused *)connection
  didFailWithError:(NSError *)error
{
    [super connection:connection didFailWithError:error];
    
    _errorCode = error.code;
    NSLog(@"didFailWithError:%@",error);
}

@end
