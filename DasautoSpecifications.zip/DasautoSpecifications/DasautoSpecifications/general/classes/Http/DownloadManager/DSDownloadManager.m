//
//  DSDownloadManager.m
//  DasautoSpecifications
//
//  Created by wangrui on 16/1/14.
//  Copyright © 2016年 bdcluster. All rights reserved.
//

#import "DSDownloadManager.h"
#import "DasautoSpecifications-swift.h"

#define kDownloadOperationUpdateNotification @"downloadOperationUpdate"
#define kDownloadStateChangedNotification @"downloadStateChanged"
#define kDownloadDirectory @"download"

@implementation DSDownloadManager
@synthesize downloadZipQueue = _downloadZipQueue;
@synthesize documentPath = _documentPath;
@synthesize downloadManager = _downloadManager;

+ (instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    static DSDownloadManager *manamger = nil;
    dispatch_once(&onceToken, ^{
        manamger = [[DSDownloadManager alloc] init];
    });
    return manamger;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        // 和 DSFileManager.swift里面的document保持一致
        _documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, true)[0];
        _downloadZipQueue = dispatch_queue_create("com.bdcluster.download.zip", DISPATCH_QUEUE_SERIAL);
        _downloadManager = [[RFDownloadManager sharedInstance] initWithDelegate:self];
        [_downloadManager setMaxRunningTaskCount:5];
        
        // 先创建一个一个文件夹
        [self createDirectory:kDownloadDirectory];
    }
    return self;
}

- (RFDownloadManager *)createRFDownloadManager
{
    if (!_downloadManager) {
        _downloadManager = [[RFDownloadManager sharedInstance] initWithDelegate:self];
        //设置最多下载个数
        [_downloadManager setMaxRunningTaskCount:5];
        [_downloadManager startAll];
    }
    return _downloadManager;
}

- (void)createDirectory:(NSString *)directory
{
    NSFileManager *fileManager = [NSFileManager new];
    NSString *directoryPath = [_documentPath stringByAppendingPathComponent:directory];
    if (![fileManager fileExistsAtPath:directoryPath]) {
        [fileManager createDirectoryAtPath:directoryPath withIntermediateDirectories:true attributes:nil error:nil];
        [Util addSkipBackupAttributeToItemAtPath:directoryPath];
    }
    else {
        NSLog(@"%@ 文件夹已经存在",directoryPath);
    }
}

#pragma mark - Download Zip
- (BOOL)addZipToDown:(id)zip
{
    ZipPackage *zipPackage = zip;
    
    NSURL *url = [NSURL URLWithString:zipPackage.urlString];
    NSString *targetPath = [[_documentPath stringByAppendingPathComponent:kDownloadDirectory] stringByAppendingPathComponent:zipPackage.zipName];
    
    RFFileDownloadOperation *downloadOperation = [_downloadManager addURL:url fileStorePath:targetPath];
    if (downloadOperation) {
        
        [_downloadManager startOperation:downloadOperation];
        // 添加下载
//        NSString *url = zipPackage.urlString;
//        NSDictionary *dict = [[NSDictionary alloc] initWithObjects:@[url,@"AddDown"] forKeys:@[@"url",@"state"]];
//        [self postDownloadStateDidChangedMessage:dict];
        return YES;
    }

    return NO;
}

#pragma mark - 下载状态改变消息的发送
#define kAddDown      @"AddDown"
#define kPauseDown    @"PauseDown"
#define kCancelDown   @"CancelDown"
#define kWaitDown     @"WaitDown"
#define kDownloading  @"Downloading"
#define kCompleteDown @"CompleteDown"
#define kFailDown     @"FailDown"
/*
 AddDown        添加下载
 PauseDown      暂停下载
 CancelDown     取消下载
 WaitDown       等待下载
 Downloading    下载中
 CompleteDown   完成下载
 FailDown       下载失败
 */
- (void)postDownloadStateDidChangedMessage:(NSDictionary *)message
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:kDownloadStateChangedNotification object:message];

    });
}

/*!
 @methd      pauseZip:
 @bastract   暂停下载
 @result
 */
- (void)pauseZip:(NSString *)url
{
    RFFileDownloadOperation *operation = [_downloadManager findOperationWithURL:[NSURL URLWithString:url]];
    // TODP:在这里实现暂停后的操作
    [_downloadManager pauseOperation:operation];
}
/*!
 @methd      resumeZip:
 @bastract   继续下载
 @result
 */
- (void)resumeZip:(NSString *)url
{
    RFFileDownloadOperation *operation = [_downloadManager findOperationWithURL:[NSURL URLWithString:url]];
    [_downloadManager startOperation:operation];
}
/*!
 @methd      cancelZip:
 @bastract   取消下载
 @result
 */
- (void)cancelZip:(NSString *)url
{
    RFFileDownloadOperation *operation = [_downloadManager findOperationWithURL:[NSURL URLWithString:url]];
    // TODP:在这里实现取消下载后的操作
    [_downloadManager cancelOperation:operation];
}

#pragma mark - 判断是否开启下载
- (BOOL)isStartOperation:(NSString *)url
{
    BOOL start;
    start = [self zipIsInDownloadingOperation:url];
    if (start) return YES;
    start = [self zipIsInPausedOperation:url];
    if (start) return YES;
    start = [self zipIsInWaitingOperation:url];
    if (start) return YES;
    return start;
}


#pragma mark - 判断zip是否是在下载队列中
- (BOOL)zipIsInDownloadingOperation:(NSString *)url
{
    NSArray *downloadingArray = [_downloadManager downloadingOperations];
    for (RFFileDownloadOperation *operation in downloadingArray) {
        NSString *absolutString = operation.request.URL.absoluteString;
        if ([absolutString isEqualToString:url]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark - 判断zip是否是在暂停队列中
- (BOOL)zipIsInPausedOperation:(NSString *)url
{
    NSArray *downloadingArray = [_downloadManager pausedOperations];
    for (RFFileDownloadOperation *operation in downloadingArray) {
        NSString *absolutString = operation.request.URL.absoluteString;
        if ([absolutString isEqualToString:url]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark - 判断zip是否是在等待队列中
- (BOOL)zipIsInWaitingOperation:(NSString *)url
{
    NSArray *downloadingArray = [_downloadManager operationsInQueue];
    for (RFFileDownloadOperation *operation in downloadingArray) {
        NSString *absolutString = operation.request.URL.absoluteString;
        if ([absolutString isEqualToString:url]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark - RFDownloadManagerDelegate
// 成功下载
- (void)RFDownloadManager:(RFDownloadManager *)downloadManager operationCompleted:(RFFileDownloadOperation *)operation
{
    NSString *url = operation.request.URL.absoluteString;
    NSDictionary *dict = [[NSDictionary alloc] initWithObjects:@[url,kCompleteDown] forKeys:@[@"url",@"state"]];
    [self postDownloadStateDidChangedMessage:dict];
}
// 下载失败
- (void)RFDownloadManager:(RFDownloadManager *)downloadManager operationFailed:(RFFileDownloadOperation *)operation
{
    NSString *url = operation.request.URL.absoluteString;
    NSDictionary *dict = [[NSDictionary alloc] initWithObjects:@[url,kFailDown] forKeys:@[@"url",@"state"]];
    [self postDownloadStateDidChangedMessage:dict];
}

// 用于下载状态更新，进度、速度
- (void)RFDownloadManager:(RFDownloadManager *)downloadManager operationStateUpdate:(RFFileDownloadOperation *)operation
{
    dispatch_async(_downloadZipQueue, ^{
        
        [[NSNotificationCenter defaultCenter] postNotificationName:kDownloadOperationUpdateNotification object:operation];
    });
}

// 下载队列的变动  下载中，暂停，取消，等待下载
- (void)RFDownloadManager:(RFDownloadManager *)downloadManager operationstateChange:(RFFileDownloadOperation*)operation state:(RFFileDownloadState)states
{
    NSString *url = operation.request.URL.absoluteString;
    NSString *state = @"";
    switch (states) {
        case RFFileDownloadWithDownloading:
            state = kDownloading;
            break;
        case RFFileDownloadWithPaused:
            state = kPauseDown;
            break;
        case RFFileDownloadWithCannel:
            state = kCancelDown;
            break;
        case RFFileDownloadWithWaitDownload:
            state = kWaitDown;
            break;
            
        default:
            break;
    }
    NSDictionary *dict = [[NSDictionary alloc] initWithObjects:@[url,state] forKeys:@[@"url",@"state"]];
    [self postDownloadStateDidChangedMessage:dict];
}

@end
