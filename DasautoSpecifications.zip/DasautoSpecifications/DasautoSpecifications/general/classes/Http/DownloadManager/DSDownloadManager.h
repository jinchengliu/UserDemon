//
//  DSDownloadManager.h
//  DasautoSpecifications
//
//  Created by wangrui on 16/1/14.
//  Copyright © 2016年 bdcluster. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RFDownloadManager.h"

@interface DSDownloadManager : NSObject<RFDownloadManagerDelegate>

// 下载对列
@property (strong, nonatomic) dispatch_queue_t downloadZipQueue;
@property (strong, nonatomic) NSString *documentPath;
@property (strong, nonatomic) RFDownloadManager *downloadManager;

+ (instancetype)shareInstance;
- (RFDownloadManager *)createRFDownloadManager;

#pragma  mark - Download Zip
/*!
 @methd      addZipToDown:
 @bastract   添加下载包_添加下载包的同时需要修改包的状态, 保存归档文件
 @result
 */
- (BOOL)addZipToDown:(id)zip;

/*!
 @methd      pauseZip:
 @bastract   暂停下载
 @result
 */
- (void)pauseZip:(NSString *)url;

/*!
 @methd      resumeZip:
 @bastract   继续下载
 @result
 */
- (void)resumeZip:(NSString *)url;

/*!
 @methd      cancelZip:
 @bastract   取消下载
 @result
 */
- (void)cancelZip:(NSString *)url;

#pragma mark - 判断是否开启下载
/**
 *  通过url判断, 是否开启下载功能
 *
 *  @param url zip的下载路径
 */
- (BOOL)isStartOperation:(NSString *)url;
#pragma mark - 判断zip是否是在下载队列中
- (BOOL)zipIsInDownloadingOperation:(NSString *)url;
#pragma mark - 判断zip是否是在暂停队列中
- (BOOL)zipIsInPausedOperation:(NSString *)url;

#pragma mark - 判断zip是否是在等待队列中
- (BOOL)zipIsInWaitingOperation:(NSString *)url;


@end
