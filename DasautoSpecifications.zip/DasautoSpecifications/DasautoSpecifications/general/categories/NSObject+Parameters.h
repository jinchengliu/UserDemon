//
//  NSObject+Parameters.h
//  FirstApp
//
//  Created by chenpan on 14-10-17.
//  Copyright (c) 2014年 chenpan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Parameters)

- (NSDictionary *)wrapParameters:(NSDictionary *)params;
@end
