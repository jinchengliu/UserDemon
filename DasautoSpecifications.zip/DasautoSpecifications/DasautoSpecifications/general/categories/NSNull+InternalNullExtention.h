//
//  NSNull+InternalNullExtention.h
//  House
//
//  Created by 博加 on 14-11-1.
//  Copyright (c) 2014年 bojia. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NSNullObjects @[@"",@0,@{},@[]]

@interface NSNull (InternalNullExtention)

@end
