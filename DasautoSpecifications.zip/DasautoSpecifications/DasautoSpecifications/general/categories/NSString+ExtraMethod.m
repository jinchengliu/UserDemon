//
//  NSString+ExtraMethod.m
//  houseApp
//
//  Created by mac on 13-6-4.
//  Copyright (c) 2013年 Plusing Advesting Co., LTD. All rights reserved.
//

#include <regex.h>

#import "NSString+ExtraMethod.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSString (ExtraMethod)

- (NSString *)sha1
{
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, (uint32_t)data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}

- (NSString *)md5
{
    const char *cStr = [self UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, (uint32_t)strlen(cStr), result );
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}

- (NSString *)sxDefinitionAVC
{
    regex_t regex;
    regmatch_t match[2];
    char msgbuf[100];
    int reti;
    
    reti = regcomp(&regex, "P([[:digit:]]{3,})", REG_EXTENDED);
    if (reti) {
        //DLog(@"regular is not compile");
    }
    
    reti = regexec(&regex, [self cStringUsingEncoding:NSUTF8StringEncoding], 2, match, 0);
    
    if ( !reti ) {
        NSRange range = NSMakeRange(match[1].rm_so, match[1].rm_eo - match[1].rm_so);
        return [self substringWithRange:range];
    } else if ( reti == REG_NOMATCH ){
        //DLog(@"No match");
        return nil;
    } else {
        regerror(reti, &regex, msgbuf, sizeof(msgbuf));
        fprintf(stderr, "Regex match failed: %s\n", msgbuf);
        return nil;
    }
    return nil;
}

- (BOOL)isMatch:(NSString *)pattern
{
    NSError *err = nil;
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&err];
    if (err != nil) {
        //DLog(@"match regular expression error is [%@]", err);
        return NO;
    } else {
        NSUInteger number = [expression numberOfMatchesInString:self options:0 range:NSMakeRange(0, [self length])];
        return number == 0 ? NO : YES;
    }
}

- (BOOL)isLegalPhone
{
    return [self isMatch:@"^1(3|4|5|8)\\d{9}$"];
}

- (NSUInteger)unsignedIntegerValue
{
    return [self integerValue];
}

- (NSString *)stringByReplacingPathExtensionWithString:(NSString *)ext
{
    NSString *path = [self stringByDeletingLastPathComponent];
    NSString *last = [[self lastPathComponent] stringByDeletingPathExtension];
    return [[path stringByAppendingPathComponent:last] stringByAppendingPathExtension:ext];
}

@end
