//
//  NSString+ExtraMethod.h
//  houseApp
//
//  Created by mac on 13-6-4.
//  Copyright (c) 2013年 Plusing Advesting Co., LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ExtraMethod)

- (NSString *)sha1;

- (NSString *)md5;

- (NSString *)sxDefinitionAVC;

- (BOOL)isMatch:(NSString *)pattern;

- (BOOL)isLegalPhone;

- (NSUInteger)unsignedIntegerValue;

- (NSString *)stringByReplacingPathExtensionWithString:(NSString *)ext;

@end
