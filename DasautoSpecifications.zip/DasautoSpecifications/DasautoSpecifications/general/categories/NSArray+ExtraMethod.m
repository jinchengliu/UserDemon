//
//  NSArray+ExtraMethod.m
//  HaoZu
//
//  Created by luochenhao on 6/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NSArray+ExtraMethod.h"

@implementation NSArray (ExtraMethod)

- (id)objectSafetyAtIndex:(NSUInteger)index
{
    if (index >= [self count]) {
        return nil;
    } else {
        return [self objectAtIndex:index];
    }
}

- (NSArray *)mergeSameString
{
    NSMutableArray *tmp = [self mutableCopy];
    int i = 0;
    NSString *stringTmp = nil;
    while (i < [tmp count]) {
        stringTmp = [tmp objectAtIndex:i];
        for (int j = i + 1; j < [tmp count]; ) {
            if ([stringTmp isEqualToString:[tmp objectAtIndex:j]]) {
                [tmp removeObjectAtIndex:j];
            } else {
                j++;
            }
        }
        i++;
    }
    return [NSArray arrayWithArray:tmp];
}

@end
