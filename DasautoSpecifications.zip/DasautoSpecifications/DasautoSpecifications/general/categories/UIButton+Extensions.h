/*
 *  filename: UIButton+Extensions.h
 *  product name: DasautoSpecifications
 *
 *  author: shimingwei
 *  date time: 14/12/15.
 *  copyright: bdcluster
 */

#import <UIKit/UIKit.h>

@interface UIButton (Extensions)
@property(nonatomic, assign) UIEdgeInsets hitTestEdgeInsets;
@end
