//
//  NSObject+Parameters.m
//  FirstApp
//
//  Created by chenpan on 14-10-17.
//  Copyright (c) 2014年 chenpan. All rights reserved.
//

#import "NSObject+Parameters.h"
#import "UIDevice+Hardware.h"
#import "NSString+ExtraMethod.h"

@implementation NSObject (Parameters)

static const NSString *publicKey = @"d5f39a07b353df4b";
static const NSString *privateKey = @"f220363ec81a78f045c8368dbee966f8";

- (NSDictionary *)wrapParameters:(NSDictionary *)params {
    NSDictionary *temp = nil;
    
    NSError *err = nil;
    NSData *jsonParams = [NSJSONSerialization dataWithJSONObject:params options:0 error:&err];
    if (err != nil) {
        return nil;
    }
    
    NSString *sigTmp = [[NSString alloc] initWithData:jsonParams encoding:NSUTF8StringEncoding];
    NSString *sig = [self createSignWithString:sigTmp];
    
    temp = [NSDictionary dictionaryWithObjectsAndKeys:@"1.0",@"VER", sigTmp,@"PARAMS", [self info],@"INFO",sig,@"SIG",publicKey,@"KEY",nil];
    //NSLog(@"temp = %@",temp);
    return temp;
}

- (NSString *)createSignWithString:(NSString *)jsonString
{
    NSString *sigTmpString = [NSString stringWithFormat:@"%@%@", jsonString, privateKey];
    return [sigTmpString md5];
}

- (NSString *)info
{
    UIDevice *device = [UIDevice currentDevice];
    NSDictionary *info = @{@"dev":@"i",
                           @"os":[device systemVersion],
                           @"uuid":[device thisUUID]};
    NSData *data = [NSJSONSerialization dataWithJSONObject:info options:0 error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

@end
