//
//  NSArray+ExtraMethod.h
//  HaoZu
//
//  Created by luochenhao on 6/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (ExtraMethod)

- (id)objectSafetyAtIndex:(NSUInteger)index;

- (NSArray *)mergeSameString;

@end
