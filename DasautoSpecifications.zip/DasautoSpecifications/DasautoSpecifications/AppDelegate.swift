 /*
 *  filename: AppDelegate.swift
 *  product name: DasautoSpecifications
 *
 *  author: cp
 *  date time: 14/11/5.
 *  copyright: bdcluster
 */
 
import UIKit
import AVFoundation
 
var PackageFileManagerFilePath =  "\(NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as NSString)/PackageFileManager.archiver"
var wallPaper = "-1"                          // 壁纸
var themeColor = "_red"                       // 主题色调
var kHtmlFontSize = "'100%'"                  // 字体大小
var kUserId = "noLogin"                       // 登录用户ID(未登录时设置为"noLogin")

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, BMKGeneralDelegate {

    var window: UIWindow?
    var mapManager: BMKMapManager?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {

//        ThemeManager.sharedInstance.configureInitThemesPath()
        InstallUncaughtExceptionHandler()
        
        // 启动网络监测
        AFNetworkReachabilityManager.sharedManager().startMonitoring()
        self.setThemeColorAndFontSize()
        self.startBMKMap()
        self.setAVAudioSession()
        self.configureUserIdAndFirstInApp()

        return true
    }

    // MARK:
    // MARK: 设置主题颜色和字体大小
    func setThemeColorAndFontSize() {
        
        let userDefault = NSUserDefaults.standardUserDefaults()
        let objectColor = userDefault.objectForKey("themeColor") as? String
        if objectColor?.isEmpty == false {
            
            themeColor = objectColor!
        }
        let objectFont = userDefault.objectForKey("fontSize") as? String
        if objectFont?.isEmpty == false {
            
            kHtmlFontSize = objectFont!
        }
        
        let objectWallPaper = userDefault.objectForKey("wallpaper") as? String
        if objectWallPaper?.isEmpty == false {
            
            wallPaper = objectWallPaper!
        }
    }
    
    // MARK:
    // MARK: 设置地图
    func startBMKMap() {
        
        self.mapManager = BMKMapManager()
        /*
        com.bdcluster.DasAutoSpecification  _ 测试
        com.bdcluster.DasAutoSpecifications _ 生产
        qumcHBqg5UVak09ajnaIWadv   _ 测试版
        ekpkLqWeH8A5ywnfPxADa05U   - 生产
        */
        let ret: Bool = self.mapManager!.start("ekpkLqWeH8A5ywnfPxADa05U", generalDelegate: self)
        if ret {
            
            Logger.info("BMKMapManager启动成功")
        }else {
            
            Logger.error("BMKMapManager启动失败")
        }
    }
    
    // MARK:
    // MARK: 设置后台运行
    func setAVAudioSession() {
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
        } catch let error as NSError {
            print(error)
        }
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch let error as NSError {
            print(error)
        }
    }
    
    // MARK:
    // MARK: 判断是否登录
    func configureUserIdAndFirstInApp() {
        
        let userDefault = NSUserDefaults.standardUserDefaults()
        let userID = userDefault.valueForKey("userId") as? Int
        let isFirst = userDefault.valueForKey("firstInstallApp") as? Bool
        if userID != nil {
            
            if userID > 0 {
                
                kUserId = userID!.description
            }
        }
        if isFirst == nil {
            
            // 百度SDK文件不备份
            var path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0]
            path = path + "/cfg"
            if NSFileManager.defaultManager().fileExistsAtPath(path) {
                Util.addSkipBackupAttributeToItemAtPath(path)
            }
            
            let introduceVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("introduceIdentifier") as! IntroduceController
            self.window?.rootViewController = introduceVC
        }
    }
    
    // MARK:
    // MARK:BMKGeneralDelegate
    func onGetNetworkState(iError: Int32) {
        
    }
    
    func onGetPermissionState(iError: Int32) {
        
    }
    
    func applicationWillResignActive(application: UIApplication) {
        
    }

    func applicationDidEnterBackground(application: UIApplication) {
        
        //设置后台运行10分钟 解决 锁屏和进入后台的下载问题
        self.addCarUserAction()
    }

    func applicationWillEnterForeground(application: UIApplication) {
        
    }

    func applicationDidBecomeActive(application: UIApplication) {
        
    }

    func applicationWillTerminate(application: UIApplication) {
        
    }
    
    // MARK: 
    // MARK: 上传用户行为
    func addCarUserAction() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            let actionList = NSMutableArray()
            let deviceUUID = UIDevice.currentDevice().identifierForVendor!.UUIDString
            var appColumnIdArray = ["NMC000",
                "NMC001",
                "NMC002",
                "NMC003",
                "NMC004",
                "NMC005",
                "NMC006"]
            var appColumnNameArray = ["AR",
                "quick",
                "maintain",
                "manual",
                "video",
                "carclass",
                "emergency"]
            
            let userDefault = NSUserDefaults.standardUserDefaults()
            for var i = 0; i < 7; i++ {
                
                let id = appColumnIdArray[i] as String
                let name = appColumnNameArray[i] as String
                let key = name + "Count"
                var count = userDefault.objectForKey(key) as? Int
                if count == nil {
                    
                    count = 0
                }
                let list = ["deviceId":deviceUUID,"appColumnId":id,"appColumnName":name,"count":count!]
                actionList.addObject(list)
            }
            
            let userDict: NSDictionary = ["actions": actionList]
            
            AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserActionAdd, param: userDict,withToken:false, success: { (operation, responseObject) -> Void in
                
                let mutableDic = responseObject as? NSMutableDictionary
                if mutableDic != nil {
                    
                    let memo = mutableDic?.objectForKey("memo") as! String
                    Logger.info("mome\(memo)")
                }
                }) { (operation, error) -> Void in
                    
                    Logger.info("_____________\(error)")
            }
        }
    }
}

