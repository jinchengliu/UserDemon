//
//  ProvinceModel.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class ProvinceModel: BaseModel, NSCopying {
    
    var provId: String?
    var provName: String?
    var latitude: NSNumber?
    var longitude: NSNumber?
    ///保存文字转拼音的内容
    var letter: String?
    
    override init() {
        
        super.init()
    }
    
    override init(JSONDic: NSDictionary) {
        
        super.init(JSONDic: JSONDic)
        if self.provName != nil {
            //汉字转拼音，比较排序时候用
            let input: NSString = NSString(string: self.provName!)
            let convertedString = input.mutableCopy() as! NSMutableString
            
            if CFStringTransform(convertedString, nil, kCFStringTransformMandarinLatin as NSString, false) {
            }
            if CFStringTransform(convertedString, nil, kCFStringTransformStripDiacritics as NSString, false) {
                self.letter = convertedString as String
            }
        }
    }
    
    func copyWithZone(zone: NSZone) -> AnyObject {
        // allocWithZone
        let provinceModel: ProvinceModel = ProvinceModel()
        provinceModel.provId = self.provId
        provinceModel.provName = self.provName
        provinceModel.latitude = self.latitude
        provinceModel.longitude = self.longitude
        return provinceModel
    }
}
