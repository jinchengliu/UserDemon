//
//  UserModel.swift
//  DasautoSpecifications
//
//  Created by chenpan on 14/12/22.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class UserModel: BaseModel {
   
    var id: NSNumber!
    var userName: String!
    var password: String!
    var nickname: String!
    var devicePlatform: Int!
    var platformVersion: String!
    var createTimeStr: String! //yyyy-MM-dd HH:mm:ss
    var lastLoginTimeStr: String! //yyyy-MM-dd HH:mm:ss
    
    override init(JSONDic: NSDictionary) {
        
        super.init(JSONDic: JSONDic)
    }
}
