/*
*  filename: DealerModel.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/11.
*  copyright: bdcluster
*/


// TODO:参数为测试使用，真实参数名称需与后台对接后确认。
import UIKit

class DealerModel: BaseModel {
    // MARK:properties
    var id: String?
    var name: String?
    var address: String?
    var tel: String?
    var latitude: NSNumber?
    var longitude: NSNumber?
    
    override init(JSONDic: NSDictionary) {
        super.init(JSONDic: JSONDic)
    }
}
