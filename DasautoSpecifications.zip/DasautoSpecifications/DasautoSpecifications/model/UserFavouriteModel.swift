//
//  UserFavouriteModel.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-23.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class UserFavouriteModel: NSObject {
   
    var name: String!
    var desc: String!
    var resouceId: NSNumber!
    
//    init(cell: QuickguideCell!) {
//        
//        super.init()
//        self.name = cell.titleLabel.text
//        self.desc = cell.subTitleLabel.text
//        
//    }
    
}
