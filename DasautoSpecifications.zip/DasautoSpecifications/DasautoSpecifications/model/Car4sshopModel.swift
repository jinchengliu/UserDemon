//
//  Car4sshopModel.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-19.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class Car4sshopModel: NSObject {
    
    var id: String?
    var name: String?
    var address: String?
    var linkTel: String?
    var latitude: NSNumber?
    var longitude: NSNumber?
    var postCode: String?
    var provId: String?
    ///保存文字转拼音的内容
    var letter: String?
    
    init(JSONDic: NSDictionary) {
        
        self.id = (JSONDic["id"] as? NSNumber)?.description
        self.name = JSONDic["name"] as? String
        self.address = JSONDic["address"] as? String
        self.linkTel = JSONDic["linkTel"] as? String
        self.latitude = JSONDic["latitude"] as? NSNumber
        self.longitude = JSONDic["longitude"] as? NSNumber
        self.postCode = JSONDic["postCode"] as? String
        self.provId = JSONDic["provId"] as? String
        
        if self.name != nil {
            //汉字转拼音，比较排序时候用
            let input: NSString = NSString(string: self.name!)
            let convertedString = input.mutableCopy() as! NSMutableString
            
            if CFStringTransform(convertedString, nil, kCFStringTransformMandarinLatin as NSString, false) {
            }
            if CFStringTransform(convertedString, nil, kCFStringTransformStripDiacritics as NSString, false) {
                self.letter = convertedString as String
            }
        }
    }
    
    init(array: NSArray) {
        
        self.name = array[0] as? String
        self.id = array[1] as? String
        self.address = array[2] as? String
        self.linkTel = array[3] as? String
    }
}
