/*
*
*      所有CustomModel需要继承BaseModel，需要使用哪种初始化放法请自行选择
*
*      方法一：调用init(JSONString : String)
*              parameters:JSONString(json字符串)
*              result:当前对象
*
*      方法二：调用init(JSONDic : NSDictionary)
*              parameters:JSONDic(json字典)
*              result:当前对象
*
*/

import UIKit

class BaseModel: NSObject {
    
    override init() {
        super.init()
    }
    
    init(JSONString: String) {
        super.init()
        
        var error : NSError?
        let JSONData = JSONString.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)
        
        let JSONDictionary: AnyObject?
        do {
            JSONDictionary = try NSJSONSerialization.JSONObjectWithData(JSONData!, options: [])
        } catch let error1 as NSError {
            error = error1
            JSONDictionary = nil
        }
//        if JSONDictionary is NSDictionary {
            for (key, value) in (JSONDictionary as! NSDictionary) {
                
                let keyName = key as! String
                let keyValue: String = value as! String
                // If property exists
                if (self.respondsToSelector(NSSelectorFromString(keyName))) {
                    self.setValue(keyValue, forKey: keyName)
                }
            }
//        }
        
    }
    
    init(JSONDic : NSDictionary) {
        super.init()
        self.setValuesForKeysWithDictionary(JSONDic as! [String : AnyObject])
    }
    
    override func setValue(value: AnyObject!, forUndefinedKey key: String) {
        //println("未定义的key:\(key)")
    }
}