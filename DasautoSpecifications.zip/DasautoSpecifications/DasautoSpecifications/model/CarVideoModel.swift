//
//  CarVideoModel.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/10.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class CarVideoModel: BaseModel {
   
    var carModel: String!
    var videoName: String!
    var videoUrl: String!
    var picUrl: String!
    var carYear: String!
    var playTime: NSNumber!
    var id: NSNumber!
    var refResList: NSArray!
    
    override init(JSONDic: NSDictionary) {
        
        super.init(JSONDic: JSONDic)
    }
}
