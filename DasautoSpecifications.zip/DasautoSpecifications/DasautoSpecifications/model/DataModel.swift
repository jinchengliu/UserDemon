//
//  DataModel.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-16.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class DataModel: NSObject {
    
    // MARK:
    // MARK:生命周期
    class var sharedInstance : DataModel {
        
        struct Static {
            
            static var onceToken : dispatch_once_t = 0
            static var instance : DataModel? = nil
        }
        dispatch_once(&Static.onceToken) {
            
            Static.instance = DataModel()
        }
        
        return Static.instance!
    }
    
    override init() {
        
        super.init()
    }
    
    // MARK:
    // MARK: 管理解析后的zip归档文件
    /**
    *  保存zip包解析后的归档文件
    */
    func savePackageManager() {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in
            let ret: Bool = NSKeyedArchiver.archiveRootObject(PackageFileManager.sharedInstance, toFile: PackageFileManagerFilePath)
            Logger.debug(PackageFileManagerFilePath)
            if ret == true {
//                if !NSFileManager.defaultManager().fileExistsAtPath(PackageFileManagerFilePath) {
                    Util.addSkipBackupAttributeToItemAtPath(PackageFileManagerFilePath)
//                }
                Logger.debug("保存PackageFileManager成功")
            }
            else {
                Logger.error("保存PackageFileManager失败")
            }
        }
    }
    
    /**
     *  主线程保存解析后的归档文件
     */
    func savePackageManagerInMainQueue() {
        
        let ret: Bool = NSKeyedArchiver.archiveRootObject(PackageFileManager.sharedInstance, toFile: PackageFileManagerFilePath)
        Logger.debug(PackageFileManagerFilePath)
        if ret == true {
            Logger.debug("保存PackageFileManager成功")
        }
        else {
            Logger.error("保存PackageFileManager失败")
        }
    }
    
    /**
    *  删除zip包解析后的归档文件
    */
    func deletePackageManager() {
        
        var error: NSError?
        do {
            try NSFileManager().removeItemAtPath(PackageFileManagerFilePath)
        } catch let error1 as NSError {
            error = error1
        }
        if error != nil {
            
            Logger.error("删除PackageFileManager失败\(error?.description)")
        }
    } 
}
