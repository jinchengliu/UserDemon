//
//  MeaasgeModel.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-27.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class MessageModel: BaseModel {
   
    var messageContent: String?
    var id: NSNumber!
    
    override init(JSONDic: NSDictionary) {
        
        super.init(JSONDic: JSONDic)
    }
    
}
