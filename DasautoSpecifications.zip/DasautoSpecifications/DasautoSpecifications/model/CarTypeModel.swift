//
//  CarTypeModel.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-14.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class CarTypeModel: BaseModel {
   
    var carModel: String!
    var carModelPicUrl: String?
    var carYearList: NSArray?
    var id: NSNumber!
    
    //----adddProverty--
    var picUrl:String!
    var carYear:String!
    var type:AnyObject!       //是否完整版
    var size:AnyObject!
    var packageSizeNv: NSNumber!       //无视频版大小
    var packageSizeV: NSNumber!        //完整版大小
    
    
    override init(JSONDic: NSDictionary) {
        
        super.init(JSONDic: JSONDic)
    }
}
