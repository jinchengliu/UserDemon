/*
*  filename: Logger.swift
*  product name: DasautoSpcifications
*  description: 根据需要，选择日志等级
*               log level(在target中选中"Build Settings",找到"swift other flags",添加根据等级添加以下字段)
*               1.-DALL         最低等级，用于打开所有日志记录
*               2.-DDEBUG       对调试程序有帮助的日志记录
*               3.-DINFO        突出强调程序的运行过程的日志记录
*               4.-DWARN        潜在发生错误的日志记录
*               5.-DERROR       发生错误，可继续执行
*               6.-DFATAL       严重错误，致程序退出
*  usage: 
*         eg:Logger.debug("debug message")
*            Logger.info("info message")
*            Logger.warn("warn message")
*            Logger.error("error message")
*            Logger.fatal("fatal message")
*  author: shimingwei
*  date time: 14/12/05.
*  copyright: bdcluster
*/

import UIKit

class Logger: NSObject {
    
    class func debug(message: String,
        function: String = __FUNCTION__,
        var file: String = __FILE__,
        line: Int = __LINE__){
            let url: NSURL! = NSURL(fileURLWithPath: file)
            file = url.lastPathComponent!
            #if ALL || DEBUG
                print("<DEBUG> \"\(message)\" (File: \(file)),(Function: \(function)),(Line: \(line))")
            #endif
    }
    
    class func info(message: String,
        function: String = __FUNCTION__,
        var file: String = __FILE__,
        line: Int = __LINE__){
            let url: NSURL! = NSURL(fileURLWithPath: file)
            file = url.lastPathComponent!
            #if ALL || INFO
                print("<INFO> \"\(message)\" (File: \(file)),(Function: \(function)),(Line: \(line))")
            #endif
    }
    
    class func warn(message: String,
        function: String = __FUNCTION__,
        var file: String = __FILE__,
        line: Int = __LINE__){
            let url: NSURL! = NSURL(fileURLWithPath: file)
            file = url.lastPathComponent!
            #if ALL || WARN
                print("<WARN> \"\(message)\" (File: \(file)),(Function: \(function)),(Line: \(line))")
            #endif
    }
    
    class func error(message: String,
        function: String = __FUNCTION__,
        var file: String = __FILE__,
        line: Int = __LINE__){
            let url: NSURL! = NSURL(fileURLWithPath: file)
            file = url.lastPathComponent!
            #if ALL || ERROR
                print("<ERROR> \"\(message)\" (File: \(file)),(Function: \(function)),(Line: \(line))")
            #endif
    }
    
    class func fatal(message: String,
        function: String = __FUNCTION__,
        var file: String = __FILE__,
        line: Int = __LINE__){
            let url: NSURL! = NSURL(fileURLWithPath: file)
            file = url.lastPathComponent!
            #if ALL || FATAL
                print("<FATAL> \"\(message)\" (File: \(file)),(Function: \(function)),(Line: \(line))")
            #endif
    }
}
