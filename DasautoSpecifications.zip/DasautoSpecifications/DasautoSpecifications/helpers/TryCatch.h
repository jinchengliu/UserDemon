/*
 *  filename: TryCatch.h
 *  product name: DasautoSpecifications
 *
 *  usage:   TryCatch.try({ () -> Void in
 *                          xxx
 *                      }, catch: { (exception: NSException!) -> Void in
 *                          xxx
 *                      }, finally: { () -> Void in
 *                          xxx
 *                      })
 *
 *  author: shimingwei
 *  date time: 14/12/09.
 *  copyright: bdcluster
 */

#import <Foundation/Foundation.h>

@interface TryCatch : NSObject

//+ (void)try:(void(^)())try catch:(void(^)(NSException*exception))catch finally:(void(^)())finally;

@end
