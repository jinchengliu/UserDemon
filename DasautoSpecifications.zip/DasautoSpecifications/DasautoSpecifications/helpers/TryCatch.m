/*
 *  filename: TryCatch.m
 *  product name: DasautoSpecifications
 *
 *  author: shimingwei
 *  date time: 14/12/09.
 *  copyright: bdcluster
 */

#import "TryCatch.h"

@implementation TryCatch

+ (void)try:(void(^)())try catch:(void(^)(NSException*exception))catch finally:(void(^)())finally{
    @try {
        try ? try() : nil;
    }
    @catch (NSException *exception) {
        catch ? catch(exception) : nil;
    }
    @finally {
        finally ? finally() : nil;
    }
}

@end
