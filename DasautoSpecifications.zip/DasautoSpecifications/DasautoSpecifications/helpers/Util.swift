/*
*  filename: Util.swift
*  product name: DasautoSpecifications
*  description: 工具类
*
*  author: shimingwei
*  date time: 14/12/11.
*  copyright: bdcluster
*/

import UIKit

class Util: NSObject {

    class func getFormatterDateTimeAccordingTo(str: String) -> String {
        
        if str.characters.count > 0 {
            let formatter: NSDateFormatter = NSDateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm"
            if let timeInterval = Int(str) {
                let timeInterval_Double = Double(timeInterval)
                let date = NSDate(timeIntervalSince1970: timeInterval_Double)
                return formatter.stringFromDate(date)
            }
        }
        return ""
    }
    
    // MARK: 网络请求4S店
    class func getCar4sshopListWithCityName(provId: String, completionHandler: (success: Bool, car4sshops: NSArray?) -> Void) {
        
        let param = NSDictionary(object: provId, forKey: "provId")
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCar4sShopList, param: param,withToken:false, success: { (operation, responseObject) -> Void in
            
            let responseDictionary: NSDictionary = responseObject as! NSDictionary
            let car4sshopArray = responseDictionary["car4sshopList"] as! NSArray
            let car4sshops: NSMutableArray = NSMutableArray(capacity: car4sshopArray.count)
            for car4sshopItem in car4sshopArray {
                
                let car4sshopDic: NSDictionary = car4sshopItem as! NSDictionary
                let car4sshop: Car4sshopModel = Car4sshopModel(JSONDic: car4sshopDic)
                
                car4sshops.addObject(car4sshop)
            }
            completionHandler(success: true, car4sshops: car4sshops)
            }) { (operation, error) -> Void in
                
                Logger.info("\(error)")
        }
    }
    
    // MARK: 判断邮箱格式
    /**
    *  判断邮箱格式是否正确
    */
    class func isValidateEmail(email: String) -> Bool{
        
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@ ", emailRegex)
        
        return emailTest.evaluateWithObject(email)
    }
    
    // MARK: 获取keyWindow
    /**
     *  获取keyWindow
     */
    class func getKeyWindow() -> UIWindow {
        if let keyWindwo = UIApplication.sharedApplication().keyWindow {
            return keyWindwo
        }
        else {
            return UIApplication.sharedApplication().windows[0]
        }
    }
    
    // MARK: 该路径不会备份到iCloud
    class func addSkipBackupAttributeToItemAtPath(filePath: String) -> Bool {
        
        let url = NSURL.fileURLWithPath(filePath)
        if let path = url.path {
            assert(NSFileManager.defaultManager().fileExistsAtPath(path))
            var success: Bool
            do {
                try url.setResourceValue(NSNumber(bool: true), forKey: NSURLIsExcludedFromBackupKey)
                success = true
            }catch _ {
                success = false
            }
            return success
        }
        return false
    }
    
    class func addSkipBackupAttributeToItemAtUrl(url: NSURL) -> Bool {
        if let path = url.path {
            assert(NSFileManager.defaultManager().fileExistsAtPath(path))
            var success: Bool
            do {
                try url.setResourceValue(NSNumber(bool: true), forKey: NSURLIsExcludedFromBackupKey)
                success = true
            }catch _ {
                success = false
            }
            return success
        }
        return false
    }
}
