//
//  BDJTimestampHelper.swift
//  House
//
//  Created by 博加 on 14-11-1.
//  Copyright (c) 2014年 bojia. All rights reserved.
//

import UIKit

class BDJTimestampHelper: NSObject {
    
    class func getFormatterDateTimeAccordingTo(str: String) -> String{
        if countElements(str) > 0 {
            var formatter: NSDateFormatter = NSDateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm"
            if var timeInterval = str.toInt() {
                var timeInterval_Double = Double(timeInterval)
                var date = NSDate(timeIntervalSince1970: timeInterval_Double)
                return formatter.stringFromDate(date)
            }
        }
        return ""
    }
}
