//
//  Boolean.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-23.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

//使用Boolean类型
typealias Boolean = UInt8

extension Boolean : BooleanLiteralConvertible {
    
    public init(booleanLiteral value: Bool) {
        
        self = value ? 1 : 0
    }
}

extension Boolean : BooleanType {
    
    public var boolValue : Bool {
        
        return self != 0
    }
}