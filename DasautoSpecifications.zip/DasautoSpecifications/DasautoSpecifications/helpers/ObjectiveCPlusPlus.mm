/*
 *  filename: ObjectiveCPlusPlus.mm
 *  product name: DasautoSpecifications
 *
 *  description: 由于百度地图需要C＋＋环境，所以此文件只是为了配合使用百度地图SDK，无其他用处。
 *
 *  author: shimingwei
 *  date time: 14/12/10.
 *  copyright: bdcluster
 */

#import "ObjectiveCPlusPlus.h"

@implementation ObjectiveCPlusPlus

@end
