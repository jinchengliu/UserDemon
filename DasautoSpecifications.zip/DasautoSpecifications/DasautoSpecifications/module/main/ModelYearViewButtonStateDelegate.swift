//
//  ModelYearViewButtonStateDelegate.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-4-28.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

@objc protocol ModelYearViewButtonStateDelegate {
    
    optional func setControlButtonState(state: String)
}


