//
//  ProblemsAndSolveController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/26.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

enum ProblemsAndSolveControllerState {
    case Normal
    case Search
}

class ProblemsAndSolveController: DasautoController ,UITableViewDelegate,UITableViewDataSource,DasautoSearchControllerDelegate{

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    
    var searchController: DasautoSearchController?
    var state: ProblemsAndSolveControllerState!
    
    var filterFiles: NSArray?
    var dasautoFile: DasAutoFile!
    var fileId: Int = 6
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.addRightNavigationItems()
        self.configureTitle("常见问题及解决")
        
        self.configureDirectory()
        self.state = ProblemsAndSolveControllerState.Normal
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func configureDirectory() {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.fileId)
        let dasAutoDirectory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        var dasAutoFileArray = dasAutoDirectory.children as [DasAutoFile]
        if dasAutoFileArray.count != 0 {
            
            for var i = 0; i < dasAutoFileArray.count; i++ {
                
                let fileLeaf = dasAutoFileArray[i] as DasAutoFile
                if fileLeaf.name == "常见问题及解决" {
                    
                    self.dasautoFile = fileLeaf
                    self.tableView.reloadData()
                    break
                }
            }
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中AR
     */
    override func onArBarButtonclicked() {
        
        super.onArBarButtonclicked()
    }
    
    /**
     *  选中搜索
     */
    override func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        
        super.onSearchBarButtonclicked(sender)
        if searchController == nil {
            
            searchController = DasautoSearchController(delegate: self)
            self.addChildViewController(searchController!)
            searchController!.view.frame.origin.y = -65
        }
        
        if self.state == ProblemsAndSolveControllerState.Normal {
            
            self.view.addSubview(searchController!.view)
            searchController!.view.frame.origin.y = -65
            self.topConstraint.constant = 65
            self.view.setNeedsUpdateConstraints()
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                self.searchController!.view.frame.origin.y = 0
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        
                        self.state = ProblemsAndSolveControllerState.Search
                    }
            })
        }else {
            searchController?.setNormalState({ (finished) -> Void in
                
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    self.topConstraint.constant = 0
                    self.view.setNeedsUpdateConstraints()
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        self.searchController!.view.frame.origin.y = -65
                        self.view.layoutIfNeeded()
                        }, completion: { (completetion) -> Void in
                            if completetion {
                                
                                self.state = ProblemsAndSolveControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }
   
    // MARK:
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.dasautoFile == nil ? 0 : self.dasautoFile.children.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 44.0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let nib = UINib(nibName: "TreeCell", bundle: nil)
        let cell: TreeCell = nib.instantiateWithOwner(nil, options: nil)[0] as! TreeCell
        cell.nameLabel.text = (self.dasautoFile.children[indexPath.row] as! DasAutoFileLeaf).name
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("ProblemToHtmlSegue", sender: nil)
    }
    
    // MARK: DasautoSearchControllerDelegate
    func dasautoSearchControllerDisappear() {
        
        if self.state == ProblemsAndSolveControllerState.Search {
            
            self.searchController!.view.frame.origin.y = 0
            self.topConstraint.constant = 0
            self.view.setNeedsUpdateConstraints()
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = -65
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        
                        self.state = ProblemsAndSolveControllerState.Normal
                        self.searchController!.view.removeFromSuperview()
                    }
            })
        }
    }
    
    func searchHandler(completion: (finished: Bool) -> Void) {
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            if SearchManager.sharedInstance.root.searchResult != nil {
                
                SearchManager.sharedInstance.root.searchResult.removeAll(keepCapacity: true)
            }
            self.filterFiles = SearchManager.sharedInstance.searchByKey(self.searchController!.searchTextField!.text!, fileId: self.fileId)
            completion(finished: true)
        }
    }
    
    func numberOfSections() -> Int {
        
        return 1
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        
        return (self.filterFiles != nil) ? self.filterFiles!.count : 0
    }
    
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "searchCell"
        var cell: SearchResultCell?
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? SearchResultCell
        if cell == nil {
            
            cell = SearchResultCell(style: .Default, reuseIdentifier: reusableIdentifier)
        }
        
        let dasautoFile: DasAutoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        cell?.nameLabel?.text = dasautoFile.name
        
        return cell!
    }
    
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("ProblemToHtmlSegue", sender: nil)
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        super.prepareForSegue(segue, sender: sender)
        
        if segue.identifier == "ProblemToHtmlSegue" {
            
            var dasautoFile: DasAutoFileLeaf!
            if self.state == ProblemsAndSolveControllerState.Normal {
                
                let indexPath = self.tableView.indexPathForSelectedRow!
                dasautoFile = self.dasautoFile.children[indexPath.row] as! DasAutoFileLeaf
            }else {
                
                if self.searchController?.state == DasautoSearchControllerState.Search {
                    
                    let indexPath: NSIndexPath = self.searchController!.searchResultTableView!.indexPathForSelectedRow!
                    dasautoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFileLeaf
                }else {
                    
                    let indexPath: NSIndexPath = self.tableView.indexPathForSelectedRow!
                    dasautoFile = dasautoFile.children[indexPath.row] as! DasAutoFileLeaf
                }
            }
            let vc = segue.destinationViewController as! HtmlDetaiController
            vc.leaf = dasautoFile
            vc.listName = "应急服务"
        }
    }
}