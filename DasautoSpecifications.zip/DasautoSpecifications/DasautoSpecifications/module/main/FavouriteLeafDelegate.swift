/*
*  filename: FavouriteLeafDelegate.swift
*  product name: DasautoSpecifications
*
*  author: wangrui
*  date time: 14/12/25.
*  copyright: bdcluster
*/

@objc protocol FavouriteLeafDelegate {
    
    optional func addFavouriteResouceId(cell: UITableViewCell)
    optional func cancelFavouriteResouceId(cell: UITableViewCell)
}


