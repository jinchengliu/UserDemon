//
//  HotButtonClickedView.swift
//  DasautoSpecifications
//
//  Created by 余新闻 on 15/7/9.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//
import UIKit
import Foundation


class HotButtonClickedView: UIView {

    var imageView:UIImageView!
    var title:String!
    var detail:String!
    var textview:UITextView!
    var imageUrlPath:String!
    
    
    init(frame: CGRect,color:UIColor,title:String,detail:String,imagePath:String) {
        super.init(frame: frame)
        
        self.backgroundColor = color
        self.title = title
        self.detail = detail
        self.imageUrlPath = imagePath
        
        self.cresteWidgets()
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func cresteWidgets()
    {
        let imageView:UIImageView = UIImageView()
        imageView.image = UIImage(contentsOfFile: self.imageUrlPath)
        imageView.layer.cornerRadius = 3.0
        imageView.clipsToBounds = true
        imageView.frame = CGRectMake(10, (self.bounds.size.height-70)/2, 70, 70)
        self.addSubview(imageView)
        
        self.textview = UITextView()
        self.textview.textContainerInset = UIEdgeInsetsZero
        self.textview.contentInset = UIEdgeInsetsZero
        self.textview.backgroundColor = UIColor.clearColor()
        self.textview.editable = false
        
        if self.imageUrlPath.characters.count == 0
        {
            self.textview.frame = CGRectMake(5, 35, self.frame.size.width-10, self.frame.size.height-35)
        }else
        {
            self.textview.frame = CGRectMake(85, 35, self.frame.size.width-85-10, self.frame.size.height-35)
        }
        self.textview.text = self.detail
        self.textview.font = UIFont.systemFontOfSize(16)
        self.addSubview(self.textview)
    }
    
    override func drawRect(rect: CGRect) {
    
        let titleDic = NSDictionary(objects: [UIColor.blackColor(),UIFont.systemFontOfSize(18)], forKeys:[NSForegroundColorAttributeName,NSFontAttributeName])        
        
        var titleRect:CGRect = CGRectMake(90, 10, self.frame.size.width-90-20, 30)
        if self.imageUrlPath.characters.count  == 0
        {
            titleRect = CGRectMake(10, 10, self.frame.size.width-20, 30)
        }
        
        self.title.drawInRect(titleRect, withAttributes: titleDic as? [String : AnyObject])
        
    }
}