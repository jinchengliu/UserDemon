//
//  ChildrenHtmlController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-4-21.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class ChildrenHtmlController: DasautoController ,UIWebViewDelegate, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var listButton: UIButton!
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    
    var favouriteButton: UIButton!
    var tableView: UITableView!
    var grayBackView: UIView!
    
    var leaf: DasAutoFile!
    var request: NSURLRequest!
    var titleString: String!
    var dataArray: NSArray!
    
    var crtZip: ZipPackage!
    var numberPage: Int = 1
    var listName: String!
    
    //--change---
    var whetherHasImgae:String!
    
    @IBOutlet weak var topConstraints: NSLayoutConstraint!
    
    
    @IBAction func onListButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if sender.selected == false {
            
            self.configureTableView()
        }else {
            
            self.tableView.removeFromSuperview()
            self.grayBackView.removeFromSuperview()
        }
        sender.selected = !sender.selected
    }
    
    // MARK: 生命周期
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    override func viewDidLoad() {
        
        /*
         已经弃用
        */
        super.viewDidLoad()
        self.addBackBarButtonItem()
        crtZip = PackageFileManager.sharedInstance.currentZipPackage
        if dataArray == nil {
            
            self.listButton.hidden = true
            bottomConstraint.constant = -40
        }
        
        self.configureTitle(leaf.name)
        let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
        let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
        self.webView.loadRequest(request!)
        
        self.addRightNavigationItemAboutFavourite()
        
        
        if self.whetherHasImgae == "true"
        {
            self.topConstraints.constant = 150;
            
            self.createImageWidget()
        }
        
    }
    //Mark --add---
    func createImageWidget()
    {
        let topImageView:UIImageView = UIImageView(image: UIImage(named: "arImage.jpg"))
        topImageView.frame = CGRectMake(0, 0, CGRectGetWidth(UIScreen.mainScreen().bounds),self.topConstraints.constant)
        self.view.addSubview(topImageView)
        
        topImageView.userInteractionEnabled = true
        let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("handleTapGesture:"))
        topImageView.addGestureRecognizer(tapGesture)
    }
    
    func handleTapGesture(tapGesture:UITapGestureRecognizer)
    {
        let controller:HtmlSpotImageController = HtmlSpotImageController()
        
        self.presentViewController(controller, animated: true, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK: 点击返回按钮
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: 添加收藏视图
    func addRightNavigationItemAboutFavourite() {
        
        favouriteButton = UIButton(frame: CGRectMake(0, 0, 21, 21))
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate_selected.png"), forState: UIControlState.Normal)
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate" + themeColor), forState: UIControlState.Selected)
        favouriteButton.addTarget(self, action: Selector("onFavouriteBarButtonItemClciked:"), forControlEvents: UIControlEvents.TouchUpInside)
        favouriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        
        let favouriteBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: favouriteButton)
        self.navigationItem.rightBarButtonItem = favouriteBarButtonItem
    }

    // MARK: 点击收藏按钮的方法
    func onFavouriteBarButtonItemClciked(sender: UIButton) {
        
        if favouriteButton.selected {
            
            DBmanager.sharedInstanceWithDBName("html").deleteHtml([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        } else {
            
            DBmanager.sharedInstanceWithDBName("html").insertHtml([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        }
        favouriteButton.selected = !favouriteButton.selected
    }
    
    // MARK: 配置tableView
    func configureTableView() {
        
        grayBackView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.navigationController!.view.bounds) - 40))
        grayBackView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onGrayBackViewTapGesture:"))
        grayBackView.backgroundColor = UIColor.grayColor()
        grayBackView.alpha = 0.66
        self.navigationController?.view.addSubview(grayBackView)
        
        let tableViewHeigth: CGFloat = CGFloat(dataArray.count * 44)
        tableView = UITableView(frame: CGRectMake(0, CGRectGetHeight(self.grayBackView.bounds) - tableViewHeigth, CGRectGetWidth(self.view.bounds), tableViewHeigth))
        tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        tableView.dataSource = self
        tableView.delegate = self
        self.navigationController?.view.addSubview(tableView)
    }
    
    // MARK: 点击灰色背景视图的手势方法
    func onGrayBackViewTapGesture(tapGesture: UITapGestureRecognizer) {
        
        tapGesture.view?.removeFromSuperview()
        tableView.removeFromSuperview()
        listButton.selected = false
    }
    
    // MARK: webViewDelegate
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
       
        return true
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        
        if numberPage != 1 {
            
            let titleString: String = webView.stringByEvaluatingJavaScriptFromString("document.title")!
            self.configureTitle(titleString)
        }
        numberPage++
        // MARK: 修改webView的字体大小
        let fontStr = "document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= " + kHtmlFontSize
        self.webView.stringByEvaluatingJavaScriptFromString(fontStr)
    }
    
    // MARK: tableViewDelegate
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dataArray.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let identifer = "listCellIdentifer"
        var cell = tableView.dequeueReusableCellWithIdentifier(identifer) 
        if cell == nil  {
            
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: identifer)
        }
        
        let data: AnyObject? = dataArray[indexPath.row] as AnyObject
        if data is RATreeNodeInfo {
            
            cell?.textLabel!.text = ((data as! RATreeNodeInfo).item as! RADataObject).name
        }else if data is RADataObject {
            
            cell?.textLabel!.text = (data as! RADataObject).name
        }else if data is DasAutoFileLeaf {
            
            cell?.textLabel!.text = (data as! DasAutoFileLeaf).name
        }
        
        let lineView = UIView(frame: CGRectMake(0, 43, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red:0.8, green:0.8, blue:0.8, alpha:1)
        cell?.addSubview(lineView)
        
        let rightImageView = UIImageView(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 25, 14, 10, 15))
        rightImageView.image = UIImage(named: "rightArrow" + themeColor)
        cell?.addSubview(rightImageView)
        return cell!
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        grayBackView.removeFromSuperview()
        tableView.removeFromSuperview()
        listButton.selected = false
        let data: AnyObject? = dataArray[indexPath.row] as AnyObject
        if data is RATreeNodeInfo {
            
            leaf = ((data as! RATreeNodeInfo).item as! RADataObject).dasautoFile as! DasAutoFileLeaf
        }else if data is RADataObject {
            
            leaf = (data as! RADataObject).dasautoFile as! DasAutoFileLeaf
        }
        self.performSegueWithIdentifier("ChildrenToDetailSegue", sender: nil)
    }
    
    // MARK: 传值
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: sender)
        if segue.identifier == "ChildrenToDetailSegue" {
            
            let vc = segue.destinationViewController as! HtmlDetaiController
            vc.leaf = self.leaf
        }
    }
}
