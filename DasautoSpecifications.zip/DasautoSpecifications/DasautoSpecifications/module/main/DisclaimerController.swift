//
//  DisclaimerController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-25.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class DisclaimerController: DasautoController {

    var carType: String!
    var carYear: String!
    // MARK:properties
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var agreeOrDisagreeButton: UIButton!
    var isAgree: Bool = false    //判断是否点击同意按钮
    
    // MARK:ui function
    // MARK: modef by wr  date: 15/01/20
    @IBAction func agreeOrDisagree(sender: UIButton) {
        isAgree = true
        agreeOrDisagreeButton.setTitleColor(UIColor.grayColor(), forState: .Normal)
    }
    
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: modf by wr  date: 15/01/20
    func onContinueBarButtonItemClicked(sender: UIBarButtonItem) {
        if isAgree {
            // TODO: 下载选中包的网址
            var modelAndYearAndVideoDictionary = NSDictionary(objects: [carType,carYear,"True"], forKeys: ["carModel","carYear","isIncludeVideo"])
            var requestSerializer: AFJSONRequestSerializer = AFJSONRequestSerializer()
        
            AFOperationManager.sharedInstance.requestManager.requestSerializer = requestSerializer
            AFOperationManager.sharedInstance.startPostOperation("http://10.11.40.8:8880/cms-web/api/car/resource/offline/download", param: modelAndYearAndVideoDictionary, success: { (operation, responseObject) -> Void in
                var zipDictionary: NSDictionary = responseObject as NSDictionary
                var urlStr: NSString = zipDictionary.objectForKey("downloadUrl") as NSString
                //TODO: 选中包网址下载成功, 下载zip包
                dispatch_async(dispatch_get_global_queue(0, 0), { () -> Void in
                    var zipPackage: ZipPackage = ZipPackage(urlString: urlStr, zipSize: "20MB", carName: self.carType, carProductYear: self.carYear, carStyle: "kd wood", picUrl: "ssss")
                    var manager: PackageFileManager = PackageFileManager.sharedInstance
                    manager.addZipPackage(zipPackage)
                    
                    var str = NSHomeDirectory()
                    manager.downloadZipPackage(zipPackage) { (response, error) -> Void in
                        if error == nil {
                            manager.unzippingPackage(zipPackage)
                        }else {
                            Logger.debug("网络请求失败")
                        }
                    }
                })
                var downloadManagerController: DownloadManagerController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as DownloadManagerController
                self.navigationController?.pushViewController(downloadManagerController, animated: true)
                }) { (operation, error) -> Void in
                    Logger.info("\(error)")
            }
        }

    }
    
    // MARK:life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureTitle("免责声明")
        self.addBackBarButtonItem()
        var continueBarButtonItem: UIBarButtonItem = UIBarButtonItem(title: "继续", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("onContinueBarButtonItemClicked:"))
        self.navigationItem.rightBarButtonItem = continueBarButtonItem
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
