/*
*  filename: QuickQuideController.swift
*  product name: DasautoSpecifications
*
*  author: wangrui
*  date time: 14/12/13.
*  copyright: bdcluster
*/

import UIKit

enum QuickQuideControllerState {
    
    case Normal
    case Search
}

class QuickQuideController: DasautoController, DasautoSearchControllerDelegate, UITableViewDataSource, UITableViewDelegate, FavouriteLeafDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    
    var searchController: DasautoSearchController?
    var state: QuickQuideControllerState!
    var nodes = NSMutableArray(capacity: 0)
    
    var directory: DasAutoDirectory!
    var childrenFile: DasAutoFile!                    // 显示进入热点页面的file
    var filterFiles: NSArray?
    
    var crtZip: ZipPackage!
    let fileId: Int = 1

    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        searchController?.removeFromParentViewController()
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("快速指南")
        self.addBackBarButtonItem()
        self.addRightNavigationItems()
        
        self.configureDirectory()
        self.state = QuickQuideControllerState.Normal
        crtZip = PackageFileManager.sharedInstance.currentZipPackage
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK: 
    // MARK: Button Actions
    /**
    *  选中返回按钮
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }

    /**
    *  选中搜索按钮
    */
    override func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        
        super.onSearchBarButtonclicked(sender)
        if searchController == nil {
            
            searchController = DasautoSearchController(delegate: self)
            self.addChildViewController(searchController!)
            searchController!.view.frame.origin.y = -65
        }
        
        if self.state == QuickQuideControllerState.Normal {
            
            self.view.addSubview(searchController!.view)
            searchController!.view.frame.origin.y = -65
            self.topConstraint.constant = 65
            self.view.setNeedsUpdateConstraints()
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = 0
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.state = QuickQuideControllerState.Search
                    }
            })
        }else {
            
            searchController?.setNormalState({ (finished) -> Void in
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    self.topConstraint.constant = 0
                    self.view.setNeedsUpdateConstraints()
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        
                        self.searchController!.view.frame.origin.y = -65
                        self.view.layoutIfNeeded()
                        }, completion: { (completetion) -> Void in
                            
                            if completetion {
                                
                                self.state = QuickQuideControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }
    
    /**
     *  选中AR
     */
    override func onArBarButtonclicked() {
        
        super.onArBarButtonclicked()
    }
    
    // MARK:
    // MARK: Configure Directory
    func configureDirectory() {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.fileId)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
        // 找出是否需要添加热点图
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(7)
        let hotDirectory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        for var i = 0; i < hotDirectory.children.count; i++ {
            
            if (hotDirectory.children[i] as DasAutoFile).isOverview == "1" {
                
                self.childrenFile = hotDirectory.children[i] as DasAutoFile
            }
        }
    }
    
    // MARK:
    // MARK: UITableViewDelegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.childrenFile == nil ? directory.children.count: directory.children.count + 1
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if self.childrenFile != nil {
            
            if indexPath.row == 0 {
                
                let cell = tableView.dequeueReusableCellWithIdentifier("QuickguideHotCell") as! QuickguideHotCell
                cell.configureCellWithDasautoFile(self.childrenFile)
                
                return cell
            }else {
                
                let cell = tableView.dequeueReusableCellWithIdentifier("QuickguideCell") as! QuickguideCell
                cell.delegate = self
                let leaf = directory.children[indexPath.row - 1] as! DasAutoFileLeaf
                cell.favouriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,"快速指南",leaf.name,leaf.resourceId,kUserId])
                
                cell.configureQuickguideCellWith(leaf)
                return cell
            }
        }else {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("QuickguideCell") as! QuickguideCell
            cell.delegate = self
            let leaf = directory.children[indexPath.row] as! DasAutoFileLeaf
            cell.favouriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,"快速指南",leaf.name,leaf.resourceId,kUserId])
            
            cell.configureQuickguideCellWith(leaf)
            
            return cell
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.childrenFile != nil {
            
            if indexPath.row == 0 {
                
                let hotSpotViewController: HotSpotViewController = HotSpotViewController()  //
                hotSpotViewController.quickGuideName = self.childrenFile.name
                hotSpotViewController.whetherFromQuickGuide = "true"
                hotSpotViewController.loadImage(self.childrenFile)
                
                self.presentViewController(hotSpotViewController, animated: true, completion: nil)
            }else {
                
                self.performSegueWithIdentifier("detail", sender: nil)
            }
        }else {
            
            self.performSegueWithIdentifier("detail", sender: nil)
        }
    }
    
    // MARK: DasautoSearchControllerDelegate
    func dasautoSearchControllerDisappear() {
        
        if self.state == QuickQuideControllerState.Search {
            
            self.searchController!.view.frame.origin.y = 0
            self.topConstraint.constant = 0
            
            self.view.setNeedsUpdateConstraints()
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = -65
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.state = QuickQuideControllerState.Normal
                        self.searchController!.view.removeFromSuperview()
                    }
            })
        }
    }
    
    func searchHandler(completion: (finished: Bool) -> Void) {
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            if SearchManager.sharedInstance.root.searchResult != nil {
                SearchManager.sharedInstance.root.searchResult.removeAll(keepCapacity: true)
            }
            self.filterFiles = SearchManager.sharedInstance.searchByKey(self.searchController!.searchTextField!.text!, fileId: self.fileId)
            completion(finished: true)
        }
    }
    
    func numberOfSections() -> Int {
        
        return 1
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        
        return (self.filterFiles != nil) ? self.filterFiles!.count : 0
    }
    
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "searchCell"
        var cell: SearchResultCell?
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? SearchResultCell
        if cell == nil {
            
            cell = SearchResultCell(style: .Default, reuseIdentifier: reusableIdentifier)
        }
        
        let dasautoFile: DasAutoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        cell?.nameLabel?.text = dasautoFile.name
        
        return cell!
    }
    
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath) {

        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("detail", sender: nil)
    }

    // MARK: FavouriteLeafDelegate
    /**
    *  添加收藏
    */
    func addFavouriteResouceId(cell: UITableViewCell) {
        
        var row: Int!
        let indexpath = tableView.indexPathForCell(cell)! as NSIndexPath
        if self.childrenFile != nil {
            
            row = indexpath.row - 1
        }else {
            
            row = indexpath.row
        }
        let leaf = directory.children[row] as! DasAutoFileLeaf
    
        DBmanager.sharedInstanceWithDBName("html").insertHtml([crtZip.carName,crtZip.carProductYear,"快速指南",leaf.name,leaf.resourceId,kUserId,kUserId])
    }
    
    /**
    *  取消收藏
    */
    func cancelFavouriteResouceId(cell: UITableViewCell) {
     
        var row: Int!
        let indexpath = tableView.indexPathForCell(cell)! as NSIndexPath
        if self.childrenFile != nil {
            
            row = indexpath.row - 1
        }else {
            
            row = indexpath.row
        }
        let leaf = directory.children[row] as! DasAutoFileLeaf
        DBmanager.sharedInstanceWithDBName("html").deleteHtml([crtZip.carName,crtZip.carProductYear,"快速指南",leaf.name,leaf.resourceId,kUserId,kUserId])
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "detail" {
            
            let vc = segue.destinationViewController as! HtmlDetaiController
            var dasautoFile: DasAutoFileLeaf!
            if self.state == QuickQuideControllerState.Normal {
                
                let indexPath: NSIndexPath = self.tableView.indexPathForSelectedRow!
                if self.childrenFile != nil {
                    
                    dasautoFile = directory.children[indexPath.row - 1] as! DasAutoFileLeaf
                }else {
                    
                    dasautoFile = directory.children[indexPath.row] as! DasAutoFileLeaf
                }
            }else {
                
                if self.searchController?.state == DasautoSearchControllerState.Search {
                    
                    let indexPath: NSIndexPath = self.searchController!.searchResultTableView!.indexPathForSelectedRow!
                    dasautoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFileLeaf
                }else {
                    
                    let indexPath: NSIndexPath = self.tableView.indexPathForSelectedRow!
                    if self.childrenFile != nil {
                        
                        dasautoFile = directory.children[indexPath.row - 1] as! DasAutoFileLeaf
                    }else {
                        
                        dasautoFile = directory.children[indexPath.row] as! DasAutoFileLeaf
                    }
                }
            }
            vc.leaf = dasautoFile
            vc.listName = "快速指南"
            vc.isWithBackHomeButton = false
        }
    }
}
