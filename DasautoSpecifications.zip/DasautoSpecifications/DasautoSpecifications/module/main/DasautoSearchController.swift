/*
*  filename: DasautoSearchController.swift
*  product name: DasautoSpecifications
*  搜索视图类
*
*  usage: 分两种情况：（原因是由于viewDidLoad中addChildViewController不能正确使用，所以无法初始化正确frame给到searchController.view。解决办法是在进入视图时重新调整frame）
*         一、1.1视图加载在viewDidLoad中，需要创建searchController对象，然后在viewDidLoad中添加以下代码
*               searchController = DasautoSearchController(delegate: self)
*               self.addChildViewController(searchController!)
*               self.view.addSubview(searchController!.view)
*            1.2之后在viewWillAppear中添加如下代码
*               searchController?.didMoveToParentViewController(self)
*            1.3最后在viewWillDisappear中添加如下代码
*               searchController?.removeFromParentViewController()
*         二、2.1视图加载是有用户事件触发，则直接添加即可,即在调用方法中添加如下方法
*               searchController = DasautoSearchController()
*               self.addChildViewController(searchController!)
*               self.view.addSubview(searchController!.view)
*  tips: 注意实现代理方法
*
*  author: shimingwei
*  date time: 14/12/12.
*  copyright: bdcluster
*/

import UIKit

protocol DasautoSearchControllerDelegate {
    
    func dasautoSearchControllerDisappear()
    func searchHandler(completion: (finished: Bool) -> Void)
    func numberOfSections() -> Int
    func numberOfRowsInSection(section: Int) -> Int
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath)
}

enum DasautoSearchControllerState: Int {
    
    case Normal
    case Search
}

class DasautoSearchController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {

    var searchTextField: MarginTextField?
    var clearButton: UIButton?
    var searchResultTableView: UITableView?
    var state: DasautoSearchControllerState!
    var delegate: DasautoSearchControllerDelegate?
    
    // MARK:
    // MARK:Life Cycle
    convenience init(delegate: DasautoSearchControllerDelegate) {
        
        self.init()
        self.delegate = delegate
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.frame = CGRectMake(0, 0, CGRectGetWidth(UIScreen.mainScreen().bounds), 65)
        self.state = DasautoSearchControllerState.Normal
        self.view.clipsToBounds = false
        self.view.backgroundColor = UIColor.clearColor()
        let searchBgImageView: UIImageView = UIImageView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 65))
        searchBgImageView.backgroundColor = UIColor.whiteColor()
        searchBgImageView.image = UIImage(named: "search_bg")
        searchTextField = MarginTextField(frame: CGRectMake(30, 15, CGRectGetWidth(self.view.bounds) - 100, 35))
        searchTextField?.font = UIFont.systemFontOfSize(14)
        searchTextField?.layer.borderColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.5).CGColor
        searchTextField?.layer.borderWidth = 1
        searchTextField?.setLeftMargin(10)
        searchTextField?.delegate = self
        searchTextField?.returnKeyType = UIReturnKeyType.Done
        searchTextField?.placeholder = "请输入关键字"
        searchTextField?.textAlignment = NSTextAlignment.Center
        
        clearButton = UIButton(frame: CGRectMake(CGRectGetMaxX(searchTextField!.frame) + 5, 15, 40, 35))
        clearButton?.addTarget(self, action: Selector("clearSearchText"), forControlEvents: .TouchUpInside)
        clearButton?.setImage(UIImage(named: "clear"), forState: .Normal)
        
        self.view.addSubview(searchBgImageView)
        self.view.addSubview(searchTextField!)
        self.view.addSubview(clearButton!)
        
        self.searchResultTableView = UITableView(frame: CGRectMake(0, 65, CGRectGetWidth(self.view.bounds), 0))
        self.searchResultTableView?.delegate = self
        self.searchResultTableView?.dataSource = self
        self.view.addSubview(self.searchResultTableView!)
        
        self.setExtraCellLineHidden(self.searchResultTableView!)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("handleTextFieldChanged:"), name: UITextFieldTextDidChangeNotification, object: nil)
    }
    
    deinit {
        
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UITextFieldTextDidChangeNotification, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    //去掉tableView多余的分割线
    func setExtraCellLineHidden(tableView: UITableView) {
        
        let view: UIView = UIView()
        view.backgroundColor = UIColor.clearColor()
        tableView.tableFooterView = view
    }
    
    func handleTextFieldChanged(notification: NSNotification) {
        
        if searchTextField?.text == "" {
            
            self.setNormalState({ (finished) -> Void in
                
            })
        }else {
            
            //开始搜索
            self.setSearchState()
            self.delegate?.searchHandler({ (finished) -> Void in
                if finished {
                    
                    self.searchResultTableView?.reloadData()
                }
            })
        }
    }
    
    func setSearchState() {
        
        self.state = DasautoSearchControllerState.Search
        UIView.animateWithDuration(0.3, animations: { () -> Void in
            
            self.view.frame.size.height = CGRectGetHeight(UIScreen.mainScreen().bounds) - 64
            self.searchResultTableView!.frame.size.height = CGRectGetHeight(UIScreen.mainScreen().bounds) - 64 - 65
            }) { (completetion) -> Void in
                
                if completetion {
                    
                }
        }
    }
    
    func setNormalState(completionHandler:(finished: Bool)-> Void) {
        
        if self.state == DasautoSearchControllerState.Search {
            
            self.state = DasautoSearchControllerState.Normal
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.view.frame.size.height = 65
                self.searchResultTableView!.frame.size.height = 0
                }) { (completetion) -> Void in
                    if completetion {
                        completionHandler(finished: true)
                    }
            }
        }else {
            
            completionHandler(finished: true)
        }
    }
    
    func clearSearchText() {
        
        self.searchTextField?.text = ""
        self.searchTextField?.resignFirstResponder()
        self.setNormalState { (finished) -> Void in
            
            self.delegate?.dasautoSearchControllerDisappear()
        }
    }
    
    // MARK:
    // MARK:UITextFieldDelegate
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        return true
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        textField.placeholder = ""
    }
    func textFieldDidEndEditing(textField: UITextField) {
        if textField.text!.isEmpty
        {
            textField.placeholder = "请输入关键字"
        }
    }
    
    // MARK:UITableViewDataSource
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 60
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return (self.delegate != nil) ? self.delegate!.numberOfSections() : 0
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (self.delegate != nil) ? self.delegate!.numberOfRowsInSection(section) : 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        return self.delegate!.cellForIndexPath(tableView, forIndexPath: indexPath)
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        self.delegate?.didSelectedCellAtIndexPath(indexPath)
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
    }
}
