/*
*  filename: CarClassController.swift
*  product name: DasautoSpecifications
*  包中可能会包含爱车课堂的内容
*  author: cp
*  date time: 14/12/23.
*  copyright: bdcluster
*/

import UIKit

enum CarClassControllerState {
    case Normal
    case Search
}

class CarClassController: DasautoController, RATreeViewDelegate, RATreeViewDataSource, DasautoSearchControllerDelegate {

    @IBOutlet weak var headImageView: UIImageView!
    @IBOutlet weak var treeView: RATreeView!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    var searchController: DasautoSearchController?
    var filterFiles: NSArray?
    
    var directory: DasAutoDirectory!
    var fileId: Int = 5                                   //MARK: 用户手册的ID为5
    var nodes = NSMutableArray(capacity: 0)
    var state: CarClassControllerState!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("爱车课堂")
        self.addBackBarButtonItem()
        self.addRightNavigationItems()
        let share = PackageFileManager.sharedInstance as PackageFileManager
        if share.packages.count != 0 && share.rootFile != nil {
            
            self.configureNodes()
            self.configureTreeView()
        }else {
            
            self.treeView.hidden = true
        }
        self.headImageView.image = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("carclass", ofType: "png")!)!
        //        if AFNetworkReachabilityManager.sharedManager().reachable == true {
        //
        //            if share.rootFile != nil && share.packages.count != 0 {
        //
        //                self.downloadCarClassHeadImageViewUrl()
        //            }
        //        }else {
        //
        //            self.showRendView("当前网络不可用,加载图片失败", isSuccess: false)
        //        }
        
        self.state = CarClassControllerState.Normal
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中AR
     */
    override func onArBarButtonclicked() {
        
        super.onArBarButtonclicked()
    }
    
    /**
     *  选中搜索
     */
    override func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        
        super.onSearchBarButtonclicked(sender)
        if searchController == nil {
            
            searchController = DasautoSearchController(delegate: self)
            self.addChildViewController(searchController!)
            searchController!.view.frame.origin.y = -65
        }
        if self.state == CarClassControllerState.Normal {
            
            self.view.addSubview(searchController!.view)
            searchController!.view.frame.origin.y = -65
            self.topConstraint.constant = 65
            self.view.setNeedsUpdateConstraints()
            
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = 0
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        
                        self.state = CarClassControllerState.Search
                    }
            })
        }else {
            searchController?.setNormalState({ (finished) -> Void in
                
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    self.topConstraint.constant = 0
                    self.view.setNeedsUpdateConstraints()
                    
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        
                        self.searchController!.view.frame.origin.y = -65
                        self.view.layoutIfNeeded()
                        }, completion: { (completetion) -> Void in
                            if completetion {
                                
                                self.state = CarClassControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置treeView
    */
    func configureTreeView() {
        
        self.treeView.delegate = self
        self.treeView.dataSource = self
        self.treeView.separatorStyle = RATreeViewCellSeparatorStyleNone
        self.treeView.showsHorizontalScrollIndicator = false
        self.treeView.reloadData()
    }
    
    // MARK:
    // MARK: Configure Files
    /**
     *  configure Nodes
     */
    func configureNodes() {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.fileId)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        self.reconfigureNodes(self.directory, parentNodes: self.nodes)
    }
    
    /**
     *  reconfigure Nodes
     */
    func reconfigureNodes(das: DasAutoFile, parentNodes: NSMutableArray) {
        
        for var i = 0; i < das.children.count; i++ {
            
            let dasFileI = das.children[i] as DasAutoFile
            let dataI: RADataObject = RADataObject(name: dasFileI.name, describe: dasFileI.desc, resouceId: dasFileI.refResourceId,fileId: dasFileI.fileId,children: NSMutableArray(capacity: 0))
            parentNodes.addObject(dataI)
            dataI.dasautoFile = dasFileI
            self.reconfigureNodes(dasFileI, parentNodes: dataI.children)
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  下载爱车课堂图片
    */
    func downloadCarClassHeadImageViewUrl() {
        
        let zip = PackageFileManager.sharedInstance.currentZipPackage
        let userDic: NSDictionary = ["carModel": zip.carName, "carYear": zip.carProductYear]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCarClassPicture, param: userDic, withToken:false,success: { (operation, responseObject) -> Void in
            
            let mutableDict: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDict !=  nil {
                
                let respCode = mutableDict?.objectForKey("respCode") as! String
                if respCode == "000000" {
                    
                    Logger.info("\(mutableDict)")
                    let downloadUrl: String? = mutableDict?.objectForKey("downloadUrl") as? String
                    if downloadUrl?.isEmpty == false {
                        
                        Logger.info(downloadUrl!)
                        self.headImageView.setImageWithURL(NSURL(string: downloadUrl!))
                    }
                }else {
                    
                    let memo = mutableDict?.objectForKey("memo") as! String
                    Logger.info(memo)
                }
            }
        }) { (operation, error) -> Void in
            
            Logger.error("\(error)")
        }
    }
    
    // MARK:
    // MARK: treeViewDelegate
    func treeView(treeView: RATreeView!, heightForRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> CGFloat {
        
        return 44.0
    }
    
    func treeView(treeView: RATreeView!, indentationLevelForRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> Int {
        
        return 3 * treeNodeInfo.treeDepthLevel;
    }
    
    func treeView(treeView: RATreeView!, canEditRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> Bool {
        
        return false
    }
    
    func treeView(treeView: RATreeView!, shouldItemBeExpandedAfterDataReload item: AnyObject!, treeDepthLevel: Int) -> Bool {
        
        return false
    }
    
    func treeView(treeView: RATreeView!, willDisplayCell cell: UITableViewCell!, forItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) {
        
        if (treeNodeInfo.treeDepthLevel == 0) {
            
            cell.backgroundColor = UIColor(red: 250.0/255, green: 250.0/255, blue: 250.0/255, alpha: 1.0)
        } else if (treeNodeInfo.treeDepthLevel == 1) {
            
            cell.backgroundColor = UIColor(red: 223.0/255, green: 223.0/255, blue: 223.0/255, alpha: 1.0)
        }
    }
    
    func treeView(treeView: RATreeView!, cellForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> UITableViewCell! {
        
        let data = item as! RADataObject
        let nib = UINib(nibName: "TreeCell", bundle: nil)
        let cell: TreeCell = nib.instantiateWithOwner(nil, options: nil)[0] as! TreeCell
        
        cell.nameLabel.text = data.name
        return cell
    }
    
    func treeView(treeView: RATreeView!, numberOfChildrenOfItem item: AnyObject!) -> Int {
        
        if item == nil {
            return self.nodes.count
        }
        let data: RADataObject = item as! RADataObject
        
        return data.children == nil ? 0 : data.children.count
    }
    
    func treeView(treeView: RATreeView!, child index: Int, ofItem item: AnyObject!) -> AnyObject! {
        
        if item == nil {
            return self.nodes[index]
        }
        let data: RADataObject = item as! RADataObject
        return data.children[index]
    }
    
    func treeView(treeView: RATreeView!, didSelectRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let cell: TreeCell = treeView.cellForItem(item) as! TreeCell
        if !treeNodeInfo.expanded {
            
            if treeNodeInfo.children.count != 0 {
                
                UIView.animateWithDuration(0.2, animations: { () -> Void in
                    cell.narrowImageView.transform = CGAffineTransformMakeRotation(CGFloat(M_PI/2))
                })
            }
        } else {
            
            if treeNodeInfo.children.count != 0 {
                
                UIView.animateWithDuration(0.2, animations: { () -> Void in
                    cell.narrowImageView.transform = CGAffineTransformMakeRotation(CGFloat(0))
                })
            }
        }
        if (treeNodeInfo.item.dasautoFile is DasAutoFileLeaf) {
            
            self.performSegueWithIdentifier("detail", sender: nil)
        }
    }
    
    // MARK:
    // MARK: DasautoSearchControllerDelegate
    func dasautoSearchControllerDisappear() {
        
        if self.state == CarClassControllerState.Search {
            
            self.searchController!.view.frame.origin.y = 0
            self.topConstraint.constant = 0
            self.view.setNeedsUpdateConstraints()
            
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = -65
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        
                        self.state = CarClassControllerState.Normal
                        self.searchController!.view.removeFromSuperview()
                    }
            })
        }
    }
    
    func searchHandler(completion: (finished: Bool) -> Void) {
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            if SearchManager.sharedInstance.root.searchResult != nil {
                
                SearchManager.sharedInstance.root.searchResult.removeAll(keepCapacity: true)
            }
            self.filterFiles = SearchManager.sharedInstance.searchByKey(self.searchController!.searchTextField!.text!, fileId: self.fileId)
            completion(finished: true)
        }
    }
    
    func numberOfSections() -> Int {
        
        return 1
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        
        return (self.filterFiles != nil) ? self.filterFiles!.count : 0
    }
    
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "searchCell"
        var cell: SearchResultCell?
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? SearchResultCell
        if cell == nil {
            
            cell = SearchResultCell(style: .Default, reuseIdentifier: reusableIdentifier)
        }
        
        let dasautoFile: DasAutoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        cell?.nameLabel?.text = dasautoFile.name
        
        return cell!
    }
    
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("detail", sender: nil)
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "detail" {
            
            let vc = segue.destinationViewController as! HtmlDetaiController
            var dasautoFile: DasAutoFileLeaf!
            if self.state == CarClassControllerState.Normal {
                
                dasautoFile = (self.treeView.itemForSelectedRow() as! RADataObject).dasautoFile as! DasAutoFileLeaf
            }else {
                
                if self.searchController?.state == DasautoSearchControllerState.Search {
                    
                    let indexPath: NSIndexPath = self.searchController!.searchResultTableView!.indexPathForSelectedRow!
                    dasautoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFileLeaf
                    self.searchController?.searchResultTableView?.deselectRowAtIndexPath(indexPath, animated: true)
                }else {
                    
                    dasautoFile = (self.treeView.itemForSelectedRow() as! RADataObject).dasautoFile as! DasAutoFileLeaf
                }
            }
            vc.leaf = (dasautoFile as DasAutoFileLeaf)
            vc.listName = "爱车课堂"
        }
    }
}
