/*
*  filename: IntellectualTechnologyController.swift
*  product name: DasautoSpecifications
*  包中可能会包含视频介绍的内容也可能不包含
*  author: cp
*  date time: 14/12/23.
*  copyright: bdcluster
*/

import UIKit

enum IntellectualTechnologyControllerState {
    
    case Normal
    case Search
}

class IntellectualTechnologyController: DasautoController, UITableViewDataSource, UITableViewDelegate, DasautoSearchControllerDelegate, FavouriteLeafDelegate{

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    
    var manager: PackageFileManager!                 //有视频数据包在包中获取,没有视频数据包后台获取
    var directory: DasAutoDirectory!
    let fileId: Int = 4
    
    var state: IntellectualTechnologyControllerState!
    var searchController: DasautoSearchController?
    var filterFiles: NSArray?
    
    var dataArray: NSMutableArray!
    var isIncludeVideo: String!
    var crtZip: ZipPackage!
    
    // MARK:
    // MARK:Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    /*
    
    "更换车轮" --- 不显示在视频介绍模块, 需要修改xml配置, 暂时的处理方式是: 直接隐藏更换车轮(如果版本更新, 这个方法需要重新考虑)
    1.完整版,   通过dataArray排除"更换车轮"  在视频介绍解析时,  排除"更换车轮" 搜索
    2.无视频版, 在请求列表里, 排除"更换车轮"
    
    */
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.state = IntellectualTechnologyControllerState.Normal
        self.addRightNavigationItems()
        self.configureTitle("视频介绍")
        self.addBackBarButtonItem()
        crtZip = PackageFileManager.sharedInstance.currentZipPackage
        isIncludeVideo = PackageFileManager.sharedInstance.currentZipPackage.isIncludeVideo
        if isIncludeVideo == "true" {
            
            dataArray = NSMutableArray()
            self.configureDirectory()
        }else {
            
            if AFNetworkReachabilityManager.sharedManager().reachable == true {
                
                dataArray = NSMutableArray()
                self.loadCarVideoList()
            }else {
                
                self.showRendView("网络不可用", isSuccess: false)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK:Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
    *  选中AR
    */
    override func onArBarButtonclicked() {
        
        super.onArBarButtonclicked()
    }
    
    /**
     *  选中搜索
     */
    override func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        
        super.onSearchBarButtonclicked(sender)
        if searchController == nil {
            
            searchController = DasautoSearchController(delegate: self)
            self.addChildViewController(searchController!)
            searchController!.view.frame.origin.y = -65
        }
        
        if self.state == IntellectualTechnologyControllerState.Normal {
            
            self.view.addSubview(searchController!.view)
            searchController!.view.frame.origin.y = -65
            self.topConstraint.constant = 65
            self.view.setNeedsUpdateConstraints()

            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = 0
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        
                        self.state = IntellectualTechnologyControllerState.Search
                    }
            })
        }else {
            
            searchController?.setNormalState({ (finished) -> Void in
                
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    self.topConstraint.constant = 0
                    self.view.setNeedsUpdateConstraints()
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        
                        self.searchController!.view.frame.origin.y = -65
                        self.view.layoutIfNeeded()
                        }, completion: { (completetion) -> Void in
                            
                            if completetion {
                                
                                self.state = IntellectualTechnologyControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }
    
    // MARK:
    // MARK: Configure Files
    /**
    *  配置dictionary
    */
    func configureDirectory() {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.fileId)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        for leaf in self.directory.children {
            
            let leaf = leaf as DasAutoFile
            if leaf.name != "更换车轮" {
                
                dataArray.addObject(leaf)
            }
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  加载视频列表
    */
    func loadCarVideoList() {
        
        self.showProgressHUDMessage("正在加载")
        let zip = PackageFileManager.sharedInstance.currentZipPackage
        let userDict: NSDictionary = ["carModel": zip.carName, "carYear": zip.carProductYear]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCarVideoList, param: userDict, withToken:false,success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            let mutableDict: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDict != nil {
                
                let respCode = mutableDict?.objectForKey("respCode") as! String
                if respCode == "000000" {
                    
                    self.dataArray.removeAllObjects()
                    let responseArray = mutableDict?.objectForKey("carVideoList") as! NSArray
                    for videoList in responseArray {
                        
                        let videoListItem: CarVideoModel = CarVideoModel(JSONDic: videoList as! NSDictionary)
                        if videoListItem.videoName != "更换车轮" {     // 不添加更换车轮
                            
                            self.dataArray.addObject(videoListItem)
                        }
                    }
                    self.tableView.reloadData()
                }
             }
        }) { (operation, error) -> Void in
            
           self.hideProgressHUD()
        }
    }
    
    // MARK:
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isIncludeVideo == "true" {
            
            return self.directory == nil ? 0: self.dataArray.count
        }else {
            
            return self.dataArray == nil ? 0 : self.dataArray.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("IntellectualTechnologyCell") as! IntellectualTechnologyCell
        cell.delegate = self
        
        if isIncludeVideo == "true" {
            
            let leaf = self.dataArray[indexPath.row] as! DasAutoFile
            
            cell.favoriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,"视频介绍",leaf.name,leaf.resourceId,kUserId])
            cell.configureIntellectualTechnologyWith(leaf)
        }else {
            
            let videoModel = self.dataArray[indexPath.row] as! CarVideoModel
            cell.favoriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,"视频介绍",videoModel.videoName,videoModel.id.description,kUserId])
            cell.configureIntellectualCellWithDataArray(videoModel)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 110
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if isIncludeVideo == "true" {
            
            self.prepareVideoWithLeaf(indexPath,isSearch: false)
        }else {
            
            if AFNetworkReachabilityManager.sharedManager().reachable != true {
                
                self.showRendView("当前网络不可用", isSuccess: false)
                return
            }
            /*
             carVideoModel.carModel:Lamando凌渡
             carVideoModel.videoName:ACC自适应巡航
             carVideoModel.videoUrl:
             http://222.73.113.5:8201/cms-file/file/download/L3dscy9yZXNvdXJjZXMvTk1DL1ZJREVPLzI4ODA3Njg0MTE3ODU5MDA4MS5tcDQ=
             carVideoModel.picUrl:
             http://222.73.113.5:8201/cms-file/file/download/L3dscy9yZXNvdXJjZXMvTk1DL0lNQUdFLzY3MzIxNTI0MTAzNDQzMzkzODcucG5n
             carVideoModel.carYear:2015款
             carVideoModel.playTime:(NSNumber!) playTime = Int64(135)
             carVideoModel.id:(NSNumber!) id = Int64(13)
           */
            let videoDownload:MWVideoPlayerController = MWVideoPlayerController()
            
            let carVideoModel = self.dataArray[indexPath.row] as! CarVideoModel
            videoDownload.titleName = carVideoModel.videoName
            videoDownload.videoDowloadUrl = carVideoModel.videoUrl
            
            let time = carVideoModel.playTime as NSNumber
            
            let minute = time.intValue.toIntMax() / 60
            let second = time.intValue.toIntMax() % 60
            
            var allTimeString: String!
            if minute >= 10 {
                
                allTimeString = String(minute)
            }else {
                
                allTimeString = "0" + String(minute)
            }
            if second >= 10 {
                
                allTimeString = allTimeString + ":" + String(second)
            }else {
                
                allTimeString = allTimeString + ":" + "0" + String(second)
            }

            videoDownload.allTime = allTimeString
            videoDownload.index = carVideoModel.id.description
            
            let listArray = carVideoModel.refResList       // MAKR: 无视频版传入数组
            videoDownload.listArray = listArray
           
            self.navigationController?.pushViewController(videoDownload, animated: true)
        }
    }

    // MARK:DasautoSearchControllerDelegate
    func dasautoSearchControllerDisappear() {
        
        if self.state == IntellectualTechnologyControllerState.Search {
            
            self.searchController!.view.frame.origin.y = 0
            self.topConstraint.constant = 0
            self.view.setNeedsUpdateConstraints()
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = -65
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.state = IntellectualTechnologyControllerState.Normal
                        self.searchController!.view.removeFromSuperview()
                    }
            })
        }
    }
    
    func searchHandler(completion: (finished: Bool) -> Void) {
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            if SearchManager.sharedInstance.root.searchResult != nil {
                
                SearchManager.sharedInstance.root.searchResult.removeAll(keepCapacity: true)
            }
            
            let key = self.searchController!.searchTextField!.text
            if isIncludeVideo == "true" {
                
                self.filterFiles = SearchManager.sharedInstance.searchByKey(key!, fileId: self.fileId)
                completion(finished: true)
            }else {        // 无视频  解析file里没有视频介绍节点, 需从下载model里搜索
                
                self.filterFiles = self.findModelWithKey(key!)
                completion(finished: true)
            }
        }
    }
    
    /**
    *  无视频版搜索
    */
    func findModelWithKey(key: String) -> NSArray {
        
        let resultModelArray = NSMutableArray()
        for var i = 0; i < self.dataArray.count; i++ {
            
            let model = self.dataArray[i] as! CarVideoModel
            let name = model.videoName
            let nameRange = name.rangeOfString(key)
            
            let pingyingName = ChineseToPinyin.pinyinFromChiniseString(name)
            let pingyingNameRange = pingyingName.rangeOfString(key, options: NSStringCompareOptions.CaseInsensitiveSearch, range: nil, locale: nil)
            
            if nameRange != nil ||  pingyingNameRange != nil  {
                
                resultModelArray.addObject(model)
            }
        }
        
        return resultModelArray
    }
    
    // MARK: searchControllDelegate
    func numberOfSections() -> Int {
        
        return 1
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        
        return (self.filterFiles != nil) ? self.filterFiles!.count : 0
    }
    
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "searchCell"
        var cell: SearchResultCell?
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? SearchResultCell
        if cell == nil {
            
            cell = SearchResultCell(style: .Default, reuseIdentifier: reusableIdentifier)
        }
        if isIncludeVideo == "true" {
            
            let dasautoFile: DasAutoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
            cell?.nameLabel?.text = dasautoFile.name
        }else {
            
            let videoModel: CarVideoModel = self.filterFiles?.objectAtIndex(indexPath.row) as! CarVideoModel
            cell?.nameLabel?.text = videoModel.videoName
        }
        
        return cell!
    }
    
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath) {

        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if isIncludeVideo == "true" {
            
            self.prepareVideoWithLeaf(indexPath,isSearch: true)
        }else {
            
            let videoDownload:MWVideoPlayerController = MWVideoPlayerController()
            
            let carVideoModel = self.filterFiles?.objectAtIndex(indexPath.row) as! CarVideoModel
            videoDownload.titleName = carVideoModel.videoName
            videoDownload.videoDowloadUrl = carVideoModel.videoUrl
            
            let time = carVideoModel.playTime as NSNumber
            
            let minute = time.intValue.toIntMax() / 60
            let second = time.intValue.toIntMax() % 60
            
            var allTimeString: String!
            if minute >= 10 {
                
                allTimeString = String(minute)
            }else {
                
                allTimeString = "0" + String(minute)
            }
            if second >= 10 {
                
                allTimeString = allTimeString + ":" + String(second)
            }else {
                
                allTimeString = allTimeString + ":" + "0" + String(second)
            }
            
            videoDownload.allTime = allTimeString
            videoDownload.index = carVideoModel.id.description
            
            let listArray = carVideoModel.refResList       // MAKR: 无视频版传入数组
            videoDownload.listArray = listArray
            
            self.navigationController?.pushViewController(videoDownload, animated: true)
        }
    }
    
    // MARK: FavouriteLeafDelegate
    /**
    *  添加收藏
    */
    func addFavouriteResouceId(cell: UITableViewCell) {
        
        let indexpath = tableView.indexPathForCell(cell)! as NSIndexPath
        if isIncludeVideo == "true" {
            
            let leaf = self.dataArray[indexpath.row] as! DasAutoFile
            DBmanager.sharedInstanceWithDBName("html").insertHtml([crtZip.carName,crtZip.carProductYear,"视频介绍",leaf.name,leaf.resourceId,kUserId])
        }else {
            
            let videoModel = self.dataArray[indexpath.row] as! CarVideoModel
            DBmanager.sharedInstanceWithDBName("html").insertHtml([crtZip.carName,crtZip.carProductYear,"视频介绍",videoModel.videoName,videoModel.id.description,kUserId])
        }
    }
    
    /**
     *  取消收藏
     */
    func cancelFavouriteResouceId(cell: UITableViewCell) {
        
        let indexpath = tableView.indexPathForCell(cell)! as NSIndexPath
        if isIncludeVideo == "true" {
            
            let leaf = self.dataArray[indexpath.row] as! DasAutoFile
            DBmanager.sharedInstanceWithDBName("html").deleteHtml([crtZip.carName,crtZip.carProductYear,"视频介绍",leaf.name,leaf.resourceId,kUserId])
        }else {
            
            let videoModel = self.dataArray[indexpath.row] as! CarVideoModel
            DBmanager.sharedInstanceWithDBName("html").deleteHtml([crtZip.carName,crtZip.carProductYear,"视频介绍",videoModel.videoName,videoModel.id.description,kUserId])
        }
    }
    
    // MARK:
    // MARK: Push Controller
    /**
    *  有视频版 传入leaf
    */
    func prepareVideoWithLeaf(indexPath: NSIndexPath,isSearch: Bool) {
        
        var leaf: DasAutoFile!
        if isSearch == true {
            
            leaf = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        }else {
            
            leaf = self.dataArray[indexPath.row] as! DasAutoFile
        }
        
        // 有视频传入  childrenLeaf
        let childrenLeaf = leaf.children[0] as DasAutoFile
        
        let urlPath = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/video/" + leaf.videoFile)
        
        let minute = Int(leaf.playTime)! / 60
        let second = Int(leaf.playTime)! % 60
        var allTimeString: String!
        if minute >= 10 {
            
            allTimeString = String(minute)
        }else {
            
            allTimeString = "0" + String(minute)
        }
        if second >= 10 {
            
            allTimeString = allTimeString + ":" + String(second)
        }else {
            
            allTimeString = allTimeString + ":" + "0" + String(second)
        }
        let videoPlayerController: MWVideoPlayerController = MWVideoPlayerController()
        videoPlayerController.fileUrl = NSURL.fileURLWithPath(urlPath)
        videoPlayerController.titleName = leaf.name
        videoPlayerController.allTime = allTimeString
        videoPlayerController.leaf = childrenLeaf
        
        if childrenLeaf.children.count != 0 {
            videoPlayerController.dataArray = childrenLeaf.children
        }
        self.navigationController?.pushViewController(videoPlayerController, animated: true)
    }
    
    /**
     *  无视频版传入model
     */
    func prepareVideoWithVideoModel(indexPath: NSIndexPath) {
        
        let videoModel = self.dataArray[indexPath.row] as! CarVideoModel
        let minute = Int(videoModel.playTime.stringValue)! / 60
        let second = Int(videoModel.playTime.stringValue)! % 60
        var allTimeString: String!
        if minute >= 10 {
            
            allTimeString = String(minute)
        }else {
            
            allTimeString = "0" + String(minute)
        }
        if second >= 10 {
            
            allTimeString = allTimeString + ":" + String(second)
        }else {
            
            allTimeString = allTimeString + ":" + "0" + String(second)
        }
        
        let videoPlayerController: MWVideoPlayerController = MWVideoPlayerController()
        videoPlayerController.titleName = videoModel.videoName
        videoPlayerController.videoUrl = videoModel.videoUrl
        videoPlayerController.allTime = allTimeString
        
        self.navigationController?.pushViewController(videoPlayerController, animated: true)
    }
    
}
