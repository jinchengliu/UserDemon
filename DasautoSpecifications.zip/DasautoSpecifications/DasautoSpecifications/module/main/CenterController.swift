/*
 *  filename: CenterController.swift
 *  product name: DasautoSpecifications
 *
 *  author: cp
 *  date time: 14/11/5.
 *  copyright: bdcluster
 */

import UIKit

class CenterController: UINavigationController, UIGestureRecognizerDelegate {
       
    var notificationCeter: NSNotificationCenter?
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        notificationCeter = NSNotificationCenter.defaultCenter()
    }

    override func prefersStatusBarHidden() -> Bool {
        return false
    }
    
    /*
     *  self method
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationCeter?.addObserver(self, selector: Selector("themeNotification:"), name: kThemeDidChangeNotification, object: nil)
        //self.loadThemeImage()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    /*
    *
    *  @desc self method
    */
    func loadThemeImage() {
        
        let image: UIImage = ThemeManager.sharedInstance.getThemeImage("navigationbar_background.png")
        self.navigationBar.setBackgroundImage(image, forBarMetrics: UIBarMetrics.Default)
    }
    
    /*
    *
    *  @desc  notification
    */
    func themeNotification(notification: NSNotification) {
        
        self.loadThemeImage()
    }
    
    // MARK: 
    // MARK:UIGestureDelegate
    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
        
        if gestureRecognizer is UIPanGestureRecognizer && self.viewControllers.first == self.topViewController {
            return true
        }else {
            return false
        }
    }
}
