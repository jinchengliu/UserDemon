//
//  HtmlSpotImageController.swift
//  DasautoSpecifications
//
//  Created by 余新闻 on 15/7/8.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit
import Foundation
import AVFoundation


class HtmlSpotImageController:UIViewController
{

    var backButton:ThemeButton!
    var enLargeButton:UIButton!
    
    var hiddenStatus = true
    var whetherPortrate:Bool!    //是否竖屏
    
    var w:CGFloat!
    var h:CGFloat!
    
    var imageView:UIImageView!
    var imageSize:CGSize!
    
    var leaf:DasAutoFile!
    var leafDic:NSMutableDictionary!
    
    var imageWidth:CGFloat = 0.0
    var imageHeight:CGFloat = 0.0
    
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool){
        
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        self.navigationController?.interactivePopGestureRecognizer!.enabled = false
        
        self.setNeedsStatusBarAppearanceUpdate()

    }

    override func viewWillDisappear(animated: Bool){
        
        super.viewWillDisappear(animated)
        
        hiddenStatus = false
        self.setNeedsStatusBarAppearanceUpdate()
        
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        UIApplication.sharedApplication().setStatusBarHidden(false, withAnimation: UIStatusBarAnimation.None)
    }
    
    override func viewDidLoad(){
        
       super.viewDidLoad()
        
       self.view.backgroundColor = UIColor.blackColor()

        w = CGRectGetWidth(self.view.bounds)
        h = CGRectGetHeight(self.view.bounds)
        
        self.createWidgets()
        self.addHotButton()
    }
    
    // MARK:
    // MARK: Screen Configure
    override func prefersStatusBarHidden() -> Bool {
        
        return hiddenStatus
    }
    
    override func shouldAutorotate() -> Bool {
        
        return false
    }
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        
        return UIInterfaceOrientationMask.Portrait
    }
    
    // MARK:
    // MARK: Create Widgets
    func createWidgets()
    {
        self.backButton = ThemeButton(frame: CGRectMake(10, 20, 48, 48))
        self.backButton?.setImage(UIImage(named: "hotBack" + themeColor), forState: .Normal)
        self.backButton?.addTarget(self, action: Selector("backAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(self.backButton!)
        
        self.enLargeButton = UIButton(frame: CGRectMake(w - 43, 20, 40, 40))
        self.enLargeButton.setImage(UIImage(named: "cellPhone"), forState: UIControlState.Normal)
        self.enLargeButton.imageEdgeInsets = UIEdgeInsetsMake(10, 7, 10, 13)
        self.enLargeButton.addTarget(self, action: "onEnLargeButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(enLargeButton)
        
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + self.leaf.picFile)
        let image:UIImage = UIImage(contentsOfFile: path)!
        
        self.imageWidth = image.size.width
        self.imageHeight = image.size.height

        imageView = UIImageView(frame: CGRectMake(0, 0, w, w*imageHeight/imageWidth))
        imageView.center = self.view.center
        self.imageSize = image.size
        imageView.image = image
        imageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onImageViewTapGesture:"))
        imageView.userInteractionEnabled = true
        imageView.contentMode = UIViewContentMode.ScaleAspectFit
        self.view.addSubview(imageView)
        
        self.whetherPortrate = true
    }
    func addHotButton()
    {
        self.leafDic = NSMutableDictionary()
        
        for var k = 0; k < self.leaf.children.count; k++
        {
            let childrenLeaf = self.leaf.children[k] as DasAutoFile
            
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            if childrenLeaf.children.count != 0 {
                
                let dictionary:NSMutableDictionary = NSMutableDictionary()
                for var i = 0; i < childrenLeaf.children.count; i++
                {
                    let file = childrenLeaf.children[i] as DasAutoFile
                    let name = file.name
                    
                    dictionary.setValue(name, forKey: "name")

                    if file.detailDesc != nil
                    {
                         dictionary.setValue(file.detailDesc, forKey: "detailDesc")
                    }
                    if file.detailPicUrl != nil
                    {
                       dictionary.setValue(file.detailPicUrl, forKey: "detailPicUrl")
                    }
                }
                 self.leafDic.setValue(dictionary, forKey: childrenLeaf.resourceId)
            }
           
            
            let hotSpotButton = UIButton()
            if whetherPortrate == true
            {
                hotSpotButton.frame = CGRectMake(w / self.imageSize.width * x - 15 , CGRectGetHeight(self.imageView.frame) / self.imageSize.height * y - 15, 30, 30)
            }else
            {
                let a = h/w
                
                 let landRightHeight = h*self.imageHeight/self.imageWidth
                 hotSpotButton.frame = CGRectMake((w / self.imageSize.width * x - 15)*a+10 , landRightHeight / self.imageSize.height * y-15+200, 30, 30)
            }

            hotSpotButton.tag = Int(childrenLeaf.resourceId)!
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }

    }
    
    // MARK Actions
    func backAction(button:ThemeButton)
    {
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    func onEnLargeButtonClicked(button:UIButton)
    {
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if button.selected == true {
            
            self.setUIFrameAtPoritate()
            
        }else {
            
            self.setUIFrameAtLandRight()
        }
        button.selected = !button.selected
        
        let hotButtonClickedView = self.imageView.viewWithTag(111)
        if hotButtonClickedView != nil
        {
            hotButtonClickedView?.removeFromSuperview()
        }

    }
    func onImageViewTapGesture(tapFesture:UITapGestureRecognizer)
    {
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let hotButtonClickedView = self.imageView.viewWithTag(111)
        if hotButtonClickedView != nil
        {
            hotButtonClickedView?.removeFromSuperview()
        }
    }
    func onHotSpotButtonClicked(button:UIButton)
    {
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.imageView.viewWithTag(111) != nil
        {
            self.imageView.viewWithTag(111)?.removeFromSuperview()
            return
        }
        var name:String!
        var detailDesc:String! = ""
        var detailPic:String! = ""
        let dictionary:NSMutableDictionary = self.leafDic.objectForKey(button.tag.description) as! NSMutableDictionary
        
        var rect:CGRect

        if whetherPortrate != true
        {
            rect = CGRectMake((h-340)/2,(w-150)/2 , 340, 150)
        }else
        {
            rect = CGRectMake(20, 20, self.imageView.frame.size.width-20*2, self.imageView.frame.size.height-20*2)
        }

        name = dictionary.objectForKey("name") as! String
        
        let keysArr = dictionary.allKeys as NSArray
        if keysArr.containsObject("detailDesc")
        {
            detailDesc =  dictionary.objectForKey("detailDesc") as! String
        }
        if keysArr.containsObject("detailPicUrl")
        {
            detailPic = dictionary.objectForKey("detailPicUrl") as! String
            detailPic = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + detailPic)
        }
        if name == "显示屏"
        {
            name = "温度显示"
            detailDesc = "显示设定的温度"
        }
        let hotButtonClickedView:HotButtonClickedView = HotButtonClickedView(frame: rect, color: UIColor.whiteColor(),title:name,detail:detailDesc,imagePath:detailPic)
        hotButtonClickedView.tag = 111
        hotButtonClickedView.layer.cornerRadius = 5.0
        hotButtonClickedView.clipsToBounds = true
        imageView.addSubview(hotButtonClickedView)
        
        
    }
    
    // MARK  Rotate Screen
    func setUIFrameAtPoritate()
    {
        UIApplication.sharedApplication().setStatusBarHidden(false, withAnimation: UIStatusBarAnimation.None)
        self.whetherPortrate = true
        
        self.view.transform = CGAffineTransformIdentity
        self.view.frame = CGRectMake(0, 0, w, h)
        
        self.backButton.frame = CGRectMake(10, 20, 48, 48)
        self.enLargeButton.frame = CGRectMake(w - 43, 20, 40, 40)
        self.imageView.frame = CGRectMake(0, 0, w, w*self.imageHeight/self.imageWidth)
        self.imageView.contentMode = UIViewContentMode.ScaleToFill
        self.imageView.center = self.view.center
        
        self.removeHotSpotButtonFromSuperView()
        self.addHotButton()
       
    }
    func setUIFrameAtLandRight()
    {
       UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
        self.whetherPortrate = false
        
        self.view.transform = CGAffineTransformMakeRotation(CGFloat(M_PI/2))
        self.view.bounds = CGRectMake(0, 0, h, w)   //不能使用self.view.frame，而是用bounds
        
        self.imageView.frame = self.view.bounds
        self.imageView.contentMode = UIViewContentMode.ScaleAspectFit
        self.backButton.frame = CGRectMake(10, 10 , 45, 45)
        self.enLargeButton.frame = CGRectMake(h - 43, 10, 40, 40)
        
        self.view.bringSubviewToFront(self.backButton)
        self.view.bringSubviewToFront(self.enLargeButton)
        
        let landRightHeight = h*self.imageHeight/self.imageWidth
        
         self.removeHotSpotButtonFromSuperView()
        for var j = 0; j < self.leaf.children.count; j++
        {
            let childrenLeaf = self.leaf.children[j] as DasAutoFile
           
            let hotspotX = childrenLeaf.hotSpotX as String
            let hotspotY = childrenLeaf.hotSpotY as String
            let resourceId = childrenLeaf.resourceId
            let x: CGFloat = CGFloat(Int(hotspotX)!)
            let y: CGFloat = CGFloat(Int(hotspotY)!)
            
            let a = h/w
            let k = self.imageSize.width/self.imageSize.height
             let hotSpotButton = UIButton()
            if  (k - a) < 0.1 && (k - a) > -0.1
            {
                 hotSpotButton.frame = CGRectMake((w / self.imageSize.width * x - 15)*a+10 ,CGRectGetHeight(self.imageView.frame) / self.imageSize.height * y-15, 30, 30)
            }else
            {
                 hotSpotButton.frame = CGRectMake((w / self.imageSize.width * x - 15)*a+10 , landRightHeight / self.imageSize.height * y-15+0.175*w, 30, 30)
            }
            //iphone系列 0.175*w
            //ipad 200
            
            hotSpotButton.setImage(UIImage(named: "hotSpot" + themeColor), forState: UIControlState.Normal)
            hotSpotButton.imageEdgeInsets = UIEdgeInsetsMake(8, 8, 8, 8)
            hotSpotButton.addTarget(self, action: "onHotSpotButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
            hotSpotButton.userInteractionEnabled = true
            hotSpotButton.tag = Int(resourceId)!
            imageView.addSubview(hotSpotButton)
        }
    }
    
    // MARK:
    // MARK: 移除hotButton
    func removeHotSpotButtonFromSuperView() {
        
        for button in imageView.subviews
        {
            if button is UIButton
            {
                (button as! UIButton).removeFromSuperview()
            }
        }
    }
    
    // MARK: 
    // MARK:  Touch Event
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
    
        let touch: UITouch = (touches as NSSet).anyObject() as! UITouch
        if touch.view  == self.view
        {
            let hotButtonClickedView = self.imageView.viewWithTag(111)
            if hotButtonClickedView != nil
            {
                hotButtonClickedView?.removeFromSuperview()
            }
        }
    }
}