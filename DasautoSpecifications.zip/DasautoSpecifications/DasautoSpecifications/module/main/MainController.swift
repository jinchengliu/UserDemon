/*
*  filename: MainController.swift
*  product name: DasautoSpecifications
*
*  author: wangrui
*  date time: 14/11/28.
*  copyright: bdcluster
*/

import UIKit

enum MainControllerState: Int {
    case Normal
    case Search
}

class MainController: DasautoController, UITableViewDataSource, UITableViewDelegate, UIScrollViewDelegate,DasautoSearchControllerDelegate {
    
    @IBOutlet weak var carouselScrollView: UIScrollView!
    @IBOutlet weak var carouselPageControl: UIPageControl!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var lefftButton: UIButton!
    @IBOutlet weak var rightButton: UIButton!
    var packingScrolllView:CycleScrollView!
    var searchController: DasautoSearchController?
    var delegate: GuideMenuDelegate?
    var state: MainControllerState?
    
    var images: NSArray?
    var filterFiles: NSArray?
    var iconImageNameArray: NSArray?
    var titleStringArray: NSArray?
    
    var pkgFileManager: PackageFileManager!
//    var zipPackage: ZipPackage?
    var carouselTimer: NSTimer?
    var leftTimer:NSTimer!
    var rightTimer:NSTimer!
    
    var isRootViewController:Bool!
    let fileId: Int = 0
    var colorName: String!
    var bounds: CGRect!
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        carouselPageControl.hidden = true
        
        pkgFileManager = PackageFileManager.sharedInstance
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            self.favouritePost()
        }else {
            
            self.removeSearchController()
        }
        
        self.configureImages()
        self.addCarouselImageViewToScrollView(self.images!)
        if themeColor != colorName {
            self.tableView.reloadData()
            colorName = themeColor
        }
        self.tableView.bounds = bounds
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.automaticallyAdjustsScrollViewInsets = false
        self.state = MainControllerState.Normal
        self.setExtraCellLineHidden(self.tableView)
        self.addMenuBarButtonItem()
        self.addLogoTitleView()
        self.addRightNavigationItems()
        bounds = self.tableView.bounds
        colorName = themeColor
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidDisappear(animated)
        carouselTimer?.invalidate()
        carouselTimer = nil
        
        leftTimer?.invalidate()
        leftTimer = nil
        
        rightTimer?.invalidate()
        rightTimer = nil
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  去掉tableView多余的分割线
    */
    func setExtraCellLineHidden(tableView: UITableView) {
        
        let view: UIView = UIView()
        view.backgroundColor = UIColor.clearColor()
        tableView.tableFooterView = view
        tableView.autoresizesSubviews = true
    }
    
    /**
     *  添加leftBarButtonItem
     */
    func addMenuBarButtonItem() {
        
        let menuBarButton: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "menu"), style: UIBarButtonItemStyle.Plain, target: self, action: Selector("openOrCloseGuideMenu:"))
        self.navigationItem.leftBarButtonItem = menuBarButton
    }
    
    
    /**
    *  移除搜索视图
    */
    func removeSearchController() {
        
        if self.searchController != nil {
            
            self.filterFiles = nil
            self.searchController!.searchResultTableView?.reloadData()
            searchController!.setNormalState({ (finished) -> Void in
                
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 0.9, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        
                        self.searchController!.view.frame.origin.y = -65
                        }, completion: { (completetion) -> Void in
                            
                            if completetion {
                                
                                self.state = MainControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }
    
    /**
     *  配置轮播图片
     */
    func configureImages() {
        
        self.iconImageNameArray = ["quickGuide",
            "maintenance",
            "userManual",
            "smartTechnology",
            "carClassroom",
            "emergencyService"]
        self.titleStringArray = ["快速指南","维护保养","用户手册","视频介绍","爱车课堂","应急服务"]
        //  self.downloadScrollViewImage()
        
        let image0: UIImage = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("carclass", ofType: "png")!)!
        var image1: UIImage = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("wallPaper1", ofType: "jpg")!)!
        
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            let downloadDire = DSFileManager.sharedInstance.getDownloadDirectory() as NSString
            let path = downloadDire.stringByAppendingPathComponent(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix ).stringByAppendingString("/wallpaper")
            
            var pictureArray: [AnyObject]? = NSFileManager.defaultManager().subpathsAtPath(path)
            if pictureArray != nil {
                
                if pictureArray!.count != 0 {
                    
                    Logger.info("wallPaperCount: \(wallPaper)")
                    if wallPaper != "-1" {
                        
                        let path = DSFileManager.sharedInstance.getWallPaperPath(pictureArray![Int(wallPaper)!] as! String)
                        image1 = UIImage(contentsOfFile: path)!
                    }
                }
            }
        }
        let image2: UIImage = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("hotSpot", ofType: "png")!)!
        
        self.images = [image0, image1, image2]
    }
    
    /**
    *  在轮播的scrollView上添加车型图片，3张车型图按照(2，0，1，2，0)顺序排列，以便处理成循环滚动的效果。
    *
    */
    func addCarouselImageViewToScrollView(images: NSArray) {
        
        let width: CGFloat = CGRectGetWidth(UIScreen.mainScreen().bounds)
        
        let tempArr:NSMutableArray = NSMutableArray()
        let imageView0:UIImageView = UIImageView()
        let imageView1:UIImageView = UIImageView()
        let imageView2:UIImageView = UIImageView()
        imageView0.contentMode = UIViewContentMode.ScaleToFill
        imageView1.contentMode = UIViewContentMode.ScaleToFill
        imageView2.contentMode = UIViewContentMode.ScaleToFill
        
        
        imageView0.image = images.objectAtIndex(1) as? UIImage
        imageView1.image = images.objectAtIndex(2) as? UIImage
        imageView2.image = images.objectAtIndex(0) as? UIImage
        
        imageView0.frame = CGRectMake(0, 0, width, width*11/16)
        imageView1.frame = CGRectMake(width, 0, width, width*11/16)
        imageView2.frame = CGRectMake(width*2, 0, width, width*11/16)
        
        tempArr.addObject(imageView0)
        tempArr.addObject(imageView1)
        tempArr.addObject(imageView2)
        
        if packingScrolllView==nil
        {
            packingScrolllView = CycleScrollView(frame: CGRectMake(0, 0, width, width*11/16), animationDuration: 4)
            packingScrolllView.backgroundColor = UIColor.clearColor()
            carouselScrollView .addSubview(packingScrolllView)
            carouselScrollView .insertSubview(packingScrolllView, atIndex: 0)
            
        }
        packingScrolllView.totalPagesCount = {
            () in
            return tempArr.count
        }
        
        packingScrolllView.fetchContentViewAtIndex = {
            
            (index:NSInteger)->UIView in
            return tempArr[index] as! UIImageView
        }
        
        packingScrolllView.TapActionBlock = {
            (index:NSInteger) in
            
            SystemConfigureManager.sharedInstance.makeSoundEffect()
            switch (index) {
            case 0:
                
                Logger.info("第一张壁纸, 不过没有点击事件")
            case 1:
                if self.pkgFileManager.packages.count != 0 && self.pkgFileManager.rootFile != nil {
                    
                    let hotSpotViewController: HotSpotViewController = HotSpotViewController()
                    self.presentViewController(hotSpotViewController, animated: true, completion: nil)
                }
            case 2:
                self.performSegueWithIdentifier("CarClassSegue", sender: nil)
            default:
                break;
            }
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中一张按钮
    */
    @IBAction func lastPicture(sender: UIButton) {

        carouselTimer?.fireDate = NSDate(timeIntervalSinceNow: 4) as NSDate
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        sender.userInteractionEnabled = false
        packingScrolllView.userInteractionEnabled = false
        
        self.leftTimer = NSTimer.scheduledTimerWithTimeInterval(0.3, target: self, selector: "lastPage:", userInfo: nil, repeats: true)
    }
    
    /**
    *  当翻向上一页时，第一页指向第四页，第二页指向第五页
    */
    func lastPage(sender:UIButton) {
        
        if self.leftTimer != nil {
            
            if self.leftTimer.valid == true {
                
                self.leftTimer.invalidate()
                self.leftTimer = nil
            }
        }
        if self.rightTimer != nil {
            
            if self.rightTimer.valid == true {
                
                self.rightTimer.invalidate()
                self.rightTimer = nil
            }
        }
        
        self.lefftButton.userInteractionEnabled = true
        self.rightButton.userInteractionEnabled = true
        packingScrolllView.userInteractionEnabled = true
        packingScrolllView.animationTimerDidFiredBeforePage(packingScrolllView.animationTimer)
        NSThread.cancelPreviousPerformRequestsWithTarget(self, selector: "lastPage:", object: sender)
    }
    
    /**
     *  选中下一张按钮
     */
    @IBAction func nextPicture(sender: UIButton) { //
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        carouselTimer?.fireDate = NSDate(timeIntervalSinceNow: 4) as NSDate
        
        sender.userInteractionEnabled = false
        packingScrolllView.userInteractionEnabled = false
        
        self.rightTimer = NSTimer.scheduledTimerWithTimeInterval(0.3, target: self, selector: "nextPage:", userInfo: nil, repeats: true)
    }
    
    /**
     *  当翻向下一页时，第四页指向第一页，第五页指向第二页
     */
    func nextPage(sender:UIButton) {
        
        //--chang--
        if self.leftTimer != nil
        {
            if self.leftTimer.valid == true
            {
                self.leftTimer.invalidate()
                self.leftTimer = nil
            }
            
        }
        
        if self.rightTimer != nil
        {
            if self.rightTimer.valid == true
            {
                self.rightTimer.invalidate()
                self.rightTimer = nil
            }
        }
        
        self.lefftButton.userInteractionEnabled = true
        self.rightButton.userInteractionEnabled = true
        packingScrolllView.userInteractionEnabled = true
        packingScrolllView.animationTimerDidFired(packingScrolllView.animationTimer)
        NSThread.cancelPreviousPerformRequestsWithTarget(self, selector: "nextPage:", object: sender)
    }
    
    /**
     *  选中搜索按钮
     *
     */
    override func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        
        super.onSearchBarButtonclicked(sender)
        if searchController == nil {
            
            searchController = DasautoSearchController(delegate: self)
            self.addChildViewController(searchController!)
        }
        
        if self.state == MainControllerState.Normal {
            
            self.view.addSubview(searchController!.view)
            searchController!.view.frame.origin.y = -CGRectGetHeight(self.view.frame)
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 0.9, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = 0
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.state = MainControllerState.Search
                    }
            })
        }else {
            
            searchController?.setNormalState({ (finished) -> Void in
                
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 0.9, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        
                        self.searchController!.view.frame.origin.y = -65
                        }, completion: { (completetion) -> Void in
                            
                            if completetion {
                                
                                self.state = MainControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }
    
    /**
     *  选中AR的
     */
    override func onArBarButtonclicked() {
        
        super.onArBarButtonclicked()
    }
    
    /**
     *  选中打开或者关闭侧边栏
     */
    func openOrCloseGuideMenu(sender: UIBarButtonItem) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        searchController?.searchTextField?.resignFirstResponder()
        self.delegate?.didOpenOrCloseGuideMenu!()
    }

    // MARK: Load Data
    /**
    *  同步收藏
    */
    func favouritePost() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if kUserId != "noLogin" {
                
                var listArray = ["快速指南",
                    "维护保养",
                    "用户手册",
                    "视频介绍",
                    "爱车课堂",
                    "应急服务"]
                var appColumnNameArray = ["quick",
                    "maintain",
                    "manual",
                    "video",
                    "carclass",
                    "emergency"]
                let resourceIdListArray = NSMutableArray()
                
                let zip = PackageFileManager.sharedInstance.currentZipPackage
                for var i = 0; i < listArray.count; i++ {
                    
                    let htmlArray = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(zip.carName, carYear: zip.carProductYear, listName: listArray[i], userId: kUserId)
                    
                    for var j = 0; j < htmlArray.count; j++ {
                        
                        let type = appColumnNameArray[i] as String
                        let array = htmlArray[j] as! NSArray
                        
                        let id = array[4] as! String
                        let resName = array[3] as! String
                        let list = ["carResourceId":Int(id)!,"resourceType":type,"carResourceName":resName]
                        resourceIdListArray.addObject(list)
                    }
                }
                
                if resourceIdListArray.count != 0 {
                    
                    let param: NSDictionary = ["userId": Int(kUserId)!,"carModel": zip.carName,"carYear":zip.carProductYear,"resourceIdList": resourceIdListArray]
                    
                    AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionSyn, param: param, withToken:true,success: { (operation, responseObject) -> Void in
                        
                        let mutableDic =  responseObject as? NSMutableDictionary
                        if mutableDic != nil {
                            
                            let respCode = mutableDic?.objectForKey("respCode") as! String
                            if respCode == "020003" {
                                
                                DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                                DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                                kUserId = "noLogin"
                                NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
                                NSUserDefaults.standardUserDefaults().synchronize()
                                self.showRendView("账号失效, 请重新登录!", isSuccess: false)
                                let menu: MenuController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("MenuStoryboardID") as!MenuController
                                
                                let aboutController: AboutController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
                                aboutController.hasRightBarButtonItem = false
                                aboutController.pushToControllerName = "BackToMainControllerFavorite"
                                menu.openingController = CurrentOpeningController.AboutController
                                self.navigationController?.pushViewController(aboutController, animated: true)
                            }
                        }
                        }) { (operation, error) -> Void in
                            
                            Logger.info("_____________\(error)")
                    }
                }
            }
        }
    }
    
    /**
    *  下载轮播图片
    */
    func downloadScrollViewImage() {
        
        let param: NSDictionary = ["userName": "", "password": ""]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCarClassPicture, param: param,withToken:false, success: { (operation, responseObject) -> Void in
            
            var mutableDic: NSMutableDictionary? = NSMutableDictionary()
            mutableDic = responseObject as? NSMutableDictionary
            Logger.debug("\(mutableDic)")
            if mutableDic != nil {
                
                if mutableDic!.objectForKey("token") != nil {
                    
                }else {
                    
                    let memo = mutableDic?.objectForKey("memo") as! String
                    self.showRendView( memo, isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                Logger.info("_____________\(error)")
        }
    }
    
    func handleTapGesture(tapGesture: UITapGestureRecognizer) {
        
        let view: UIView = tapGesture.view!
        switch (view.tag) {
        case 0:
            
            Logger.info("第一张壁纸, 不过没有点击事件")
        case 1:
            
            if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
             
                let hotSpotViewController: HotSpotViewController = HotSpotViewController()
                self.presentViewController(hotSpotViewController, animated: true, completion: nil)
            }
        case 2:
            
            self.performSegueWithIdentifier("CarClassSegue", sender: nil)
        default:
            break;
        }
    }
    
    // MARK:
    // MARK: UIScrollViewDelegate
    // 滚动完成后，计算当前页，显示在pageControl上，按照(2，0，1，2，0)顺序计算
    func scrollViewDidScroll(scrollView: UIScrollView) {
        if scrollView == self.carouselScrollView
        {
            
            let n: Int = self.images!.count
            var pageIndex: Int!
            let curPage: Int = Int(scrollView.contentOffset.x / CGRectGetWidth(scrollView.frame))
            if  curPage == 0 {
                pageIndex = n - 3
            }else if curPage == 1 {
                pageIndex = n - 2
            }else if curPage == 2 {
                pageIndex = n - 1
            }else if curPage == n + 2 {
                pageIndex = 2
            }else if curPage == n + 3 {
                pageIndex = 0
            }else{
                pageIndex = curPage - 3
            }
            self.carouselPageControl.currentPage = pageIndex
        }
    }
    
    // MARK:UITableViewDataSource
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return CGRectGetHeight(tableView.bounds) / 6
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "categoryCell"
        var cell: UITableViewCell?
        
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier, forIndexPath: indexPath)
        
        let iconImageView: UIImageView = cell!.viewWithTag(1) as! UIImageView
        let titleLabel: UILabel = cell!.viewWithTag(2) as! UILabel
        let rightImageView: UIImageView = cell?.viewWithTag(3) as!UIImageView
        
        let iconName = (iconImageNameArray!.objectAtIndex(indexPath.row) as! String) + themeColor
        iconImageView.image = UIImage(named: iconName)
        titleLabel.text = titleStringArray!.objectAtIndex(indexPath.row) as? String
        rightImageView.image = UIImage(named: "rightArrow" + themeColor)
        return cell!
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {

        SystemConfigureManager.sharedInstance.makeSoundEffect()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        var typeString: String?
        var identifier: String?
        if indexPath.row == 5 {
            
            typeString = "emergencyCount"
            identifier = "EmergencyServiceSegue"
        }else {
            if pkgFileManager.packages.count != 0 {
                
                if pkgFileManager.rootFile != nil {
                    if indexPath.row == 0 {
                        
                        typeString = "quickCount"
                        identifier = "QuickQuideSegue"
                    }
                    else if indexPath.row == 1 {
                        
                        typeString = "maintainCount"
                        identifier = "MaintenanceSegue"
                    }
                    else if indexPath.row == 2 {
                        
                        typeString = "manualCount"
                        identifier = "UserManualSegue"
                    }
                    else if indexPath.row == 3 {
                        
                        typeString = "videoCount"
                        identifier = "ItellectualTechnologySegue"
                    }
                    else if indexPath.row == 4 {
                        
                        typeString = "carclassCount"
                        identifier = "CarClassSegue"
                    }
                }
                else {
                    // 遍历所以的zip包, 优先查看是否有下载完成的包
                    for zip in pkgFileManager.packages {
                        if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
                            zipPackage = zip
                            self.showAlertView("车型包已下载完成,\n 请解析数据包", tag: 2215)
                            return
                        }
                    }
                    for zip in pkgFileManager.packages {
                        if zip.state == ZipPackageDownloadState.downloadPause {
                            self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                            return
                        }else if zip.state == ZipPackageDownloadState.downloading {
                            if DSDownloadManager.shareInstance().isStartOperation(zip.urlString) {
                                self.showRendView("正在下载中", isSuccess: false)
                            }else {
                                self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                            }
                            return
                        }
                    }
                }
            }else {
                
                self.showAlertView("尚无数据,\n 请先下载车型", tag: 2217)
            }
        }
        
        if let type = typeString {
            
            self.saveCountWithType(type)
        }
        if let idef = identifier {
            
            self.performSegueWithIdentifier(idef, sender: nil)
        }
    }
    
    /**
    *  写入点击次数
    */
    func saveCountWithType(keyType: String) {
        
        let userDefault = NSUserDefaults.standardUserDefaults()
        var cnt = userDefault.objectForKey(keyType) as? Int
        if cnt == nil {
            
            cnt = 0
        }
        cnt = cnt! + 1
        userDefault.setObject(cnt, forKey: keyType)
        userDefault.synchronize()
    }
    
    
    // MARK:DasautoSearchControllerDelegate
    func dasautoSearchControllerDisappear() {
        
        if self.state == MainControllerState.Search {
            
            self.searchController!.view.frame.origin.y = 0
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 0.9, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                
                self.searchController!.view.frame.origin.y = -65
                }, completion: { (completetion) -> Void in
                    
                    if completetion {
                        
                        self.state = MainControllerState.Normal
                        self.searchController!.view.removeFromSuperview()
                    }
            })
        }
    }
    
    func searchHandler(completion: (finished: Bool) -> Void) {
        
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
           
            if SearchManager.sharedInstance.root.searchResult != nil {
                
                SearchManager.sharedInstance.root.searchResult.removeAll(keepCapacity: true)
            }
            self.filterFiles = SearchManager.sharedInstance.searchByKey(self.searchController!.searchTextField!.text!, fileId: 0)
            completion(finished: true)
        }else {
            
            if self.filterFiles != nil {
                
                self.filterFiles = nil
                completion(finished: true)
            }
        }
    }
    
    func numberOfSections() -> Int {
        
        return 1
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        
        return (self.filterFiles != nil) ? self.filterFiles!.count : 0
    }
    
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "searchCell"
        var cell: SearchResultCell?
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? SearchResultCell
        if cell == nil {
            
            cell = SearchResultCell(style: .Default, reuseIdentifier: reusableIdentifier)
        }
        
        let dasautoFile: DasAutoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        cell?.nameLabel?.text = dasautoFile.name
        
        return cell!
    }
    
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("MainToDetailHtml", sender: nil)
    }
    
    // MARK: 
    // MARK: 根据fieldId获取DasAutoDirectory
    func configureDasAutoDirectioryWithFieldId(fieldId: Int) -> DasAutoDirectory {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(fieldId)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        return directory
    }
    
    // MARK: 遍历快速指南
    func searchLeafFromQuickQuide(title: String, vc: HtmlDetaiController) {
        
        let directory = self.configureDasAutoDirectioryWithFieldId(1)
        for var i = 0; i < directory.children.count; i++ {
            
            let leaf = directory.children[i] as DasAutoFile
            if leaf.name == title {
                
                vc.listName = "快速指南"
                vc.leaf = leaf
                return
            }
        }
        self.searchLeafFromMaintenance(title, vc: vc)
    }
    
    // MARK: 遍历维护保养
    func searchLeafFromMaintenance(title: String, vc: HtmlDetaiController) {
        
        let directory = self.configureDasAutoDirectioryWithFieldId(2)
        for var i = 0; i < directory.children.count; i++ {
            
            let leaf = directory.children[i] as DasAutoFile
            for var i = 0; i < leaf.children.count; i++ {
                
                let childrenLeaf = leaf.children[i] as DasAutoFile
                if childrenLeaf.name == title {
                    
                    vc.listName = "维护保养"
                    vc.leaf = childrenLeaf
                    return
                }
            }
        }
        self.searchLeafFromUserManual(title, vc: vc)
    }
    
    // 遍历用户手册
    func searchLeafFromUserManual(title: String, vc: HtmlDetaiController) {
        
        let directory = self.configureDasAutoDirectioryWithFieldId(3)
        for var i = 0; i < directory.children.count; i++ {
            
            let file = directory.children[i] as DasAutoFile
            for var i = 0; i < file.children.count; i++ {
                
                let childrenFile = file.children[i] as DasAutoFile
                for var i = 0; i < childrenFile.children.count; i++ {
                    
                    let leaf = childrenFile.children[i] as DasAutoFile
                    if leaf.name == title {
                        
                        vc.listName = "用户手册"
                        vc.leaf = leaf
                        if leaf.children.count != 0 {
                            
                            vc.dataArray = leaf.children
                        }
                        return
                    }
                    for var i = 0; i < leaf.children.count; i++ {
                        
                        let childrenLeaf = leaf.children[i] as DasAutoFile
                        if childrenLeaf.name == title {
                            
                            vc.listName = "用户手册"
                            vc.leaf = childrenLeaf
                            return
                        }
                    }
                }
            }
        }
        self.searchLeafFromLoveClass(title, vc: vc)
    }
    
    // 遍历爱车课堂
    func searchLeafFromLoveClass(title: String, vc: HtmlDetaiController) {
        
        let directory = self.configureDasAutoDirectioryWithFieldId(5)
        for var i = 0; i < directory.children.count; i++ {
            
            let leaf = directory.children[i] as DasAutoFile
            if leaf.name == title {
                
                vc.listName = "爱车课堂"
                vc.leaf = leaf
                if leaf.resourceId == nil {
                    
                    Logger.info("resourceId :\(leaf.resourceId)")
                }
                return
            }
        }
        self.searchLeafFromEmergencyService(title, vc: vc)
    }
    
    // 遍历应急服务
    func searchLeafFromEmergencyService(title: String, vc: HtmlDetaiController) {
        
        let directory = self.configureDasAutoDirectioryWithFieldId(6)
        for var i = 0; i < directory.children.count; i++ {
            
            let leaf = directory.children[i] as DasAutoFile
            for var i = 0; i < leaf.children.count; i++ {
                
                let childrenLeaf = leaf.children[i] as DasAutoFile
                if childrenLeaf.name == title {
                    
                    vc.listName = "应急服务"
                    vc.leaf = childrenLeaf
                    if childrenLeaf.resourceId != nil {
                        
                        Logger.info("resourceId :\(leaf.resourceId)")
                    }
                    return
                }
            }
        }
        
        self.searchLeafFromOtherRes(title, vc: vc)
    }
    
    // 遍历otherRes
    func searchLeafFromOtherRes(title: String, vc: HtmlDetaiController) {
        
        let directory = self.configureDasAutoDirectioryWithFieldId(8)
        for var i = 0; i < directory.children.count; i++ {
            
            let leaf = directory.children[i] as DasAutoFile
            if leaf.name == title {
                
                vc.listName = "快速指南"      // 再判断
                vc.leaf = leaf
                return
            }
        }
    }
    
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "MainToDetailHtml" {
            
            let vc = segue.destinationViewController as! HtmlDetaiController
            var dasautoFile: DasAutoFile!
            let indexPath: NSIndexPath = self.searchController!.searchResultTableView!.indexPathForSelectedRow!
            dasautoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
            self.searchLeafFromQuickQuide(dasautoFile.name, vc: vc)
        }
    }
}
