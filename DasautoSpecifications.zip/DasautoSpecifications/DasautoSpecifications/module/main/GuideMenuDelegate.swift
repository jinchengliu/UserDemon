/*
*  filename: GuideMenuDelegate.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/1.
*  copyright: bdcluster
*/

import UIKit

@objc protocol GuideMenuDelegate {
    optional func didOpenOrCloseGuideMenu()
    optional func didCloseGuideMenu()
}
