//
//  IndicatorAndWarningLightController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-30.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class IndicatorAndWarningLightController: DasautoController, UIWebViewDelegate {
   
    @IBOutlet weak var webView: UIWebView!              // webView
    @IBOutlet weak var telephoneButton: UIButton!       // 拨打电话按钮
    @IBOutlet weak var findButton: UIButton!            // 查找按钮
    
    var favouriteButton: UIButton!
    
    var directory: DasAutoDirectory!
    var leaf: DasAutoFile!
    var crtZip: ZipPackage!
    
    var telephoneNumber = "4008201111"                // 大众服务热线
    var telephoneTitle = "400 820 1111"
    var fileId: Int = 6
    
    var hasRefresh = false
    var numberWebPage = 0
    var listName: String!
    
    var leafArray: NSMutableArray!
    var listNameArray: NSMutableArray!
    
    // MARK;
    // MARK: Life Cycle
    override func viewDidLoad() {
        /*
        弃用
        */
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.setButtonTitleColor(telephoneButton)
        self.setButtonTitleColor(findButton)
        self.configureDirectoryAndWebView()
        if listName != nil {
            
            self.addRightNavigationItemAboutFavourite()
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: 配置directory
    func configureDirectoryAndWebView() {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.fileId)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        crtZip = PackageFileManager.sharedInstance.currentZipPackage
        
        leafArray = NSMutableArray()
        listNameArray = NSMutableArray()
        var dasAutoFileArray = directory.children as [DasAutoFile]
        if dasAutoFileArray.count != 0 {
            
            for var i = 0; i < dasAutoFileArray.count; i++ {
                
                let fileLeaf = dasAutoFileArray[i] as DasAutoFile
                if fileLeaf.name == "指示灯及警告灯" {
                    
                    listName = "应急服务"
                    self.webViewLoadRequestWithDasautoFileLeaf(fileLeaf, isRefresh: false)
                    break
                }
            }
        }
    }
    
    func webViewLoadRequestWithDasautoFileLeaf(fileLeaf: DasAutoFile ,isRefresh: Bool) {
        
        leaf = fileLeaf
        leafArray.addObject(leaf)
        listNameArray.addObject(listName)
        self.configureTitle(leaf.name)
        let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
        let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
        self.webView.loadRequest(request!)
        
        if isRefresh == true {
            
            favouriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        }
    }
    
    /**
     *  刷新webView
     */
    func refreshWebView() {
        
        numberWebPage--
        hasRefresh = false  //  防止再次解析webView的url
        
        //self.webView.goBack()
        listName = listNameArray[numberWebPage] as! String
        leaf = leafArray[numberWebPage] as! DasAutoFile
        let htmlPath = DSFileManager.sharedInstance.getFilePathAboutSpecification(leaf)
        let request: NSURLRequest? = NSURLRequest(URL: NSURL(fileURLWithPath: htmlPath))
        self.webView.loadRequest(request!)
        
        self.configureTitle(leaf.name)
        favouriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
    }
    
    // MARK;
    // MARK: Configure Views
    /**
    *  添加收藏按钮
    */
    func addRightNavigationItemAboutFavourite() {
        
        favouriteButton = UIButton(frame: CGRectMake(0, 0, 21, 21))
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate_selected.png"), forState: UIControlState.Normal)
        favouriteButton.setBackgroundImage(UIImage(named: "personalFavourate" + themeColor), forState: UIControlState.Selected)
        favouriteButton.addTarget(self, action: Selector("onFavouriteBarButtonItemClciked:"), forControlEvents: UIControlEvents.TouchUpInside)
        favouriteButton.selected = DBmanager.sharedInstanceWithDBName("html").isSelectedWithArray([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        
        let favouriteBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: favouriteButton)
        self.navigationItem.rightBarButtonItem = favouriteBarButtonItem
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中拨打电话
    */
    @IBAction func onTelephoneButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let customAlertView = CustomAlertView(messageTitle: "上海大众服务热线_" + "400 820 1111", sureTitle: "phone", cancelTitle: "取消", delegate: self)
        customAlertView.show()
    }
    
    /**
    *  选中查找维修中心按钮
    */
    @IBAction func onFindButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        Car4sshopListManager.sharedInstance.removeSelectedProvice()
        let car4sshopListController: Car4sshopListController = Car4sshopListController()
        self.navigationController?.pushViewController(car4sshopListController, animated: true)
    }
    
    /**
     *  选中返回按钮
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        Logger.info("back numberWebPage = \(numberWebPage)")
        if numberWebPage == 0 {
        
            super.onBackBarButtonItemClciked(sender)
            self.navigationController?.popViewControllerAnimated(true)
        }else {

            leafArray.removeObjectAtIndex(numberWebPage)
            listNameArray.removeObjectAtIndex(numberWebPage)
            
            self.refreshWebView()
        }
    }
    
    /**
    *  选中收藏按钮
    */
    func onFavouriteBarButtonItemClciked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if favouriteButton.selected {
            
            DBmanager.sharedInstanceWithDBName("html").deleteHtml([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        } else {
            
            DBmanager.sharedInstanceWithDBName("html").insertHtml([crtZip.carName,crtZip.carProductYear,listName,leaf.name,leaf.resourceId,kUserId])
        }
        favouriteButton.selected = !favouriteButton.selected
    }
    
    // MARK:
    // MARK: CustomAlertViewDelegate
    override func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        
        UIApplication.sharedApplication().openURL(NSURL(string: "telprompt:" + telephoneNumber)!)
    }
    
    // MARK: UIWebViewDeleagate
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        if hasRefresh == true {
            
            let urlString = request.URL!.absoluteString
            var array: [String] = urlString.componentsSeparatedByString("html/")
            if array.count != 1 {
                
                let separatedString = array[1] as String
                
                //  -- change --
                let chilArray = separatedString.componentsSeparatedByString("#")
                if chilArray.count == 1 {
                    
                    var indexArray = separatedString.componentsSeparatedByString(".")
                    let resIndex = indexArray[0]         // 获取resIndex
                    
                    var ground = indexArray[1]
                    var groundArray = ground.componentsSeparatedByString("ground=")
                    if groundArray.count != 1 {
                        
                        var groundArray = groundArray[1].componentsSeparatedByString("&")
                        ground = groundArray[0]          // 获取listName
                    }
                    
                    // 遍历获得leaf
                    leaf = self.getLeafFromOtherResWithResIndex(resIndex)
                    if ground == "manual" {
                        
                        listName = "用户手册"
                    }else if ground == "carclass" {
                        
                        listName = "爱车课堂"
                    }else if ground == "emergency" {
                        
                        listName = "应急服务"
                    }
                    
                    Logger.info("应急服务 listName: \(listName)")
                    self.webViewLoadRequestWithDasautoFileLeaf(leaf, isRefresh:true)
                    numberWebPage++
                    hasRefresh = false
                }else {
                    
                    hasRefresh = true
                }
            }
            
            return true
        }
        
        hasRefresh = true
        return true
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        
        let fontStr = "document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= " + kHtmlFontSize
        self.webView.stringByEvaluatingJavaScriptFromString(fontStr)
    }
    
    // MARK:
    // MARK: Search Leaf
    /**
    *  userManual里面搜索获取leaf
    */
    func getLeafFromUserManaulWithResIndex(resIndex: String) -> DasAutoFile {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(3)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
//        let leaf: DasAutoFile!
        for var i = 0; i < directory.children.count; i++ {
            
            let file = directory.children[i] as DasAutoFile
            for var i = 0; i < file.children.count; i++ {
                
                let fileChildren = file.children[i] as DasAutoFile
                for var i = 0; i < fileChildren.children.count; i++ {
                    
                    let leaf = fileChildren.children[i] as DasAutoFile
                    if leaf.resIndex == resIndex {
                        
                        return leaf
                    }
                    for var i = 0; i < leaf.children.count; i++ {
                        
                        let leafChildren = leaf.children[i] as DasAutoFile
                        if leafChildren.resIndex == resIndex {
                            
                            return leafChildren
                        }
                        for var i = 0; i < leafChildren.children.count; i++ {
                            
                            let le = leafChildren.children[i] as DasAutoFile
                            if le.resIndex == resIndex {
                                
                                return le
                            }
                        }
                    }
                }
            }
        }
//        return leaf
        return PackageFileManager.sharedInstance.rootFile
    }
    
    /**
    *  从otherRes里面搜索获取leaf
    */
    func getLeafFromOtherResWithResIndex(resIndex: String) -> DasAutoFile {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
        let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        
        var leaf: DasAutoFile!
        for var i = 0; i < directory.children.count; i++ {
            
            let directoryChildren = directory.children[i] as DasAutoFile
            if directoryChildren.resIndex == resIndex {
                
                return directoryChildren
            }
        }
        
        leaf = self.getLeafFromUserManaulWithResIndex(resIndex)
        return leaf
    }
}
