/*
*  filename: MenuController.swift
*  product name: DasautoSpecifications
*
*  author: cp
*  date time: 14/11/5.
*  copyright: bdcluster
*/

import UIKit

let kICSDrawerControllerLeftViewInitialOffset : CGFloat  = 60.0

//Drawer status open or close
enum ICSDrawerControllerState : Int {
    
    case MenuControllerStateOpening
    case MenuControllerStateClosing
}

//current opening view controller
enum CurrentOpeningController : Int {
    
    case HomeController
    case SelectCarTypeController
    case PersonalFavourateController
    case SettingController
    case FeedBackController
    case MyMessageController
    case AboutController
    case MyContentController
    case LoginController
}

class MenuController: DasautoController, GuideMenuDelegate {
    
    var panGestureRecognizer: UIPanGestureRecognizer!
    var tapGestureRecognizer: UITapGestureRecognizer!
    var panGestureStartLocation : CGPoint!
    var drawerState : ICSDrawerControllerState!
    var drawerControllerDrawerDepth: CGFloat!
    var openingController : CurrentOpeningController!
    
    var storyBoard = UIStoryboard(name: "Main", bundle: nil)
    var guideView: GuideView!
    var centerController: CenterController!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        UIApplication.sharedApplication().setStatusBarHidden(false, withAnimation: UIStatusBarAnimation.None)
        
        self.view.backgroundColor = UIColor.grayColor()
        drawerControllerDrawerDepth = CGFloat(CGRectGetWidth(self.view.frame)*3/4)
        self.getComponetsControllers()
        self.configureGuideListener()
        
        self.view.addSubview(self.guideView)
        self.addChildViewController(self.centerController)
        self.view.addSubview(self.centerController.view)
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count == 0 && pkgFileManager.rootFile == nil {
            
            let selectCarTypeVC = storyBoard.instantiateViewControllerWithIdentifier("SelectCarTypeStoryboardID") as! SelectCarTypeController
            selectCarTypeVC.delegate = self
            selectCarTypeVC.isRootViewController = true
            self.openingController = CurrentOpeningController.SelectCarTypeController
            self.setCenterControllerRootController(selectCarTypeVC)
            Logger.debug("进入下载车型界面")
        }else {
            
            Logger.debug("加载打开包数据")
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("setCenterControllerRootControllerWithMainController"), name: "setMainController", object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: NSNotificationCenter
    func setCenterControllerRootControllerWithMainController() {
        
        let mainController: MainController = storyboard?.instantiateViewControllerWithIdentifier("MainStoryboardID") as! MainController
        mainController.delegate = self
        mainController.isRootViewController = true
        self.openingController = CurrentOpeningController.HomeController
        self.setCenterControllerRootController(mainController)
    }
    
    func setCenterControllerRootController(viewController: UIViewController) {

        self.centerController.viewControllers = [viewController]
    }
    
    func setMainControllerAsRootController(string: String) {
        
        let mainController: MainController = storyBoard.instantiateViewControllerWithIdentifier(string) as! MainController
        mainController.delegate = self
        mainController.isRootViewController = true
        self.openingController = CurrentOpeningController.HomeController
        self.setCenterControllerRootController(mainController)
    }
    
    // MARK:
    // MARK: fetch components of drawer,which is, contorllers
    func getComponetsControllers() {
        
        self.drawerState = ICSDrawerControllerState.MenuControllerStateClosing
        self.openingController = CurrentOpeningController.HomeController
        
        centerController = storyBoard.instantiateViewControllerWithIdentifier("CenterStoryboardID") as!CenterController
        (centerController.topViewController as! MainController).delegate = self
        guideView = GuideView(frame: CGRectMake(-drawerControllerDrawerDepth*2/3, 0, drawerControllerDrawerDepth, CGRectGetHeight(self.view.frame)))
        panGestureRecognizer = UIPanGestureRecognizer(target: self, action: Selector("onPanGestureRecognized:"))
        panGestureRecognizer.delegate = centerController
        centerController.view.addGestureRecognizer(panGestureRecognizer)
        //阴影效果
        centerController.view.layer.shadowOffset = CGSizeMake(-10, 0)
        centerController.view.layer.shadowOpacity = 0.6
        centerController.view.layer.shadowRadius = 10
        centerController.view.layer.shadowColor = UIColor.blackColor().CGColor
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置侧边栏
    */
    func configureGuideListener() {
        
        guideView.selectCarTypeButton.addTarget(self, action: Selector("onSelectCarTypeAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        guideView.personalFavouriteButton.addTarget(self, action: Selector("onFavouriteAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        guideView.settingButton.addTarget(self, action: Selector("onSettingAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        guideView.feedBackButton.addTarget(self, action: Selector("onFeedBackAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        guideView.myMessageButton.addTarget(self, action: Selector("onMessageAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        guideView.aboutButton.addTarget(self, action: Selector("onAboutButtonAction:"), forControlEvents: UIControlEvents.TouchUpInside)
        guideView.myContentButton.addTarget(self, action: Selector("onMyContentButtonAction:"), forControlEvents: UIControlEvents.TouchUpInside)
    }
    
    // MARK:
    // MARK: UIGestureRecognizer
    /**
    *  handle pan gesture
    */
    func onPanGestureRecognized(pan:UIPanGestureRecognizer) {
        
        let state = panGestureRecognizer.state
        let location = panGestureRecognizer.locationInView(self.view)
        
        switch (state) {
        case UIGestureRecognizerState.Began:
            self.panGestureStartLocation = location
            break;
        case UIGestureRecognizerState.Changed:
            var c = self.centerController.view.frame
            var g = self.guideView.frame
            
            if (panGestureRecognizer.translationInView(self.centerController.view).x > 0){
                if (self.drawerState == ICSDrawerControllerState.MenuControllerStateClosing){
                    c.origin.x = location.x - self.panGestureStartLocation.x
                }
            }else if (panGestureRecognizer.translationInView(self.centerController.view).x > -drawerControllerDrawerDepth){
                if (self.drawerState == ICSDrawerControllerState.MenuControllerStateOpening){
                    c.origin.x = panGestureRecognizer.translationInView(self.centerController.view).x+drawerControllerDrawerDepth
                }
            }
            let gNewX: CGFloat = (c.origin.x - drawerControllerDrawerDepth)*2/3
            if gNewX < 0 {
                g.origin.x = gNewX
            }
            self.centerController.view.frame = c
            self.guideView.frame = g
            break;
        case UIGestureRecognizerState.Ended:
            
            let c = self.centerController.view.frame
            //  表示用户需要展开
            if (location.x - self.panGestureStartLocation.x > kICSDrawerControllerLeftViewInitialOffset){
                self.didOpen(true)
            }else{
                if  (c.origin.x < (drawerControllerDrawerDepth - 40)){
                    self.didClose()
                }else{
                    self.didOpen(true)
                }
            }
            break;
        default:
            break;
        }
    }
    
    /**
    *  handle tap gesture
    */
    func onTapGestureRecognized(tap:UITapGestureRecognizer) {
        
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中选择车型
    */
    func onSelectCarTypeAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.openingController != CurrentOpeningController.SelectCarTypeController {
            
            let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
            if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
                
                guideView.setSubButtonsUnselectedExcept(obj)
                let selectCarTypeController: SelectCarTypeController = storyBoard.instantiateViewControllerWithIdentifier("SelectCarTypeStoryboardID") as!SelectCarTypeController
                selectCarTypeController.delegate = self
                selectCarTypeController.isRootViewController = true
                self.openingController = CurrentOpeningController.SelectCarTypeController
                self.setCenterControllerRootController(selectCarTypeController)
            }else {
            
                guideView.setSubButtonsUnselectedExcept(obj)
                let selectCarTypeController: SelectCarTypeController = storyBoard.instantiateViewControllerWithIdentifier("SelectCarTypeStoryboardID") as! SelectCarTypeController
                selectCarTypeController.delegate = self
                selectCarTypeController.isRootViewController = false
                centerController.popToRootViewControllerAnimated(false)
                centerController.pushViewController(selectCarTypeController, animated: false)
            }
            self.didClose()
            self.openingController = CurrentOpeningController.SelectCarTypeController
        }else {

            self.didClose()
        }
    }
    
    /**
    *  选中个人收藏
    */
    func onFavouriteAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.openingController != CurrentOpeningController.PersonalFavourateController {
            
            guideView.setSubButtonsUnselectedExcept(obj)
            let personalFavouriteController: PersonalFavouriteController = storyBoard.instantiateViewControllerWithIdentifier("PersonalFavouriteStoryboardID") as! PersonalFavouriteController
            personalFavouriteController.delegate = self
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(personalFavouriteController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.PersonalFavourateController
        }else {
             
            self.didClose()
        }
    }
    
    
    /**
     *  选中我的消息
     */
    func onMessageAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if kUserId != "noLogin" {
            
            guideView.setSubButtonsUnselectedExcept(obj)
            let myMessageController: MyMessageController = storyBoard.instantiateViewControllerWithIdentifier("MyMessageStoryboardID") as! MyMessageController
            myMessageController.delegate = self
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(myMessageController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.MyMessageController
        }else {
            
            let aboutController: AboutController = storyBoard.instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
            aboutController.delegate = self
            aboutController.hasRightBarButtonItem = false
            aboutController.pushToControllerName = "MyMessageController"
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(aboutController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.AboutController
        }
    }
    
    /**
    *  选中下载管理
    */
    func onMyContentButtonAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.openingController != CurrentOpeningController.MyContentController {
            
            guideView.setSubButtonsUnselectedExcept(obj)
            let downloadManagerVC = storyBoard.instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as! DownloadManagerController
            downloadManagerVC.delegate = self
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(downloadManagerVC, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.MyContentController
        }else {
            
            self.didClose()
        }
    }
    
    /**
    *  选中功能设置
    */
    func onSettingAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.openingController != CurrentOpeningController.SettingController {
            guideView.setSubButtonsUnselectedExcept(obj)
            let settingController: SettingController = storyBoard.instantiateViewControllerWithIdentifier("SettingStoryboardID") as! SettingController
            settingController.delegate = self
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(settingController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.SettingController
        }else {
            self.didClose()
        }
    }
    
    
    /**
    *  选中账号管理
    */
    func onAboutButtonAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        guideView.setSubButtonsUnselectedExcept(obj)
        if kUserId != "noLogin" {
            
            let userInfoController: LoginController = storyBoard.instantiateViewControllerWithIdentifier("UserInfoStoryboardID") as! LoginController
            userInfoController.delegate = self
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(userInfoController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.LoginController
        }else {
            
            let aboutController: AboutController = storyBoard.instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
            aboutController.delegate = self
            aboutController.hasRightBarButtonItem = false
            aboutController.pushToControllerName = "BackToMainController"
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(aboutController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.AboutController
        }
     }
    
    /**
     *  选中用户反馈
     */
    func onFeedBackAction(obj: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if self.openingController != CurrentOpeningController.FeedBackController {
            
            guideView.setSubButtonsUnselectedExcept(obj)
            let feedbackController: FeedBackController = storyBoard.instantiateViewControllerWithIdentifier("FeedBackStoryboardID") as! FeedBackController
            feedbackController.delegate = self
            centerController.popToRootViewControllerAnimated(false)
            centerController.pushViewController(feedbackController, animated: false)
            self.didClose()
            self.openingController = CurrentOpeningController.FeedBackController
        }else {
            
            self.didClose()
        }
    }
    
    //对菜单按钮取消选中
    func setUnselectedGuideButtons() {
        
        guideView.setAllSubButtonsUnselected()
    }
    
    // MARK:
    // MARK: GuideMenuDelegate
    func didCloseGuideMenu() {
        
        guideView.setAllSubButtonsUnselected()
        self.openingController = CurrentOpeningController.HomeController
    }
    
    func didOpenOrCloseGuideMenu() {
        
        if self.drawerState == ICSDrawerControllerState.MenuControllerStateClosing {
            
            self.didOpen(false)
        }else if self.drawerState == ICSDrawerControllerState.MenuControllerStateOpening {
            
            self.didClose()
        }
    }
    
    // MARK:
    // MARK: Open Or Close GuideMenu
    /**
    *  菜单打开
    */
    func didOpen(isUsingSpringWithDamping: Bool){
        
        var c = self.centerController.view.frame
        var g = self.guideView.frame
        c.origin.x = drawerControllerDrawerDepth
        g.origin.x = 0
        
        var cUsingSpringWithDamping: CGFloat = 1.0
        if isUsingSpringWithDamping {
            cUsingSpringWithDamping = 0.5
        }
        
        UIView.animateWithDuration(0.7,delay:0,usingSpringWithDamping:cUsingSpringWithDamping,initialSpringVelocity:1.0,options:UIViewAnimationOptions.AllowUserInteraction,animations:{
            
            self.centerController.view.frame = c
            },completion: { (finished: Bool) -> Void in
                
        })
        
        UIView.animateWithDuration(0.7,delay:0,usingSpringWithDamping:1.0,initialSpringVelocity:1.0,options:UIViewAnimationOptions.AllowUserInteraction,animations:{
            
            self.guideView.frame = g
            },completion: { (finished: Bool) -> Void in
                
        })
        
        self.drawerState = ICSDrawerControllerState.MenuControllerStateOpening
        //增加点击事件
        if (self.tapGestureRecognizer == nil){
            
            self.tapGestureRecognizer  = UITapGestureRecognizer()
            self.tapGestureRecognizer.addTarget(self,action:"onTapGestureRecognized:");
        }
        self.centerController.view.addGestureRecognizer(self.tapGestureRecognizer)
    }
    
    /**
     *  菜单关闭
     */
    func didClose(){
        
        if (self.drawerState == ICSDrawerControllerState.MenuControllerStateOpening){
            
            self.drawerState = ICSDrawerControllerState.MenuControllerStateClosing
            self.centerController.view.removeGestureRecognizer(self.tapGestureRecognizer)
        }
        var c = self.centerController.view.frame
        var g = self.guideView.frame
        
        c.origin.x = 0
        g.origin.x = -self.drawerControllerDrawerDepth*2/3
        
        UIView.animateWithDuration(0.5,delay:0,usingSpringWithDamping:0.9,initialSpringVelocity:1.0,options:UIViewAnimationOptions.AllowUserInteraction,animations:{
            
            self.centerController.view.frame = c
            },completion: { (finished: Bool) -> Void in
        })
        UIView.animateWithDuration(0.5,delay:0,usingSpringWithDamping:1.0,initialSpringVelocity:1.0,options:UIViewAnimationOptions.AllowUserInteraction,animations:{
            
            self.guideView.frame = g
            },completion: { (finished: Bool) -> Void in
        })
    }
}
