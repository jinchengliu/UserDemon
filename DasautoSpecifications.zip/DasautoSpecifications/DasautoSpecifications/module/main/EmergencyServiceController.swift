/*
*  filename: EmergencyServiceController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/16.
*  copyright: bdcluster
*/

import UIKit

enum EmergencyServiceControllerState {
    case Normal
    case Search
}

class EmergencyServiceController: DasautoController, RATreeViewDelegate, RATreeViewDataSource, DasautoSearchControllerDelegate {
    
    @IBOutlet weak var treeView: RATreeView!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    
    var state: EmergencyServiceControllerState!
    var searchController: DasautoSearchController?
    var directory: DasAutoDirectory!
    
//    var zipPackage: ZipPackage?
    var nodes = NSMutableArray(capacity: 0)
    var filterFiles: NSArray?
    let fileId: Int = 6
    
    var isIndicatorLight = false
    var telephoneNumber = "4008201111"                // 大众服务热线
    var telephoneTitle = "400 820 1111"
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        self.isIndicatorLight = false
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("应急服务")
        self.addBackBarButtonItem()
        self.addRightNavigationItems()
        self.configureNodes()
        self.configureTreeView()
        
        self.state = EmergencyServiceControllerState.Normal
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置treeView
    */
    func configureTreeView() {
        
        self.treeView.delegate = self
        self.treeView.dataSource = self
        self.treeView.separatorStyle = RATreeViewCellSeparatorStyleNone
        self.treeView.showsHorizontalScrollIndicator = false
        self.treeView.reloadData()
    }
    
    // MARK:
    // MARK: Configure Files
    /*
    *  配置自定义方法
    *  parentNodes 包含了RADataObject对象的数组 即封装后的目录节点
    *  das 原始数据节点
    */
    func configureNodes() {
    
        for i in 0...3 {
            var dataName: String?
            switch i {
            case 0:
                dataName = "指示灯及警告灯"
            case 1:
                dataName = "常见问题及解决"
            case 2:
                dataName = "查找上海大众汽车经销商"
            case 3:
                dataName = "上海大众客户服务热线"
            default:
                dataName = ""
            }
            let data: RADataObject = RADataObject(name: dataName, describe: nil, resouceId: nil,fileId: nil, children: nil)
            self.nodes.addObject(data)
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中AR
     */
    override func onArBarButtonclicked() {
        
        super.onArBarButtonclicked()
    }
    
    /**
     *  选中搜索
     */
    override func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        
        super.onSearchBarButtonclicked(sender)
        if searchController == nil {
            searchController = DasautoSearchController(delegate: self)
            self.addChildViewController(searchController!)
            searchController!.view.frame.origin.y = -65
        }
        
        if self.state == EmergencyServiceControllerState.Normal {
            
            self.view.addSubview(searchController!.view)
            searchController!.view.frame.origin.y = -65
            self.topConstraint.constant = 65
            self.view.setNeedsUpdateConstraints()
            
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                self.searchController!.view.frame.origin.y = 0
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        self.state = EmergencyServiceControllerState.Search
                    }
            })
        }else {
            searchController?.setNormalState({ (finished) -> Void in
                if finished {
                    
                    self.searchController!.view.frame.origin.y = 0
                    self.topConstraint.constant = 0
                    self.view.setNeedsUpdateConstraints()
                    UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                        self.searchController!.view.frame.origin.y = -65
                        self.view.layoutIfNeeded()
                        }, completion: { (completetion) -> Void in
                            if completetion {
                                
                                self.state = EmergencyServiceControllerState.Normal
                                self.searchController?.clearSearchText()
                                self.searchController!.view.removeFromSuperview()
                            }
                    })
                }
            })
        }
    }

    // MARK:
    // MARK: CustomAlertViewDelegate
    override func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        
        super.onCustomAlertViewSureButtonAction(alertView)
        if alertView.tag == 2018 {
            UIApplication.sharedApplication().openURL(NSURL(string: "telprompt://" + telephoneNumber)!)
        }
    }
    
    // MARK: TreeViewDelegate
    func treeView(treeView: RATreeView!, heightForRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> CGFloat {
        
        return 44.0
    }
    
    func treeView(treeView: RATreeView!, indentationLevelForRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> Int {
        
        return 3 * treeNodeInfo.treeDepthLevel;
    }
    
    func treeView(treeView: RATreeView!, shouldItemBeExpandedAfterDataReload item: AnyObject!, treeDepthLevel: Int) -> Bool {
        
        return false
    }
    
    func treeView(treeView: RATreeView!, canEditRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> Bool {
        
        return false
    }
    
    func treeView(treeView: RATreeView!, willDisplayCell cell: UITableViewCell!, forItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) {
        
        if (treeNodeInfo.treeDepthLevel == 0) {
            
             cell.backgroundColor = UIColor(red: 250.0/255, green: 250.0/255, blue: 250.0/255, alpha: 1.0)
        } else if (treeNodeInfo.treeDepthLevel == 1) {
            
           cell.backgroundColor = UIColor(red: 223.0/255, green: 223.0/255, blue: 223.0/255, alpha: 1.0)
        } else if (treeNodeInfo.treeDepthLevel == 2) {
            
            cell.backgroundColor = UIColor(red: 223.0/255, green: 223.0/255, blue: 223.0/255, alpha: 1.0)
        }
    }
    
    func treeView(treeView: RATreeView!, cellForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) -> UITableViewCell! {
        
        let data = item as! RADataObject
        let nib = UINib(nibName: "TreeCell", bundle: nil)
        let cell: TreeCell = nib.instantiateWithOwner(nil, options: nil)[0] as! TreeCell
        cell.nameLabel.text = data.name
        
        return cell
    }
    
    func treeView(treeView: RATreeView!, numberOfChildrenOfItem item: AnyObject!) -> Int {
        
        if item == nil {
            
            return self.nodes.count
        }
        let data: RADataObject = item as! RADataObject
        
        return data.children == nil ? 0 : data.children.count
    }
    
    func treeView(treeView: RATreeView!, child index: Int, ofItem item: AnyObject!) -> AnyObject! {
        
        if item == nil {
            
            return self.nodes[index]
        }
        let data: RADataObject = item as! RADataObject
        return data.children[index]
    }
    
    func treeView(treeView: RATreeView!, didSelectRowForItem item: AnyObject!, treeNodeInfo: RATreeNodeInfo!) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let index: Int = self.nodes.indexOfObject(item)
        if index == 0 || index == 1 {
            let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
            if pkgFileManager.packages.count != 0{
                
                if pkgFileManager.rootFile != nil {
                    if index == 0 {
                        isIndicatorLight = true
                    }
                    self.performSegueWithIdentifier("EmergencyToHtmlSegue", sender: nil)
                }else {
                    for zip in pkgFileManager.packages {
                        if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
                            zipPackage = zip
                            self.showAlertView("车型包已下载完成,\n 请解析数据包", tag: 2215)
                            return
                        }
                    }
                    for zip in pkgFileManager.packages {
                        if zip.state == ZipPackageDownloadState.downloadPause {
                            self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                            return
                        }else if zip.state == ZipPackageDownloadState.downloading {
                            if DSDownloadManager.shareInstance().isStartOperation(zip.urlString) {
                                self.showRendView("正在下载中", isSuccess: false)
                            }else {
                                self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                            }
                            return
                        }
                    }
                }
            }else {
                self.showAlertView("尚无数据,\n 请先下载车型", tag: 2217)
            }
        }else if index == 2 {
            
            Car4sshopListManager.sharedInstance.removeSelectedProvice()
            let vc = Car4sshopListController()
            self.navigationController?.pushViewController(vc, animated: true)
        }else if index == 3 {
            
            let title =  "上海大众客户服务热线_" + "400 820 1111"
            let customAlertView = CustomAlertView(messageTitle: title, sureTitle: "phone", cancelTitle: "取消", delegate: self)
            customAlertView.tag = 2018
            customAlertView.show()
        }
    }
    
    // MARK:DasautoSearchControllerDelegate
    func dasautoSearchControllerDisappear() {
        
        if self.state == EmergencyServiceControllerState.Search {
            
            self.searchController!.view.frame.origin.y = 0
            self.topConstraint.constant = 0
            self.view.setNeedsUpdateConstraints()
            
            UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
                self.searchController!.view.frame.origin.y = -65
                self.view.layoutIfNeeded()
                }, completion: { (completetion) -> Void in
                    if completetion {
                        
                        self.state = EmergencyServiceControllerState.Normal
                        self.searchController!.view.removeFromSuperview()
                    }
            })
        }
    }
    
    func searchHandler(completion: (finished: Bool) -> Void) {
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            if SearchManager.sharedInstance.root.searchResult != nil {
                
                SearchManager.sharedInstance.root.searchResult.removeAll(keepCapacity: true)
            }
            self.filterFiles = SearchManager.sharedInstance.searchByKey(self.searchController!.searchTextField!.text!, fileId: self.fileId)
            completion(finished: true)
        }
    }
    
    func numberOfSections() -> Int {
        
        return 1
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        
        return (self.filterFiles != nil) ? self.filterFiles!.count : 0
    }
    
    func cellForIndexPath(tableView: UITableView, forIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "searchCell"
        var cell: SearchResultCell?
        cell = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? SearchResultCell
        if cell == nil {
            
            cell = SearchResultCell(style: .Default, reuseIdentifier: reusableIdentifier)
        }
        
        let dasautoFile: DasAutoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        cell?.nameLabel?.text = dasautoFile.name
        
        return cell!
    }
    
    func didSelectedCellAtIndexPath(indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let dasautoFile = self.filterFiles?.objectAtIndex(indexPath.row) as! DasAutoFile
        if dasautoFile.name == "指示灯及警告灯" {
            
            isIndicatorLight = true
        }else {
            
        }
        self.performSegueWithIdentifier("EmergencyToHtmlSegue", sender: nil)
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: sender)
        if segue.identifier == "EmergencyToHtmlSegue" {
            
            let vc = segue.destinationViewController as! HtmlDetaiController
            vc.listName = "应急服务"
            if self.filterFiles != nil {
                
                let indexPath: NSIndexPath = self.searchController!.searchResultTableView!.indexPathForSelectedRow!
                self.searchController?.searchResultTableView?.deselectRowAtIndexPath(indexPath, animated: false)
                let file = self.filterFiles!.objectAtIndex(indexPath.row) as! DasAutoFile
                vc.isIndicatorLight = isIndicatorLight
                vc.leaf = file
                
            }else {
                
                PackageFileManager.sharedInstance.rootFile.findFileWithFileId(6)
                let directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
                
                var dasAutoFileArray = directory.children as [DasAutoFile]
                if dasAutoFileArray.count != 0 {
                    
                    for var i = 0; i < dasAutoFileArray.count; i++ {
                        
                        let fileLeaf = dasAutoFileArray[i] as DasAutoFile
                        if fileLeaf.name == "指示灯及警告灯" {
                            
                            vc.leaf = fileLeaf
                            vc.isIndicatorLight = true
                        }
                    }
                }
            }
        }
    }
}
