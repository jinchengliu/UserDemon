//
//  WallpaperController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-1-30.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class WallpaperController: DasautoController ,UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var tableView: UITableView!
    
    var dataArray: [AnyObject]!
    var index: Int = -1
    
    // MARK: 
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("壁纸")
        self.addBackBarButtonItem()
        
        let pkgFileManager = PackageFileManager.sharedInstance
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            let documentDir = (DSFileManager.sharedInstance.getDownloadDirectory() as NSString).stringByAppendingPathComponent(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix )
            let path = (documentDir as NSString).stringByAppendingPathComponent("wallpaper")
            
            dataArray = NSFileManager.defaultManager().subpathsAtPath(path)
            if dataArray.count != 0 {
                
                if wallPaper != "-1" {
                    
                    self.index = Int(wallPaper)!
                }
                self.tableView.reloadData()
            }
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        if self.index != -1 {
            
            wallPaper = self.index.description
            NSUserDefaults.standardUserDefaults().setValue(self.index.description, forKey: "wallpaper")
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if dataArray == nil {
            
            return 0
        }else {
            
            if dataArray.count % 2 == 0 {
                
                return dataArray.count / 2
            }else {
                
                return dataArray.count / 2 + 1
            }
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let identifier = "wallPaperCell"
        var cell = tableView.dequeueReusableCellWithIdentifier(identifier) as? WallPaperCell
        if cell == nil {
            
            cell = WallPaperCell(style: UITableViewCellStyle.Default, reuseIdentifier: identifier)
        }
        cell?.selectionStyle = UITableViewCellSelectionStyle.None
        
        var nameOne: String!
        var nameSecond: String!
        if dataArray.count % 2 == 0 {
            
            nameOne = DSFileManager.sharedInstance.getWallPaperPath(dataArray[indexPath.row * 2] as! String)
            nameSecond =  DSFileManager.sharedInstance.getWallPaperPath(dataArray[indexPath.row * 2 + 1] as! String)
           cell?.configureImageView(nameOne, fileNameSecond: nameSecond)
        }else {
            
            
            if indexPath.row == dataArray.count / 2 {
                
                nameOne = DSFileManager.sharedInstance.getWallPaperPath(dataArray[indexPath.row + 1] as! String)
                cell?.configureImageViewOne(nameOne)
            }else {
                
                nameOne = DSFileManager.sharedInstance.getWallPaperPath(dataArray[indexPath.row] as! String)
                nameSecond =  DSFileManager.sharedInstance.getWallPaperPath(dataArray[indexPath.row + 1] as! String)
                cell?.configureImageView(nameOne, fileNameSecond: nameSecond)
            }
        }
        
        if cell?.hasCheckImageView == true {
            
            cell?.checkImageView.removeFromSuperview()
            cell?.hasCheckImageView = false
        }
        cell?.wallPaperClosure = { () in
            
            self.indexOfcheckImageView()
        }
        
        if self.index != -1 {
            
            if self.index / 2 == indexPath.row {
                
                if self.index % 2 == 0 {
                    
                    cell?.selectFirstImage()
                }else {
                    
                    cell?.selectSecondImage()
                }
            }
        }
        
        return cell!
    }
    
    func checkImageViewDisappear() {
        
        let cellArray = self.tableView.visibleCells
        for cell in cellArray {
            
            if  (cell as! WallPaperCell).hasCheckImageView == true {
                
                (cell as! WallPaperCell).checkImageView.removeFromSuperview()
                (cell as! WallPaperCell).hasCheckImageView = false
            }
        }
    }
    
    func indexOfcheckImageView() {
        
        var cellArray = self.tableView.visibleCells
        for var i = 0; i < cellArray.count; i++ {
            
            let cell = cellArray[i] as! WallPaperCell
            if cell.selected == true {
                
                self.index = i * 2 + cell.index
                cell.selected = false
            }
        }
        self.tableView.reloadData()
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        let w = (UIScreen.mainScreen().bounds.size.width/2)
        let h = (UIScreen.mainScreen().bounds.size.width/2)*43.0/64.0
        Logger.info("wid: \(w)")
        Logger.info("hei: \(h)")
        return (UIScreen.mainScreen().bounds.size.width/2)*43.0/64.0
    }
    
}
