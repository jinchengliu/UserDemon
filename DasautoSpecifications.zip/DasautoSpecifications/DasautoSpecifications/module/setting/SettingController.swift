/*
*  filename: SettingController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/1.
*  copyright: bdcluster
*/

import UIKit

class SettingController: DasautoController {

    var delegate: GuideMenuDelegate?
    
    @IBOutlet weak var soundEffectView: UIView!
    @IBOutlet weak var soundSwitch: UISwitch!
    @IBOutlet weak var softwareUpdateView: UIView! // hidden = YES 约束height = 0
    @IBOutlet weak var clearCacheView: UIView!
    @IBOutlet weak var lawerView: UIView!
    @IBOutlet weak var disclaimerView: UIView!
    @IBOutlet weak var skinView: UIView!
    @IBOutlet weak var fontSizeView: UIView!
    
    @IBOutlet weak var updateArrowImageView: UIImageView!
    @IBOutlet weak var clearLabel: UILabel!
    @IBOutlet weak var lawImageView: UIImageView!
    @IBOutlet weak var discamlerImageView: UIImageView!
    @IBOutlet weak var skinImageView: UIImageView!
    @IBOutlet weak var fontSizeImageView: UIImageView!
    
    var a = UIButton(type: UIButtonType.System)
    var b = UIButton(type: UIButtonType.System)
    var c = UIButton(type: UIButtonType.System)
    var currentScreenBounds = UIScreen.mainScreen().bounds
    
    var actionSheetView = UIView()
    var customAlertView: UIView!
    var buttonHeight: CGFloat = 44
    var xFloat: CGFloat = 10
    
    var videoSize: CGFloat!
    var cachSize: CGFloat!
    var isLaw: Bool!

    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.addTapGestures()
        cachSize = SystemConfigureManager.sharedInstance.getCacheSize()
        videoSize = SystemConfigureManager.sharedInstance.getVideoSize()
        let size = (cachSize + videoSize).description
        clearLabel.text = size + "MB"
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.configureImageViewsImage()
        self.addBackBarButtonItem()
        var tintColor: UIColor!
        if themeColor == "_red" {
            
            tintColor = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }else if themeColor == "_blue" {
            
            tintColor = UIColor(red: 0, green: 0.56, blue: 0.84, alpha: 1.0)
        }else {
            
            tintColor = UIColor(red: 0.82, green: 0.67, blue: 0.5, alpha: 1.0)
        }
        soundSwitch.onTintColor = tintColor
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  清除成功视图
    */
    func configureClearSuccessAlertView() {
        
        customAlertView = UIView(frame: CGRectMake(0, 0, 125, 125))
        customAlertView.backgroundColor = UIColor.darkGrayColor()
        customAlertView.layer.cornerRadius = 10
        customAlertView.layer.masksToBounds = true
        self.navigationController!.view.addSubview(self.customAlertView)
        customAlertView.center = self.navigationController!.view.center
        
        let circleImageView = UIImageView(frame: CGRectMake(45, 25, 35, 35))
        circleImageView.image = UIImage(named: "roundCircle" + themeColor)
        customAlertView.addSubview(circleImageView)
        
        let semiCircleImageView = UIImageView(frame: CGRectMake(0, 0, 35, 35))
        semiCircleImageView.image = UIImage(named: "semicircle" + themeColor)
        circleImageView.addSubview(semiCircleImageView)
        
        let label = UILabel(frame: CGRectMake(20, 75, 85, 22))
        label.textAlignment = NSTextAlignment.Center
        label.textColor = UIColor.whiteColor()
        label.text = "清除成功"
        customAlertView.addSubview(label)
        
        UIView.animateWithDuration(1.2, animations: { () -> Void in
            
            self.customAlertView.alpha = 0.0
            }, completion: { (complete) -> Void in
                
                self.customAlertView.removeFromSuperview()
        })
    }
    
    /**
    *  actionSheet
    */
    func configureCustomActionSheet() {
        
        actionSheetView.frame = self.navigationController!.view.bounds
        actionSheetView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onActionSheetViewTapGesture:"))
        actionSheetView.backgroundColor = UIColor.grayColor()
        actionSheetView.alpha = 0.6
        self.navigationController!.view.addSubview(actionSheetView)
        
        self.a.frame = CGRectMake(xFloat, self.currentScreenBounds.height, self.currentScreenBounds.width - xFloat * 2, buttonHeight)
        self.a.setTitle("清空消息列表", forState: UIControlState.Normal)
        self.a.setTitleColor(color, forState: UIControlState.Normal)
        self.a.titleLabel!.font = UIFont.systemFontOfSize(17)
        self.a.backgroundColor = UIColor.whiteColor()
        self.a.addTarget(self, action: Selector("onCustomActionSheetButtonsClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        a.tag = 2020
        self.navigationController!.view.addSubview(self.a)
        
        self.b.frame = CGRectMake(xFloat, self.currentScreenBounds.height + buttonHeight + 1, self.currentScreenBounds.width - xFloat * 2, buttonHeight)
        self.b.setTitle("清空缓存视频", forState: UIControlState.Normal)
        self.b.setTitleColor(color, forState: UIControlState.Normal)
        self.b.titleLabel!.font = UIFont.systemFontOfSize(17)
        self.b.addTarget(self, action: Selector("onCustomActionSheetButtonsClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.b.backgroundColor = UIColor.whiteColor()
        b.tag = 2021
        self.navigationController!.view.addSubview(self.b)
        
        self.c.frame = CGRectMake(xFloat, self.currentScreenBounds.height + buttonHeight * 2 + 11, self.currentScreenBounds.width - xFloat * 2, buttonHeight)
        self.c.setTitleColor(color, forState: UIControlState.Normal)
        self.c.setTitle("取消", forState: UIControlState.Normal)
        self.c.titleLabel!.font = UIFont.systemFontOfSize(17)
        self.c.addTarget(self, action: Selector("onCustomActionSheetButtonsClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.c.backgroundColor = UIColor.whiteColor()
        c.tag = 2022
        self.navigationController!.view.addSubview(self.c)
        
        UIView.animateWithDuration(0.3) { () -> Void in
            
            self.a.frame = CGRectMake(self.xFloat, self.currentScreenBounds.height - self.buttonHeight * 3 - 31, self.currentScreenBounds.width - self.xFloat * 2, self.buttonHeight)
            self.b.frame = CGRectMake(self.xFloat, self.currentScreenBounds.height - self.buttonHeight * 2 - 30, self.currentScreenBounds.width - self.xFloat * 2, self.buttonHeight)
            self.c.frame = CGRectMake(self.xFloat, self.currentScreenBounds.height - self.buttonHeight - 20, self.currentScreenBounds.width - self.xFloat * 2, self.buttonHeight)
        }
    }
    
    /**
     *  alertsheet消失
     */
    func buttonDisappear(animated: Bool) {
        
        if animated {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                
                self.a.frame = CGRectMake(self.xFloat, self.currentScreenBounds.height, self.currentScreenBounds.width - self.xFloat * 2, self.buttonHeight)
                self.b.frame = CGRectMake(self.xFloat, self.currentScreenBounds.height + self.buttonHeight + 1, self.currentScreenBounds.width - self.xFloat * 2, self.buttonHeight)
                self.c.frame = CGRectMake(self.xFloat, self.currentScreenBounds.height + self.buttonHeight * 2 + 11, self.currentScreenBounds.width - self.xFloat * 2, self.buttonHeight)
                }) { (complete) -> Void in
                    
                    self.a.removeFromSuperview()
                    self.b.removeFromSuperview()
                    self.c.removeFromSuperview()
                    self.actionSheetView.removeFromSuperview()
            }
        }else {
            
            self.a.removeFromSuperview()
            self.b.removeFromSuperview()
            self.c.removeFromSuperview()
            self.actionSheetView.removeFromSuperview()
        }
    }
    
    /**
     *  show AletView
     */
    func showAlertViewWithTitle(title: String) {
        
        let customAlertView = CustomAlertView(messageTitle: title, sureTitle: "确定", cancelTitle: "取消", delegate: self)
        customAlertView.show()
    }
    
    /**
     *  configure Image
     */
    func configureImageViewsImage() {
        
        let image = UIImage(named: "rightArrow" + themeColor)
        updateArrowImageView.image = image
        lawImageView.image = image
        discamlerImageView.image = image
        skinImageView.image = image
        fontSizeImageView.image = image
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
        self.delegate?.didCloseGuideMenu!()
    }
    
    /**
    *  点击自定义actionSheet按钮的响应事件
    */
    func onCustomActionSheetButtonsClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if sender.tag == 2020 {
            
            self.buttonDisappear(false)
            self.showAlertViewWithTitle("确认删除消息列表?")
        }else if sender.tag == 2021 {
            
            self.buttonDisappear(false)
            self.showAlertViewWithTitle("确认删除缓存视频?")
        }else {
            
            self.buttonDisappear(true)
        }
    }
    
    // MARK: UITapGestureRecognizer
    /**
    *  添加手势
    */
    func addTapGestures() {
        
        let clearCacheTap = UITapGestureRecognizer(target: self, action: Selector("onClearCacheData"))
        let lawerTap = UITapGestureRecognizer(target: self, action: Selector("onMakeLawText"))
        let discamlerTap = UITapGestureRecognizer(target: self, action: Selector("onMakeDiscamlerText"))
        let skinTap = UITapGestureRecognizer(target: self, action: Selector("onChangeSkin"))
        let fontSizeTap = UITapGestureRecognizer(target: self, action: Selector("onMakeSelectFontSize"))
        
        clearCacheView.addGestureRecognizer(clearCacheTap)
        lawerView.addGestureRecognizer(lawerTap)
        disclaimerView.addGestureRecognizer(discamlerTap)
        skinView.addGestureRecognizer(skinTap)
        fontSizeView.addGestureRecognizer(fontSizeTap)
        
        soundSwitch.addTarget(self, action: Selector("onSwitchValueChange:"), forControlEvents: UIControlEvents.ValueChanged)
        soundSwitch.setOn(SystemConfigureManager.sharedInstance.querySoundEffectSwitch(), animated: false)
    }
    
    /**
     *  点击 软件更新
     */
    func onUpdateSoftware() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("ToSoftUpdateSegue", sender: nil)
    }
    
    /**
    *  点击 清理内存
    */
    func onClearCacheData() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if clearLabel.text == "0MB" || clearLabel.text == "0.0MB" {
            
            self.showRendView("没有缓存可以清除", isSuccess: false)
        }else {
            
            self.configureCustomActionSheet()
        }
    }
    
    /**
     *  点击 法律声明
     */
    func onMakeLawText() {
        
        self.isLaw = true
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("LawSegue", sender: nil)
    }
    
    /**
     *  点击 免责声明
     */
    func onMakeDiscamlerText() {
        
        self.isLaw = false
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("LawSegue", sender: nil)
    }
    
    /**
     *  点击 背景选择
     */
    func onChangeSkin() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("SkinSegue", sender: nil)
    }
    
    /**
     *  点击 字体大小
     */
    func onMakeSelectFontSize() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("ToFontSizeSegue", sender: nil)
    }
    
    /**
     *  点击 声音/音效
     */
    func onSwitchValueChange(sender: UISwitch) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let switchobj = sender as UISwitch
        Logger.info("\(switchobj.on)")
        SystemConfigureManager.sharedInstance.setSoundEffectSwitch(switchobj.on)
    }
    
    /**
    *  点击自定义actionSheet的手势
    */
    func onActionSheetViewTapGesture(tapGesture: UITapGestureRecognizer) {
        
        self.buttonDisappear(true)
    }
    
    // MARK:
    // MARK: CustomAlertViewDelegate
    override func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        
        if alertView.messageTitle == "确认删除消息列表?" {
            
            cachSize = 0
            self.clearLabel.text = videoSize.description + "MB"
            SystemConfigureManager.sharedInstance.clearCache()
        }else {
            
            videoSize = 0
            self.clearLabel.text = cachSize.description + "MB"
            SystemConfigureManager.sharedInstance.clearVideo()
        }
        self.configureClearSuccessAlertView()
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: sender)
        if segue.identifier == "LawSegue" {
            
            let lawController: LawController = segue.destinationViewController as! LawController
            lawController.isLaw = self.isLaw
        }
    }
}
