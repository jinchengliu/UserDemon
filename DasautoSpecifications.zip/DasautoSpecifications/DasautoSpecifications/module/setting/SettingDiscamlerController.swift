
//
//  SettingDiscamlerController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-4-14.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class SettingDiscamlerController: DasautoController {

    var scrollView: UIScrollView!
    var boardButton: UIButton!
    var continueButton: UIButton!
    var checkImageView: UIImageView!
    
    var isIncludeVideo: String!             // 是否包含视频
    var carType: String!                    // 车型
    var carYear: String!                    // 年款
    
    var hasDownload = false
    var picUrl: String!                     // picUrl
    var isAgree: Bool!
    var isLaw: Bool!
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        if hasDownload == true {
            
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        self.addBackBarButtonItem()
        self.addLogoTitleView()
/*
        self.configureScrollView()
        self.configureDiscamlerLabel()
        if isAgree == true {
        
            self.addContinueBarButtonItem()
        }
*/
        self.configureDiscamlerLabel()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  configure ScrollView
    */
    func configureScrollView() {
        
        scrollView = UIScrollView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds)))
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.backgroundColor = UIColor.whiteColor()
        scrollView.bounces = false
        self.view.addSubview(scrollView)
        if CGRectGetHeight(self.view.bounds) < 500 {
            
            scrollView.contentSize = CGSizeMake(0, CGRectGetHeight(self.view.bounds) + 88)
        }
    }
    
    /**
    *  配置label和button
    */
    func configureDiscamlerLabel() {
        
        let w = CGRectGetWidth(self.view.bounds)
        let h = CGRectGetHeight(self.view.bounds)
        let imageView = UIImageView(frame: CGRectMake(0, 0, w, h - 60 - 64))
        imageView.image = UIImage(named: "discamlerImage")
        self.view.addSubview(imageView)
        
        boardButton = UIButton(frame: CGRectMake(4, h-156, 42, 40))
        boardButton.setImage(UIImage(named: "board"), forState: UIControlState.Normal)
        boardButton.setImage(UIImage(named: "boardOn"), forState: UIControlState.Selected)
        boardButton.imageEdgeInsets = UIEdgeInsetsMake(14, 14, 11, 13)
        boardButton.addTarget(self, action: "onBoardButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(boardButton)
        
        let readLabel = UILabel(frame: CGRectMake(46, h-150, 42, 30))
        readLabel.font = UIFont.systemFontOfSize(14)
        readLabel.textAlignment = NSTextAlignment.Center
        readLabel.textColor = UIColor.darkTextColor()
        readLabel.text = "已阅读"
        self.view.addSubview(readLabel)
        
        let discamlerButton = UIButton(frame: CGRectMake(90, h-150, 90, 30))
        discamlerButton.setTitle("《免责声明》", forState: UIControlState.Normal)
        discamlerButton.titleLabel?.font = UIFont.systemFontOfSize(15)
        discamlerButton.setTitleColor(UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0), forState: UIControlState.Normal)
        discamlerButton.addTarget(self, action: "onDiscamlerButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(discamlerButton)
        
        let agreeLabel = UILabel(frame: CGRectMake(180, h-150, 42, 30))
        agreeLabel.font = UIFont.systemFontOfSize(14)
        agreeLabel.textAlignment = NSTextAlignment.Center
        agreeLabel.textColor = UIColor.darkTextColor()
        agreeLabel.text = "并同意"
        self.view.addSubview(agreeLabel)
        
        let lawButton = UIButton(frame: CGRectMake(222, h-150, 90, 30))
        lawButton.titleLabel?.font = UIFont.systemFontOfSize(15)
        lawButton.setTitle("《法律声明》", forState: UIControlState.Normal)
        lawButton.setTitleColor(UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0), forState: UIControlState.Normal)
        lawButton.addTarget(self, action: "onLawButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(lawButton)
        
        continueButton = UIButton(type: UIButtonType.System)
        continueButton.frame = CGRectMake(14, h - 64 - 50, w - 27, 46)
        continueButton.titleLabel?.font = UIFont.systemFontOfSize(15)
        continueButton.setTitle("继续", forState: UIControlState.Normal)
        continueButton.setBackgroundImage(UIImage(named: "submitButton"), forState: UIControlState.Normal)
        continueButton.addTarget(self, action: "onContinueButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        continueButton.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
        self.view.addSubview(continueButton)
        
    }
    
    /**
    *  添加继续按钮
    */
    func addContinueBarButtonItem() {
        
        let continueBarButtonItem = UIBarButtonItem()
        continueButton = UIButton(frame: CGRectMake(0, 0, 45, 45))
        continueButton.setTitle("继续", forState: UIControlState.Normal)
        continueButton.setTitleColor(color, forState: UIControlState.Normal)
        continueButton.addTarget(self, action: "onContinueButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        
        continueBarButtonItem.customView = continueButton
        self.navigationItem.rightBarButtonItem = continueBarButtonItem
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中继续
    */
    func onContinueButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if boardButton.selected == true {
            
            if kUserId == "noLogin" {
                
                self.performSegueWithIdentifier("DiscamLerToAboutSegue", sender: nil)
            }else {
                
                if AFNetworkReachabilityManager.sharedManager().reachable == true {
                    
                    if hasDownload == false {
                        
                        self.offLineDownloadCarZip()
                        hasDownload = true
                    }
                }else {
                    
                    self.showRendView("当前网络不可用", isSuccess: false)
                }
            }
        }else {
            
            self.showRendView("请同意", isSuccess: false)
        }
    }
    
    /**
     *  选中同意方框
     */
    func onBoardButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if sender.selected  == true {
            
            continueButton.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
        }else {
            
            continueButton.setTitleColor(UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0), forState: UIControlState.Normal)
        }
        sender.selected = !sender.selected
    }
    
    /**
     *  选中免责声明
     */
    func onDiscamlerButtonClicked(sender: UIButton) {
        
        self.isLaw = false
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("DiscamlerToLawSegue", sender: nil)
    }
    
    /**
     *  选中法律声明
     */
    func onLawButtonClicked(sender: UIButton) {
        
        self.isLaw = true
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("DiscamlerToLawSegue", sender: nil)
    }
    
    /**
    *  选中同意
    */
    func onAgreeButtonClicked() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if isAgree == true {
            
            continueButton.userInteractionEnabled = false
            continueButton.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
            checkImageView.image = UIImage(named: "")
        }else {
            
            continueButton.userInteractionEnabled = true
            continueButton.setTitleColor(color, forState: UIControlState.Normal)
            checkImageView.image = UIImage(named: "check" + themeColor)
        }
        isAgree = !isAgree
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  下载车型zip包
    */
    func offLineDownloadCarZip() {
        
        let downloadManagerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as! DownloadManagerController
        downloadManagerVC.hasSelectCarTypeController = false
        downloadManagerVC.downloadVideo(carType, carYear: carYear, isIncludeVideo: isIncludeVideo,picUrl:self.picUrl)
        
        self.navigationController?.pushViewController(downloadManagerVC, animated: true)
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: sender)
        if segue.identifier == "DiscamLerToAboutSegue" {
            
            let aboutController: AboutController = segue.destinationViewController as! AboutController
            aboutController.pushToControllerName = "DownloadController"
            aboutController.isIncludeVideo = self.isIncludeVideo
            aboutController.hasRightBarButtonItem = true
            aboutController.carType = self.carType
            aboutController.carYear = self.carYear
            aboutController.picUrl = self.picUrl
            aboutController.whetherToDownLoad = "true"
        }else if segue.identifier == "DiscamlerToLawSegue" {
            
            let lawController: LawController = segue.destinationViewController as! LawController
            lawController.isLaw = self.isLaw
        }
    }
}
