//
//  SkinController.swift
//  DasautoSpecifications
//
//  Created by chenpan on 14/12/29.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class SkinController: DasautoController {

    
    @IBOutlet weak var wallPaperImageView: UIImageView!
    @IBOutlet weak var blueButton: UIButton!
    @IBOutlet weak var champagneButton: UIButton!
    @IBOutlet weak var redButton: UIButton!
    @IBOutlet weak var selectWallpaperView: UIView!
    @IBOutlet weak var rightImageView: UIImageView!
    
    @IBOutlet weak var heightBlueConstraint: NSLayoutConstraint!
    @IBOutlet weak var verticalBlueConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomBlueConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var heightChampagnConstraint: NSLayoutConstraint!
    @IBOutlet weak var verticalChampagnConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomChampagnConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var heightRedConstraint: NSLayoutConstraint!
    @IBOutlet weak var verticalRedConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomRedConstraint: NSLayoutConstraint!
    
    var colorHeight: CGFloat = 23
    var colorVertical: CGFloat = 13
    var colorBottom: CGFloat = 11
    var colorChange: CGFloat = 5
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        let pkgFileManager = PackageFileManager.sharedInstance
        if pkgFileManager.packages.count != 0 && pkgFileManager.rootFile != nil {
            
            let documentDir = (DSFileManager.sharedInstance.getDownloadDirectory() as NSString).stringByAppendingPathComponent(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix )
            let path = (documentDir as NSString).stringByAppendingPathComponent("wallpaper")
            
            var dataArray: [AnyObject]! = NSFileManager.defaultManager().subpathsAtPath(path)
            if dataArray.count != 0 {
                
                if wallPaper != "-1" {
                    
                    let path = DSFileManager.sharedInstance.getWallPaperPath(dataArray[Int(wallPaper)!] as! String)
                    wallPaperImageView.image = UIImage(contentsOfFile: path)!
                }
            }
        }
        
        Logger.info("frame\(wallPaperImageView.frame)")
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.configureTitle("背景选择")
        self.addBackBarButtonItem()
        self.configureSkinButton()
    }
    
    override func didReceiveMemoryWarning() {

        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  configureSkinButton
    */
    func configureSkinButton() {
        
        if themeColor == "_red" {
            
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightRedConstraint.constant = self.colorHeight + self.colorChange * 2
                self.verticalRedConstraint.constant = self.colorVertical - self.colorChange
                self.bottomRedConstraint.constant = self.colorBottom - self.colorChange
            })
            redButton.selected = true
        }else if themeColor == "_blue" {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightBlueConstraint.constant = self.colorHeight + self.colorChange * 2
                self.verticalBlueConstraint.constant = self.colorVertical - self.colorChange
                self.bottomBlueConstraint.constant = self.colorBottom - self.colorChange
            })
            blueButton.selected = true
        }else {
           
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightChampagnConstraint.constant = self.colorHeight + self.colorChange * 2
                self.verticalChampagnConstraint.constant = self.colorVertical - self.colorChange
                self.bottomChampagnConstraint.constant = self.colorBottom - self.colorChange
            })
            champagneButton.selected = true
        }
        blueButton.addTarget(self, action: #selector(SkinController.onSelectSkinColor(_:)), forControlEvents: UIControlEvents.TouchUpInside)
        champagneButton.addTarget(self, action: #selector(SkinController.onSelectSkinColor(_:)), forControlEvents: UIControlEvents.TouchUpInside)
        redButton.addTarget(self, action: #selector(SkinController.onSelectSkinColor(_:)), forControlEvents: UIControlEvents.TouchUpInside)
        
        let selectWallpaperTap = UITapGestureRecognizer(target: self, action: #selector(SkinController.onSelectWallpaper))
        self.selectWallpaperView.addGestureRecognizer(selectWallpaperTap)
        rightImageView.image = UIImage(named: "rightArrow" + themeColor)
    }
    
    // MARK: 
    // MARK:Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中界面色调
     */
    func onSelectSkinColor(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        switch sender.tag {
        case 100:
            if sender.selected == false {
                
                self.didSelectedButton(true, isChampagn: false, isRed: false)
            }
        case 101:
            if sender.selected == false {
                
                self.didSelectedButton(false, isChampagn: true, isRed: false)
            }
        case 102:
            if sender.selected == false {
                
                self.didSelectedButton(false, isChampagn: false, isRed: true)
            }
        default :
            break
        }
    }
    
    /**
     *  选中界面颜色
     */
    func didSelectedButton(isBlue:Bool ,isChampagn: Bool, isRed: Bool) {
        
        blueButton.selected = isBlue
        champagneButton.selected = isChampagn
        redButton.selected = isRed
        if themeColor == "_blue" {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightBlueConstraint.constant = self.colorHeight
                self.verticalBlueConstraint.constant = self.colorVertical
                self.bottomBlueConstraint.constant = self.colorBottom
            })
        }else if themeColor == "_champagne" {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightChampagnConstraint.constant = self.colorHeight
                self.verticalChampagnConstraint.constant = self.colorVertical
                self.bottomChampagnConstraint.constant = self.colorBottom
            })
        }else {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightRedConstraint.constant = self.colorHeight
                self.verticalRedConstraint.constant = self.colorVertical
                self.bottomRedConstraint.constant = self.colorBottom
            })
        }
        
        if isBlue == true {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightBlueConstraint.constant = self.colorHeight + self.colorChange * 2
                self.verticalBlueConstraint.constant = self.colorVertical - self.colorChange
                self.bottomBlueConstraint.constant = self.colorBottom - self.colorChange
            })
            themeColor = "_blue"
        }else if isChampagn == true {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightChampagnConstraint.constant = self.colorHeight + self.colorChange * 2
                self.verticalChampagnConstraint.constant = self.colorVertical - self.colorChange
                self.bottomChampagnConstraint.constant = self.colorBottom - self.colorChange
            })
            themeColor = "_champagne"
        }else {
            
            UIView.animateWithDuration(1.0, animations: { () -> Void in
                
                self.heightRedConstraint.constant = self.colorHeight + self.colorChange * 2
                self.verticalRedConstraint.constant = self.colorVertical - self.colorChange
                self.bottomRedConstraint.constant = self.colorBottom - self.colorChange
            })
            themeColor = "_red"
        }
        self.addBackBarButtonItem()
        rightImageView.image = UIImage(named: "rightArrow" + themeColor)
        NSUserDefaults.standardUserDefaults().setObject(themeColor, forKey: "themeColor")
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    /**
    *  选中壁纸
    */
    func onSelectWallpaper() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let manager = PackageFileManager.sharedInstance
        if manager.packages.count != 0 && manager.rootFile != nil {
            
            self.performSegueWithIdentifier("WallpaperSegue", sender: nil)
        }else {
            
            self.showRendView("请选择车型", isSuccess: false)
        }
    }
}
