//
//  SoftUpdateController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-4-14.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class SoftUpdateController: DasautoController {

    var versionLabel: UILabel!
    
    // MARK: 
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        /*
        已经弃用
        */
        self.configureTitle("软件更新")
        self.addBackBarButtonItem()
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            self.appVersionCheck()
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }
        self.configureVersionLabel()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK: Configure
    /**
    *  配置versionLabel
    */
    func configureVersionLabel() {
        
        versionLabel = UILabel(frame: CGRectMake(20, 10, CGRectGetWidth(self.view.frame) - 20 * 2, 80))
        versionLabel.text = "您的软件版本号是V 1.0.0\n已经是最新的版本!"
        versionLabel.textColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        versionLabel.font = UIFont.systemFontOfSize(17)
        versionLabel.textAlignment = NSTextAlignment.Center
        versionLabel.numberOfLines = 0
        self.view.addSubview(versionLabel)
    }
    
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: Load Data
    /**
    *  请求数据
    */
    func appVersionCheck() {
        
        let dict: NSDictionary = ["appId": "s", "currentVersion":"1.0", "platformType":1]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kAppVersionCheck, param: dict,withToken:false, success: { (operation, responseObject) -> Void in
            
            let mutableDic: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                
                let respCode = mutableDic?.objectForKey("respCode") as! String
                if respCode == "000000" {
                    
                }
            }
        }) { (operation, error) -> Void in
            
            Logger.info("请求错误\(error)")
        }
    }
}
