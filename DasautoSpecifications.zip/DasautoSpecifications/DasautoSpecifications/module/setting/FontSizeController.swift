//
//  FontSizeController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-4-14.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class FontSizeController: DasautoController {

    @IBOutlet weak var smallSizeView: UIView!
    @IBOutlet weak var middleSizeView: UIView!
    @IBOutlet weak var largeSizeView: UIView!
    
    @IBOutlet weak var smallImageView: UIImageView!
    @IBOutlet weak var middleImageView: UIImageView!
    @IBOutlet weak var largeImageView: UIImageView!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        self.configureTitle("字体大小")
        self.addBackBarButtonItem()
        
        self.addTapGestures()
        self.setImages(kHtmlFontSize, isSelected: false)
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    func setImages(size: String, isSelected: Bool) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if size == "'80%'" {
            
            smallImageView.image = UIImage(named: "check" + themeColor)
            smallImageView.hidden = false
            middleImageView.hidden = true
            largeImageView.hidden = true
        }else if size == "'100%'" {
            
            smallImageView.hidden = true
            middleImageView.image = UIImage(named: "check" + themeColor)
            middleImageView.hidden = false
            largeImageView.hidden = true
        }else if size == "'120%'"{
            
            smallImageView.hidden = true
            middleImageView.hidden = true
            largeImageView.hidden = false
            largeImageView.image = UIImage(named: "check" + themeColor)
        }
        
        if isSelected == true {
            
            kHtmlFontSize = size
            NSUserDefaults.standardUserDefaults().setObject(kHtmlFontSize, forKey: "fontSize")
            NSUserDefaults.standardUserDefaults().synchronize()
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: 
    // MARK: UITapGesture
    /**
    *  添加tapGesture
    */
    func addTapGestures() {
        
        let smallTap = UITapGestureRecognizer(target: self, action: "onSmallSizeViewTapGesture")
        let middleTap = UITapGestureRecognizer(target: self, action: "onMiddleSizeViewTapGesture")
        let largeTap = UITapGestureRecognizer(target: self, action: "onLargeSizeViewTapGesture")
        smallSizeView.addGestureRecognizer(smallTap)
        middleSizeView.addGestureRecognizer(middleTap)
        largeSizeView.addGestureRecognizer(largeTap)
    }
    
    /**
     *  点击小字体
     */
    func onSmallSizeViewTapGesture() {
        
        self.setImages("'80%'", isSelected: true)
    }
    
    /**
     *  点击中字体
     */
    func onMiddleSizeViewTapGesture() {
        
        self.setImages("'100%'", isSelected: true)
    }
    
    /**
     *  点击大字体
     */
    func onLargeSizeViewTapGesture() {
        
        self.setImages("'120%'", isSelected: true)
    }
}
