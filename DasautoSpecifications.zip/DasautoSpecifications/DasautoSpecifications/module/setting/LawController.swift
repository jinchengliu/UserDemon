//
//  LawController.swift
//  DasautoSpecifications
//
//  Created by chenpan on 14/12/29.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class LawController: DasautoController ,UIWebViewDelegate{

    var webView: UIWebView!
    var isLaw: Bool!
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        self.view.backgroundColor = UIColor.whiteColor()
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        
        if isLaw == true {
            
            self.configureTitle("法律声明")
            self.configureWebView()
        }else {
            
            self.configureTitle("免责声明")
            self.configureDiscamlerLabel()
        }
    }

    override func didReceiveMemoryWarning() {

        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  法律声明页
    */
    func configureWebView() {
        
        webView = UIWebView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds) - 64))
        self.view.addSubview(webView)
        webView.delegate = self
        let str = NSBundle.mainBundle().pathForResource("3", ofType: "html")
        let request = NSURLRequest(URL: NSURL(string: str!)!)
        self.webView.loadRequest(request)
    }
    
    /**
     *  免责声明页
     */
    func configureDiscamlerLabel() {
        
        let dotImageViewOne = UIImageView(frame: CGRectMake(20, 25, 4, 4))
        dotImageViewOne.image = UIImage(named: "dot" + themeColor)
        self.view.addSubview(dotImageViewOne)
        let discamlerLabelOne = UILabel(frame: CGRectMake(34, 15, CGRectGetWidth(self.view.frame) - 20 - 34, 54))
        discamlerLabelOne.text = "请在您的车辆处于静止状态且不妨碍交通的情况下使用本应用程序，请勿在驾驶时使用手机！！"
        discamlerLabelOne.textColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        discamlerLabelOne.font = UIFont.systemFontOfSize(15)
        discamlerLabelOne.numberOfLines = 0
        discamlerLabelOne.sizeToFit()
        self.view.addSubview(discamlerLabelOne)
        
        let dotImageViewTwo = UIImageView(frame: CGRectMake(20, 83, 4, 4))
        dotImageViewTwo.image = UIImage(named: "dot" + themeColor)
        self.view.addSubview(dotImageViewTwo)
        let discamlerLabelTwo = UILabel(frame: CGRectMake(34, 75, CGRectGetWidth(self.view.frame) - 20 - 34, 54))
        discamlerLabelTwo.text = "请注意，本应用程序中的某些功能需要启用手机数据连接，可能导致您需要向移动数据供应商支付费用。"
        discamlerLabelTwo.textColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        discamlerLabelTwo.font = UIFont.systemFontOfSize(15)
        discamlerLabelTwo.numberOfLines = 0
        discamlerLabelTwo.sizeToFit()
        self.view.addSubview(discamlerLabelTwo)
        
        let dotImageViewThree = UIImageView(frame: CGRectMake(20, 142, 4, 4))
        dotImageViewThree.image = UIImage(named: "dot" + themeColor)
        self.view.addSubview(dotImageViewThree)
        let discamlerLabelThree = UILabel(frame: CGRectMake(34, 135, CGRectGetWidth(self.view.frame) - 20 - 34, 165))
        discamlerLabelThree.text = "本应用程序中有关车辆设计、技术数据以及图示等信息不具有法律约束力。因汽车及其配置处于不断的改进和后续开发之中，相关内容如有变动，请以实车配置为准，恕不另行通知。同时，在任何情况下，本应用程序都不能取代随车所附之印刷版使用维护说明书，本应用程序仅供方便用户快速查阅和了解上海大众汽车车辆使用维护相关信息之用。"
        discamlerLabelThree.textColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        discamlerLabelThree.font = UIFont.systemFontOfSize(15)
        discamlerLabelThree.numberOfLines = 0
        discamlerLabelThree.sizeToFit()
        self.view.addSubview(discamlerLabelThree)
        
        let dotImageViewFour = UIImageView(frame: CGRectMake(20, 312, 4, 4))
        dotImageViewFour.image = UIImage(named: "dot" + themeColor)
        self.view.addSubview(dotImageViewFour)
        let discamlerLabelFour = UILabel(frame: CGRectMake(34, 305, CGRectGetWidth(self.view.frame) - 20 - 34, 36))
        discamlerLabelFour.text = "如您在使用本应用程序时有任何疑问，请垂询上海大众汽车经销商。"
        discamlerLabelFour.textColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        discamlerLabelFour.font = UIFont.systemFontOfSize(15)
        discamlerLabelFour.numberOfLines = 0
        discamlerLabelFour.sizeToFit()
        self.view.addSubview(discamlerLabelFour)
        
        let dotImageViewFive = UIImageView(frame: CGRectMake(20, 353, 4, 4))
        dotImageViewFive.image = UIImage(named: "dot" + themeColor)
        self.view.addSubview(dotImageViewFive)
        let discamlerLabelFive = UILabel(frame: CGRectMake(34, 346, CGRectGetWidth(self.view.frame) - 20 - 34, 54))
        discamlerLabelFive.text = "如您愿意帮助本公司改进产品服务或有任何的希望和建议，欢迎通过本应用程序中的用户反馈功能进行反馈。"
        discamlerLabelFive.textColor = UIColor(red: 69/255, green: 69/255, blue: 69/255, alpha: 1)
        discamlerLabelFive.font = UIFont.systemFontOfSize(15)
        discamlerLabelFive.numberOfLines = 0
        discamlerLabelFive.sizeToFit()
        self.view.addSubview(discamlerLabelFive)
    }
    
    // MARK: 
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
}
