//
//  SendEmaliController.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-19.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class SendEmaliController: DasautoController ,UITextFieldDelegate{

    //Mark: 属性
    @IBOutlet weak var remindLabel: UILabel!            //进度提示
    @IBOutlet weak var userEmailLabel: UILabel!         //用户名
    @IBOutlet weak var checkImageView: UIImageView!
    
    @IBOutlet weak var timeButton: UIButton!
    @IBOutlet weak var codeTextField: UITextField!
    @IBOutlet weak var nextButton: UIButton!
    
    var userEmailString: String!        //保存用户名
    
    //Mark: 发送邮件按钮
    @IBAction func sendEmailButton(sender: AnyObject) {
        
        var button = sender as UIButton
        if button.selected == false {
            
            button.selected = true
            button.titleEdgeInsets = UIEdgeInsetsMake(0, -30, 0, 0)
            timeButton.hidden = false
            self.sendEmail()
        }else {
            
            button.selected = false
            button.titleEdgeInsets = UIEdgeInsetsZero
            timeButton.hidden = true
        }
        
    }
    
    @IBAction func onNextButtonAction(sender: UIButton) {
        
        if sender.selected == true {
            
            self.performSegueWithIdentifier("ToNewPasswordSegue", sender: nil)
        }
    }
    
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //Mark: 生命周期
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.userEmailLabel.text = "您的邮箱：" + userEmailString
        
        self.remindLabel.attributedText = self.getMutableColorSrting(self.remindLabel.text!)
        var leftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        codeTextField.leftView = leftView
        codeTextField.leftViewMode = UITextFieldViewMode.Always
        nextButton.userInteractionEnabled = false
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "textFieldDidChanged", name: UITextFieldTextDidChangeNotification, object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: textFieldDelegate
    func textFieldDidBeginEditing(textField: UITextField) {
        
        textField.text = nil
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidChanged() {
        
        if codeTextField.text == "123456" {
            
            checkImageView.hidden = false
            nextButton.selected = true
            nextButton.userInteractionEnabled = true
        }
    }
    //Mark: 请求发送修改密码的邮件
    func sendEmail() {
        
        var userDict: NSDictionary = ["userName": userEmailString, "userType": 0]
        var afjson: AFJSONRequestSerializer = AFJSONRequestSerializer()
        AFOperationManager.sharedInstance.requestManager.requestSerializer = afjson
        AFOperationManager.sharedInstance.startPostOperation("http://10.11.40.8:8880/cms-web/api/cms/user/pwd/forget", param: userDict, success: { (operation, responseObject) -> Void in
            
            var mutableDic: NSMutableDictionary? = NSMutableDictionary()
            mutableDic = responseObject as? NSMutableDictionary
            Logger.debug("\(mutableDic)")
            if mutableDic != nil {
                if mutableDic!.objectForKey("memo") as String == "修改成功" {
                    
                    showAlertHelper.shared.showAlert("修改成功", inController: self)
                }else {
                    
                    if mutableDic!.objectForKey("memo") as String == "系统错误" {
                    
                        showAlertHelper.shared.showAlert("请确认您的邮箱是否正确", inController: self)
                    }else {
                    
                        showAlertHelper.shared.showAlert(mutableDic!.objectForKey("memo") as String, inController: self)
                    }
                }
            }
            }) { (operation, error) -> Void in
                
                Logger.info("_____________\(error)")
        }
    }
    
    //Mark: 给进度提示label设置不同颜色
    func getMutableColorSrting(title: String) -> NSMutableAttributedString{
        
        var attrubuteString =  NSMutableAttributedString(string: title)

        attrubuteString.addAttribute(NSForegroundColorAttributeName, value: UIColor.blackColor(), range: NSMakeRange(7, 5))

        return attrubuteString
    }
}
