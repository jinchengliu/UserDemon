/*
*  filename: AboutController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/1.
*  copyright: bdcluster
*/

import UIKit

class AboutController: DasautoController, UITextFieldDelegate {

    @IBOutlet weak var emailTextField: UITextField!      //输入密码框
    @IBOutlet weak var passwordTextField: UITextField!   //用户名输入框
    @IBOutlet weak var loginButton: UIButton!
    
    var modelYearDelegate: ModelYearViewButtonStateDelegate?
    var delegate: GuideMenuDelegate?
    var hasRightBarButtonItem: Bool!                     //判断是否需要rightBarButtonItem
    var pushToControllerName: String!                    //登录成功后跳入的视图name
    
    var isIncludeVideo: String!
    var carType: String!                                 // 需要下载的车型
    var carYear: String!                                 // 需要下载的车型年款
    var picUrl: String!                                  // 需要下载车图片的url
    
    var successCount:Int = 0
    var hasDownLoad = false
    var whetherToDownLoad:String?
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.configureTitle("登录账户")
        self.setButtonTitleColor(loginButton)
        self.configureLeftView()
        if hasRightBarButtonItem == true {
            
            self.addRightBarButtonItem("跳过")
        }
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        self.view.endEditing(true)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    /**
    *  下载车型zip包
    */
    func offLineDownloadCarZip() {
        
        let downloadManagerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as! DownloadManagerController
        downloadManagerVC.hasSelectCarTypeController = true
        downloadManagerVC.downloadVideo(carType, carYear: carYear, isIncludeVideo: isIncludeVideo,picUrl:self.picUrl)
        
        self.navigationController?.pushViewController(downloadManagerVC, animated: true)
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  设置textField的leftView
    */
    func configureLeftView() {
        
        let emailLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        let passwordLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        emailTextField.leftView = emailLeftView
        passwordTextField.leftView = passwordLeftView
        emailTextField.leftViewMode = UITextFieldViewMode.Always
        passwordTextField.leftViewMode = UITextFieldViewMode.Always
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  登录
    */
    func loginPost() {
        
        self.showProgressHUDMessage("正在登录中")
        let userDict: NSDictionary = ["userName": self.emailTextField.text!, "password": self.passwordTextField.text!]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserLogin, param: userDict,withToken:false, success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            if let mutableDic = responseObject as? NSMutableDictionary{
                
                if mutableDic.objectForKey("token") != nil {
                    
                    let carDict = mutableDic.objectForKey("user") as! NSDictionary
                    kUserId = (carDict.objectForKey("id") as! Int).description
                    
                    let userDefault = NSUserDefaults.standardUserDefaults()
                    userDefault.setObject(mutableDic.objectForKey("token"), forKey: "userToken")
                    userDefault.setObject(carDict.objectForKey("userName"), forKey: "userName")
                    userDefault.setObject(carDict.objectForKey("id"), forKey: "userId")
                    userDefault.synchronize()
                    // 顺便把收藏拉下来
                    self.queryResourceCollectionList()
                    self.queryShopCollectionList()
                }else {
                    
                    let memo = mutableDic.objectForKey("memo") as! String
                    self.showRendView(memo, isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                self.hideProgressHUD()
                self.showRendView("登录失败", isSuccess: false)
        }
    }
    
    /**
     *  登录成功后的操作
     */
    func hasLoginSuccesss() {
        
        if pushToControllerName == "MyMessageController" {
            
            self.performSegueWithIdentifier("AboutToMessageSegue", sender: nil)
        }else if pushToControllerName == "DownloadController" {
            
            let downloadManagerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as! DownloadManagerController
            downloadManagerVC.hasSelectCarTypeController = true
            downloadManagerVC.downloadVideo(carType, carYear: carYear, isIncludeVideo: isIncludeVideo,picUrl:self.picUrl)
            self.navigationController?.pushViewController(downloadManagerVC, animated: true)
        }else if pushToControllerName == "BackToListController" {
            
            self.navigationController?.popViewControllerAnimated(false)
            self.navigationController?.popViewControllerAnimated(false)
        }else {
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let userInfoController: LoginController = storyBoard.instantiateViewControllerWithIdentifier("UserInfoStoryboardID") as! LoginController
            self.navigationController?.pushViewController(userInfoController, animated: true)
        }
    }
    
    /**
    *  请求html收藏
    */
    func queryResourceCollectionList() {
        
        let userDict: NSDictionary = ["userId": Int(kUserId)!]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionList, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
            
            if let mutableDic = responseObject as? NSMutableDictionary {
                
                let respCode = mutableDic.objectForKey("respCode") as! String
                if respCode == "020003" {
                    // 弃用
//                    self.tokenLoseEfficacy()
                }else if respCode == "000000" {
                    
                    if let arr = mutableDic.objectForKey("collectionList") as? NSArray {
                        
                        // 1. 删除数据库(html)
                        DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                        // 2. 添加到数据库
                        self.analysisHtmlDataWithNSArray(arr)
                    }
                }
            }
        }) { (operation, error) -> Void in
                
        }
    }
    
    /**
     *  请求4S经销商收藏
     */
    func queryShopCollectionList() {
        
        let userDict: NSDictionary = ["userId": Int(kUserId)!]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kShopCollectionList, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
            
            if let mutableDic = responseObject as? NSMutableDictionary {
                
                let respCode = mutableDic.objectForKey("respCode") as! String
                if respCode == "020003" {
                    // 弃用
//                    self.tokenLoseEfficacy()
                }else if respCode == "000000" {
                    
                    // 请求数据成功
                    if let arr = mutableDic.objectForKey("collections") as? NSArray {
                        // 2. 删除数据库
                        DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                        // 3. 添加到数据库
                        self.analysisShopDataWithNSArray(arr)
                    }
                }
            }
            }) { (operation, error) -> Void in
                
                Logger.info("_____________\(error)")
        }
    }
    
    /**
     *  账号失效, 重新登录
     */
    func tokenLoseEfficacy() {
        
        DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
        DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
        kUserId = "noLogin"
        NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
        NSUserDefaults.standardUserDefaults().synchronize()
        self.showRendView("账号失效, 请重新登录!", isSuccess: false)
        
//        let aboutController: AboutController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
//        aboutController.hasRightBarButtonItem = false
//        aboutController.pushToControllerName = "BackToListController"
//        self.navigationController?.pushViewController(aboutController, animated: true)
    }
    
    // MARK:
    // MARK: FMDataBase
    /**
    *  解析添加html数据
    */
    func analysisHtmlDataWithNSArray(array: NSArray) {
        
        successCount++
        let titleArray = ["快速指南","维护保养","用户手册","视频介绍","爱车课堂","应急服务"]
        var typeArray = ["quick","maintain","manual","video","carclass","emergency"]
        for var i = 0; i < array.count; i++ {
            
            let dict = array[i] as! NSDictionary
            var typeName = dict.objectForKey("resourceType") as! String        // type
            let carResListArray = dict.objectForKey("carResList") as! NSArray
            
            for var j = 0; j < typeArray.count; j++ {
                
                if typeName == typeArray[j] {
                    
                    typeName = titleArray[j]
                }
            }
            for var m = 0; m < carResListArray.count; m++ {
                
                let resDict = carResListArray[m] as! NSDictionary
                let carYear = resDict.objectForKey("carYear") as! String
                let carModel = resDict.objectForKey("carModel") as! String
                let resListArray = resDict.objectForKey("resList") as! NSArray
                for var n = 0; n < resListArray.count; n++ {
                    
                    let resListDict = resListArray[n] as! NSDictionary
                    let name = resListDict.objectForKey("carResourceName") as! String
                    let id = (resListDict.objectForKey("carResourceId") as! Int).description
                    DBmanager.sharedInstanceWithDBName("html").insertHtml([carModel,carYear,typeName,name,id,kUserId])
                }
            }
        }
        
        self.refreshTableView()
    }
    
    /**
     *  解析添加经销商数据
     */
    func analysisShopDataWithNSArray(array: NSArray) {
        
        successCount++
        for var i = 0; i < array.count; i++ {
            
            let dict  = array[i] as! NSDictionary
            
            let id = (dict.objectForKey("id") as! Int).description
            let name = dict.objectForKey("name") as! String
            let address = dict.objectForKey("address") as! String
            let linkTel = dict.objectForKey("linkTel") as! String
            DBmanager.sharedInstance().insertShop(["经销商",name,id,address,linkTel,kUserId])     // 添加经销商
        }
        self.refreshTableView()
    }
    
    /**
     *  html和经销商数据都请求成功后退出页面
     */
    func refreshTableView() {
        
        if self.successCount == 2 {
        
            self.showRendView("登录成功", isSuccess: true)
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.hasLoginSuccesss()
            })
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中忘记密码
    */
    @IBAction func forgetPasswordButton(sender: AnyObject) {
        
        self.performSegueWithIdentifier("ForgetSegue", sender: nil)
    }
    
    /**
    *  选中注册
    */
    @IBAction func registerButton(sender: AnyObject) {
        
        self.performSegueWithIdentifier("ToRegisSegue", sender: nil)
    }
    
    /**
    *  选中登录
    */
    @IBAction func loginButton(sender: AnyObject) {
        
        self.emailTextField.resignFirstResponder()
        self.passwordTextField.resignFirstResponder()
        if self.emailTextField.text!.isEmpty {
            
            self.showRendView("请输入用户名", isSuccess: false)
        }else if self.passwordTextField.text!.isEmpty{
            
            self.showRendView("请输入密码", isSuccess: false)
        }else{
            
            let isValidate = Util.isValidateEmail(self.emailTextField.text!)
            if isValidate == true {
                
                if AFNetworkReachabilityManager.sharedManager().reachable == true {
                    
                    self.loginPost()
                }else {
                    
                    self.showRendView("当前网络不可用", isSuccess: false)
                }
            }else {
                
                self.showRendView("输入邮箱格式有误,请重新输入", isSuccess: false)
            }
        }
    }
    
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        if hasRightBarButtonItem == true {
            
            self.navigationController?.popViewControllerAnimated(true)
        }else {
            
            if pushToControllerName != "BackToMainController" {
                
                self.navigationController?.popToRootViewControllerAnimated(true)
                self.delegate?.didCloseGuideMenu!()
            }else {
                
                self.navigationController?.popViewControllerAnimated(true)
            }
        }
    }
    
    /**
    *  选中跳过
    */
    override func onRightBarButtonClicked(sender: UIBarButtonItem) {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if hasDownLoad == false {
                
                self.offLineDownloadCarZip()
                hasDownLoad = true
            }
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    // MARK:
    // MARK: UITextFieldDelegate
    /**
    *  收键盘
    */
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        self.emailTextField.resignFirstResponder()
        self.passwordTextField.resignFirstResponder()
        return true
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: nil)
        if segue.identifier == "AboutToMessageSegue" {
            
        }
        
        if segue.identifier == "ToRegisSegue"
        {
            let register: RegisterController = segue.destinationViewController as! RegisterController
            register.carType = self.carType
            register.carYear = self.carYear
            register.isIncludeVideo = self.isIncludeVideo
            register.picUrl = self.picUrl
            
            register.whetherToDownload = self.whetherToDownLoad
        }
    }
}
