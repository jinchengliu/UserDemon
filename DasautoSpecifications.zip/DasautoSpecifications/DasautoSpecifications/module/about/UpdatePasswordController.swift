//
//  UpdatePasswordController.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-22.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class UpdatePasswordController: DasautoController , UITextFieldDelegate{

    @IBOutlet weak var oldPasswordTextField: UITextField!       //旧密码
    @IBOutlet weak var newPasswordTextField: UITextField!       //新密码
    @IBOutlet weak var repeatPasswordTextField:UITextField!
    @IBOutlet weak var sureButton: UIButton!
    
    // MARK:
    // MARK: Life Cycel
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.configureTextFieldLeftView()
        self.setButtonTitleColor(sureButton)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        self.resignTextFieldsFirstResponder()
    }
    
    // MARK:
    // MARK:Configure Views
    /**
    *  设置textField的leftView
    */
    func configureTextFieldLeftView() {
        
        let oldLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        let newLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        let repeatLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        oldPasswordTextField.leftView = oldLeftView
        newPasswordTextField.leftView = newLeftView
        repeatPasswordTextField.leftView = repeatLeftView
        oldPasswordTextField.leftViewMode = UITextFieldViewMode.Always
        newPasswordTextField.leftViewMode = UITextFieldViewMode.Always
        repeatPasswordTextField.leftViewMode = UITextFieldViewMode.Always
    }
    
    //MARK: Button Actions
    /**
    *  选中确认
    */
    @IBAction func onSureButtonAction(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let newString = self.newPasswordTextField.text! as NSString
        if self.oldPasswordTextField.text!.isEmpty {
            
            self.showRendView("请输入原密码", isSuccess: false)
        }else if self.newPasswordTextField.text!.isEmpty{
            
            self.showRendView("请输入新密码", isSuccess: false)
        }else if self.newPasswordTextField.text != self.repeatPasswordTextField.text{
            
            self.showRendView("两次新密码输入不一样", isSuccess: false)
        }else if newString.length < 6 {
            
            self.showRendView("新密码个数不足6个", isSuccess: false)
        }else if newString.length > 16{
            
            self.showRendView("密码个数不能超过16位", isSuccess: false)
        }else {
            
            self.resignTextFieldsFirstResponder()
            if AFNetworkReachabilityManager.sharedManager().reachable == true {
                
                self.updatePasswordPost()
            }else {
                
                self.showRendView("当前网络不可用", isSuccess: false)
            }
        }
    }
    
    /**
     *  选中返回
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  收键盘
     */
    func resignTextFieldsFirstResponder() {
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            
        }
        self.oldPasswordTextField.resignFirstResponder()
        self.newPasswordTextField.resignFirstResponder()
        self.repeatPasswordTextField.resignFirstResponder()
    }

    //MARK: Load Data
    /**
    *  修改密码
    */
    func updatePasswordPost() {
    
        self.showProgressHUD()
        let userDict: NSDictionary = ["userId": Int(kUserId)!, "oldPwd": self.oldPasswordTextField.text!, "newPwd": self.newPasswordTextField.text!]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserUpdatePassword, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            let mutableDic = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                if mutableDic!.objectForKey("memo") as! String == "成功" {
                    
                    self.showRendView("密码修改成功", isSuccess: false)
                }else {
                    
                    self.showRendView(mutableDic!.objectForKey("memo") as! String, isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                self.hideProgressHUD()
                self.showRendView("密码修改失败", isSuccess: false)
        }
    }
    
    // MARK: 
    // MARK: UITextFieldDelegate
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}
