//
//  LoginController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-1-15.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class LoginController: DasautoController{
    
    var delegate: GuideMenuDelegate?
    var userName: String!                       //用户名
    
    @IBOutlet weak var userNameLabel: UILabel!  //用户名label
    @IBOutlet weak var rightImageViewUp: UIImageView!
    @IBOutlet weak var rightImageViewBottom: UIImageView!
    @IBOutlet weak var loginOutButton: UIButton!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.setButtonTitleColor(loginOutButton)
        userNameLabel.text = NSUserDefaults.standardUserDefaults().objectForKey("userName") as? String
        rightImageViewUp.image = UIImage(named: "rightArrow" + themeColor)
        rightImageViewBottom.image = UIImage(named: "rightArrow" + themeColor)
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中修改密码
    */
    @IBAction func upDatePasswordButton(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("ToUpdatePasswordSegue", sender: nil)
    }
    
    /**
     *  选中退出登录
     */
    @IBAction func onLoginOutButtonAction(sender: AnyObject) {
    
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            self.userLogout()
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    /**
    *  选中下载历史
    */
    @IBAction func onDownloadHistoryButtonAction(sender: AnyObject) {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            SystemConfigureManager.sharedInstance.makeSoundEffect()
            self.performSegueWithIdentifier("ToDownloadHistorySegue", sender: nil)
        }else {
            
            self.showRendView("当前网络不可用", isSuccess: false)
        }

//        SystemConfigureManager.sharedInstance.makeSoundEffect()
//        self.performSegueWithIdentifier("ToDownloadHistorySegue", sender: nil)
    }
    
    /**
     *  选中返回
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  退出登录
    */
    func userLogout() {
    
        self.showProgressHUDMessage("退出登录中")
        let token = NSUserDefaults.standardUserDefaults().objectForKey("userToken") as! String
        let userDict: NSDictionary = [ "token" : token]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserLogin, param: userDict, withToken:false,success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            var mutableDic: NSMutableDictionary? = NSMutableDictionary()
            mutableDic = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                
                if mutableDic!.objectForKey("respCode") != nil {
                    
                    // 退出成功 删除用户登录的收藏缓存
                    DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                    DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                    kUserId = "noLogin"
                    NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
                    NSUserDefaults.standardUserDefaults().synchronize()
                    self.showRendView("退出登录成功",isSuccess: false)
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        self.hasLogoutSuccesss()
                    })
                }
                else {
                    self.showRendView("退出登录失败!",isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                self.hideProgressHUD()
                self.showRendView("退出登录失败!",isSuccess: false)
        }
    }
    
    func hasLogoutSuccesss() {
        
        self.performSegueWithIdentifier("LoginToAboutSegue", sender: nil)
    }

    // MARK:
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "LoginToAboutSegue" {
            
            let aboutController = segue.destinationViewController as! AboutController
            aboutController.pushToControllerName = "backToLogin"
            aboutController.hasRightBarButtonItem = false
        }
    }
}
