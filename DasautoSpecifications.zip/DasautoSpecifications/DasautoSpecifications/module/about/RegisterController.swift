//
//  RegisterController.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-15.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class RegisterController: DasautoController ,UITextFieldDelegate{
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var repeatTextFiled: UITextField!
    @IBOutlet weak var registerButton: UIButton!
    
    var whetherToDownload:String?
    var carType:String!
    var carYear:String!
    var isIncludeVideo:String!
    var picUrl:String!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureTitle("注册新账号")
        self.addBackBarButtonItem()
        self.setButtonTitleColor(registerButton)
        self.configureLeftView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        self.resignTextFieldFirstResponder()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  设置textField的leftView
    */
    func configureLeftView() {
        
        let emailLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        let passwordLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        let repeatLeftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        emailTextField.leftView = emailLeftView
        passwordTextField.leftView = passwordLeftView
        repeatTextFiled.leftView = repeatLeftView
        emailTextField.leftViewMode = UITextFieldViewMode.Always
        passwordTextField.leftViewMode = UITextFieldViewMode.Always
        repeatTextFiled.leftViewMode = UITextFieldViewMode.Always
    }
    
    //MARK: Button Actions
    /**
    *  选中注册按钮
    */
    @IBAction func onRegisterButtonAction(sender: AnyObject) {

        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.emailTextField.resignFirstResponder()
        self.passwordTextField.resignFirstResponder()
        self.repeatTextFiled.resignFirstResponder()
        
        if self.emailTextField.text!.isEmpty {
            
            self.showRendView("邮箱不能为空", isSuccess: false)
        }else if self.passwordTextField.text!.isEmpty{
            
            self.showRendView("密码不能为空", isSuccess: false)
        }else if self.repeatTextFiled.text!.isEmpty{
            
            self.showRendView("请重复输入密码", isSuccess: false)
        }else if self.passwordTextField.text != self.repeatTextFiled.text{
            
            self.showRendView("两次密码输入不一致", isSuccess: false)
        }else{
            
            let passwordCount = self.passwordTextField.text!.characters.count
            if passwordCount < 6 {
                
                self.showRendView("密码长度不能少于6个", isSuccess: false)
                return
            }
            if passwordCount > 16 {
                
                self.showRendView("密码长度不能超过于16个", isSuccess: false)
                return
            }
            let isValidateEmail = Util.isValidateEmail(self.emailTextField.text!)
            if isValidateEmail == true {
                
                if AFNetworkReachabilityManager.sharedManager().reachable == true {
                    
                    self.registerPost()
                }else {
                    
                    self.showRendView("当前网络不可用", isSuccess: false)
                }
            }else {
                
                self.showRendView("邮箱格式错误, 请重新输入", isSuccess: false)
            }
        }
    }
    
    /**
    *  选中登录
    */
    @IBAction func loginButton(sender: AnyObject) {
        
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    /**
     *  选中返回
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //MARK: Load Data
    /**
    *  注册
    */
    func registerPost() {
        
        self.showProgressHUDMessage("正在注册中")
        let currentDevice = UIDevice.currentDevice().systemVersion
        let userDict: NSDictionary = ["userName": self.emailTextField.text!, "password": self.passwordTextField.text!, "nickName": "xiaogang", "devicePlatform": 1, "platformVersion": currentDevice]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserRegister, param: userDict, withToken:false,success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            if let mutableDic = responseObject as? NSMutableDictionary {
                
                if mutableDic.objectForKey("userId") != nil {
                    
                    self.showRendView("注册成功", isSuccess: false)
                    self.loginPost()
                    if self.whetherToDownload != nil {
                        if self.whetherToDownload == "true" {
                            //跳转至下载页
                            let downloadManagerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as! DownloadManagerController
                            downloadManagerVC.hasSelectCarTypeController = true
                            downloadManagerVC.downloadVideo(self.carType, carYear: self.carYear, isIncludeVideo: self.isIncludeVideo, picUrl: self.picUrl)
                            
                            self.navigationController?.pushViewController(downloadManagerVC, animated: true)
                        }
                    }else {
                        //返回主页面
                        self.navigationController?.popToRootViewControllerAnimated(true)
                    }
                }else {
                    
                    self.showRendView("该邮箱已被注册", isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                self.hideProgressHUD()
                self.showRendView("注册失败", isSuccess: false)
        }
    }
    
    /**
     *  登录
     */
    func loginPost() {
        
        let userDict: NSDictionary = ["userName": self.emailTextField.text!, "password": self.passwordTextField.text!]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserLogin, param: userDict, withToken:false,success: { (operation, responseObject) -> Void in
            
            if let mutableDic = responseObject as? NSMutableDictionary {
                
                if mutableDic.objectForKey("token") != nil {
                    
                    let carDict = mutableDic.objectForKey("user") as! NSDictionary
                    kUserId = (carDict.objectForKey("id") as! Int).description
                    
                    let userDefault = NSUserDefaults.standardUserDefaults()
                    userDefault.setObject(mutableDic.objectForKey("token"), forKey: "userToken")
                    userDefault.setObject(carDict.objectForKey("userName"), forKey: "userName")
                    userDefault.setObject(carDict.objectForKey("id"), forKey: "userId")
                    userDefault.synchronize()
                    
                    self.queryResourceCollectionList()
                    self.queryShopCollectionList()
                }else {
                    
                    let memo = mutableDic.objectForKey("memo") as! String
                    self.showRendView( memo, isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                self.showRendView("登录失败",isSuccess: false)
        }
    }
    
    /**
     *  请求html收藏
     */
    func queryResourceCollectionList() {
        
        let userDict: NSDictionary = ["userId": Int(kUserId)!]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionList, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
            
            if let mutableDic = responseObject as? NSMutableDictionary {
                
                let respCode = mutableDic.objectForKey("respCode") as! String
                if respCode == "020003" {
                    // 弃用
//                    self.tokenLoseEfficacy()
                }else if respCode == "000000" {
                    
                    if let arr = mutableDic.objectForKey("collectionList") as? NSArray {
                        // 1. 删除数据库(html)
                        DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                        // 2. 添加到数据库
                        self.analysisHtmlDataWithNSArray(arr)
                    }
                }
            }
        }) { (operation, error) -> Void in
                
        }
    }
    
    /**
     *  请求4S经销商收藏
     */
    func queryShopCollectionList() {
        
        let userDict: NSDictionary = ["userId": Int(kUserId)!]
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kShopCollectionList, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
            
            if let mutableDic = responseObject as? NSMutableDictionary {
                
                let respCode = mutableDic.objectForKey("respCode") as! String
                if respCode == "020003" {
                    // 弃用
//                    self.tokenLoseEfficacy()
                }else if respCode == "000000" {
                    
                    // 请求数据成功
                    if let arr = mutableDic.objectForKey("collections") as? NSArray {
                        // 2. 删除数据库
                        DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                        // 3. 添加到数据库
                        self.analysisShopDataWithNSArray(arr)
                    }
                }
            }
            }) { (operation, error) -> Void in
                
                Logger.info("_____________\(error)")
        }
    }
    
    /**
     *  账号失效, 重新登录
     */
    func tokenLoseEfficacy() {
        
        DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
        DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
        kUserId = "noLogin"
        NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
        NSUserDefaults.standardUserDefaults().synchronize()
        self.showRendView("账号失效, 请重新登录!", isSuccess: false)
    }
    
    // MARK:
    // MARK: FMDataBase
    /**
    *  解析添加html数据
    */
    func analysisHtmlDataWithNSArray(array: NSArray) {
        
        let titleArray = ["快速指南","维护保养","用户手册","视频介绍","爱车课堂","应急服务"]
        var typeArray = ["quick","maintain","manual","video","carclass","emergency"]
        for var i = 0; i < array.count; i++ {
            
            let dict = array[i] as! NSDictionary
            var typeName = dict.objectForKey("resourceType") as! String        // type
            let carResListArray = dict.objectForKey("carResList") as! NSArray
            
            for var j = 0; j < typeArray.count; j++ {
                
                if typeName == typeArray[j] {
                    
                    typeName = titleArray[j]
                }
            }
            for var m = 0; m < carResListArray.count; m++ {
                
                let resDict = carResListArray[m] as! NSDictionary
                let carYear = resDict.objectForKey("carYear") as! String
                let carModel = resDict.objectForKey("carModel") as! String
                let resListArray = resDict.objectForKey("resList") as! NSArray
                for var n = 0; n < resListArray.count; n++ {
                    
                    let resListDict = resListArray[n] as! NSDictionary
                    let name = resListDict.objectForKey("carResourceName") as! String
                    let id = (resListDict.objectForKey("carResourceId") as! Int).description
                    DBmanager.sharedInstanceWithDBName("html").insertHtml([carModel,carYear,typeName,name,id,kUserId])
                }
            }
        }
    }
    
    /**
     *  解析添加经销商数据
     */
    func analysisShopDataWithNSArray(array: NSArray) {
        
        for var i = 0; i < array.count; i++ {
            
            let dict  = array[i] as! NSDictionary
            
            let id = (dict.objectForKey("id") as! Int).description
            let name = dict.objectForKey("name") as! String
            let address = dict.objectForKey("address") as! String
            let linkTel = dict.objectForKey("linkTel") as! String
            DBmanager.sharedInstance().insertShop(["经销商",name,id,address,linkTel,kUserId])     // 添加经销商
        }
    }
    
    /**
     *  收键盘 
     */
    func resignTextFieldFirstResponder() {
        
        self.emailTextField.resignFirstResponder()
        self.passwordTextField.resignFirstResponder()
        self.repeatTextFiled.resignFirstResponder()
    }
    
    // MARK: 
    // MARK: UITextFieldDelegate
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}
