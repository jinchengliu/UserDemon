//
//  ForgetPasswordController.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-15.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class ForgetPasswordController: DasautoController {
    
    @IBOutlet weak var userNameTextField: UITextField!  // 用户名
    @IBOutlet weak var nextButton: UIButton!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.setButtonTitleColor(nextButton)
        self.configureTextFieldLeftView()
    }
    
    /**
     *  收键盘
     */
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        self.userNameTextField.resignFirstResponder()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置textField的leftView
    */
    func configureTextFieldLeftView() {
        
        let leftView = UIView(frame: CGRectMake(0, 0, 10, 40))
        userNameTextField.leftView = leftView
        userNameTextField.leftViewMode = UITextFieldViewMode.Always
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中发送邮件
    */
    @IBAction func onNextButtonAction(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.userNameTextField.resignFirstResponder()
        if self.userNameTextField.text!.isEmpty {
        
            self.showRendView("请输入您的邮箱", isSuccess: false)
        }else{
            
            let isValidate = Util.isValidateEmail(userNameTextField.text!)
            if isValidate == true {
                
                if AFNetworkReachabilityManager.sharedManager().reachable == true {
                    
                    self.senderEmailForFindPassword(userNameTextField.text!)
                }else {
                    
                    self.showRendView("当前网络不可用", isSuccess: false)
                }
            }else {
                
                self.showRendView("输入邮箱格式有误,请重新输入", isSuccess: false)
            }
        }
    }
    
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  发送邮件找回密码
    */
    func senderEmailForFindPassword(userName: String) {
        
        let dict: NSDictionary = ["userName":userName];
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserForgetPassword, param: dict, withToken:false,success: { (operation, responseObject) -> Void in
            
            let mutableDic: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                
                let respCode = mutableDic?.objectForKey("respCode") as! String
                let memo = mutableDic?.objectForKey("memo") as! String
                if respCode == "000000" {
                    
                    self.showRendView("找回密码成功, 请关注您的邮箱", isSuccess: false)
                }else {
                    
                    self.showRendView(memo, isSuccess: false)
                }
            }
        }) { (operation, error) -> Void in
            
            self.showRendView("找回密码失败", isSuccess: false)
        }
    }
    
    // MARK: 
    // MARK:UITextFieldDelegate
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}
