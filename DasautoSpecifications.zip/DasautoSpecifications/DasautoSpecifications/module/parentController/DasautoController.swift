/*
 *  filename: DasautoController.swift
 *  product name: DasautoSpecifications
 *  项目控制器基类
 *  author: cp
 *  date time: 14/11/24.
 *  copyright: bdcluster
 */

import UIKit

//extension NSIndexPath {
//    var isOpen: Bool!
//}

class DasautoController: UIViewController,CustomAlertViewDelegate {

    var progressHUD: MBProgressHUD!
    var alertButton: UIButton!
    var backView: UIView!
    
    var zipPackage: ZipPackage?
    var color: UIColor!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        if themeColor == "_red" {
            
            color = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }else if themeColor == "_blue" {
            
            color = UIColor(red: 0, green: 0.56, blue: 0.84, alpha: 1.0)
        }else {
            
            color = UIColor(red: 0.82, green: 0.67, blue: 0.5, alpha: 1.0)
        }
        self.view.backgroundColor = UIColor.whiteColor()
        self.navigationController?.navigationBar.tintColor = UIColor.blackColor()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        Logger.warn("receive memory warning")
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  添加BarButtonItem
    */
    func configureTitle(title: String) {
        
        self.navigationItem.title = title
    }
    
    /**
     *  添加返回按钮
     */
    func addBackBarButtonItem() {
        
        var tintColor: UIColor!
        if themeColor == "_red" {
            
            tintColor = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }else if themeColor == "_blue" {
            
            tintColor = UIColor(red: 0, green: 0.56, blue: 0.84, alpha: 1.0)
        }else {
            
            tintColor = UIColor(red: 0.82, green: 0.67, blue: 0.5, alpha: 1.0)
        }
        let backBarButtonItem: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconBack_red"), style: UIBarButtonItemStyle.Plain, target: self, action: #selector(DasautoController.onBackBarButtonItemClciked(_:)))
        backBarButtonItem.tintColor = tintColor
        self.navigationItem.leftBarButtonItem = backBarButtonItem
    }
    
    /**
     *  添加导航栏logo标题
     */
    func addLogoTitleView() {
        
        let logoImageView: UIImageView = UIImageView(frame: CGRectMake(0, 12, 100, 20))
        logoImageView.image = UIImage(named: "logo")
        self.navigationItem.titleView = logoImageView
    }
    
    /**
     *  添加导航栏右侧AR和搜索按钮
     */
    func addRightNavigationItems() {
        
        let searchBarButton: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "search"), style: UIBarButtonItemStyle.Plain, target: self, action: #selector(DasautoController.onSearchBarButtonclicked(_:)))
        searchBarButton.tintColor = UIColor.blackColor()
        
        var arBarButton: UIBarButtonItem!
        if CGRectGetWidth(self.view.bounds) <= 320 {
            
            arBarButton = UIBarButtonItem()
            let but = UIButton(frame: CGRectMake(0, 0, 50, 44))
            but.setImage(UIImage(named: "AR"), forState: UIControlState.Normal)
            but.addTarget(self, action: #selector(DasautoController.onArBarButtonclicked), forControlEvents: UIControlEvents.TouchUpInside)
            but.imageEdgeInsets = UIEdgeInsetsMake(0, 28, 0, 0)
            arBarButton.customView = but
        }else {
            
            arBarButton = UIBarButtonItem(image: UIImage(named: "AR"), style: UIBarButtonItemStyle.Plain, target: self, action: Selector("onArBarButtonclicked"))
        }
        
        arBarButton.tintColor = UIColor.blackColor()
        self.navigationItem.rightBarButtonItems = [searchBarButton, arBarButton]
    }
    
    /**
     *  添加导航栏右侧继续按钮
     */
    func addRightBarButtonItem(title: String) {
        
        let barButton = UIBarButtonItem(title: title, style: UIBarButtonItemStyle.Plain, target: self, action: "onRightBarButtonClicked:")
        barButton.tintColor = color
        
        self.navigationItem.rightBarButtonItem = barButton
    }
    
    /**
     *  显示progressHUD(不显示labeltext)
     */
    func showProgressHUD() {
        progressHUD = MBProgressHUD()
        progressHUD.show(true)
        Util.getKeyWindow().addSubview(progressHUD)
    }
    
    /**
     *  显示progressHUD(带有labeltext)
     */
    func showProgressHUDMessage(message: String) {
        progressHUD = MBProgressHUD()
        progressHUD.labelText = message
        progressHUD.show(true)
        Util.getKeyWindow().addSubview(progressHUD)
    }
    
    /**
     *  隐藏progressHUD
     */
    func hideProgressHUD() {
        if progressHUD != nil {
            progressHUD.hide(true)
            progressHUD = nil
        }
    }
    
    /**
     *  显示弹框视图
     */
    func showRendView(title: String, isSuccess:Bool) {
        let remindView = NSBundle.mainBundle().loadNibNamed("RemindView", owner:nil, options: nil)[0] as! RemindView
        remindView.showReminderView(title, isSuccess: isSuccess)
    }
    
    /**
     *  显示alertView
     */
    func showAlertView(title: String, tag: NSInteger) {
        
        let alertView = CustomAlertView(messageTitle: title, sureTitle: "确定", cancelTitle: "取消", delegate: self)
        alertView.tag = tag
        alertView.show()
    }
    
    ///设置button的颜色
    func setButtonTitleColor(button: UIButton) {

        button.setTitleColor(color, forState: UIControlState.Normal)
        button.setTitleColor(color, forState: UIControlState.Selected)
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回按钮
    */
    func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        //Logger.debug("点击导航栏返回按钮")
        SystemConfigureManager.sharedInstance.makeSoundEffect()
    }
    
    /**
     *  选中搜索按钮
     */
    func onSearchBarButtonclicked(sender: UIBarButtonItem) {
        Logger.debug("点击搜索按钮")
        SystemConfigureManager.sharedInstance.makeSoundEffect()
    }
    
    /**
     *  选中AR按钮
     */
    func onArBarButtonclicked() {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let userDefault = NSUserDefaults.standardUserDefaults()
        var cnt = userDefault.objectForKey("ARCount") as? Int
        if cnt == nil {
            
            cnt = 0
        }
        cnt = cnt! + 1
        userDefault.setObject(cnt, forKey: "ARCount")
        userDefault.synchronize()
        
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        if pkgFileManager.packages.count != 0 {
            
            if pkgFileManager.rootFile != nil {
                let anyObjectType: AnyObject.Type = NSClassFromString("ImageTargetsViewController")!
                let NSObjectType: NSObject.Type = anyObjectType as! NSObject.Type
                let vc :AnyObject = NSObjectType.init()
                
                self.navigationController?.pushViewController(vc as! UIViewController, animated: true)
            }else {
                // 遍历所以的zip包, 优先查看是否有下载完成的包
                for zip in pkgFileManager.packages {
                    if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
                        zipPackage = zip
                        self.showAlertView("车型包已下载完成,\n 请解析数据包", tag: 2215)
                        return
                    }
                }
                for zip in pkgFileManager.packages {
                    if zip.state == ZipPackageDownloadState.downloadPause {
                        self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                        return
                    }else if zip.state == ZipPackageDownloadState.downloading {
                        if DSDownloadManager.shareInstance().isStartOperation(zip.urlString) {
                            self.showRendView("正在下载中", isSuccess: false)
                        }else {
                            self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                        }
                        return
                    }
                }
            }
        }else {
    
            self.showAlertView("尚无数据,\n 请先下载车型", tag: 2217)
        }
    }
    
    /**
     *  选中继续按钮
     */
    func onRightBarButtonClicked(sender: UIBarButtonItem) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        Logger.debug("点击继续按钮")
    }
    
    // MARK:
    // MARK: UITapGestureRecognizer
    /**
    *  自定义警告视图的点击手势
    */
    func onCustomBackViewTapGesture(tapGesture: UITapGestureRecognizer) {
        Logger.debug("自定义警告视图的点击手势")
    }
    
    // MARK: 
    // MARK: CustomAlertViewDelegate
    func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        if alertView.tag == 2215 { // 下载完成
            
            if let zip = zipPackage {
                
                self.showProgressHUDMessage("正在应用中")
                dispatch_async(dispatch_get_main_queue()) { () -> Void in
                    
                    PackageFileManager.sharedInstance.unzippingPackage(zip)
                    NSNotificationCenter.defaultCenter().postNotificationName("setMainController", object: nil)
                    self.hideProgressHUD()
                }
            }
        }else if alertView.tag == 2216 { // 下载暂停
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("DownloadManagerStoryboardID") as! DownloadManagerController
            self.navigationController?.pushViewController(vc, animated: true)
        }else if alertView.tag == 2217 { // 没有下载包
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SelectCarTypeStoryboardID") as! SelectCarTypeController
            vc.isRootViewController = false
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    // MARK:
    // MARK: 状态栏的配置
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        
        return .Default
    }
    
    override func shouldAutorotate() -> Bool {
        
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        
        return UIInterfaceOrientationMask.Portrait
    }
}
