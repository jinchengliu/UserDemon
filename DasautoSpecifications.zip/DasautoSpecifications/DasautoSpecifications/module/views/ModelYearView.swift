/*
*  filename: ModelYearView.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/11/28.
*  copyright: bdcluster
*/

import UIKit

enum ModelYearState :Int {
    
    case Download           //可下载状态
    case Downloading        //正在下载状态
    case Open               //可打开状态
}

//选择车型列表需要进行的其他操作，通过代理实现
protocol ModelYearViewDelegate {
    
    func pushToDisclaimerController(carType carType: String!, carYear: String!, state: String!,picUrl: String!, isIncludeVideo: String!, zipSize: String!)
    func removeModelYearView(modelYearView: ModelYearView)
    func openZipPackage(zip: ZipPackage)
}

class ModelYearView: UIView, UIPickerViewDelegate, UIPickerViewDataSource{
    
    var delegate: ModelYearViewDelegate?
    var modelYearState: ModelYearState!
    
    var contentView: UIView!
    var controlView: UIView!
    var dismissView: UIView!
    
    var pickerView: UIPickerView!
    var controlButton: UIButton!
    var carImageView: UIImageView!
    
    var backButton: UIButton!
    var titleLabel: UILabel!
    var didDownload = false            // default false, didDownload = true 表示进入车型内选择包, 然后进行下载
    var isReuseView = false
    
    var carType: String!               // 车型
    var carYear: String!               // 年款String
    var downHistoryIconUrl: String!    // 图片地址
    
    var isIncludeVideo = "true"        // 是否包含视频
    var dataSource: NSArray!           // 数据包对象，包含标题，数据包大小以及下载链接等信息
    var zipArray: [ZipPackage]!        // 车型对应的zip包(最多包含两个: 一个是完整版, 一个无视频版)
    
    required init?(coder aDecoder: NSCoder) {
        
        fatalError("init(coder:) has not been implemented")
    }
    
    init(frame: CGRect, contentFrame: CGRect, dataSource: NSArray, carTypeTitle: String, modelYearState: ModelYearState, zipArray: [ZipPackage]) {
        
        super.init(frame: frame)
        self.backgroundColor = UIColor.clearColor()
        dismissView = UIView(frame: frame)
        dismissView.backgroundColor = UIColor.clearColor()
        self.addSubview(dismissView)
        
        
        //赋值
        self.dataSource = dataSource
        self.carType = carTypeTitle
        self.modelYearState = modelYearState
        self.zipArray = zipArray
        
        let yearDic = self.dataSource.objectAtIndex(0) as? NSDictionary
        self.carYear = yearDic?.objectForKey("carYear") as? String
        let picUrl = yearDic?.objectForKey("picUrl") as? String
        downHistoryIconUrl = yearDic?.objectForKey("downHistoryIconUrl") as? String
        
        //添加点击手势
        let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("tapGestureHanlder:"))
        tapGesture.cancelsTouchesInView = true
        dismissView.addGestureRecognizer(tapGesture)
        
        contentView = UIView(frame: contentFrame)
        contentView.backgroundColor = UIColor(red: 239/255, green: 239/255, blue: 239/255, alpha: 1.0)
        contentView.layer.cornerRadius = 3
        contentView.layer.shadowColor = UIColor.grayColor().CGColor
        contentView.layer.shadowOffset = CGSizeMake(-1, 0)
        contentView.layer.shadowOpacity = 1.0
        contentView.layer.shadowRadius = 10
        self.addSubview(contentView)
        
        //标题Label
        titleLabel = UILabel(frame: CGRectMake(0, 0,CGRectGetWidth(contentFrame),50))
        titleLabel.backgroundColor = UIColor.whiteColor()
        titleLabel.textAlignment = NSTextAlignment.Center
        titleLabel.font = UIFont.systemFontOfSize(20)
        titleLabel.textColor = UIColor.blackColor()
        titleLabel.text = carTypeTitle
        contentView.addSubview(titleLabel)
        
        //”请选择型号及年份“Label
        let descriptionLabel: UILabel = UILabel(frame: CGRectMake(0, CGRectGetMaxY(titleLabel.frame)+5, CGRectGetWidth(contentFrame), 40))
        descriptionLabel.backgroundColor = UIColor.whiteColor()
        descriptionLabel.textAlignment = NSTextAlignment.Center
        descriptionLabel.font = UIFont.systemFontOfSize(14)
        descriptionLabel.textColor = UIColor.lightGrayColor()
        descriptionLabel.text = "请选择型号及年份"
        contentView.addSubview(descriptionLabel)
        
        // pickerView
        pickerView = UIPickerView(frame: CGRectZero)
        pickerView.autoresizingMask = [UIViewAutoresizing.FlexibleHeight, UIViewAutoresizing.FlexibleWidth]
        pickerView.frame = CGRectMake(30, CGRectGetMaxY(descriptionLabel.frame) - 30, CGRectGetWidth(contentFrame)-60, 162)
        pickerView.showsSelectionIndicator = false
        pickerView.dataSource = self
        pickerView.delegate = self
        contentView.addSubview(pickerView)
        
        let leftArrorImageView: UIImageView = UIImageView(frame: CGRectMake(0, 0, 10, 15))
        leftArrorImageView.image = UIImage(named: "leftArrow" + themeColor)
        contentView.addSubview(leftArrorImageView)
        leftArrorImageView.center = CGPointMake( CGRectGetWidth(contentView.frame) - 10 - 3.5, CGRectGetMidY(pickerView.frame))
        
        let rightArrowImageView: UIImageView = UIImageView(frame: CGRectMake(0, 0, 10, 15))
        rightArrowImageView.image = UIImage(named: "rightArrow" + themeColor)
        contentView.addSubview(rightArrowImageView)
        rightArrowImageView.center = CGPointMake( 10 + 3.5, CGRectGetMidY(pickerView.frame))
        
        //  -- change --
        carImageView = UIImageView(frame: CGRectMake(0, CGRectGetMaxY(pickerView.frame) - 30, CGRectGetWidth(contentFrame), CGRectGetWidth(contentFrame) * 0.343))
        if picUrl!.isEmpty == false {
            
            carImageView.setImageWithURL(NSURL(string: picUrl!))
            contentView.addSubview(carImageView)
        }
        
        var color: UIColor!
        if themeColor == "_red" {
            
            color = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }else if themeColor == "_blue" {
            
            color = UIColor(red: 0, green: 0.56, blue: 0.84, alpha: 1.0)
        }else {
            
            color = UIColor(red: 0.82, green: 0.67, blue: 0.5, alpha: 1.0)
        }
        // 底部视图
        let controlHeight = CGRectGetHeight(contentFrame) - CGRectGetMaxY(carImageView.frame)
        controlView = UIView(frame: CGRectMake(0, CGRectGetMaxY(carImageView.frame), CGRectGetWidth(contentFrame), controlHeight))
        controlView.backgroundColor = UIColor.whiteColor()
        contentView.addSubview(controlView)
        
        // 下载和返回按钮
        let controlViewHalfWidth = CGRectGetWidth(controlView.bounds) / 2
        controlButton = UIButton(frame: CGRectMake( (controlViewHalfWidth - 60) / 2, 0, 60, controlHeight))
        controlButton.titleLabel?.font = UIFont.systemFontOfSize(18)
        controlButton.setTitleColor(color, forState: .Normal)
        controlButton.addTarget(self, action: Selector("onControlButtonClicked:"), forControlEvents: .TouchUpInside)
        controlButton.userInteractionEnabled = true
        controlButton.tag = 2015
        controlView.addSubview(controlButton)
        
        let verticalLine = UIView(frame: CGRectMake(controlViewHalfWidth - 1, 13, 1, controlHeight - 26))
        verticalLine.backgroundColor = color
        controlView.addSubview(verticalLine)
        
        backButton = UIButton(frame: CGRectMake(controlViewHalfWidth * 3 / 2 - 30, 0, 60, controlHeight))
        backButton.setTitle("返回", forState: UIControlState.Normal)
        backButton.setTitleColor(color, forState: .Normal)
        backButton.titleLabel?.font = UIFont.systemFontOfSize(18)
        backButton.addTarget(self, action: Selector("onControlButtonClicked:"), forControlEvents: .TouchUpInside)
        backButton.userInteractionEnabled = true
        backButton.tag = 2016
        controlView.addSubview(backButton)
        
        if modelYearState == ModelYearState.Download {
            
            self.setDownloadSate()
        }else if modelYearState == ModelYearState.Downloading {
            
            self.setOpenState()
        }else if modelYearState == ModelYearState.Open {
            
            self.setOpenState()
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "setControlButtonState:", name: "setModelYearViewControlleButtonState", object: nil)
    }
    
    // MARK:
    // MARK: NSNotificationCenter
    func setControlButtonState(notification: NSNotification) {
        
        let state = notification.object as! String
        if state == "loading" {
            
            self.setDownloadingState()
        }else if state == "completed" {
            
            self.setOpenState()
        }
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  从父类移除self
    */
    func removeCurrentView() {
        
        self.removeFromSuperview()
        delegate?.removeModelYearView(self)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    /**
    *  定义年款label和checkButton
    */
    func configureViewForPickerView(row: Int,frame: CGRect) -> UIView{
        
        let pickerRowView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(frame), 44))
        pickerRowView.userInteractionEnabled = false
        let yearLabel = UILabel(frame: CGRectMake(15, 0, CGRectGetWidth(frame) - 15*2 , 44))
        yearLabel.textAlignment = NSTextAlignment.Center
        yearLabel.font = UIFont.systemFontOfSize(16)
        yearLabel.textColor = UIColor.blackColor()
        
        var title: String!
        if didDownload {
            
            if row == 0 {
                
                title = "用户手册(完整版)"
            }else {
                
                title = "用户手册(无视频版)"
            }
            yearLabel.text = title
        }else {
            
            let yearDic = self.dataSource.objectAtIndex(row) as? NSDictionary
            self.carYear = yearDic?.objectForKey("carYear") as? String
            yearLabel.text = self.carYear
        }
        
        pickerRowView.addSubview(yearLabel)
        
        let checkButton = UIButton(frame: CGRectMake(CGRectGetMaxX(yearLabel.frame) , 15, 15, 15))
        checkButton.setBackgroundImage(UIImage(named: "roundCheck"), forState: UIControlState.Normal)
        checkButton.setBackgroundImage(UIImage(named: "roundCheck" + themeColor), forState: UIControlState.Selected)
        
        // ---change---
        if isReuseView == false {
            
            if didDownload {
                
                checkButton.hidden = true
                /* 弃用
                var isIn: String!
                if row == 0 {
                
                isIn = "true"
                }else {
                
                isIn = "false"
                }
                self.setState(isIn)
                */
                self.setState("true")     //  进入完整版和无视频版选择时刷新完整版状态
            }
            if self.modelYearState == ModelYearState.Downloading || self.modelYearState == ModelYearState.Open {
                
                checkButton.selected = true
            }
        }else {
            
            if didDownload {
                
                checkButton.hidden = true
            }
        }
        checkButton.tag = row + 2000
        pickerRowView.addSubview(checkButton)
        
        return pickerRowView
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  点击controlButton的响应事件
    */
    func onControlButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if sender.tag == 2015 {
        
            if self.modelYearState == ModelYearState.Download {
                
                self.downloadPackage()
            }else if self.modelYearState == ModelYearState.Downloading {
                
                self.isLoadingPackage()
            }else if self.modelYearState == ModelYearState.Open {
                
                self.openPackage()
            }
        }else {
            
            self.removeCurrentView()
        }
    }
    
    // MARK: UITapGestureRecognizer
    /**
    *  页面手势点击方法
    */
    func tapGestureHanlder(tapGesture: UITapGestureRecognizer) {
        
        self.removeCurrentView()
    }
    
    // MARK:
    // MARK: 设置状态
    /**
    *  下载
    */
    func setDownloadSate() {
        
        self.modelYearState = ModelYearState.Download
        self.controlButton.enabled = true
        self.controlButton.setTitle("下载", forState: .Normal)
    }
    
    /**
    *  下载中
    */
    func setDownloadingState() {
        
        self.modelYearState = ModelYearState.Downloading
        self.controlButton.enabled = true
        self.controlButton.setTitle("下载中", forState: .Normal)
    }
    
    /**
     *  打开
     */
    func setOpenState() {
        
        self.modelYearState = ModelYearState.Open
        self.controlButton.enabled = true
        self.controlButton.setTitle("打开", forState: .Normal)
    }
    
    // MARK:
    // MARK: 下载车型包
    func downloadPackage() {
        
        Logger.debug("下载车型包")
        if didDownload == true {
            
            if AFNetworkReachabilityManager.sharedManager().reachable {
                
                if AFNetworkReachabilityManager.sharedManager().reachableViaWiFi {
                    
                    self.delegate?.pushToDisclaimerController(carType: self.carType, carYear: self.carYear, state: "download", picUrl: downHistoryIconUrl, isIncludeVideo: isIncludeVideo,zipSize: "0")
                }else {
                    
                    var keyString = "packageSizeV"
                    if isIncludeVideo != "true" {
                        
                        keyString = "packageSizeNv"
                    }
                    let yearDic = self.dataSource.objectAtIndex(0) as? NSDictionary
                    let s = yearDic?.objectForKey(keyString) as! NSNumber
                    let zipSize =  (s.longValue / 1024 / 1024).description
                    
                    self.delegate?.pushToDisclaimerController(carType: self.carType, carYear: self.carYear, state: "download", picUrl: downHistoryIconUrl, isIncludeVideo: isIncludeVideo,zipSize: zipSize)
                }
            }else {
                
                self.removeCurrentView()
                self.delegate?.pushToDisclaimerController(carType: self.carType, carYear: self.carYear, state: "download", picUrl: downHistoryIconUrl, isIncludeVideo: isIncludeVideo,zipSize: "0")
            }
        }else {
            
            didDownload = true
            pickerView.reloadAllComponents()
        }
    }
    
    /**
    *  正在下载车型包
    */
    func isLoadingPackage() {
        
        if didDownload {
            
            self.removeCurrentView()
            self.delegate?.pushToDisclaimerController(carType: self.carType, carYear: self.carYear, state: "isLoading", picUrl: self.downHistoryIconUrl, isIncludeVideo: "false",zipSize: "0")
        }else {
            
            didDownload = true
            pickerView.reloadAllComponents()
        }
    }
    
    /**
    *  打开车型包
    */
    func openPackage() {
        
        if didDownload {
            
            self.removeCurrentView()
            for zip in zipArray {
                
                if zip.carProductYear == self.carYear && zip.isIncludeVideo == isIncludeVideo{
                    if zip.state == ZipPackageDownloadState.isUsing {
                        
                        NSNotificationCenter.defaultCenter().postNotificationName("setMainController", object: nil)
                        return
                    }else if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
                        
                        self.delegate?.openZipPackage(zip)
                        return
                    }
                }
            }
        }else {
            
            didDownload = true
            pickerView.reloadAllComponents()
        }
    }
    
    // MARK:
    // MARK:UIPickerViewDataSource
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        
        return 34
    }
    
    func pickerView(pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        
        if component == 0 {
            
            return CGRectGetWidth(pickerView.bounds)
        }else {
            
            return 0
        }
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if component == 0 {
            
            if didDownload == false  {
                
                return self.dataSource.count
            }else {
                
                return 2
            }
        }else {
            
            return 0
        }
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView {
        
        if component == 0 {
            
           return self.configureViewForPickerView(row, frame: pickerView.bounds)
        }else {
            
            return UIView()
        }
    }

    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if didDownload {
            
            isReuseView = true
            if row == 0 {
                
                isIncludeVideo = "true"
            }else {
                
                isIncludeVideo = "false"
            }
        }
        
        //   ---change--- 滚定判断是否下载
        if didDownload {
            
            self.setState(isIncludeVideo)
        }else {
            
            let view = pickerView.viewForRow(row, forComponent: component)
            let checkButton = view?.viewWithTag(2000 + row) as! UIButton
            
            if self.modelYearState == ModelYearState.Downloading || self.modelYearState == ModelYearState.Open {
                
                checkButton.selected = true
            }
        }
    }
    
    // MARK: 滚动的过程中设置状态
    func setState(isIncludeVideo: String) {
        
        // 根据zip判断checkButton的状态
        for var i = 0; i < zipArray.count; i++  {
            
            let zip = zipArray[i] as ZipPackage
            let state = zip.state
            if self.carYear == zip.carProductYear {
                
                if didDownload == false {
                    
                    switch state.hashValue {
                    case 0:
                        self.setDownloadingState()
                    case 1:
                        self.setDownloadingState()
                    case 2:
                        self.setDownloadingState()
                    case 4:
                        self.setOpenState()
                    case 5:
                        self.setOpenState()
                    case 6:
                        self.setOpenState()
                    case 7:
                        self.setOpenState()
                    default :
                        break
                    }
                    break
                }else {
                    
                    // 判断是否是完整版
                    if zip.isIncludeVideo == isIncludeVideo {
                        
                        switch state.hashValue {
                        case 0:
                            self.setDownloadingState()
                        case 1:
                            self.setDownloadingState()
                        case 2:
                            self.setDownloadingState()
                        case 4:
                            self.setOpenState()
                        case 5:
                            self.setOpenState()
                        case 6:
                            self.setOpenState()
                        case 7:
                            self.setOpenState()
                        default :
                            break
                        }
                        break
                    }
                }
            }
            
            self.setDownloadSate()
        }
    }
}
