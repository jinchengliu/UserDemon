/*
*  filename: FaouriteMainListCell.swift
*  product name: DasautoSpecifications
*
*  author: cp
*  date time: 14/12/16.
*  copyright: bdcluster
*/

class FaouriteMainListCell: UITableViewCell {
    
    @IBOutlet weak var favouriteNameLabel: ThemeLabel!

    @IBOutlet weak var rightArrowImageView: UIImageView!
    @IBOutlet weak var messageCountButton: UIButton!
    @IBOutlet weak var messageCountButtonWidthConstraint: NSLayoutConstraint!
   
    override func awakeFromNib() {
        
        super.awakeFromNib()
        rightArrowImageView.image = UIImage(named: "rightArrow" + themeColor)
    }
    
    func configureMainListCellWith(name: String, favouriteCount: Int) {
        
        self.favouriteNameLabel.text = name
        self.messageCountButton.setTitle(String(favouriteCount), forState: UIControlState.Normal)
        messageCountButton.setBackgroundImage(UIImage(named: "remindRound" + themeColor), forState: UIControlState.Normal)
        
        if favouriteCount > 9 {
            
            self.messageCountButtonWidthConstraint.constant = 23
            messageCountButton.setBackgroundImage(UIImage(named: "moreRemindRound" + themeColor), forState: UIControlState.Normal)
        }
        if favouriteCount > 99 {
           
            self.messageCountButton.setTitle(String(99) + "+", forState: UIControlState.Normal)
            self.messageCountButtonWidthConstraint.constant = 32
            messageCountButton.setBackgroundImage(UIImage(named: "largeRemidRound" + themeColor), forState: UIControlState.Normal)
        }
    }
}
