//
//  CustomAlertView.swift
//
//  Created by wangrui on 15/7/14.
//  Copyright (c) 2015年 wangrui. All rights reserved.

import UIKit

protocol CustomAlertViewDelegate: NSObjectProtocol {
    
    func onCustomAlertViewSureButtonAction(alertView: CustomAlertView)
}

class CustomAlertView: UIView {
    
    var customRemondView: UIView!
    weak var delegate: protocol<CustomAlertViewDelegate>!
    var messageTitle: String!
    var keyWindow: UIWindow!
    
    required init?(coder aDecoder: NSCoder) {
        
        fatalError("init(coder:) has not been implemented")
    }
    
    init(messageTitle: String, sureTitle: String, cancelTitle: String ,delegate: protocol<CustomAlertViewDelegate>?) {
        
        keyWindow = Util.getKeyWindow()
        super.init(frame: keyWindow.bounds)
        
        self.backgroundColor = UIColor.grayColor()
        self.alpha = 0
        self.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onCustomAlertViewTapGest:"))
        
        self.messageTitle = messageTitle
        self.delegate = delegate
        
        customRemondView = UIView(frame: CGRectMake(0, 0, 251, 141))
        customRemondView.center = self.center
        customRemondView.backgroundColor = UIColor.whiteColor()
        customRemondView.alpha = 0
        customRemondView.layer.cornerRadius = 7
        customRemondView.layer.masksToBounds = true
        
        if sureTitle == "phone" {
            
            var array = messageTitle.componentsSeparatedByString("_")
            var title = "上海大众客户服务热线"
            var message = "400 820 1111"
            if array.count != 1 {
                
                title = array[0] as String
                message = array[1] as String
            }
            let titleLabel = UILabel(frame: CGRectMake(0, 20, 251, 30))
            titleLabel.textAlignment = NSTextAlignment.Center
            titleLabel.font = UIFont.systemFontOfSize(17)
            titleLabel.textColor = UIColor.grayColor()
            titleLabel.text = title
            customRemondView.addSubview(titleLabel)
            
            let numberLabel = UILabel(frame: CGRectMake(0, 50, 251, 40))
            numberLabel.textAlignment = NSTextAlignment.Center
            numberLabel.font = UIFont.systemFontOfSize(19)
            numberLabel.textColor = UIColor.darkTextColor()
            numberLabel.text = message
            customRemondView.addSubview(numberLabel)
        }else {
            
            let titleLabel = UILabel(frame: CGRectMake(0, 20, 251, 70))
            titleLabel.textAlignment = NSTextAlignment.Center
            titleLabel.font = UIFont.systemFontOfSize(19)
            titleLabel.textColor = UIColor.darkTextColor()
            titleLabel.text = messageTitle
            titleLabel.numberOfLines = 0
            customRemondView.addSubview(titleLabel)
        }
        
        let horizontalLineView = UIView(frame: CGRectMake(0, 90, 251, 1))
        horizontalLineView.backgroundColor = UIColor(red:0.96, green:0.96, blue:0.96, alpha:1)
        customRemondView.addSubview(horizontalLineView)
        
        var color: UIColor!
        if themeColor == "_red" {
            
            color = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }else if themeColor == "_blue" {
            
            color = UIColor(red: 0, green: 0.56, blue: 0.84, alpha: 1.0)
        }else {
            
            color = UIColor(red: 0.82, green: 0.67, blue: 0.5, alpha: 1.0)
        }
        let cancelButton = UIButton(frame: CGRectMake(0, 91, 125, 50))
        cancelButton.setTitle(cancelTitle, forState: UIControlState.Normal)
        cancelButton.setTitleColor(UIColor.grayColor(), forState: UIControlState.Normal)
        cancelButton.titleLabel?.font = UIFont.systemFontOfSize(17)
        cancelButton.addTarget(self, action: "onCustomRemondViewButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        cancelButton.tag = 2015
        customRemondView.addSubview(cancelButton)
        
        let verticalLineView = UIView(frame: CGRectMake(125, 91, 1, 50))
        verticalLineView.backgroundColor = UIColor(red:0.96, green:0.96, blue:0.96, alpha:1)
        customRemondView.addSubview(verticalLineView)
        
        let ensureButton = UIButton(frame: CGRectMake(126, 91, 125, 50))
        ensureButton.addTarget(self, action: "onCustomRemondViewButtonClicked:", forControlEvents: UIControlEvents.TouchUpInside)
        ensureButton.tag = 2016
        if sureTitle == "phone" {
            
            ensureButton.setImage(UIImage(named: "phone"), forState: UIControlState.Normal)
            ensureButton.imageEdgeInsets = UIEdgeInsetsMake(10, 48, 10, 48)
        }else {
            
            ensureButton.setTitle(sureTitle, forState: UIControlState.Normal)
            ensureButton.setTitleColor(color, forState: UIControlState.Normal)
            ensureButton.titleLabel?.font = UIFont.systemFontOfSize(17)
        }
        customRemondView.addSubview(ensureButton)
    }
    
    /**
     *  显示警告视图_父类DasautoController遵守了协议->判断zip的下载情况, 其他情况请覆盖父类遵守的代理方法
     */
    func show() {
        
        keyWindow.addSubview(self)
        keyWindow.addSubview(customRemondView)
        UIView.animateWithDuration(0.4, animations: { () -> Void in
            
            self.alpha = 0.66
            self.customRemondView.alpha = 1.0
        })
    }
    
    // MARK: 
    // MARK: 点击自定义警告视图按钮的方法
    func onCustomRemondViewButtonClicked(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        UIView.animateWithDuration(0.4, animations: { () -> Void in
            
            self.alpha = 0
            self.customRemondView.alpha = 0
            }, completion: { (complete) -> Void in
                
                self.removeFromSuperview()
                self.customRemondView.removeFromSuperview()
                if sender.tag == 2016 {
                    
                    if self.delegate.respondsToSelector(Selector("onCustomAlertViewSureButtonAction:")) {
                        self.delegate.onCustomAlertViewSureButtonAction(self)
                        self.delegate = nil
                    }
                }
        })
    }
    
    func onCustomAlertViewTapGest(tapGesture: UITapGestureRecognizer) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        UIView.animateWithDuration(0.4, animations: { () -> Void in
            
            self.alpha = 0
            self.customRemondView.alpha = 0
            }, completion: { (complete) -> Void in
                
                self.removeFromSuperview()
                self.customRemondView.removeFromSuperview()
        })
        self.delegate = nil
    }
}
