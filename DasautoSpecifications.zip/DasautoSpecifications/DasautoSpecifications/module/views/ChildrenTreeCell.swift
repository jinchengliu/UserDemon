//
//  ChildrenTreeCell.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/16.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class ChildrenTreeCell: UITableViewCell {

    @IBOutlet weak var dotImageView: UIImageView!
    @IBOutlet weak var norrowImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        dotImageView.image = UIImage(named: "dot" + themeColor)
        norrowImageView.image = UIImage(named: "rightArrow" + themeColor)
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}
