//
//  SearchResultCell.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-15.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class SearchResultCell: UITableViewCell {

    var nameLabel: ThemeLabel?
    var descLabel: ThemeLabel?
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.nameLabel = ThemeLabel(frame: CGRectMake(20, 10, CGRectGetWidth(UIScreen.mainScreen().bounds) - 40, 25))
        self.nameLabel?.textColor = UIColor(red: 140/255, green: 140/255, blue: 139/255, alpha: 1.0)
        self.addSubview(self.nameLabel!)
        
        self.descLabel = ThemeLabel(frame: CGRectMake(20, CGRectGetMaxY(self.nameLabel!.frame) + 2 , CGRectGetWidth(UIScreen.mainScreen().bounds) - 40, 15))
        self.descLabel?.font = UIFont.systemFontOfSize(12)
        self.descLabel?.textColor = UIColor(red: 140/255, green: 140/255, blue: 139/255, alpha: 1.0)
        self.addSubview(self.descLabel!)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
