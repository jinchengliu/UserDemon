//
//  Helper.swift
//  登录注册demo
//
//  Created by cgg on 15/1/16.
//  Copyright (c) 2015年 equweiyu. All rights reserved.
//

import Foundation
import UIKit

/// iOS版本
var iOSVersion:Float = NSString(string: UIDevice.currentDevice().systemVersion).floatValue

/**
html颜色值转换为UIcolor

:param: value html颜色值

:returns: UIColor
*/
func HexRGB(value:Int) -> UIColor {
    
    let red = CGFloat((value&0xff0000)>>16)/255
    let green = CGFloat((value&0xff00)>>8)/255
    let blue = CGFloat(value&0xff)/255
    
    return UIColor(red: red, green: green, blue: blue, alpha: 1)
}


/**
html颜色值转换为UIcolor

:param: HexString 16进制颜色字符串
:param: alpha 透明度

:returns: UIColor
*/
func HexToColor(var HexString:String,alpha:CGFloat) -> UIColor {
    HexString = HexString.componentsSeparatedByString("#").last!
    HexString = HexString.componentsSeparatedByString("0x").last!
    var HexNum = UInt32()
    NSScanner(string: HexString).scanHexInt(&HexNum)
    let red = CGFloat((HexNum&0xff0000)>>16)/255
    let green = CGFloat((HexNum&0xff00)>>8)/255
    let blue = CGFloat(HexNum&0xff)/255
    return UIColor(red: red, green: green, blue: blue, alpha: alpha)
}
/**
在inview视图中间放置一个 UIActivityIndicatorView

:param: 放置的容器

:returns: UIActivityIndicatorView
*/
func ActivityIndicatorViewInView(inview:UIView) -> UIActivityIndicatorView {
    
    let activityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.WhiteLarge)
    activityIndicatorView.color = UIColor.grayColor()
    activityIndicatorView.hidesWhenStopped = true
    inview.addSubview(activityIndicatorView)
    inview.bringSubviewToFront(activityIndicatorView)
    
//    activityIndicatorView.translatesAutoresizingMaskIntoConstraints = false
//    activityIndicatorView.setTranslatesAutoresizingMaskIntoConstraints(false)
    
    let centerXLayoutConstraint = NSLayoutConstraint(item: activityIndicatorView, attribute: NSLayoutAttribute.CenterX, relatedBy: NSLayoutRelation.Equal, toItem: inview, attribute: NSLayoutAttribute.CenterX, multiplier: 1, constant: 0)
    let centerYLayoutConstraint = NSLayoutConstraint(item: activityIndicatorView, attribute: NSLayoutAttribute.CenterY, relatedBy: NSLayoutRelation.Equal, toItem: inview, attribute: NSLayoutAttribute.CenterY, multiplier: 1, constant: 0)
    inview.addConstraints([centerXLayoutConstraint,centerYLayoutConstraint])
    
    
    return activityIndicatorView
}

/**
*  辅助单例用于展示Alert
*/
class showAlertHelper: NSObject,UIAlertViewDelegate {
    
    struct Inner {
        
        static let instance:showAlertHelper = showAlertHelper()
    }
    class var shared:showAlertHelper {
        
        return Inner.instance
    }
    
    var cancelHandlerHelper:(() -> Void)!
    /**
    展示一个带有title的提示框
    
    :param: title        提示框内容
    :param: inController 弹出提示框的控制器
    */
    func showAlert(title:String,inController:UIViewController) {
        
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: nil, preferredStyle: UIAlertControllerStyle.Alert)
            inController.presentViewController(alert, animated: true, completion: nil)
            let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.Cancel, handler: nil)
            alert.addAction(cancelAction)
        } else {
            
            let alert = UIAlertView(title: title, message: nil, delegate: self, cancelButtonTitle: "确定")
            alert.show()
        }
//        if iOSVersion < 8.0 {
//            
//            let alert = UIAlertView(title: title, message: "删除", delegate: inController, cancelButtonTitle: "确定")
//            alert.show()
//        }else {
//            let alert = UIAlertController(title: title, message: nil, preferredStyle: UIAlertControllerStyle.Alert)
//            inController.presentViewController(alert, animated: true, completion: nil)
//            let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.Cancel, handler: nil)
//            alert.addAction(cancelAction)
//        }
    }
    /**
    展示一个带有title和handler的提示框
    
    :param: title        提示框内容
    :param: inController 弹出提示框的控制器
    :param: handler      点击确定调用的闭包
    */
    func showEXAlert(title:String,inController:UIViewController,handler:() -> Void ) {
        
        if #available(iOS 8.0, *) {
            
            let alert = UIAlertController(title: title, message: nil, preferredStyle: UIAlertControllerStyle.Alert)
            inController.presentViewController(alert, animated: true, completion: nil)
            let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.Cancel) { (action) -> Void in
                handler()
            }
            alert.addAction(cancelAction)
        } else {
            
            let alert = UIAlertView(title: title, message: nil, delegate: self, cancelButtonTitle: "确定")
            self.cancelHandlerHelper = handler
            alert.show()
        }
        
//        if iOSVersion < 8.0 {
//            let alert = UIAlertView(title: title, message: nil, delegate: self, cancelButtonTitle: "确定")
//            self.cancelHandlerHelper = handler
//            alert.show()
//        }else{
//            let alert = UIAlertController(title: title, message: nil, preferredStyle: UIAlertControllerStyle.Alert)
//            inController.presentViewController(alert, animated: true, completion: nil)
//            let cancelAction = UIAlertAction(title: "确定", style: UIAlertActionStyle.Cancel) { (action) -> Void in
//                handler()
//            }
//            alert.addAction(cancelAction)
//        }
    }
    
    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if self.cancelHandlerHelper != nil {
            self.cancelHandlerHelper()
        }
    }
}