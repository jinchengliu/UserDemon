//
//  QuickguideHotCell.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/27.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class QuickguideHotCell: UITableViewCell {

    @IBOutlet weak var hotImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCellWithDasautoFile(dasAutoFile: DasAutoFile) {
        
        let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + dasAutoFile.picFile)
        let image:UIImage =  UIImage(contentsOfFile: path)!
      
        hotImageView.image = image
        
        nameLabel.text = dasAutoFile.name
        if dasAutoFile.name == "驾驶员侧视图"
        {
            nameLabel.text = "概览图"
            hotImageView.contentMode = UIViewContentMode.ScaleAspectFit
            self.topConstraint.constant = 10
        }
    }
}
