//
//  IntellectualTechnologyCell.swift
//  DasautoSpecifications
//
//  Created by chenpan on 14/12/23.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class IntellectualTechnologyCell: UITableViewCell {
    
    @IBOutlet weak var intellectualImageView: UIImageView!
    @IBOutlet weak var nameLabel: ThemeLabel!
    @IBOutlet weak var durationLabel: ThemeLabel!
    @IBOutlet weak var favouriteImageView: UIImageView!
    @IBOutlet weak var favoriteButton: UIButton!
    
    var delegate: FavouriteLeafDelegate!
    
    @IBAction func onFavoriteButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        favoriteButton.selected = !favoriteButton.selected
        self.configureFavouriteImageView()
        if favoriteButton.selected {
            
            delegate.addFavouriteResouceId!(self)
        } else {
            
            delegate.cancelFavouriteResouceId!(self)
        }
    }
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
    }
    
    // MARK: 配置cell的UI
    func configureIntellectualTechnologyWith(das: DasAutoFile!) {
        
        if das == nil {
            
            return
        }
        let minute = Int(das.playTime)! / 60
        let second = Int(das.playTime)! % 60
        var playTime: String!
        if minute >= 10 {
            
            playTime = String(minute)
        }else {
            
            playTime = "0" + String(minute)
        }
        
        if second >= 10 {
            
            playTime = playTime + ":" + String(second)
        }else {
            
            playTime = playTime + ":" + "0" + String(second)
        }
        nameLabel.text = das.name
        durationLabel.text = "片长 " + playTime
        if das.picFile != nil {
            
            intellectualImageView.image = UIImage(contentsOfFile: DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + das.picFile))
        }
        self.configureFavouriteImageView()
    }
    
    func configureIntellectualCellWithDataArray(carModel: CarVideoModel) {
        
        let minute = Int(carModel.playTime.stringValue)! / 60
        let second = Int(carModel.playTime.stringValue)! % 60
        var playTime: String!
        if minute >= 10 {
            
            playTime = String(minute)
        }else {
            
            playTime = "0" + String(minute)
        }
        
        if second >= 10 {
            
            playTime = playTime + ":" + String(second)
        }else {
            
            playTime = playTime + ":" + "0" + String(second)
        }
        nameLabel.text = carModel.videoName
        durationLabel.text = "片长 " + playTime
        intellectualImageView.setImageWithURL(NSURL(string: carModel.picUrl))
        self.configureFavouriteImageView()
    }
    
    // MARK: 配置收藏视图
    func configureFavouriteImageView() {
        
        if favoriteButton.selected {
            
            favouriteImageView.image = UIImage(named: "personalFavourate" + themeColor)
        } else {
            
            favouriteImageView.image = UIImage(named: "personalFavourate_selected.png")
        }
    }
}
