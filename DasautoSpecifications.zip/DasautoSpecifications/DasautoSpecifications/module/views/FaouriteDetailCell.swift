//
//  FaouriteDetailCell.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-28.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class FaouriteDetailCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var describeLabel: UILabel!
    
    @IBOutlet weak var favouriteImageView: UIImageView!
    @IBOutlet weak var favouriteButton: UIButton!
    
    var delegate: FavouriteLeafDelegate!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        favouriteImageView.image = UIImage(named: "personalFavourate" + themeColor)
        favouriteButton.addTarget(self, action: Selector("favourteIt:"), forControlEvents: UIControlEvents.TouchUpInside)
        favouriteButton.tag = self.tag
    }

    func configureQuickguideCellWith(das: DasAutoFile) {
        
        titleLabel.text = das.name
        describeLabel.text = das.desc
        
        self.configureFavouriteImageView()
    }
    
    func configureFavouriteImageView() {
        
        if favouriteButton.selected {
            
            favouriteImageView.image = UIImage(named: "personalFavourate" + themeColor)
        } else {
            
            favouriteImageView.image = UIImage(named: "personalFavourate_selected.png")
        }
    }
    
    func favourteIt(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        favouriteButton.selected = !favouriteButton.selected
        self.configureFavouriteImageView()
        
        if favouriteButton.selected {
            
            delegate.addFavouriteResouceId!(self)
        } else {
            
            delegate.cancelFavouriteResouceId!(self)
        }
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
