//
//  MyMessageCell.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15-4-24.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class MyMessageCell: UITableViewCell {

    @IBOutlet weak var roundImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!

    override func awakeFromNib() {
        
        super.awakeFromNib()
        roundImageView.image = UIImage(named: "messageRound" + themeColor)
    }

    // MARK: 配置cell的ui
    func configureCellWithModel(model: MessageModel) {
        
        contentLabel.text = model.messageContent
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
