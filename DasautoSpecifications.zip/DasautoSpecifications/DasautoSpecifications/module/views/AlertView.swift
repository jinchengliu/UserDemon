//
//  AlertView.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-1.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class AlertView: UIView {
    
    let alertHeight: CGFloat = 50
    var contentLabel: UILabel?
    var hiddenTimer: NSTimer?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    convenience init(alertContent: String, bgColor: UIColor) {
        
        self.init()
        self.frame = CGRectMake(0, -alertHeight, CGRectGetWidth(UIScreen.mainScreen().bounds), alertHeight)
        if contentLabel==nil {
            
            contentLabel = UILabel(frame: self.bounds)
            contentLabel?.textAlignment = NSTextAlignment.Center
            contentLabel?.textColor = UIColor.whiteColor()
            self.addSubview(contentLabel!)
        }
        contentLabel?.text = alertContent
        self.backgroundColor = bgColor
    }
    
    // MARK: public function
    func setAlertContent(alertContent: String, bgColor: UIColor) {
        
        self.hiddenTimer?.invalidate()
        contentLabel?.text = alertContent
        self.backgroundColor = bgColor
    }
    
    func showAlertOnView(superView: UIView){
        
        superView.addSubview(self)
        var newFrame: CGRect = self.frame
        newFrame.origin.y = 0
        
        UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 0.8, initialSpringVelocity: 1.0, options: nil, animations: { () -> Void in
            self.frame = newFrame
        }) { (completetion) -> Void in
            if completetion {
                
                self.hiddenTimer = NSTimer.scheduledTimerWithTimeInterval(3, target: self, selector: Selector("hideAlert"), userInfo: nil, repeats: false)
            }
        }
    }
    
    func hideAlert() {
        
        var newFrame: CGRect = self.frame
        newFrame.origin.y = -alertHeight
        
        UIView.animateWithDuration(0.5, delay: 0.0, usingSpringWithDamping: 0.8, initialSpringVelocity: 1.0, options: nil, animations: { () -> Void in
            self.frame = newFrame
            }) { (completetion) -> Void in
                if completetion {
                    self.removeFromSuperview()
                }
        }
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
