/*
*  filename: GuideView.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/11/27.
*  copyright: bdcluster
*/

import UIKit

let kSubButtonHeight : CGFloat  = 40.0
let kSubButtonPadding: CGFloat = 5.0

class GuideView: UIView {

    var carTypeLabelButton: UIButton!
    var selectCarTypeButton: UIButton!
    var personalFavouriteButton: UIButton!
    var settingButton: UIButton!
    var feedBackButton: UIButton!
    var myMessageButton: UIButton!
    var aboutButton: UIButton!
    var myContentButton: UIButton!
    var subButtons: NSArray!
    
    // MARK:
    // MARK: init
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.backgroundColor = UIColor.grayColor();
        //顶部车型名称Label
        self.carTypeLabelButton = UIButton(frame: CGRectMake(0, 0, CGRectGetWidth(frame), 64))
        self.carTypeLabelButton.backgroundColor = UIColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 0.8)
        self.carTypeLabelButton.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        self.carTypeLabelButton.setTitle("当前车型: Lamando凌渡", forState: UIControlState.Normal)
        self.carTypeLabelButton.titleEdgeInsets = UIEdgeInsetsMake(32, 10, 12, 10)
        self.carTypeLabelButton.titleLabel?.font = UIFont.systemFontOfSize(18)
        self.addSubview(self.carTypeLabelButton)
        //底部车型图片
        let carImageView: UIImageView = UIImageView(image: UIImage(named: "guideCarImage"))
        carImageView.frame = CGRectMake(0, CGRectGetHeight(frame) - 325, 320, 325)
        self.addSubview(carImageView)
        
        //添加按钮
        let tmpSubButtons: NSMutableArray = NSMutableArray(capacity: 6)
        self.selectCarTypeButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.carTypeLabelButton.frame) + 30, CGRectGetWidth(frame), kSubButtonHeight), title: "选择车型",imageName: "selectCarType")
        self.addSubview(selectCarTypeButton)
        tmpSubButtons.addObject(self.selectCarTypeButton)
        
        self.personalFavouriteButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.selectCarTypeButton.frame) + kSubButtonPadding, CGRectGetWidth(frame), kSubButtonHeight), title: "个人收藏", imageName: "collect")
        self.addSubview(personalFavouriteButton)
        tmpSubButtons.addObject(self.personalFavouriteButton)
        
        self.myMessageButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.personalFavouriteButton.frame) + kSubButtonPadding, CGRectGetWidth(frame), kSubButtonHeight), title: "我的消息", imageName: "myMessage")
        self.addSubview(myMessageButton)
        tmpSubButtons.addObject(self.myMessageButton)
        
        self.myContentButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.myMessageButton.frame) + kSubButtonPadding, CGRectGetWidth(frame), kSubButtonHeight), title: "下载管理", imageName: "wdxz")
        self.addSubview(myContentButton)
        tmpSubButtons.addObject(self.myContentButton)
        
        self.settingButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.myContentButton.frame) + kSubButtonPadding, CGRectGetWidth(frame), kSubButtonHeight), title: "功能设置", imageName: "setting")
        self.addSubview(settingButton)
        tmpSubButtons.addObject(self.settingButton)
        
        self.aboutButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.settingButton.frame) + kSubButtonPadding, CGRectGetWidth(frame), kSubButtonHeight), title: "账号管理", imageName: "about")
        self.addSubview(aboutButton)
        tmpSubButtons.addObject(self.aboutButton)
        
        self.feedBackButton = self.addSubButtonWithFrame(CGRectMake(0, CGRectGetMaxY(self.aboutButton.frame) + kSubButtonPadding, CGRectGetWidth(frame), kSubButtonHeight), title: "用户反馈", imageName: "feedBack")
        self.addSubview(feedBackButton)
        tmpSubButtons.addObject(self.feedBackButton)
        
        self.subButtons = NSArray(array: tmpSubButtons)
    }

    // MARK:
    // MARK: private function
    func addSubButtonWithFrame(frame :CGRect, title: String, imageName: String) -> UIButton {
        
        let subButton :UIButton! = UIButton(type: .Custom)
        subButton.titleLabel!.textColor = UIColor.whiteColor()
        subButton.frame = frame
        subButton.setTitle(title, forState: .Normal)
        subButton.setImage(UIImage(named: imageName), forState: UIControlState.Normal)
        subButton.setImage(UIImage(named: "\(imageName)_selected"), forState: UIControlState.Highlighted)
        subButton.imageEdgeInsets = UIEdgeInsetsMake(-13, -100, -10, -10)
        subButton.titleEdgeInsets = UIEdgeInsetsMake(0, -50, 0, 0)
        subButton.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        subButton.setTitleColor(UIColor(red: 230/255, green: 40/255, blue: 80/255, alpha: 1.0), forState: UIControlState.Highlighted)
        subButton.titleLabel?.font = UIFont.systemFontOfSize(16)
        return subButton
    }
    
    // MARK: 
    // MARK: public function
    func setSubButtonsUnselectedExcept(button: UIButton){
        
        for item in subButtons {
            let subButton = item as! UIButton
            if subButton == button {
                subButton.selected = true
            }else{
                subButton.selected = false
            }
        }
    }
    
    func setAllSubButtonsUnselected(){
        
        for item in subButtons {
            let subButton = item as! UIButton
            subButton.selected = false
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}