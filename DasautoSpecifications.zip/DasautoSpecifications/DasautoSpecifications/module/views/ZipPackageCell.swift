//
//  ZipPackageCell.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-24.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

protocol ZipPackageCellDelegate {
    /**
     *  下载完成之后回调给controller, 判断是否需要解压zip
     */
    func zipPackageDidDownloadCompleted(zip:ZipPackage)
}

class ZipPackageCell: UITableViewCell {

    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var downloadingView: UIView!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var downloadCompleteView: UIView!
    @IBOutlet weak var canDownloadView: UIView!
    @IBOutlet weak var successLabel: UILabel!
    @IBOutlet weak var downloadStatusLabel: UILabel!
    @IBOutlet weak var controlButton: UIButton!
    @IBOutlet weak var loadButton: UIButton!
    
    var delegate: ZipPackageCellDelegate!
    var totalSize:String?
    var valueString: String!
    private var zip: ZipPackage!
    private var operation: AFHTTPRequestOperation!
    
    // MARK:
    // MARK: Life Cycle
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        var color: UIColor!
        if themeColor == "_red" {
            color = UIColor(red: 232/255, green: 26/255, blue: 77/255, alpha: 1.0)
        }
        else if themeColor == "_blue" {
            color = UIColor(red:0, green:0.56, blue:0.84, alpha:1)
        }
        else {
            color = UIColor(red:0.82, green:0.67, blue:0.5, alpha:1)
        }
        self.controlButton.setImage(UIImage(named: "stop" + themeColor), forState: UIControlState.Normal)
        self.controlButton.setImage(UIImage(named: "play" + themeColor), forState: UIControlState.Selected)
        
        self.loadButton.setTitleColor(color, forState: .Normal)
        self.progressView.tintColor = color
        self.successLabel.textColor = color
        
        // 不能放在主线程, 防止阻塞主线程刷新UI
        dispatch_async(DSDownloadManager.shareInstance().downloadZipQueue) { () -> Void in
            NSNotificationCenter.defaultCenter().addObserver(self, selector: "downloadOperationUpdate:", name: "downloadOperationUpdate", object: nil)
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "downloadStateChanged:", name: "downloadStateChanged", object: nil)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        
        super.setSelected(selected, animated: animated)
    }
    
    /**
     *  刷新cell
     */
    func setZipPackage(zipPackage: ZipPackage) {
        self.zip = zipPackage
        if zipPackage.picUrl != nil {
            self.iconImageView.setImageWithURL(NSURL(string: zipPackage.picUrl))
        }
        self.titleLabel.text = zipPackage.carName
        var isIncludeVideo: String!
        if zipPackage.isIncludeVideo == "true" {
            isIncludeVideo = "完整版 "
        }
        else {
            isIncludeVideo = "无视频版 "
        }
        self.subTitleLabel.text = isIncludeVideo + zipPackage.zipSize + "MB"
        
        self.configureCellAfterRestartApp()
        self.changeCellState()
        
    }
    
    /**
     *  重新启动app, 判读是否还有未下载完成的zip
     */
    func configureCellAfterRestartApp() {
        
        /*
        1. 通过url是否在队列中,
        */
        if self.zip.state == ZipPackageDownloadState.downloading || self.zip.state == ZipPackageDownloadState.downloadPause{
            // 根据url获取operation是否存在
            let isStart = DSDownloadManager.shareInstance().isStartOperation(self.zip.urlString)
            if isStart == false {
                let fileManager =  DSFileManager.sharedInstance
                let zipFilePath = fileManager.getFileAtDownload(self.zip.zipName)
                var loadedSize:Int64 = 0
                var allSize:Int64 = 0
                if fileManager.isExist(zipFilePath) {
                    // 获取已下载的大小
                    loadedSize = fileManager.getFileSize(zipFilePath)
                    allSize = self.zip.operationAllSize
                }
                if self.zip.state == ZipPackageDownloadState.downloading  {
                    self.zip.state = ZipPackageDownloadState.downloadPause
                }
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    self.progressView.progress = Float(loadedSize) / Float(allSize)
                    self.downloadStatusLabel.text = "正在加载文字和图像  " + String((loadedSize * 100) / allSize) + "%"
                })
                
            }
        }
    }
    
    // MARK:
    // MARK: NSNotificationCenter
    /**
    *  刷新下载进度
    */
    func downloadOperationUpdate(noti: NSNotification) {
        let operation = noti.object as! RFFileDownloadOperation
        let loaded = operation.bytesDownloaded()
        let fileSize = operation.bytesFileSize()
        
        if (zip != nil) {
            if zip.urlString == operation.request.URL!.absoluteString {
                if zip.operationAllSize == nil {
                    zip.operationAllSize = fileSize
                    DataModel.sharedInstance.savePackageManager()
                }
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    let valueString: String? = (loaded * 100 / fileSize).description
                    if valueString != nil {
                        self.progressView.progress = Float(loaded) / Float(fileSize)
                        self.downloadStatusLabel.text = "正在加载文字和图像  " + valueString! + "%"
                    }
                })
            }
        }
    }
    
    /**
     *  下载状态的改变
     */
     /*
     AddDown        添加下载
     PauseDown      暂停下载
     CancelDown     取消下载
     WaitDown       等待下载
     Downloading    下载中
     CompleteDown   完成下载
     FailDown       下载失败
     */
    func downloadStateChanged(noti: NSNotification) {
        let dict = noti.object as! NSDictionary
        let url = dict["url"] as! String
        if self.zip != nil {
            if self.zip.urlString == url {
                let state = dict["state"] as! String
                if state == "AddDown" {
                    self.zip.state = ZipPackageDownloadState.downloadStart
                    self.startState()
                }
                else if state == "PauseDown"{
                    self.zip.state = ZipPackageDownloadState.downloadPause
                    self.pauseState()
                }
                else if state == "CancelDown"{
                    self.zip.state = ZipPackageDownloadState.downloadPause
                    self.pauseState()
                }
                else if state == "WaitDown"{
                    self.zip.state = ZipPackageDownloadState.downloadPause
                    self.pauseState()
                }
                else if state == "Downloading"{
                    self.zip.state = ZipPackageDownloadState.downloading
                    self.downloadingState()
                }
                else if state == "CompleteDown"{
                    for zip in PackageFileManager.sharedInstance.packages {
                        if zip.zipNameWithoutsubffix == self.zip.zipNameWithoutsubffix {
                            if zip.state != ZipPackageDownloadState.downloadCompleted {
                                self.zip.state = ZipPackageDownloadState.downloadCompleted
                                zip.state = ZipPackageDownloadState.downloadCompleted
                                DataModel.sharedInstance.savePackageManager()
                                self.completedState()
                            }
                        }
                    }
                    dispatch_async(dispatch_get_main_queue()) { () -> Void in
                        self.downloadingView.hidden = true
                        self.canDownloadView.hidden = true
                        self.downloadCompleteView.hidden = false
                        self.successLabel.text = "下载成功"
                    }
                }
                else if state == "FailDown"{
                    self.zip.state = ZipPackageDownloadState.downloadPause
                    
                    DSDownloadManager.shareInstance().pauseZip(self.zip.urlString)
                    self.pauseState()
                }
            }
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中开始下载
    */
    @IBAction func startDownload(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if zip != nil {
            if DSDownloadManager.shareInstance().isStartOperation(zip.urlString) {
                DSDownloadManager.shareInstance().resumeZip(zip.urlString)
            }else {
                DSDownloadManager.shareInstance().addZipToDown(self.zip)
            }
        }
    }
    
    /**
    *  选中暂停和继续__判断网络
    */
    @IBAction func continueOrPauseDownload(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if AFNetworkReachabilityManager.sharedManager().reachable == false {
            let reminderView = NSBundle.mainBundle().loadNibNamed("RemindView", owner: nil, options: nil)[0] as! RemindView
            reminderView.showReminderView("当前网络不可用", isSuccess: false)
            return
        }
        
//        self.controlButton.selected = !self.controlButton.selected
        if self.zip.state == ZipPackageDownloadState.downloading {

            DSDownloadManager.shareInstance().pauseZip(zip.urlString)
        }
        else if self.zip.state == ZipPackageDownloadState.downloadPause{

            let isStart = DSDownloadManager.shareInstance().isStartOperation(self.zip.urlString)
            if isStart {
                DSDownloadManager.shareInstance().resumeZip(zip.urlString)
            }
            else {
                DSDownloadManager.shareInstance().addZipToDown(self.zip)
            }
        }
        
        DataModel.sharedInstance.savePackageManager()
    }

    // MARK:
    // MARK: 设置下载状态
    func changeCellState() {
        
        if self.zip != nil {
            
            if self.zip.state == ZipPackageDownloadState.downloadStart {
                self.startState()
            }
            else if self.zip.state == ZipPackageDownloadState.downloading {
                self.downloadingState()
            }
            else if self.zip.state == ZipPackageDownloadState.downloadPause {
                self.pauseState()
            }
            else if self.zip.state == ZipPackageDownloadState.downloadCompleted{
                self.completedState()
            }
            else if self.zip.state == ZipPackageDownloadState.hadUnzip{
                self.completedState()
            }
            else if self.zip.state == ZipPackageDownloadState.isUsing {
                self.isUsingState()
            }
            else if self.zip.state == ZipPackageDownloadState.downloadError {
                self.startState()
            }
        }
    }
    
    ///未下载状态
    func startState() {
        
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.canDownloadView.hidden = false
            self.downloadingView.hidden = true
            self.downloadCompleteView.hidden = true
        }
    }
    
    ///正在下载状态
    func downloadingState() {
        
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.downloadingView.hidden = false
            self.canDownloadView.hidden = true
            self.downloadCompleteView.hidden = true
            self.controlButton.selected = false
        }
    }
    
    ///暂停下载状态
    func pauseState() {
        
        var loadedSize: Int64!
        var allSize: Int64!
        if self.progressView.progress == 0 {
            let fileManager =  DSFileManager.sharedInstance
            let zipFilePath = fileManager.getFileAtDownload(self.zip.zipName)
            // 获取已下载的大小
            if fileManager.isExist(zipFilePath) {
                loadedSize = fileManager.getFileSize(zipFilePath)
                allSize = self.zip.operationAllSize
            }
        }

        dispatch_async(dispatch_get_main_queue()) { () -> Void in
        
            self.downloadingView.hidden = false
            self.canDownloadView.hidden = true
            self.downloadCompleteView.hidden = true
            self.controlButton.selected = true
            
            if allSize != nil {
                self.progressView.progress = Float(loadedSize) / Float(allSize)
                self.downloadStatusLabel.text = "正在加载文字和图像  " + String((loadedSize * 100) / allSize) + "%"
            }
        }
    }
    
    ///下载完成状态
    func completedState() {
        
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.downloadingView.hidden = true
            self.canDownloadView.hidden = true
            self.downloadCompleteView.hidden = false
            self.successLabel.text = "下载成功"
            if self.delegate != nil  {
                self.delegate.zipPackageDidDownloadCompleted(self.zip)
            }
        }
    }
    
    ///正在应用状态
    func isUsingState() {
        
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.downloadingView.hidden = true
            self.canDownloadView.hidden = true
            self.downloadCompleteView.hidden = false
            self.successLabel.text = "正在应用中"
        }
    }
}
