//
//  DownloadHistoryCell.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/30.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class DownloadHistoryCell: UITableViewCell {

    @IBOutlet weak var carImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var sizeLabel: UILabel!
    
    var carTypeModel:CarTypeModel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCellWithArray(carTypeModel: CarTypeModel) {
        
        carImageView.setImageWithURL(NSURL(string: carTypeModel.picUrl))
        titleLabel.text = carTypeModel.carModel
        sizeLabel.text  = carTypeModel.size.description + "MB"
        
        if carTypeModel.type as! Int == 1
        {
            typeLabel.text = "完整版"
        }else
        {
            typeLabel.text = "无视频版"
        }
        
        typeLabel.textColor = UIColor.blackColor()
        sizeLabel.textColor = UIColor.blackColor()
    }
    class func getHeight()->CGFloat
    {
        return 110
    }
}
