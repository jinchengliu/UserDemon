//
//  RemindView.swift
//  DasautoSpecifications
//
//  Created by wangrui on 16/1/21.
//  Copyright © 2016年 bdcluster. All rights reserved.
//

import UIKit


class RemindView: UIView {

    @IBOutlet weak var backImageView: UIImageView!
    @IBOutlet weak var remindLabel: UILabel!
    @IBOutlet weak var backImageViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var backImageViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var remindLabelHeightConstraint: NSLayoutConstraint!
    
    /**
     *  显示弹框提示视图_isSuccess = true 表示登录成功
     */
    func showReminderView(title: String, isSuccess:Bool) {
        
        let keyWindow = Util.getKeyWindow()
        self.frame = keyWindow.bounds
        keyWindow.addSubview(self)
        
        remindLabel.text = title
        if isSuccess {
            backImageView.image = UIImage(named: "successImage")
            backImageViewHeightConstraint.constant = 125
            backImageViewWidthConstraint.constant = 125
            remindLabelHeightConstraint.constant = 75
        }else {
            self.backgroundColor = UIColor.clearColor()
        }
        UIView.animateWithDuration(2 , animations: { () -> Void in
            self.alpha = 0
            }, completion: { (complete) -> Void in
                self.removeFromSuperview()
        })
    }
}
