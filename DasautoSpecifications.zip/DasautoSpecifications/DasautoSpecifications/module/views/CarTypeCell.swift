/*
*  filename: CarTypeCell.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/11/28.
*  copyright: bdcluster
*/

import UIKit

class CarTypeCell: UITableViewCell {

    var cellContentView: UIView!
    var carTypeImageView: UIImageView?
    var titleLabel: UILabel!
    var coverView: UIView!
    
    init(style: UITableViewCellStyle, reuseIdentifier: String?, contentFrame: CGRect) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.clipsToBounds = true
        cellContentView = UIView()
        cellContentView.clipsToBounds = true
//        let cellWidth: CGFloat = CGRectGetWidth(UIScreen.mainScreen().bounds)
        cellContentView.frame = contentFrame
        cellContentView.backgroundColor = UIColor.grayColor()
        self.addSubview(cellContentView!)
        
        // TODO:根据UI，调整车型包cell界面显示
        carTypeImageView = UIImageView(frame: cellContentView.bounds)
        carTypeImageView?.contentMode = UIViewContentMode.ScaleAspectFill
        cellContentView.addSubview(carTypeImageView!)
        
        let shadeView: UIView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(cellContentView.bounds), 40))
        shadeView.backgroundColor = UIColor.blackColor()
        shadeView.alpha = 0.6
        cellContentView.addSubview(shadeView)
        
        titleLabel = UILabel(frame: shadeView.bounds)
        titleLabel.textAlignment = NSTextAlignment.Center
        titleLabel.textColor = UIColor.whiteColor()
        cellContentView.addSubview(titleLabel)
        
        coverView = UIView(frame: cellContentView.bounds)
        coverView.backgroundColor = UIColor.whiteColor()
        coverView.alpha = 0.5
        cellContentView.addSubview(coverView)
    }
    
    // MARK:
    // MARK:Public Function
    func showCoverView() {
        
        coverView.hidden = false
    }
    
    func hideCoverView() {
        
        coverView.hidden = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        
        super.setSelected(selected, animated: animated)
    }
}
