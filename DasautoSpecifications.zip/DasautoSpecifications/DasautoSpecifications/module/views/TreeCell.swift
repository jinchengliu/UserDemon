//
//  TreeCell.swift
//  DasautoSpecifications
//
//  Created by chenpan on 14/12/11.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class TreeCell: UITableViewCell {

    var das: DasAutoFile!
    var isOpen: Bool = false
    var isDirectory = true
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var narrowImageView: UIImageView!
    
    func configureTreeCell(das: DasAutoFile) {
        
        self.das = das
        self.nameLabel.text = das.name

    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        narrowImageView.image = UIImage(named: "rightArrow" + themeColor)
    }
    
    override func willMoveToSuperview(newSuperview: UIView?)
    {
//        if isOpen == true
//        {
//            narrowImageView.transform = CGAffineTransformMakeRotation(CGFloat(M_PI/2))
//        }else
//        {
//            narrowImageView.transform = CGAffineTransformIdentity
//        }
       
    }
}
