//
//  WallPaperCell.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/11.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class WallPaperCell: UITableViewCell {

    @IBOutlet weak var imageViewOne: UIImageView!
    @IBOutlet weak var imageViewSecond: UIImageView!
    
    var checkImageView: UIImageView!
    var wallPaperClosure: (()->())?
    var hasCheckImageView: Bool = false
    var index: Int!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        imageViewOne.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onImageViewOneTapGesture:"))
        imageViewSecond.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onImageViewSecondTapGesture:"))
    }

    override func setSelected(selected: Bool, animated: Bool) {
        
        super.setSelected(selected, animated: animated)
    }
    
    func configureImageView(fileName: String, fileNameSecond: String) {
        
        imageViewOne.image = UIImage(contentsOfFile: fileName)
        imageViewSecond.image = UIImage(contentsOfFile: fileNameSecond)
    }
    
    func configureImageViewOne(fileName: String) {
        
        imageViewOne.image = UIImage(contentsOfFile: fileName)
        imageViewSecond.userInteractionEnabled = false
    }
    
    //选中第一张图
    func selectFirstImage() {
        
        index = 0
        let frame = UIScreen.mainScreen().bounds
        self.configureCheckImageView(frame.size.width/2-10, yFloat: 15)
    }
    
    //选中第二张图
    func selectSecondImage() {
        
        index = 1
        let frame = UIScreen.mainScreen().bounds
        self.configureCheckImageView(frame.size.width-10, yFloat: 15)
    }
    
    // 配置checkImageView
    func configureCheckImageView(xFloat: CGFloat, yFloat: CGFloat) {
        
        if hasCheckImageView == true {
            
            UIView.animateWithDuration(0.5, animations: { () -> Void in
                
                self.checkImageView.hidden = true
            }, completion: { (complete) -> Void in
                
                self.checkImageView.hidden = false
                self.checkImageView.frame = CGRectMake(xFloat - 8, yFloat - 8, 15, 15)
            })
        }else {
            
            hasCheckImageView = true
            checkImageView = UIImageView(frame: CGRectMake(xFloat - 8, yFloat - 8, 15, 15))
            checkImageView.image = UIImage(named: "roundCheck" + themeColor)
            self.addSubview(checkImageView)
        }
    }
    
    // MARK: 点击图片手势方法
    func onImageViewOneTapGesture(tapGesture: UITapGestureRecognizer) {
        
        index = 0
        self.selected = true
        self.wallPaperClosure?()
        SystemConfigureManager.sharedInstance.makeSoundEffect()
    }
    
    func onImageViewSecondTapGesture(tapGesture: UITapGestureRecognizer) {
        
        index = 1
        self.selected = true
        self.wallPaperClosure?()
        SystemConfigureManager.sharedInstance.makeSoundEffect()
    }
}
