//
//  QuickguideCell.swift
//  DasautoSpecifications
//
//  Created by chenpan on 14/12/22.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class QuickguideCell: UITableViewCell {

    @IBOutlet weak var guideImageView: UIImageView!
    @IBOutlet weak var titleLabel: ThemeLabel!
    @IBOutlet weak var subTitleLabel: ThemeLabel!
    @IBOutlet weak var favouriteImageView: ThemeImageView!
    @IBOutlet weak var favouriteButton: UIButton!
    
    var delegate: FavouriteLeafDelegate!
    
    override func awakeFromNib() {
    
        super.awakeFromNib()
        self.selectionStyle = UITableViewCellSelectionStyle.None
        favouriteButton.addTarget(self, action: Selector("favourteIt:"), forControlEvents: UIControlEvents.TouchUpInside)
        favouriteButton.tag = self.tag
    }
    
    func configureQuickguideCellWith(das: DasAutoFile) {
        
        titleLabel.text = das.name
        subTitleLabel.text = das.desc
        
        if das.picFile != nil {
            
            let path = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/picture/" + das.picFile)
            guideImageView.image = UIImage(contentsOfFile: path)
        }
        self.configureFavouriteImageView()
    }
    
    // MARK: 配置收藏视图
    func configureFavouriteImageView() {
        
        if favouriteButton.selected {
            
            favouriteImageView.image = UIImage(named: "personalFavourate" + themeColor)
        } else {
            
            favouriteImageView.image = UIImage(named: "personalFavourate_selected.png")
        }
    }
    
    func favourteIt(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        favouriteButton.selected = !favouriteButton.selected
        self.configureFavouriteImageView()
        
        if favouriteButton.selected {
            
            delegate.addFavouriteResouceId!(self)
        } else {
            
            delegate.cancelFavouriteResouceId!(self)
        }
    }
}
