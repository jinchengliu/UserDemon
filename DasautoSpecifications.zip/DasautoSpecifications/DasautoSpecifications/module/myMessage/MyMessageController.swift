/*
*  filename: MyMessageController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/1.
*  copyright: bdcluster
*/

import UIKit

class MyMessageController: DasautoController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noMessageLabel: UILabel! //警示label
    
    var delegate: GuideMenuDelegate?
    var dataArray: NSMutableArray = []       // 存放i消息列表:messageModel
    var messageId: Int = 0                   // 消息Id,删除消息的时候需要
    
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) { 
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
        self.delegate?.didCloseGuideMenu!()
    }
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            noMessageLabel.text = "暂无消息"
            self.getMessage()
        }else {
            
            noMessageLabel.hidden = false
            noMessageLabel.text = "网络连接错误";
            self.showRendView("当前网络不可用", isSuccess: false)
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  请求消息
    */
    func getMessage() {
        
        let param: NSDictionary = ["userId": Int(kUserId)!]
        AFOperationManager.sharedInstance.startPostOperation( HttpBaseUrl + kUserMessageList, param: param, withToken:true,success: { (operation, responseObject) -> Void in
            
            
            let mutableDic: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                
                self.dealWithInformationFromNetwork(mutableDic!)
            }
            }) { (operation, error) -> Void in
                
                self.noMessageLabel.hidden = false
                Logger.info("_____________\(error)")
        }
    }
    
    // 处理请求message返回的信息
    func dealWithInformationFromNetwork(mutableDic: NSMutableDictionary) {
        
        let respCode = mutableDic.objectForKey("respCode") as! String
        if respCode == "000000" {
            
            let messageArray: NSArray = mutableDic.objectForKey("messages") as! NSArray
            if messageArray.count != 0 {
                
                for var i = 0; i < messageArray.count; i++ {
                    
                    let messageModel: MessageModel = MessageModel(JSONDic: messageArray[i] as! NSDictionary)
                    self.dataArray.addObject(messageModel)
                }
                self.tableView.reloadData()
            }else {
                
                //TODO 消息列表为空时走这，如果需要给用户提醒，可以在这里添加代码
                self.noMessageLabel.hidden = false
            }
        }else {
            
            self.showRendView(mutableDic.objectForKey("memo") as! String, isSuccess: false)
        }
    }
    
    /**
    *  删除消息
    */
    func delegateMessage(index: Int) {
        
        if kUserId != "noLogin" {
            
            let messageModel = dataArray[index] as! MessageModel
            let userDict: NSDictionary = ["userId": Int(kUserId)!, "messageId": messageModel.id]
            
            AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kUserMessageDelete, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
                
                let mutableDic = responseObject as? NSMutableDictionary
                Logger.debug("\(mutableDic)")
                if mutableDic != nil {
                    
                    //TODO 后期添加删除消息提醒的话在这里写
                }
                }) { (operation, error) -> Void in
                    Logger.info("_____________\(error)")
            }
        }
    }
    
    // MARK: 
    // MARK: UITableViewDataSource
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dataArray.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cellId") as! MyMessageCell
        let messageModel = dataArray[indexPath.row] as! MessageModel
        cell.configureCellWithModel(messageModel)
        
        return cell
    }
    
    func tableView(tableView: UITableView, titleForDeleteConfirmationButtonForRowAtIndexPath indexPath: NSIndexPath) -> String? {
        
        return "删除"
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            
            if AFNetworkReachabilityManager.sharedManager().reachable == true {
                
                self.delegateMessage(indexPath.row)
                dataArray.removeObjectAtIndex(indexPath.row)
                tableView.reloadData()
                if dataArray.count == 0 {
                    
                    noMessageLabel.text = "暂无消息"
                    noMessageLabel.hidden = false
                }
            }else {
                
                self.showRendView("当前网络不可用", isSuccess: false)
            }
        }
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
    
}
