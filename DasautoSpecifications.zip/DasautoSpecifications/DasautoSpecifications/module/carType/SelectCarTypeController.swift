 /*
*  filename: SelectCarTypeController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/11/28.
*  copyright: bdcluster
*/

import UIKit

class SelectCarTypeController: DasautoController, UITableViewDelegate, UITableViewDataSource, ModelYearViewDelegate {

    @IBOutlet weak var carTypeListTableView: UITableView!
    @IBOutlet weak var noSelectButton: UIButton!
    @IBOutlet weak var noNetworkBackgroundView: UIView!
    
    @IBOutlet weak var refreshButton: UIButton!
    var grayView: UIView!
    var customRemondView: UIView!
    var currentIndex: Int!
    var paddingHeight: CGFloat?
    var itemHeight: CGFloat!
    var scrollTimer: NSTimer?
    var delegate: GuideMenuDelegate?
    let kCellTagBasicNumber: Int = 10000
    var dataArray: NSMutableArray = [] //数据源数组
    
    var isRootViewController: Bool!
    var tmpCells: NSArray?      //滚动过程中，将这些可见cell设为不可点击，以便滑动。滚动结束，将这些cell恢复点击事件。
    var carArray: NSMutableArray!     //  存放下载车型包的信息
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.setButtonTitleColor(noSelectButton)
        self.loadCarTypeList()
        
        //设置scrollView滚动速率（0.0-1.0）
        self.carTypeListTableView.decelerationRate = 1.0
        currentIndex = -1
        // FIXME:按照需要更改Cell高度
        self.itemHeight = CGFloat(CGRectGetWidth(UIScreen.mainScreen().bounds)*220/320)       //根据屏幕宽度计算每个车型高度,比例为320，260
        self.carTypeListTableView.addObserver(self, forKeyPath: "contentOffset", options: [.New, .Old], context: nil)
        
        // MARK: 还未用得到
        if self.isRootViewController == true {
            
            self.addTitleViewAndBarButtonToNavigationBar()
        }
        
        scrollTimer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: Selector("scrollTableView"), userInfo: nil, repeats: true)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func shouldAutorotate() -> Bool {
        
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        
        return UIInterfaceOrientationMask.Portrait
    }
    
    // MARK:
    // MARK: KVO
    /**
    *  为carTypeListTableView添加contentOffset观察
    */
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        if keyPath == "contentOffset" {
            let newIndex: Int = self.indexForCurrentOffset()
            if newIndex != -1 && currentIndex != newIndex && newIndex != 0 && newIndex != self.dataArray.count + 1{
                if (currentIndex != -1 ) {
                    let oldIndexPath: NSIndexPath = NSIndexPath(forRow: currentIndex, inSection: 0)
                    if (carTypeListTableView.cellForRowAtIndexPath(oldIndexPath) != nil) {
                        let oldCell: CarTypeCell = carTypeListTableView.cellForRowAtIndexPath(oldIndexPath)! as! CarTypeCell
                        UIView.animateWithDuration(0.5, animations: { () -> Void in
                            oldCell.cellContentView.layer.transform = CATransform3DIdentity
                            oldCell.showCoverView()
                        })
                    }
                }
                
                let newIndexPath: NSIndexPath = NSIndexPath(forRow: newIndex, inSection: 0)
                if (carTypeListTableView.cellForRowAtIndexPath(newIndexPath) != nil) {
                    let newCell: CarTypeCell = carTypeListTableView.cellForRowAtIndexPath(newIndexPath)! as! CarTypeCell
                    UIView.animateWithDuration(0.5, animations: { () -> Void in
                        // 按照需要更改方法系数
                        newCell.cellContentView.layer.transform = CATransform3DMakeScale(1.1, 1.1, 1)
                        self.currentIndex = newIndex
                        newCell.hideCoverView()
                    })
                }
            }
        }
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置navigationItem
    */
    func addTitleViewAndBarButtonToNavigationBar() {
        
        let menuBarButton: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "menu"), style: UIBarButtonItemStyle.Plain, target: self, action: Selector("openOrCloseGuideMenu:"))
        self.navigationItem.leftBarButtonItem = menuBarButton
        
        self.navigationController?.navigationBar.tintColor = UIColor.blackColor()
        let logoImageView: UIImageView = UIImageView(frame: CGRectMake(0, 12, 100, 20))
        logoImageView.image = UIImage(named: "logo")
        self.navigationItem.titleView = logoImageView
    }
    
    
    /**
     *  显示网络加载失败视图
     */
    func showNoNetworkBackgroundView () {
        
        if self.noNetworkBackgroundView.hidden {
            
            self.noNetworkBackgroundView.hidden = false
            self.refreshButton.layer.cornerRadius = 3
            self.refreshButton.layer.borderWidth = 1
            self.refreshButton.layer.borderColor = UIColor(red: 35.0/255.0, green: 167.0/255.0, blue: 241.0/255.0, alpha: 1.0).CGColor
            self.refreshButton.layer.masksToBounds = true
        }
    }
    
    /**
     *  隐藏网络加载失败视图
     */
    func hideNoNetworkBackgroundView () {
        
        if !self.noNetworkBackgroundView.hidden {
            
            self.noNetworkBackgroundView.hidden = true;
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中重新加载
    */
    @IBAction func onRefreshButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.loadCarTypeList()
    }
    
    /**
     *  选中暂不选择
     */
    @IBAction func onNoSelectedButtonAction(sender: AnyObject) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        NSNotificationCenter.defaultCenter().postNotificationName("setMainController", object: nil)
    }
    
    /**
     *  选中返回
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
        self.delegate?.didCloseGuideMenu!()
    }
    
    /**
     *  选中打开或者关闭侧边栏
     */
    func openOrCloseGuideMenu(sender: UIBarButtonItem) {
        
        self.delegate?.didOpenOrCloseGuideMenu!()
    }
    
    // MARK: UITapGestureRecognizer
    /**
    *  点击某个车型
    */
    func handleTapGesture(tapGesture: UITapGestureRecognizer) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                
                self.carTypeListTableView.contentOffset = self.offsetForCellTag(tapGesture.view!.tag)
                }) { (completetion) -> Void in
                    
                    if completetion {
                        
                        let index: Int = tapGesture.view!.tag - self.kCellTagBasicNumber
                        Logger.debug("选中车型index:\(index)")
                        self.scrollTimer?.invalidate()
                        self.scrollTimer = nil
                        let width: CGFloat = CGRectGetWidth(UIScreen.mainScreen().bounds)*0.8*1.1
                        
                        var  height:CGFloat = 331
                        let ss = UIScreen.mainScreen().bounds.size.height
                        
                        if ss > 568 && ss <= 667
                        {
                            height = 348
                        }else if ss > 667 && ss <= 736
                        {
                            height = 361
                        }
                        
                        /*
                        case downloadStart        // 开始下载
                        case downloading          // 下载中
                        case downloadPause        // 暂停下载
                        case downloadError        // 下载失败
                        case downloadCompleted    // 下载完成(但是还没有解压)
                        case unZipping            // 正在解压
                        case hadUnzip             // 已经解压
                        case isUsing              // 应用中
                        case None
                        */
                        let carTypeModel = self.dataArray[index-1] as! CarTypeModel
                        var modelYearView: ModelYearView
                        if carTypeModel.carYearList!.count != 0 {
                            
                            let yearDic = carTypeModel.carYearList!.objectAtIndex(0) as? NSDictionary
                            let carYear = yearDic?.objectForKey("carYear") as! String
                            let zipMessage = self.getAllZipPackagesHadDownload(carTypeModel.carModel, carProductYear: carYear) as ([ZipPackage], Int)
                            
                            var modelState: ModelYearState!
                            switch zipMessage.1 {
                            case 0:
                                modelState = ModelYearState.Download
                            case 1:
                                modelState = ModelYearState.Downloading
                            case 2:
                                modelState = ModelYearState.Downloading
                            case 3:
                                modelState = ModelYearState.Downloading
                            case 4:
                                modelState = ModelYearState.Open
                            case 5:
                                modelState = ModelYearState.Open
                            case 6:
                                modelState = ModelYearState.Open
                            case 7:
                                modelState = ModelYearState.Open
                            case 999:
                                modelState = ModelYearState.Download
                            default:
                                break
                            }
                            
                            modelYearView = ModelYearView(frame: self.view.bounds, contentFrame: CGRectMake((CGRectGetWidth(UIScreen.mainScreen().bounds) - width)/2, (CGRectGetHeight(self.view.bounds)-height)/2, width, height),dataSource: carTypeModel.carYearList!, carTypeTitle: carTypeModel.carModel, modelYearState: modelState, zipArray: zipMessage.0)
                        }else {
                            
                            modelYearView = ModelYearView(frame: self.view.bounds, contentFrame: CGRectMake((CGRectGetWidth(UIScreen.mainScreen().bounds) - width)/2, (CGRectGetHeight(self.view.bounds)-height)/2, width, height),dataSource: ["\(carTypeModel.carModel)"], carTypeTitle: carTypeModel.carModel, modelYearState: ModelYearState.Download,zipArray: [ZipPackage]())
                        }
                        
                        modelYearView.delegate = self
                        self.view.addSubview(modelYearView)
                        modelYearView.layer.transform = CATransform3DMakeScale(0.8, 0.8, 0.2)
                        UIView.animateWithDuration(0.2, animations: { () -> Void in
                            
                            modelYearView.layer.transform = CATransform3DMakeScale(1.1, 1.1, 1.1)
                            }) { (completetion) -> Void in
                                
                                if completetion {
                                    UIView.animateWithDuration(0.1, animations: { () -> Void in
                                        modelYearView.dismissView.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.8)
                                        modelYearView.layer.transform = CATransform3DIdentity
                                        }, completion: { (completetion) -> Void in
                                            if completetion {
                                            }
                                    })
                                }
                        }
                    }
            }
        }else {
            
            self.showRendView("网络不可用", isSuccess: false)
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  网络请求车型列表
    */
    func loadCarTypeList() {
        
        let nonDic: NSDictionary = NSDictionary()
        AFOperationManager.sharedInstance.configureRequestSerializer()
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCarList, param: nonDic, withToken:false,success: { (operation, responseObject) -> Void in
            
            self.hideNoNetworkBackgroundView()
            var mutableDic: NSMutableDictionary? = NSMutableDictionary()
            mutableDic = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                for carDict in mutableDic!.objectForKey("carList") as! NSArray! {
                    
                    let carModel = CarTypeModel(JSONDic: carDict as! NSDictionary)
                    self.dataArray.addObject(carModel)
                }
                self.carTypeListTableView.reloadData()
            }
            }) { (operation, error) -> Void in
                
                self.showNoNetworkBackgroundView()
        }
    }
    
    // MARK: private function
    /**
    *  滚动carTypeListTableView
    */
    func scrollTableView() {
        
        var newScrollViewContentOffset: CGPoint = self.carTypeListTableView.contentOffset
        newScrollViewContentOffset.y += 0.5
        newScrollViewContentOffset.y = max(0, newScrollViewContentOffset.y)
        
        if newScrollViewContentOffset.y >= self.carTypeListTableView.contentSize.height - CGRectGetHeight(self.carTypeListTableView.bounds) {
            
            //滚动到底部回滚到顶部重新滚动
            self.carTypeListTableView.contentOffset = CGPointZero
        }else {
            
            self.carTypeListTableView.contentOffset = newScrollViewContentOffset
        }
    }
    
    /**
     *  获取carTypeListTableView当前contentOffset的Index
     */
    func indexForCurrentOffset() -> Int {
        
        let offsetY: CGFloat = carTypeListTableView.contentOffset.y
        if offsetY < itemHeight/2 {
            
            return 1
        }else {
            
            let y = CGFloat(offsetY + itemHeight/2 + CGRectGetHeight(carTypeListTableView.bounds)/2)
            return Int(y / itemHeight)
        }
    }
    
    /**
     *  计算移动到某个车型的cell需要的offset
     */
    func offsetForCellTag(cellTag: Int) -> CGPoint {
        
        let offsetY: CGFloat = (CGFloat(cellTag - kCellTagBasicNumber - 1))*itemHeight
        return CGPointMake(0, offsetY)
    }
    
    // MARK:
    // MARK: Handle Zip
    /**
    *  获取已经保存的zip包, 获取zip包的状态
    */
    func getAllZipPackagesHadDownload(carTypeTitle: String, carProductYear: String) -> ([ZipPackage],Int){
        
        let zipPackageArray = PackageFileManager.sharedInstance.packages as NSArray   // 所有的zip包
        var sameCarTypeArray = [ZipPackage]()
        var state: Int = 999
        for zipPackage in zipPackageArray {
            
            let zip = zipPackage as! ZipPackage
            let carName = zip.carName
            let carYear = zip.carProductYear
            if carName == carTypeTitle {
                
                // 将zip包添加到数组
                sameCarTypeArray.append(zip)
                if carYear == carProductYear {
                    
                    let d: ZipPackageDownloadState = zip.state
                    state = d.hashValue
                }
            }
        }
        
        return (sameCarTypeArray, state)
    }
    
    // MARK:
    // MARK: ModelYearViewDelegate
    /**
     *  打开zip包
     */
    func openZipPackage(zip: ZipPackage) {
        
        self.showAlertView("车型包已下载完成,\n 请解析数据包", tag: 2215)
    }
    
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.dataArray.count + 2
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifer: String!
        if indexPath.row == 0 || indexPath.row == self.dataArray.count + 1 {
            
            identifer = "padding"
            var cell: UITableViewCell? = tableView.dequeueReusableCellWithIdentifier(identifer)
            if cell == nil {
                
                cell = UITableViewCell(style: .Default, reuseIdentifier: identifer)
            }
            
            return cell!
        }else {
            
            identifer = "cell"
            var cell: CarTypeCell? = tableView.dequeueReusableCellWithIdentifier(identifer) as? CarTypeCell
            if cell == nil {
                // FIXME:按照需要改变cellContentView宽度，cellContentView宽高比等同于cell宽高比
                let scale: CGFloat = 0.8
                cell = CarTypeCell(style: .Default, reuseIdentifier: identifer, contentFrame: CGRectMake(CGRectGetWidth(UIScreen.mainScreen().bounds)*(1-scale)/2, itemHeight*(1-scale)/2, CGRectGetWidth(UIScreen.mainScreen().bounds)*scale, itemHeight*scale))
                let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: Selector("handleTapGesture:"))
                cell!.cellContentView.addGestureRecognizer(tapGesture)
            }
            
            cell?.userInteractionEnabled = true
            let carTypeModel = self.dataArray[indexPath.row-1] as! CarTypeModel
            cell!.titleLabel.text = carTypeModel.carModel
            cell!.carTypeImageView?.setImageWithURL(NSURL(string: carTypeModel.carModelPicUrl!))
            // 为cellContentView添加tag，以便后面根据点击手势查找所点击的cell的IndexPath
            cell!.cellContentView.tag = kCellTagBasicNumber + indexPath.row
            return cell!
        }
    }
    
    // MARK: UITableViewDelegate
    /**
    *  顶部和尾部空白cell高度单独设置，车型cell返回itemHeight
    */
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if indexPath.row == 0 || indexPath.row == self.dataArray.count + 1 {
            
            paddingHeight = CGRectGetHeight(tableView.bounds)/2 - itemHeight/2
            if paddingHeight < 0 {
                
                paddingHeight = 0
            }
            return paddingHeight!
        }else {
            
            return itemHeight
        }
    }
    
    // MARK: ScrollViewDelegate
    /**
    *  滚动中将cell的可接收事件设为fasle，避免与用户滑动动作产生冲突
    */
    func scrollViewWillBeginDecelerating(scrollView: UIScrollView) {
        
        for cell in self.carTypeListTableView.visibleCells {
            
            if cell is CarTypeCell {
                
                (cell as! CarTypeCell).userInteractionEnabled = false
            }
        }
        self.tmpCells = self.carTypeListTableView.visibleCells
    }
    
    /**
     *  滚动完毕，将cell的可接收事件设为true，以便后续操作
     */
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        
        if self.tmpCells != nil {
            
            for cell in self.tmpCells! {
                
                if cell is CarTypeCell {
                    
                    (cell as! CarTypeCell).userInteractionEnabled = true
                }
            }
        }
    }
    
    // MARK: ModelYearDelegate
    func removeModelYearView(modelYearView: ModelYearView) {
        
        scrollTimer = NSTimer.scheduledTimerWithTimeInterval(0.02, target: self, selector: Selector("scrollTableView"), userInfo: nil, repeats: true)
    }
    
    func pushToDisclaimerController(carType carType: String!, carYear: String!, state: String!, picUrl: String!, isIncludeVideo: String!,zipSize: String!) {
        
        if zipSize != "0" {
            
            let title = "目前在非WiFi条件下!\n离线包大小为: " + zipSize + "MB"
            let customAlertView = CustomAlertView(messageTitle: title, sureTitle: "继续", cancelTitle: "取消", delegate: self)
            customAlertView.show()
            
            carArray = NSMutableArray()
            carArray.addObject(carType)
            carArray.addObject(carYear)
            carArray.addObject(picUrl)
            carArray.addObject(isIncludeVideo)
            return
        }
        if state == "download" {
            
            let settingDiscamlerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SettingDisclaimerStoryboardID") as! SettingDiscamlerController
            
            settingDiscamlerVC.isIncludeVideo = isIncludeVideo
            settingDiscamlerVC.carType = carType
            settingDiscamlerVC.carYear = carYear
            settingDiscamlerVC.picUrl = picUrl
            self.navigationController?.pushViewController(settingDiscamlerVC, animated: true)
        }else {
            
            // 正在下载中进入下载管理
            self.performSegueWithIdentifier("SelectCarToDownloadSegue", sender: nil)
        }
    }
    
    // MARK: CustomAlertViewDelegate
    override func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        
        self.pushToSettingVC()
    }
    
    func pushToSettingVC() {
        
        if (carArray != nil) {
            
            for vi in self.view.subviews {
                
                if vi is ModelYearView {
                    
                    (vi as! ModelYearView).removeCurrentView()
                    Logger.info("rrrrrrrr")
                }
            }
            let settingDiscamlerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("SettingDisclaimerStoryboardID") as! SettingDiscamlerController
            
            settingDiscamlerVC.carType = carArray[0] as! String
            settingDiscamlerVC.carYear = carArray[1] as! String
            settingDiscamlerVC.picUrl = carArray[2] as! String
            settingDiscamlerVC.isIncludeVideo = carArray[3] as! String
            self.navigationController?.pushViewController(settingDiscamlerVC, animated: true)
        }
    }
}
