//
//  FavouriteController.swift
//  DasautoSpecifications
//
//  Created by chenggang on 15-1-28.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class FavouriteController: DasautoController, UITableViewDelegate, UITableViewDataSource, FavouriteLeafDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    
    var expandeArray = [NSMutableDictionary]()
    var keyString: NSString = "keySting"
    var expanded: Bool = false                            //判断是否需要展开
    
    var directory: DasAutoDirectory!
    var indexPth: NSIndexPath!
    var listName: String!           
    var index: Int = 0                                    //区分点击哪个cell进来的
    
//    var zipPackage: ZipPackage?
    var isIndicatorLight = false
    var dataArray: NSMutableArray!
    var typeArray: NSMutableArray!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.configureTitle("个人收藏")
    }

    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
                
        self.getCarNameAndCarYearFromDataBase()
        self.getIsOpen()
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidDisappear(animated)
        self.isIndicatorLight = false
    }
    
    // MARK: Configure Views
    /**
    *  配置警告视图
    */
    func doSomeThingWithPackageFileManager(manager: PackageFileManager) {
        
        if manager.packages.count != 0 {
            
            for zip in manager.packages {
                if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
                    zipPackage = zip
                    self.showAlertView("车型包已下载完成,\n 请解析数据包", tag: 2215)
                    return
                }
            }
            for zip in manager.packages {
                if zip.state == ZipPackageDownloadState.downloadPause {
                    self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                    return
                }else if zip.state == ZipPackageDownloadState.downloading {
                    if DSDownloadManager.shareInstance().isStartOperation(zip.urlString) {
                        self.showRendView("正在下载中", isSuccess: false)
                    }else {
                        self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                    }
                    return
                }
            }
        }else {
            self.showAlertView("尚无数据,\n 请先下载车型", tag: 2217)
        }
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *   加载视频列表
    */
    func loadCarVideoList() {
        
        dataArray = NSMutableArray()
        let zip = PackageFileManager.sharedInstance.currentZipPackage
        let userDict: NSDictionary = ["carModel": zip.carName, "carYear": zip.carProductYear]
        
        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCarVideoList, param: userDict, withToken:false,success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            let mutableDict: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if mutableDict != nil {
                
                let respCode = mutableDict?.objectForKey("respCode") as! String
                if respCode == "000000" {
                    
                    self.dataArray.removeAllObjects()
                    let responseArray = mutableDict?.objectForKey("carVideoList") as! NSArray
                    for videoList in responseArray {
                        
                        let videoListItem: CarVideoModel = CarVideoModel(JSONDic: videoList as! NSDictionary)
                        self.dataArray.addObject(videoListItem)
                    }
                    
                    self.sendValueForIntellectualTechnologyWithOutVideo()
                }
            }
            }) { (operation, error) -> Void in
                
                self.showRendView("网络请求失败", isSuccess: false)
        }
    }
    
    // MARK:
    // MARK: UITapGestureRecognizer
    /**
    *  点击头视图的方法
    */
    func onHeadViewTapGesture(tapGeture: UITapGestureRecognizer) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let tag = tapGeture.view?.tag
        self.collapseOrExpand(tag! - 100)
    }
    
    // MARK:
    // MARK: FMDataBase
    /**
    *  获取数据库   车型 + 年款
    */
    func getCarNameAndCarYearFromDataBase() {
        
        typeArray = NSMutableArray()
        var carName: String!
        var carYear: String!
            
        let array = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithListName(listName, userId: kUserId)
        for var i = 0; i < array.count; i++ {
            
            let listArray = array[i] as! NSArray
            let name = listArray[0] as! String
            let year = listArray[1] as! String
            if i == 0 {
                
                carName = name
                carYear = year
                let dict = ["carName":carName,"carYear":carYear]
                typeArray.addObject(dict)
            }else if carName != name && carYear != year {
                
                let dict = ["carName":carName,"carYear":carYear]
                typeArray.addObject(dict)
            }
        }
        
        Logger.info("count = \(typeArray.count)")
        Logger.info("array = \(typeArray)")
    }
    
    /**
    *  获取收藏数据库的数组
    */
    func fecthHtmlArray(indexPath: NSIndexPath) -> NSArray {
        
        let dict = typeArray[indexPath.section] as! NSDictionary
        let carName = dict.objectForKey("carName") as! String
        let carYear = dict.objectForKey("carYear") as! String
        let array = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(carName, carYear: carYear, listName: listName, userId: kUserId)[indexPath.row] as! NSArray
        return array
    }
    
    // MARK:
    /**
    *  生成展开或者关闭数组
    */
    func getIsOpen() {
        
        var count = typeArray.count
        if index == 5 {
            
            if DBmanager.sharedInstance().fecthShopWithUserId(kUserId).count != 0 {
                
                count += 1
            }
        }
        for var i = 0; i < count ; i++ {
            
            if i == 0 {
                
                let dic = NSMutableDictionary(object: false, forKey: keyString)
                expandeArray.append(dic)
            }else {
                
                let dic = NSMutableDictionary(object: expanded, forKey: keyString)
                expandeArray.append(dic)
            }
        }
    }
    
    /**
    *  判断是否展开
    */
    func collapseOrExpand(section: Int) {
        
        let dic = expandeArray[section] as NSMutableDictionary
        var expanded = expandeArray[section].objectForKey(keyString) as! Bool
        
        if expanded == false {
            
            expanded = true
            dic.setValue(expanded, forKey: keyString as String)
        }else {
            
            expanded = false
            dic.setValue(expanded, forKey: keyString as String)
        }
        
        self.tableView.reloadData()
    }
    
    /**
    *  计算zip存在, 但是包内容没有收藏的个数_可能弃用
    */
    func getCountOfZipHasNotFavourite() -> Int {
        
        var pagesArray = PackageFileManager.sharedInstance.packages
        var count: Int = 0
        for var i = 0; i < pagesArray.count; i++ {
            
            let zip = pagesArray[i] as ZipPackage
            let array = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(zip.carName, carYear: zip.carProductYear, listName: listName, userId: kUserId) as NSArray
            if array.count == 0 {
                
                count++
            }
        }
        
        return count
    }
    
    // MARK:
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        if index == 5 {
            
            if DBmanager.sharedInstance().fecthShopWithUserId(kUserId).count != 0 {
                
                return typeArray.count + 1
            }else {
                
                return typeArray.count
            }
        }
        return typeArray.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var count: Int = 0
        if expandeArray[section].objectForKey(keyString) as! Bool == false {
            
            return count
        }else {
            
            if index != 5 {
                
                let dict = typeArray[section] as! NSDictionary
                let carName = dict.objectForKey("carName") as! String
                let carYear = dict.objectForKey("carYear") as! String
                count = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(carName, carYear: carYear, listName: listName, userId: kUserId).count
                return count
            }else {
                
                
                if section < typeArray.count  {
                    let dict = typeArray[section] as! NSDictionary
                    let carName = dict.objectForKey("carName") as! String
                    let carYear = dict.objectForKey("carYear") as! String
                    count = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(carName, carYear: carYear, listName: listName, userId: kUserId).count
                    return count
                }else {
                    
                    return DBmanager.sharedInstance().fecthShopWithUserId(kUserId).count
                }
            }
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let identifer = "FavoriteCell"
        var cell = tableView.dequeueReusableCellWithIdentifier(identifer)
        if cell == nil {
            
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: identifer)
        }
        let dotView = cell?.viewWithTag(100)
        dotView?.backgroundColor = color
        
        let nameLabel = cell?.viewWithTag(101) as! UILabel
        if index != 5 {
            
            let dict = typeArray[indexPath.section] as! NSDictionary
            let carName = dict.objectForKey("carName") as! String
            let carYear = dict.objectForKey("carYear") as! String
            let array = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithCarName(carName, carYear: carYear, listName: listName, userId: kUserId)[indexPath.row] as! NSArray
            nameLabel.text = array[3] as? String
        }else {
            
            // 应急服务 + 经销商
            if indexPath.section < typeArray.count {
                
                let array = self.fecthHtmlArray(indexPath)
                nameLabel.text = array[3] as? String
            }else {
                
                let array = DBmanager.sharedInstance().fecthShopWithUserId(kUserId)[indexPath.row] as! NSArray
                nameLabel.text = array[0] as? String
            }
        }
        
        return cell!
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        indexPth = indexPath
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let manager = PackageFileManager.sharedInstance as PackageFileManager
        if index == 5 {
            
            // 判断是否是经销商和指示灯
            if indexPath.section < typeArray.count {
                
                if manager.packages.count == 0 || manager.rootFile == nil {
                    
                    self.doSomeThingWithPackageFileManager(manager)
                }else {
                    
                    let array = self.fecthHtmlArray(indexPath)
                    if (array[3] as! String) == "指示灯及警告灯" {
                        
                        isIndicatorLight = true
                    }else {
                        
                    }
                    self.performSegueWithIdentifier("detailSegue", sender: nil)
                }
            }else {
                
                let array = DBmanager.sharedInstance().fecthShopWithUserId(kUserId)[indexPath.row] as! NSArray
                self.sendValueForCarDetailShop(array)
            }
        }else {
            
            if manager.packages.count == 0 || manager.rootFile == nil{
                
                self.doSomeThingWithPackageFileManager(manager)
            }else {
                
                if index == 3 {
                    
                    if manager.currentZipPackage.isIncludeVideo == "true" {
                        
                        self.sendValueForIntellectualTechnologyWithVideo()
                    }else {
                        
                        self.loadCarVideoList()
                    }
                }else {
                    
                    self.performSegueWithIdentifier("detailSegue", sender: nil)
                }
            }
        }
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 44
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 44
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headView = UIView(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 44))
        headView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: "onHeadViewTapGesture:"))
        headView.backgroundColor = UIColor.whiteColor()
        headView.tag = 100 + section
        
        let headLabel = UILabel(frame: CGRectMake(15, 11, CGRectGetWidth(self.view.bounds) - 50, 21))
        if index != 5 {
            
            let dict = typeArray[section] as! NSDictionary
            headLabel.text = dict.objectForKey("carName") as? String
        }else {
            
            headLabel.text = "大众汽车经销商"
            if section < typeArray.count {
                
                let dict = typeArray[section] as! NSDictionary
                headLabel.text = dict.objectForKey("carName") as? String
            }else {
                
                headLabel.text = "大众汽车经销商"
            }
        }
        headView.addSubview(headLabel)
        
        let rightImageView = UIImageView(frame: CGRectMake(CGRectGetWidth(self.view.bounds) - 25, 14, 10, 15))
        rightImageView.tag = 101 + section
        rightImageView.image = UIImage(named: "rightArrow" + themeColor)
        headView.addSubview(rightImageView)
        let expanded = expandeArray[section].objectForKey(keyString) as! Bool
        if expanded == true {
            
            UIView.animateWithDuration(2.0, animations: { () -> Void in
                
                rightImageView.transform = CGAffineTransformMakeRotation(CGFloat(M_PI/2))
            })
        }else {
            
            UIView.animateWithDuration(2.0, animations: { () -> Void in
                
                rightImageView.transform = CGAffineTransformMakeRotation(CGFloat(0))
            })
        }
        
        let lineView = UIView(frame: CGRectMake(0, 43, CGRectGetWidth(self.view.bounds), 1))
        lineView.backgroundColor = UIColor(red: 204/255, green: 204/255, blue: 204/255, alpha: 1.0)
        headView.addSubview(lineView)
        
        return headView
    }
    
    // MARK: 配置zip包文件
    /**
    *  配置zip包文件
    */
    func configureDirectory()  {
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(self.index + 1)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
    }
    
    // MARK:
    // MARK: 快速指南
    func sendValueForQuickQuide(vc: HtmlDetaiController) {
        
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            if leaf.resourceId == resourcesId {
                
                vc.leaf = leaf
                return
            }
        }
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            
            if leaf.resourceId == resourcesId {
                
                vc.leaf = leaf
                return
            }
        }
    }
    
    // MARK: 维护保养
    func sendValueForMaintenance(vc: HtmlDetaiController) {
        
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            for var i = 0; i < leaf.children.count; i++ {
                
                let childrenLeaf = leaf.children[i] as DasAutoFile
                if childrenLeaf.resourceId == resourcesId {
                    
                    vc.leaf = childrenLeaf
                    return
                }
            }
        }
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            
            if leaf.resourceId == resourcesId {
                
                vc.leaf = leaf
                return
            }
        }
//        self.sendValueForCarClass(vc)   //   为什么要去遍历爱车课堂
    }
    
    // MARK: 用户手册传值
    func sendValueForUserManual(vc: HtmlDetaiController) {
        
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        
        for var i = 0; i < self.directory.children.count; i++ {
            
            let file = self.directory.children[i] as DasAutoFile
            for var i = 0; i < file.children.count; i++ {
                
                let childrenFile = file.children[i] as DasAutoFile
                for var i = 0; i < childrenFile.children.count; i++ {
                    
                    let leaf = childrenFile.children[i] as DasAutoFile
                    if leaf.resourceId == resourcesId {
                        
                        vc.leaf = leaf
                        if leaf.children.count != 0 {
                            
                            vc.dataArray = leaf.children
                        }
                        return
                    }
                }
            }
        }
        
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            
            if leaf.resourceId == resourcesId {
                
                vc.leaf = leaf
                return
            }
        }
    }
    
    // MARK: 视频介绍传值
    func sendValueForIntellectualTechnologyWithVideo() {
        
        self.configureDirectory()
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        var videoFile: DasAutoFile!
        
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            if leaf.resourceId == resourcesId {
                
                videoFile = leaf
            }
        }
        let videoPlayerController: MWVideoPlayerController = MWVideoPlayerController()
        let urlPath = DSFileManager.sharedInstance.getImagePath(PackageFileManager.sharedInstance.currentZipPackage.zipNameWithoutsubffix + "/video/" + videoFile.videoFile)
        let minute = Int(videoFile.playTime)! / 60
        let second = Int(videoFile.playTime)! % 60
        
        var allTimeString: String!
        if minute >= 10 {
            
            allTimeString = String(minute)
        }else {
            
            allTimeString = "0" + String(minute)
        }
        if second >= 10 {
            
            allTimeString = allTimeString + ":" + String(second)
        }else {
            
            allTimeString = allTimeString + ":" + "0" + String(second)
        }
        
        if videoFile.children.count != 0 {
            
            videoPlayerController.leaf = videoFile.children[0] as DasAutoFile
        }
        videoPlayerController.allTime = allTimeString
        videoPlayerController.titleName = videoFile.name
        videoPlayerController.fileUrl = NSURL.fileURLWithPath(urlPath)
        self.navigationController?.pushViewController(videoPlayerController, animated: true)
    }
    
    func sendValueForIntellectualTechnologyWithOutVideo() {
        
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        
        var videoModel: CarVideoModel!
        for var i = 0; i < self.dataArray.count; i++ {
            
            let model = self.dataArray[i] as! CarVideoModel
            if model.id.description == resourcesId {
                
                videoModel = model
            }
        }
        let videoPlayerController: MWVideoPlayerController = MWVideoPlayerController()
        let time = videoModel.playTime as NSNumber
        let minute = time.intValue.toIntMax() / 60
        let second = time.intValue.toIntMax() % 60
        
        var allTimeString: String!
        if minute >= 10 {
            
            allTimeString = String(minute)
        }else {
            
            allTimeString = "0" + String(minute)
        }
        if second >= 10 {
            
            allTimeString = allTimeString + ":" + String(second)
        }else {
            
            allTimeString = allTimeString + ":" + "0" + String(second)
        }
        
        let listArray = videoModel.refResList                          // MAKR: 无视频版传入数组
        videoPlayerController.listArray = listArray
        videoPlayerController.allTime = allTimeString
        videoPlayerController.index = videoModel.id.description
        videoPlayerController.titleName = videoModel.videoName
        videoPlayerController.videoDowloadUrl = videoModel.videoUrl
        self.navigationController?.pushViewController(videoPlayerController, animated: true)
    }
    
    // MARK: 爱车课堂传值
    func sendValueForCarClass(vc: HtmlDetaiController) {
        
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        // 在 carclass 里面搜索
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            
            if leaf.resourceId == resourcesId {
                
                vc.leaf = leaf
                return
            }
        }
        
        // 在 otherRes 里面搜索
        PackageFileManager.sharedInstance.rootFile.findFileWithFileId(8)
        self.directory = PackageFileManager.sharedInstance.rootFile.result as! DasAutoDirectory
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            
            if leaf.resourceId == resourcesId {
                
                vc.leaf = leaf
                return
            }
        }
    }
    
    // MARK: 应急服务传值
    func sendValueForCarDetailShop(array: NSArray) {
        
        let car4sshopModel = Car4sshopModel(array: array)
        let car4sshopDetailController: Car4sshopDetailController = Car4sshopDetailController(car4sshopModel: car4sshopModel)
        self.navigationController?.pushViewController(car4sshopDetailController, animated: true)
    }
    
    func sendValueForProblemAndSolve(vc: HtmlDetaiController) {
        
        let array = self.fecthHtmlArray(indexPth) as NSArray
        let resourcesId = array[4] as! String
        
        if self.isIndicatorLight == true {
            
            vc.isIndicatorLight = self.isIndicatorLight
        }
        
        for var i = 0; i < self.directory.children.count; i++ {
            
            let leaf = self.directory.children[i] as DasAutoFile
            if leaf.resourceId != nil {
                
                if leaf.resourceId == resourcesId {
                    
                    vc.leaf = leaf
                    return
                }
            }
            for var i = 0; i < leaf.children.count; i++ {
                
                let childrenLeaf = leaf.children[i] as DasAutoFile
                if childrenLeaf.resourceId == resourcesId {
                    
                    vc.leaf = childrenLeaf
                    return
                }
            }
        }
        
        self.sendValueForCarClass(vc)
    }
    
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: sender)
        if segue.identifier == "detailSegue" {
            
            let vc = segue.destinationViewController as! HtmlDetaiController
            vc.listName = self.listName
            self.configureDirectory()
            if index == 0 {
                
                self.sendValueForQuickQuide(vc)
            }else if index == 1 {
                
                self.sendValueForMaintenance(vc)
            }else if index == 2 {
                
                self.sendValueForUserManual(vc)
            }else if index == 4{
                
                self.sendValueForCarClass(vc)
            }else if index == 5 {
                
                self.sendValueForProblemAndSolve(vc)
            }
        }
    }
}