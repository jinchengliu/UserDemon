/*
*  filename: PersonalFavouriteController.swift
*  product name: DasautoSpecifications
*
*  author: wangrui
*  date time: 14/12/1.
*  copyright: bdcluster
*/

import UIKit

class PersonalFavouriteController: DasautoController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var titleArray = ["快速指南","维护保养","用户手册","视频介绍","爱车课堂","应急服务"]
    var delegate: GuideMenuDelegate?
    var pagesArray: NSArray!                                       //存放zip包
    
    var successCount: Int = 0
    var index: Int = 0                                             //区分点击的是哪个cell
    
    // MARK:
    // MARK: Life Cycle
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
       
        let pkgFileManager = PackageFileManager.sharedInstance as PackageFileManager
        pagesArray = pkgFileManager.packages
        self.tableView.reloadData()
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        
        if kUserId == "noLogin" {
            
            self.showRendView("登录后,您的收藏将跟账户绑定", isSuccess: false)
        }else {
            
            let isFirstLogin = NSUserDefaults.standardUserDefaults().objectForKey("isFirstLogin") as? Bool
            if isFirstLogin != nil {
                
                if isFirstLogin == true {
                    
//                    self.queryResourceCollectionList()
//                    self.queryShopCollectionList()
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中返回
    */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
        self.delegate?.didCloseGuideMenu!()
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  查询html收藏
    */
    func queryResourceCollectionList() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if kUserId != "noLogin" {
                
                // html
                self.showProgressHUDMessage("请求收藏数据")
                let userDict: NSDictionary = ["userId": Int(kUserId)!]
                AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kCollectionList, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
                    
                    self.hideProgressHUD()
                    if let mutableDic = responseObject as? NSMutableDictionary {
                        
                        let respCode = mutableDic.objectForKey("respCode") as! String
                        if respCode == "020003" {
                            
                            DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                            DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                            kUserId = "noLogin"
                            NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
                            NSUserDefaults.standardUserDefaults().synchronize()
                            self.showRendView("账号失效, 请重新登录!", isSuccess: false)
                            
                            let aboutController: AboutController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
                            aboutController.hasRightBarButtonItem = false
                            aboutController.pushToControllerName = "BackToListController"
                            self.navigationController?.pushViewController(aboutController, animated: true)
                        }else if respCode == "000000" {
                            
                            // 请求数据成功
                            let collections = mutableDic.objectForKey("collectionList") as? NSArray
                            Logger.info("html :\(collections!)")
                            // 2. 删除数据库(html)
                            DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                            // 3. 添加到数据库
                            if collections != nil {
                                
                                self.analysisHtmlDataWithNSArray(collections!)
                            }
                        }
                    }
                }) { (operation, error) -> Void in
                    
                    self.hideProgressHUD()
                    Logger.info("_____________\(error)")
                }
            }
        }
    }
    
    /**
    *  查询4S经销商收藏
    */
    func queryShopCollectionList() {
        
        if AFNetworkReachabilityManager.sharedManager().reachable == true {
            
            if kUserId != "noLogin" {
                
                let userDict: NSDictionary = ["userId": Int(kUserId)!]
                AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kShopCollectionList, param: userDict, withToken:true,success: { (operation, responseObject) -> Void in
                    
                    
                    if let mutableDic = responseObject as? NSMutableDictionary {
                        
                        let respCode = mutableDic.objectForKey("respCode") as! String
                        if respCode == "020003" {
                            
                            DBmanager.sharedInstanceWithDBName("html").deleteAllLoginHtmlWithUserId(kUserId)
                            DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                            kUserId = "noLogin"
                            NSUserDefaults.standardUserDefaults().setObject(-1, forKey: "userId")
                            NSUserDefaults.standardUserDefaults().synchronize()
                            self.showRendView("账号失效, 请重新登录!", isSuccess: false)
                            
                            // 4.跳转到登录页
                            let aboutController: AboutController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("AboutStoryboardID") as! AboutController
                            aboutController.hasRightBarButtonItem = false
                            aboutController.pushToControllerName = "BackToListController"
                            self.navigationController?.pushViewController(aboutController, animated: true)
                        }else if respCode == "000000" {
                            
                            // 请求数据成功
                            let collections = mutableDic.objectForKey("collections") as? NSArray
                            Logger.info("\(collections!)")
                           
                            if collections != nil {
                                // 2. 删除数据库
                                DBmanager.sharedInstance().deleteAllShopWithUserId(kUserId)
                                // 3. 添加到数据库
                                self.analysisShopDataWithNSArray(collections!)
                            }
                        }
                   }
                }) { (operation, error) -> Void in
                        
                        Logger.info("_____________\(error)")
                }
            }
        }
    }
    
    // MARK:
    // MARK: FMDataBase
    /**
    *  解析添加html数据
    */
    func analysisHtmlDataWithNSArray(array: NSArray) {
        
        successCount++
        var typeArray = ["quick",
            "maintain",
            "manual",
            "video",
            "carclass",
            "emergency"]
        for var i = 0; i < array.count; i++ {
            
            let dict = array[i] as! NSDictionary
            var typeName = dict.objectForKey("resourceType") as! String        // type
            let carResListArray = dict.objectForKey("carResList") as! NSArray
            
            for var j = 0; j < typeArray.count; j++ {
                
                if typeName == typeArray[j] {
                    
                    typeName = titleArray[j]
                }
            }
            
            for var m = 0; m < carResListArray.count; m++ {
                
                let resDict = carResListArray[m] as! NSDictionary
                let carYear = resDict.objectForKey("carYear") as! String
                let carModel = resDict.objectForKey("carModel") as! String
                let resListArray = resDict.objectForKey("resList") as! NSArray
                for var n = 0; n < resListArray.count; n++ {
                    
                    Logger.info("ciutn:   \(n)")
                    let resListDict = resListArray[n] as! NSDictionary
                    let name = resListDict.objectForKey("carResourceName") as! String
                    let id = (resListDict.objectForKey("carResourceId") as! Int).description
                    DBmanager.sharedInstanceWithDBName("html").insertHtml([carModel,carYear,typeName,name,id,kUserId])
                }
            }
        }
        
        self.refreshTableView()
    }
    
    /**
     *  解析添加经销商数据
     */
    func analysisShopDataWithNSArray(array: NSArray) {
        
        successCount++
        for var i = 0; i < array.count; i++ {
            
            let dict  = array[i] as! NSDictionary
            
            let id = (dict.objectForKey("id") as! Int).description
            let name = dict.objectForKey("name") as! String
            let address = dict.objectForKey("address") as! String
            let linkTel = dict.objectForKey("linkTel") as! String
            DBmanager.sharedInstance().insertShop(["经销商",name,id,address,linkTel,kUserId])     // 添加经销商
        }
        self.refreshTableView()
    }
    
    /**
     *  html和经销商数据都请求成功后刷新tableView
     */
    func refreshTableView() {
        
        if self.successCount == 2 {
            
            NSUserDefaults.standardUserDefaults().setObject(false, forKey: "isFirstLogin")
            NSUserDefaults.standardUserDefaults().synchronize()
            self.tableView.reloadData()
        }
    }
    
    /**
    *  获取数据库中收藏的个数
    */
    func fetchHemlArray(indexPath: NSIndexPath) -> Int {
        
        var count: Int = 0
        let array = DBmanager.sharedInstanceWithDBName("html").fecthHtmlWithListName(titleArray[indexPath.row], userId: kUserId) as NSArray
        count = array.count

        return count
    }
    
    // MARK:
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("FaouriteMainListCell") as! FaouriteMainListCell
        var count: Int = 0
        if indexPath.row == 5 {
          
            let array = DBmanager.sharedInstance().fecthShopWithUserId(kUserId)
            count = array.count + self.fetchHemlArray(indexPath)
            
        }else {
            
            count = self.fetchHemlArray(indexPath)
       }
        
        cell.configureMainListCellWith(titleArray[indexPath.row], favouriteCount: count)
        
        return cell
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        index = indexPath.row
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! FaouriteMainListCell
        let c = Int((cell.messageCountButton.titleLabel?.text!)!)
        
        if c != 0 {
            
            self.performSegueWithIdentifier("FavouriteSegue", sender: nil)
        }
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "FavouriteSegue" {
            
            let favouriteController:FavouriteController = segue.destinationViewController as! FavouriteController
            favouriteController.index = index
            favouriteController.listName = self.titleArray[index] as String
        }
    }
}