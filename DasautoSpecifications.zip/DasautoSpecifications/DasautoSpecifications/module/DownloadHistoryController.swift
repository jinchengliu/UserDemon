//
//  DownloadHistoryController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/6/5.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class DownloadHistoryController: DasautoController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var remindBackgroundView: UIView!   //警示背景图(默认隐藏)
    @IBOutlet weak var remindLabel: UILabel!           //警示label
    
    var historyArray: NSMutableArray!
    var row: Int!
    
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.configureTitle("下载历史")
        self.getBindListForCarUser()
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  服务器请求下载历史
    */
    func getBindListForCarUser() {
        
        self.showProgressHUDMessage("网络请求中")
        let userId = Int(kUserId)!
        let userIdDictionary = NSDictionary(objects: [userId], forKeys: ["userId"])
        
        historyArray = NSMutableArray()
        AFOperationManager.sharedInstance.startPostOperation( HttpBaseUrl + kUserDownloadBindList, param: userIdDictionary,withToken:false, success: { (operation, responseObject) -> Void in
            
            self.hideProgressHUD()
            let dictionary: NSMutableDictionary? = responseObject as? NSMutableDictionary
            if dictionary != nil {
                
                let respCode = dictionary!.objectForKey("respCode") as! String
                if respCode == "000000" {
                    
                    let list = dictionary!.objectForKey("bindList") as! NSArray
                    if list.count == 0 {
                        
                        self.remindBackgroundView.hidden = false
                    }else {
                        
                        for dict in list {
                            
                            let carTypeModel = CarTypeModel(JSONDic: (dict as! NSDictionary))
                            self.historyArray.addObject(carTypeModel)
                        }
                        self.tableView.reloadData()
                    }
                }
            }
            }) { (operation, error) -> Void in
                
                self.remindBackgroundView.hidden = false
                self.remindLabel.text = "网络连接错误"
                self.hideProgressHUD()
        }
    }
    
    // MARK:
    // MARK: 对zip的操作
    /**
    *  遍历已经下载的zip包
    */
    func getDownloadZipFromPackages(name: String, year: String, isVideo: String) {
        
        let manager = PackageFileManager.sharedInstance
        var pages = manager.packages
        if pages.count == 0 {                      // 没有车型包  --- 下载
            
            self.showAlertView("尚无数据,\n 请先下载车型", tag: 2217)
        }else {                                    // 多个车型包  --- 判断是否已经下载
            
            for var i = 0; i < pages.count; i++ {
                
                let zip = pages[i] as ZipPackage
                if zip.carName == name && zip.carProductYear == year && zip.isIncludeVideo == isVideo {
                    
                    if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
                        
                        // 解压zip包
                        self.showAlertView("车型包已下载完成,\n 请解析数据包", tag: 2215)
                        return
                    }else if zip.state == ZipPackageDownloadState.downloading {
                        
                        self.showRendView("正在下载中", isSuccess: false)
                        return
                    }else if zip.state == ZipPackageDownloadState.downloadPause {
                        
                        self.showAlertView("车型包尚未下载完成,\n 是否继续下载", tag: 2216)
                        return
                    }else if zip.state == ZipPackageDownloadState.isUsing {
                        
                        self.showRendView("正在应用中", isSuccess: false)
                        self.navigationController?.popToRootViewControllerAnimated(true)
                        return
                    }
                }
                
                if i == pages.count - 1 {
                    
                    self.showAlertView("尚无数据,\n 请先下载车型", tag: 2217)
                }
            }
        }
    }
    
    // MARK:
    // MARK: UITableViewDataSource
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return historyArray == nil ? 0 : historyArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let identifier = "DownloadCellIdentifier"
        let cell = tableView.dequeueReusableCellWithIdentifier(identifier) as? DownloadHistoryCell
        cell?.configureCellWithArray(historyArray[indexPath.row] as! CarTypeModel)
        
        return cell!
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        row = indexPath.row
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        let model = historyArray[indexPath.row] as! CarTypeModel
        var isIncludeVideo: String!
        if model.type as! Int == 1 {
            isIncludeVideo = "true"
        }else {
            isIncludeVideo = "false"
        }
        self.getDownloadZipFromPackages(model.carModel, year: model.carYear, isVideo: isIncludeVideo)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return DownloadHistoryCell.getHeight()
    }
    
}
