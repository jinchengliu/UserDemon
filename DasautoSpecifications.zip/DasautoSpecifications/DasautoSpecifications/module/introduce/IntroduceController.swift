//
//  IntroduceController.swift
//  DasautoSpecifications
//
//  Created by wangrui on 15/8/4.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class IntroduceController: UIViewController,UIScrollViewDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        self.configureScrollView()
        pageControl.hidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  配置scrollView
    */
    func configureScrollView() {
        
        let w = CGRectGetWidth(self.view.bounds)
        let h = CGRectGetHeight(self.view.bounds)
        for var i = 0; i < 4; i++ {
            
            let imageView = UIImageView(frame: CGRectMake(w * CGFloat(i), 0, w, h))
            imageView.image = UIImage(named: "introduceImage" + String(i + 1))
            if i == 3 {
                
                let experienceButton = UIButton(frame: CGRectMake(60, h - 84 , w - 60 * 2, 40))
                
                experienceButton.layer.borderWidth = 1
                experienceButton.layer.borderColor = UIColor(red:0.77, green:0, blue:0.29, alpha:1).CGColor
                experienceButton.layer.cornerRadius = 5
                experienceButton.layer.masksToBounds = true
                
                experienceButton.setTitle("立即体验", forState: UIControlState.Normal)
                experienceButton.setTitleColor(UIColor(red:0.8, green:0, blue:0.29, alpha:1), forState: UIControlState.Normal)
                experienceButton.titleLabel?.font = UIFont.boldSystemFontOfSize(18)
                experienceButton.addTarget(self, action: "onButtonClicked", forControlEvents: UIControlEvents.TouchUpInside)
                experienceButton.userInteractionEnabled = true
                
                imageView.userInteractionEnabled = true
                imageView.addSubview(experienceButton)
            }
            scrollView.addSubview(imageView)
        }
        scrollView.contentSize = CGSizeMake(w * 4, 0)
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  点击进入程序
    */
    func onButtonClicked() {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("MenuStoryboardID") as! MenuController
        
        //        UIApplication.sharedApplication().delegate!.window?!.rootViewController = vc    // 方式一
        self.presentViewController(vc, animated: true, completion: nil)                // 方式二
        
        NSUserDefaults.standardUserDefaults().setBool(false, forKey: "firstInstallApp")
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    // MARK: 
    // MARK: scrollViewDelegate
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        
        let index = scrollView.contentOffset.x / CGRectGetWidth(scrollView.frame)
        pageControl.currentPage = Int(index)
    }
    
    func scrollViewDidEndScrollingAnimation(scrollView: UIScrollView) {
        
        Logger.info("DDDDDDDDDDDDDDDDDDD")
    }
}
