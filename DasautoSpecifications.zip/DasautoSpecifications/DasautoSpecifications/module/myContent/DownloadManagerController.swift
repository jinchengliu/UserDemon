//
//  DownloadManagerController.swift
//  DasautoSpecifications
//
//  Created by 石茗伟 on 14-12-17.
//  Copyright (c) 2014年 bdcluster. All rights reserved.
//

import UIKit

class DownloadManagerController: DasautoController, UITableViewDataSource, UITableViewDelegate ,ZipPackageCellDelegate{
    
    @IBOutlet weak var packageListTableView: UITableView!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var lawButton: UIButton!
    @IBOutlet weak var remindBackgroundView: UIView!   //警示背景图(默认隐藏)
    @IBOutlet weak var remindLabel: UILabel!           //警示label
    
    var hasSelectCarTypeController: Bool!
    var delegate: GuideMenuDelegate?
    var indexPth: NSIndexPath!
    var zipArray: NSArray!
    var isEdit = false
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.configureTitle("下载管理")
        self.setButtonTitleColor(editButton)
        self.setButtonTitleColor(lawButton)
        
        zipArray = PackageFileManager.sharedInstance.packages
        if zipArray.count == 0 {
            self.remindBackgroundView.hidden = false
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        if progressHUD != nil {
            progressHUD = nil
        }
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中编辑
    */
    @IBAction func onEditButtonAction(sender: UIButton) {
        
        if PackageFileManager.sharedInstance.packages.count == 0 {
            editButton.userInteractionEnabled = false
            return
        }
        else {
            editButton.userInteractionEnabled = true
        }
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        if isEdit == false {
           
            if sender.selected == false {
                
                packageListTableView.setEditing(true, animated: true)
            }
            else {
                packageListTableView.setEditing(false, animated: true)
            }
            sender.selected = !sender.selected
        }
    }

    /**
     *  选中法律声明
     */
    @IBAction func onLawButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.performSegueWithIdentifier("DownloadToLawSegue", sender: nil)
    }
    
    /**
     *  选中返回
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)

        if hasSelectCarTypeController != nil {
            
            if hasSelectCarTypeController == true {
                
                if self.navigationController != nil {
                    
                    for vc in self.navigationController!.viewControllers {
                        
                        if vc is SelectCarTypeController {
                            
                            self.navigationController?.popToViewController(vc as! SelectCarTypeController, animated: true)
                            self.delegate?.didCloseGuideMenu!()
                            break
                        }
                    }
                }
                self.navigationController?.popToRootViewControllerAnimated(true)
                self.delegate?.didCloseGuideMenu!()
            }
            else {
                self.navigationController?.popViewControllerAnimated(false)
            }
        }
        else {
            self.navigationController?.popViewControllerAnimated(true)
            self.delegate?.didCloseGuideMenu!()
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  下载选中包的网址
    */
    func downloadVideo(carType:String,carYear:String,isIncludeVideo:String,picUrl:String)
    {
        let param = NSDictionary(objects: [carType,carYear,isIncludeVideo], forKeys: ["carModel","carYear","isIncludeVideo"])
        AFOperationManager.sharedInstance.startPostOperation( HttpBaseUrl + kResourceOfflineDownload, param: param,withToken:false, success: { (operation, responseObject) -> Void in
            
            self.remindBackgroundView.hidden = true
            if let zipDict = responseObject as? NSMutableDictionary {
                
                let respCode = zipDict.objectForKey("respCode") as! String
                let memo = zipDict.objectForKey("memo") as! String
                if respCode == "000000" {
                    
                    let urlStr = zipDict.objectForKey("downloadUrl") as! String
                    // 判断zip是否已经存在
                    for zip in PackageFileManager.sharedInstance.packages {
                        if zip.urlString == urlStr {
                            return
                        }
                    }
                    let fileSize = zipDict.objectForKey("fileSize") as! NSNumber
                    let size = fileSize.longLongValue / 1024 / 1024
                    if kUserId != "noLogin" {
                        self.sendListCarUserDownloadCarType(carType, carYear: carYear, size:Int(size.description)!, isIncludeVideo: isIncludeVideo)
                    }
                    
                    let zip = ZipPackage(urlString: urlStr, zipSize: size.description, carName: carType, carProductYear: carYear, carStyle: "kd wood", picUrl: picUrl, isIncludeVideo:isIncludeVideo)
                    PackageFileManager.sharedInstance.addZipPackage(zip)
            
                    // 下载zip包
                    DSDownloadManager.shareInstance().addZipToDown(zip)
                    
                    self.zipArray = PackageFileManager.sharedInstance.packages
                    self.packageListTableView.reloadData()
                }
                else {
                    self.showRendView(memo, isSuccess: false)
                }
            }
            }) { (operation, error) -> Void in
                
                self.remindBackgroundView.hidden = false
                self.remindLabel.text = "网络连接错误"
        }
    }
    
    /**
     *  发送服务器绑定用户下载车型列表
     */
    func sendListCarUserDownloadCarType(carType: String,carYear:String,size: Int,isIncludeVideo: String) {
        
        var isVideo: Int = 0
        if isIncludeVideo == "true" {
            isVideo = 1
        }
        let userId = NSUserDefaults.standardUserDefaults().valueForKey("userId") as! Int
        let param = NSDictionary(objects: [userId,carType,carYear,isVideo,size], forKeys: ["userId","carModel","carYear","type","size"])
        AFOperationManager.sharedInstance.startPostOperation( HttpBaseUrl + kUserDownloadBind, param: param, withToken:false,success: { (operation, responseObject) -> Void in
            
            }) { (operation, error) -> Void in
            
        }
    }
    
    // MARK: 对zip包的操作
    /**
    *  解压zip包或者解析zip包
    */
    func unzippingPackage(zipPackage: ZipPackage) {
        
        self.showProgressHUDMessage("正在应用中")
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            
            PackageFileManager.sharedInstance.unzippingPackage(zipPackage)
            NSNotificationCenter.defaultCenter().postNotificationName("setMainController", object: nil)
            self.hideProgressHUD()
        }
    }
    
    /**
     *  删除下载的zip包
     */
    func deleteDownloadZipPackage(indexPath: NSIndexPath) {
        
        // 添加旋转_ progressHUD
        self.showProgressHUD()
        let zipPackage = zipArray.objectAtIndex(indexPath.row) as! ZipPackage
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            
            DSDownloadManager.shareInstance().cancelZip(zipPackage.urlString)
            PackageFileManager.sharedInstance.removePackage(zipPackage)
            self.hideProgressHUD()
            self.editButton.selected = false
            
            self.zipArray = PackageFileManager.sharedInstance.packages
            self.packageListTableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
            self.packageListTableView.reloadData()
        }
    }

    // MARK:
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return zipArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let reusableIdentifier: String = "zipPackageCell"
        let cell: ZipPackageCell? = tableView.dequeueReusableCellWithIdentifier(reusableIdentifier) as? ZipPackageCell

        let zipPackage = zipArray.objectAtIndex(indexPath.row) as! ZipPackage
        cell!.setZipPackage(zipPackage)
        cell!.delegate = self

        return cell!
    }

    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let zip = zipArray.objectAtIndex(indexPath.row) as! ZipPackage
        if zip.state == ZipPackageDownloadState.downloadCompleted || zip.state == ZipPackageDownloadState.hadUnzip || zip.state == ZipPackageDownloadState.unZipping {
            
            self.unzippingPackage(zip)
        }else if zip.state == ZipPackageDownloadState.isUsing {
            
            SystemConfigureManager.sharedInstance.makeSoundEffect()
            NSNotificationCenter.defaultCenter().postNotificationName("setMainController", object: nil)
        }
    }
    
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        
        return UITableViewCellEditingStyle.Delete
    }
    
    func tableView(tableView: UITableView, titleForDeleteConfirmationButtonForRowAtIndexPath indexPath: NSIndexPath) -> String? {
        
        return "删除"
    }
    
    func tableView(tableView: UITableView, willBeginEditingRowAtIndexPath indexPath: NSIndexPath) {
        
        isEdit = true
    }
    
    func tableView(tableView: UITableView, didEndEditingRowAtIndexPath indexPath: NSIndexPath) {
        
        isEdit = false
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if editingStyle == UITableViewCellEditingStyle.Delete {
            
            isEdit = false
            indexPth = indexPath
            
            let customAlertView = CustomAlertView(messageTitle: "确定删除这款车型?", sureTitle: "确定", cancelTitle: "取消", delegate: self)
            customAlertView.show()
        }
    }
    
    // MARK: ZipPackageCellDelegate
    func zipPackageDidDownloadCompleted(zip: ZipPackage) {
        if PackageFileManager.sharedInstance.packages.count == 1 {
            
            self.unzippingPackage(zip)
        }
    }
    
    // MARK: CustomAlertViewDelegate
    override func onCustomAlertViewSureButtonAction(alertView: CustomAlertView) {
        
        self.deleteDownloadZipPackage(indexPth)
    }
    
    // MARK: 
    // MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        super.prepareForSegue(segue, sender: sender)
        if segue.identifier == "DownloadToLawSegue" {
            
            let lawController = segue.destinationViewController as! LawController
            lawController.isLaw = true
        }
    }
}
