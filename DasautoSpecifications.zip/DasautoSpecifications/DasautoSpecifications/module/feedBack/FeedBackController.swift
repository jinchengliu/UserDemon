/*
*  filename: FeedBackController.swift
*  product name: DasautoSpecifications
*
*  author: shimingwei
*  date time: 14/12/1.
*  copyright: bdcluster
*/

import UIKit

class FeedBackController: DasautoController ,UITextViewDelegate{

    var delegate: GuideMenuDelegate?
    @IBOutlet weak var placeHoldLabel: UILabel!              // 自定义placeHold
    @IBOutlet weak var feedbackTextView: UITextView!
    @IBOutlet weak var submitButton: UIButton!
    
    // MARK:
    // MARK: Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.addBackBarButtonItem()
        self.setButtonTitleColor(submitButton)
        self.configureTextViewAccessoryView()
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        feedbackTextView.resignFirstResponder()
    }
    
    // MARK:
    // MARK: Configure Views
    /**
    *  设置textView的inputAccessoryView
    */
    func configureTextViewAccessoryView() {
        
        let topView = UIToolbar(frame: CGRectMake(0, 0, CGRectGetWidth(self.view.frame), 44))
        topView.barStyle = UIBarStyle.Default
        
        let camreaButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.Camera, target: self, action: "onCameraBarButtonItemClicked")
        camreaButton.tintColor = UIColor.grayColor()
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: self, action: nil)
        let sendButton = UIBarButtonItem(title: "Send", style: UIBarButtonItemStyle.Plain, target: self, action: "onSendBarButtonItemClicked")
        sendButton.tintColor = UIColor.blueColor()
        let buttonArrays = [camreaButton,spaceButton,sendButton]
        topView.items = buttonArrays
        feedbackTextView.inputAccessoryView = topView
    }
    
    // MARK:
    // MARK: Button Actions
    /**
    *  选中提交
    */
    @IBAction func onSubmitButtonAction(sender: UIButton) {
        
        SystemConfigureManager.sharedInstance.makeSoundEffect()
        self.isNullString(feedbackTextView.text)
    }

    /**
     *  选中返回
     */
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
        self.delegate?.didCloseGuideMenu!()
    }
    
    /**
    *  选中send
    */
    func onSendBarButtonItemClicked() {
        
        self.isNullString(feedbackTextView.text)
    }
    
    /**
     *  选中camera
     */
    func onCameraBarButtonItemClicked() {
        
    }
    
    /**
    *  判断输入的字符串是否是空值
    */
    func isNullString(string: String) {
        
        feedbackTextView.resignFirstResponder()
        if string.isEmpty == true {
           
            self.showRendView("请确认您要反馈的信息是否存在", isSuccess: false)
        }else if string.characters.count <= 200{
            
            let trimString = string.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet()) as NSString
            if trimString.length == 0 {
                
                self.showRendView("输入信息不能为空格", isSuccess: false)
            }else {
                
                if AFNetworkReachabilityManager.sharedManager().reachable == true {
                    
                    self.feedBackMessage()
                }else {
                    
                    self.showRendView("当前网络不可用", isSuccess: false)
                }
            }
        }else {
            
            self.showRendView("评价必须在两百字以内", isSuccess: false)
        }
    }
    
    // MARK:
    // MARK: Load Data
    /**
    *  用户反馈
    */
    func feedBackMessage() {
        
        var userId: Int!
        if kUserId == "noLogin" {
            userId = 0
        }
        else {
            userId = Int(kUserId)!
        }
        let userDict: NSDictionary = ["userId": userId,"feedback": feedbackTextView.text]

        AFOperationManager.sharedInstance.startPostOperation(HttpBaseUrl + kFeedBackAdd, param: userDict, withToken:false, success: { (operation, responseObject) -> Void in
            
            let mutableDic = responseObject as? NSMutableDictionary
            if mutableDic != nil {
                
                self.showRendView("非常感谢您的反馈，我们会努力做的更好", isSuccess: false)
                
                let when = dispatch_time(DISPATCH_TIME_NOW, Int64(1 * NSEC_PER_SEC))
                dispatch_after(when, dispatch_get_main_queue(), { () -> Void in
                    
                    self.navigationController?.popViewControllerAnimated(true)
                    self.delegate?.didCloseGuideMenu!()
                })
            }
            }) { (operation, error) -> Void in
                
                Logger.info("_____________\(error)")
        }
    }
    
    // MARK: 
    // MARK: UITextViewDelegate
    func textViewDidChange(textView: UITextView) {
        
        if placeHoldLabel.hidden == false {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                
                self.placeHoldLabel.alpha = 0
                }, completion: { (complete) -> Void in
                    
                    self.placeHoldLabel.alpha = 0
                    self.placeHoldLabel.hidden = true
            })
        }
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        
        if textView.text.isEmpty == true {
            
            placeHoldLabel.hidden = false
        }
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        
        placeHoldLabel.hidden = true
    }
}
