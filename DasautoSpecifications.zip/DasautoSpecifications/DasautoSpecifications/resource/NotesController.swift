//
//  NotesController.swift
//  CarRelations
//
//  Created by chenpan on 15/1/12.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit

class NotesController: DasautoController, UITableViewDataSource {
    
    ///Mark: 属性
    @IBOutlet weak var someoneImageView: UIImageView!
    @IBOutlet weak var loginButton: UIButton!

    var passwordTextField: UITextField!  //输入密码框
    var usernameTextField: UITextField!  //用户名输入框
    
    var actvities: [String]!  //活动内容actvities集合
    
    //MARK: 登录
    @IBAction func loginAction(sender: AnyObject) {
        
        //TODO:
    }
    
    //Mark: 登出
    @IBAction func loginOutAction(sender: AnyObject) {
        
        //TODO:
    }
    
    // MARK: 
    // MARK: 生命周期
    override func viewDidLoad() {
        
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    //Mark: 自定义方法
    ///配置导航栏
    func configureUINavgationItem() {
        
        //定制UI 请再前面加上相应的configure
    }
    
    /*
     * param: state
     */
    ///加载活动内容
    func loadActivitiesContent(state: String) {
        
        if true {
        
        } else {
            
        }
    }
    
    //Mark: 事件响应
    ///响应返回按钮事件
    override func onBackBarButtonItemClciked(sender: UIBarButtonItem) {
        
        super.onBackBarButtonItemClciked(sender)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    //Mark: 委托协议实现
    
    //Mark: 表格有多少行
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 10
    }
    
    //Mark: 每个NSIndexPath对应的UITableViewCell
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell")
        
        return cell!
    }
    
    //Mark: 过段前数据的准备
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        //数据传递
        //TODO:
    }

}
