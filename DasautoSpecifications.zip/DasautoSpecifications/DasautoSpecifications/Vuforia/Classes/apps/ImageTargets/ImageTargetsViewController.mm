/*===============================================================================
Copyright (c) 2012-2014 Qualcomm Connected Experiences, Inc. All Rights Reserved.

Vuforia is a trademark of QUALCOMM Incorporated, registered in the United States 
and other countries. Trademarks of QUALCOMM Incorporated are used with permission.
===============================================================================*/
#import "ImageTargetsViewController.h"
#import <QCAR/QCAR.h>
#import <QCAR/TrackerManager.h>
#import <QCAR/ObjectTracker.h>
#import <QCAR/Trackable.h>
#import <QCAR/DataSet.h>
#import <QCAR/CameraDevice.h>

#import "QCAR_iOS.h"

#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#import <sys/time.h>

#import "DasautoSpecifications-Swift.h"


@interface ImageTargetsViewController ()

@end

@implementation ImageTargetsViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        vapp = [[SampleApplicationSession alloc] initWithDelegate:self];
        
        // Create the EAGLView with the screen dimensions
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        viewFrame = screenBounds;
        
        // If this device has a retina display, scale the view bounds that will
        // be passed to QCAR; this allows it to calculate the size and position of
        // the viewport correctly when rendering the video background
        if (YES == vapp.isRetinaDisplay) {
            viewFrame.size.width *= 2.0;
            viewFrame.size.height *= 2.0;
        }
        
        dataSetCurrent = nil;
        isEnable = NO;
        extendedTrackingIsOn = NO;
        
        // a single tap will trigger a single autofocus operation
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(cameraIsWorkingForTrackingPicture:)
         name:@"trackResult"
         object:nil];
    }
    return self;
}

// MARK: 接受消息后的响应事件
- (void)cameraIsWorkingForTrackingPicture:(NSNotification *)notification {
    
    if (![notification.object  isEqual: @"false"]) {
        
        NSDictionary *userinfo = notification.userInfo;
        NSString *name = userinfo[@"name"];
        NSArray *nameArr = [name componentsSeparatedByString:@"_"];
        name = nameArr[0];
        
        [self search:name];
        
        isEnable = YES;
    }
}

//---change--
-(void)search:(NSString *)name
{
   
    //用户手册中搜索
    [[PackageFileManager sharedInstance].rootFile findFileWithFileId:3];
    DasAutoFile *userManualFile = [PackageFileManager sharedInstance].rootFile.result;
    
    for (int i = 0; i < userManualFile.children.count; i++ )
    {
        DasAutoFile *manualLeaf = userManualFile.children[i];
        
         for (int j = 0; j < manualLeaf.children.count; j++)
         {
             DasAutoFile *childrenLeaf = manualLeaf.children[j];
            
             for (int k = 0; k < childrenLeaf.children.count; k++)
             {
                 DasAutoFile *leaf = childrenLeaf.children[k];
                
                 NSString *letterString = [ChineseToPinyin pinyinFromChiniseString:leaf.name].lowercaseString;

                 if ([letterString rangeOfString:name].location != NSNotFound) {
                     
                     HotSpotHtmlController *htmlPage = [[HotSpotHtmlController alloc]init];
                     
                     htmlPage.leaf = leaf;
                     htmlPage.whetherFormAR = @"true";
                     
                     [self presentViewController:htmlPage animated:YES completion:nil];
                     return;
                 }
//                 if([name isEqualToString:letterString])
//                 {
//                     
//                     HotSpotHtmlController *htmlPage = [[HotSpotHtmlController alloc]init];
//                     
//                     htmlPage.leaf = leaf;
//                     htmlPage.whetherFormAR = @"true";
//                     
//                     [self presentViewController:htmlPage animated:YES completion:nil];
//                     return;
//                    
//                 }
            }
         }
    }
    
    //otherRes中搜索
    [[PackageFileManager sharedInstance].rootFile findFileWithFileId:8];
    
    DasAutoFile *userManualFile2 = [PackageFileManager sharedInstance].rootFile.result;
    
    for (int i = 0; i < userManualFile2.children.count; i++ )
    {
        DasAutoFile *manualLeaf2 = userManualFile2.children[i];
        NSString *letterString = [ChineseToPinyin pinyinFromChiniseString:manualLeaf2.name].lowercaseString;
        
        if([name isEqualToString:letterString])
        {
            HotSpotHtmlController *htmlPage = [[HotSpotHtmlController alloc]init];
            
            htmlPage.leaf = manualLeaf2;
            htmlPage.whetherFormAR = @"true";
            
            [self presentViewController:htmlPage animated:YES completion:nil];
            
            return;
        }
    }
    
    //热点
    [[PackageFileManager sharedInstance].rootFile findFileWithFileId:7];
    
    DasAutoFile *userManualFile3 = [PackageFileManager sharedInstance].rootFile.result;
    
    for (int i = 0; i < userManualFile3.children.count; i++ )
    {
        DasAutoFile *manualLeaf2 = userManualFile3.children[i];
        
        NSString *letterString = [ChineseToPinyin pinyinFromChiniseString:manualLeaf2.name].lowercaseString;
        
        if([name isEqualToString:letterString])
        {
            if([name isEqualToString:@"chedingbushitu"]||[name isEqualToString:@"chemenshitu"]||[name isEqualToString:@"zhongkongtaixiabushitu"])
            {

                HotSpotViewController *hotSpotViewController = [[HotSpotViewController alloc]init];
            
                hotSpotViewController.whetherFromQuickGuide = @"true";
                hotSpotViewController.quickGuideName = manualLeaf2.name;
                [hotSpotViewController loadImage:manualLeaf2];
                [self presentViewController:hotSpotViewController animated:YES completion:nil];
                
                return;
            }

        }
    }
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [vapp release];
    [eaglView release];
    
    [super dealloc];
}


- (void)viewWillDisappear:(BOOL)animated {
    
    
    [vapp stopAR:nil];
    [eaglView finishOpenGLESCommands];
    [eaglView freeOpenGLESResources];
    [timer invalidate];
    timer = nil;
    [UIApplication sharedApplication].idleTimerDisabled = NO;   // 自动锁屏
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
    [super viewWillDisappear:animated];
    
}

-(void)viewWillAppear:(BOOL)animated {
    
    [UIApplication sharedApplication].idleTimerDisabled = YES;  // 不自动锁屏
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    if (isEnable == YES) {
        
        [self.navigationController popViewControllerAnimated:YES];
        [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
        return;
    }
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}

- (void)loadView
{
    // Create the EAGLView
    eaglView = [[ImageTargetsEAGLView alloc] initWithFrame:viewFrame appSession:vapp];
    [self setView:eaglView];
    [self showLoadingAnimation];
    [vapp initAR:QCAR::GL_20 ARViewBoundsSize:viewFrame.size orientation:UIInterfaceOrientationPortrait];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];
}

// MARK: 配置取景框
-(void)configureCameraAperture {
    
    CGFloat w = CGRectGetWidth(self.view.bounds);
    CGFloat h = CGRectGetHeight(self.view.bounds);
    NSArray *imageNameArray = @[@"camera_frame_lt",
                                @"camera_frame_rt",
                                @"camera_frame_lb",
                                @"camera_frame_rb"];
    for (int i = 0; i < imageNameArray.count; i++) {
        CGFloat x;
        CGFloat y;
        if (i == 0) {
            
            x = 20;
            y = 30;
        }else if (i == 1) {
            
            x = w - 46;
            y = 30;
        }else if (i == 2) {
            
            x = 20;
            y = h - 120;
        }else {
            
            x = w - 46;
            y = h - 120;
        }
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, 36, 36)];
        imageView.image = [UIImage imageNamed:imageNameArray[i]];
        [self.view addSubview:imageView];
    }
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(40, h - 80, w - 80, 30)];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:15];
    label.text = @"请将摄像头对准您需要识别的部分";
    [self.view addSubview:label];
}

// MARK: 配置返回按钮
- (void)addBackButton{
    
    CGFloat w = CGRectGetWidth([UIScreen mainScreen].bounds);
    CGFloat h = CGRectGetHeight([UIScreen mainScreen].bounds);
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    backButton.backgroundColor = [UIColor blackColor];
//    backButton.alpha = 0.88;
    backButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    backButton.frame = CGRectMake( 0, h - 40, w, 40);
    backButton.tag = 2000;
    [backButton setTitle:@"取消" forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:16];
    UIColor *color = [UIColor colorWithRed:0.98 green:0 blue:0.24 alpha:1];
    [backButton setTitleColor:color forState:UIControlStateNormal];
//    [backButton setImageEdgeInsets:UIEdgeInsetsMake(6, 10, 6, 36)];
    [backButton addTarget:self action:@selector(onBackButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backButton];
    
    // -- change -- (修改UI切图)
    UIButton *helpButton = [UIButton buttonWithType:UIButtonTypeCustom];
    helpButton.frame = CGRectMake(w - 60, h - 60, 40, 40);
    helpButton.tag = 3000;
    [helpButton setImage:[UIImage imageNamed:@"arHelp"] forState:UIControlStateNormal];
    [helpButton addTarget:self action:@selector(onBackButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [helpButton setImageEdgeInsets:UIEdgeInsetsMake(2, 12, 10, 0)];
    [self.view addSubview:helpButton];
}

// MARK: 点击返回按钮的响应事件
- (void)onBackButtonClicked:(UIButton *)sender {
    
    if (sender.tag == 2000) {
        
        [self.navigationController popViewControllerAnimated:YES];
    }else if (sender.tag == 3000){
        
        // -- changge ---
        if (![self.view viewWithTag:1000]) {
            
            UIButton *showButton = [UIButton buttonWithType:UIButtonTypeCustom];
            showButton.frame = CGRectMake(30, CGRectGetHeight(self.view.bounds) / 2 - 110, CGRectGetWidth(self.view.bounds) - 60, 220 );
            [showButton addTarget:self action:@selector(onShowButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
            showButton.tag = 1000;
            showButton.layer.cornerRadius = 5;
            showButton.layer.masksToBounds = YES;
            showButton.backgroundColor = [UIColor whiteColor];
            [self.view addSubview:showButton];
            
            UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, 0, CGRectGetWidth(showButton.bounds) - 8, CGRectGetHeight(showButton.bounds))];
            titleLabel.text = @"友情提示:\n• AR智能识别功能较易收到光线及拍摄角度的影响，室外强光及夜晚昏暗环境都会影响识别的成功率，请适当调整拍摄角度。\n• 目前AR识别功能可支持对车辆仪表、多功能方向盘、中控台以及天窗等部件或其上按钮的识别，您可在这些设备上体验AR识别功能。";
            titleLabel.numberOfLines = 0;
            titleLabel.textColor = [UIColor grayColor];
            [showButton addSubview:titleLabel];
        }else {
            
            UIButton *button = (UIButton *)[self.view viewWithTag:1000];
            [button removeFromSuperview];
        }
    }
}

- (void)onShowButtonClicked:(UIButton *)sender {
    
    [sender removeFromSuperview];
}

- (void)onTapGestureAction:(UITapGestureRecognizer *)tapGesture {
    
    if ([self.view viewWithTag:1000]) {
        
        UIButton *button = (UIButton *)[self.view viewWithTag:1000];
        [button removeFromSuperview];
    }
}

- (void)finishOpenGLESCommands
{
    // Called in response to applicationWillResignActive.  Inform the EAGLView
    [eaglView finishOpenGLESCommands];
}

- (void)freeOpenGLESResources
{
    // Called in response to applicationDidEnterBackground.  Inform the EAGLView
    [eaglView freeOpenGLESResources];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - loading animation
- (void) showLoadingAnimation {
    
    CGRect mainBounds = [[UIScreen mainScreen] bounds];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(mainBounds) , CGRectGetHeight(mainBounds))];
    NSLog(@"arImageL  :%@",NSStringFromCGRect(mainBounds));

    imageView.image = [UIImage imageNamed:@"arImage.jpg"];
    imageView.tag = 1;
    [self.view addSubview:imageView];
}

- (void) hideLoadingAnimation {
    
//    UIActivityIndicatorView *loadingIndicator = (UIActivityIndicatorView *)[eaglView viewWithTag:1];
//    [loadingIndicator removeFromSuperview];
    
    UIImageView *imageView = (UIImageView *)[self.view viewWithTag:1];
    
    [UIView animateWithDuration:0.3 animations:^
    {
        imageView.center = self.view.center;
        imageView.frame = CGRectMake(self.view.center.x, self.view.center.y, 0, 0);

        
    } completion:^(BOOL finished)
    {
        [imageView removeFromSuperview];
    }];
    
}

#pragma mark - SampleApplicationControl
- (bool) doInitTrackers {
    
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::Tracker* trackerBase = trackerManager.initTracker(QCAR::ObjectTracker::getClassType());
    if (trackerBase == NULL)
    {
        NSLog(@"Failed to initialize ObjectTracker.");
        return false;
    }
    NSLog(@"Successfully initialized ObjectTracker.");
    return true;
}

// MARK: loadData
- (bool) doLoadTrackersData {
    
    dataSetImage1 = [self loadObjectTrackerDataSet:@"1.xml"];
    if (dataSetImage1 == NULL) {
        
        NSLog(@"Failed to load datasets");
        return NO;
    }
    if (! [self activateDataSet:dataSetImage1]) {
        NSLog(@"Failed to activate dataset");
        return NO;
    }
    return YES;
}

- (bool) doStartTrackers {
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::Tracker* tracker = trackerManager.getTracker(QCAR::ObjectTracker::getClassType());
    if(tracker == 0) {
        return NO;
    }

    tracker->start();
    return YES;
}

// callback: the AR initialization is done
- (void) onInitARDone:(NSError *)initError {
    
    [self hideLoadingAnimation];
    // MARK: 添加取消button
    [self addBackButton];
    [self configureCameraAperture];
    if (initError == nil) {
        
        // If you want multiple targets being detected at once,
        // you can comment out this line
        // QCAR::setHint(QCAR::HINT_MAX_SIMULTANEOUS_IMAGE_TARGETS, 2);
        NSError * error = nil;
        [vapp startAR:QCAR::CameraDevice::CAMERA_BACK error:&error];
        
    } else {
        NSLog(@"Error initializing AR:%@", [initError description]);
        dispatch_async( dispatch_get_main_queue(), ^{

            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"连接错误"
                                                            message:@"网络连接错误,无法初始化"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            [alert release];
        });
    }
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) onQCARUpdate: (QCAR::State *) state {
    if (switchToTarmac) {
        [self activateDataSet:dataSetTarmac];
        switchToTarmac = NO;
    }
    if (switchToStonesAndChips) {
        [self activateDataSet:dataSetStonesAndChips];
        switchToStonesAndChips = NO;
    }
}

// Load the image tracker data set
- (QCAR::DataSet *)loadObjectTrackerDataSet:(NSString*)dataFile
{
    NSLog(@"loadObjectTrackerDataSet (%@)", dataFile);
    QCAR::DataSet * dataSet = NULL;
    
    // Get the QCAR tracker manager image tracker
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::ObjectTracker* objectTracker = static_cast<QCAR::ObjectTracker*>(trackerManager.getTracker(QCAR::ObjectTracker::getClassType()));
    
    if (NULL == objectTracker) {
        NSLog(@"ERROR: failed to get the ObjectTracker from the tracker manager");
        return NULL;
    } else {
        dataSet = objectTracker->createDataSet();
        
        if (NULL != dataSet) {
            NSLog(@"INFO: successfully loaded data set");
            
            // Load the data set from the app's resources location
            if (!dataSet->load([dataFile cStringUsingEncoding:NSASCIIStringEncoding], QCAR::STORAGE_APPRESOURCE)) {
                NSLog(@"ERROR: failed to load data set");
                objectTracker->destroyDataSet(dataSet);
                dataSet = NULL;
            }
        }
        else {
            NSLog(@"ERROR: failed to create data set");
        }
    }
    
    return dataSet;
}

- (bool) doStopTrackers {
    // Stop the tracker
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::Tracker* tracker = trackerManager.getTracker(QCAR::ObjectTracker::getClassType());
    if (NULL != tracker) {
        tracker->stop();
        NSLog(@"INFO: successfully stopped tracker");
        return YES;
    }
    else {
        NSLog(@"ERROR: failed to get the tracker from the tracker manager");
        return NO;
    }
}

- (bool) doUnloadTrackersData {
    [self deactivateDataSet: dataSetCurrent];
    dataSetCurrent = nil;
    
    // Get the image tracker:
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::ObjectTracker* objectTracker = static_cast<QCAR::ObjectTracker*>(trackerManager.getTracker(QCAR::ObjectTracker::getClassType()));
    
    // Destroy the data sets:
    if (!objectTracker->destroyDataSet(dataSetTarmac))
    {
        NSLog(@"Failed to destroy data set Tarmac.");
    }
    if (!objectTracker->destroyDataSet(dataSetStonesAndChips))
    {
        NSLog(@"Failed to destroy data set Stones and Chips.");
    }
    
    NSLog(@"datasets destroyed");
    return YES;
}

- (BOOL)activateDataSet:(QCAR::DataSet *)theDataSet
{
    // if we've previously recorded an activation, deactivate it
    if (dataSetCurrent != nil)
    {
//        [self deactivateDataSet:dataSetCurrent];
    }
    BOOL success = NO;
    
    // Get the image tracker:
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::ObjectTracker* objectTracker = static_cast<QCAR::ObjectTracker*>(trackerManager.getTracker(QCAR::ObjectTracker::getClassType()));
    
    if (objectTracker == NULL) {
        NSLog(@"Failed to load tracking data set because the ObjectTracker has not been initialized.");
    }
    else
    {
        // Activate the data set:
        if (!objectTracker->activateDataSet(theDataSet))
        {
            NSLog(@"Failed to activate data set.");
        }
        else
        {
            NSLog(@"Successfully activated data set.");
            dataSetCurrent = theDataSet;
            success = YES;
        }
    }
    
    // we set the off target tracking mode to the current state
    if (success) {
        [self setExtendedTrackingForDataSet:dataSetCurrent start:extendedTrackingIsOn];
    }
    
    return success;
}

- (BOOL)deactivateDataSet:(QCAR::DataSet *)theDataSet
{
    if ((dataSetCurrent == nil) || (theDataSet != dataSetCurrent))
    {
        NSLog(@"Invalid request to deactivate data set.");
        return NO;
    }
    
    BOOL success = NO;
    
    // we deactivate the enhanced tracking
    [self setExtendedTrackingForDataSet:theDataSet start:NO];
    
    // Get the image tracker:
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    QCAR::ObjectTracker* objectTracker = static_cast<QCAR::ObjectTracker*>(trackerManager.getTracker(QCAR::ObjectTracker::getClassType()));
    
    if (objectTracker == NULL)
    {
        NSLog(@"Failed to unload tracking data set because the ObjectTracker has not been initialized.");
    }
    else
    {
        // Activate the data set:
        if (!objectTracker->deactivateDataSet(theDataSet))
        {
            NSLog(@"Failed to deactivate data set.");
        }
        else
        {
            success = YES;
        }
    }
    
    dataSetCurrent = nil;
    
    return success;
}

- (BOOL) setExtendedTrackingForDataSet:(QCAR::DataSet *)theDataSet start:(BOOL) start {
    BOOL result = YES;
    for (int tIdx = 0; tIdx < theDataSet->getNumTrackables(); tIdx++) {
        QCAR::Trackable* trackable = theDataSet->getTrackable(tIdx);
        if (start) {
            if (!trackable->startExtendedTracking())
            {
                NSLog(@"Failed to start extended tracking on: %s", trackable->getName());
                result = false;
            }
        } else {
            if (!trackable->stopExtendedTracking())
            {
                NSLog(@"Failed to stop extended tracking on: %s", trackable->getName());
                result = false;
            }
        }
    }
    return result;
}

- (bool) doDeinitTrackers {
    QCAR::TrackerManager& trackerManager = QCAR::TrackerManager::getInstance();
    trackerManager.deinitTracker(QCAR::ObjectTracker::getClassType());
    return YES;
}

@end
