//
//  ARDetailViewController.m
//  QualcommVuforiaSamples
//
//  Created by wangrui on 15-4-2.
//  Copyright (c) 2015年 wangrui. All rights reserved.
//

#import "ARDetailViewController.h"
#import "AppViewController.h"

@interface ARDetailViewController ()

@end

@implementation ARDetailViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
 
}
- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}


@end
