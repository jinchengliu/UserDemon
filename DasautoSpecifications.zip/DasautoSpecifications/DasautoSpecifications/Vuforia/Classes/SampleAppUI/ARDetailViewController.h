//
//  ARDetailViewController.h
//  QualcommVuforiaSamples
//
//  Created by wangrui on 15-4-2.
//  Copyright (c) 2015年 wangrui. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ARDetailViewController : UIViewController

@end
