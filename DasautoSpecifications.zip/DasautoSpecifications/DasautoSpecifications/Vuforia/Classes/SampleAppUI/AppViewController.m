//
//  AppViewController.m
//  VuforiaSamples
//
//  Created by wangrui on 15-3-19.
//  Copyright (c) 2015年 Qualcomm. All rights reserved.
//

#import "AppViewController.h"

@interface AppViewController ()

@end

@implementation AppViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.navigationController setNavigationBarHidden:NO animated:NO];

    UIButton *startButton = [UIButton buttonWithType:UIButtonTypeCustom];
    startButton.frame = CGRectMake(0, 0, 100, 60);
    startButton.backgroundColor = [UIColor whiteColor];
    [startButton setTitle:@"点击开始AR" forState:UIControlStateNormal];
    [startButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    startButton.center = self.view.center;
    [startButton addTarget:self action:@selector(onStartButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:startButton];
    
}

- (void)onStartButtonClicked:(UIButton *)button {
    
    Class vcClass =  NSClassFromString(@"ImageTargetsViewController");
    id vc = [[vcClass alloc]  initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
