//
//  AppViewController.h
//  VuforiaSamples
//
//  Created by wangrui on 15-3-19.
//  Copyright (c) 2015年 Qualcomm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppViewController : UIViewController

@end
