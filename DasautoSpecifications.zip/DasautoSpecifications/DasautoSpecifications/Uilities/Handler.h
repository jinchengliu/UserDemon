//
//  Handler.h
//  DasautoSpecifications
//
//  Created by 余新闻 on 15/7/23.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Handler : NSObject

+ (NSString *)hardwareIdentifier;

@end
