//
//  InsetsLabel.h
//  yoyaku-topten
//
//  Created by 新闻 on 14-8-20.
//
//  调整内编剧的UILabel,重载drawTextInRect方法

#import <UIKit/UIKit.h>

@interface InsetsLabel : UILabel

@property(assign,nonatomic)UIEdgeInsets insets;

-(id) initWithFrame:(CGRect)frame andInsets: (UIEdgeInsets) insets;

-(id) initWithInsets: (UIEdgeInsets) insets;

@end
