//
//  SingleNews.swift
//  DasautoSpecifications
//
//  Created by 余新闻 on 15/7/16.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

import UIKit
import Foundation

let _singleNewsInstance = SingleNews()

class SingleNews
{
    var downloadTask:NSURLSessionDownloadTask?
    
    class var sharedInstance : SingleNews
    {
        return _singleNewsInstance
    }
}