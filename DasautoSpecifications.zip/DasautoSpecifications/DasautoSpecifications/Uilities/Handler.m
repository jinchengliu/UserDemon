//
//  Handler.m
//  DasautoSpecifications
//
//  Created by 余新闻 on 15/7/23.
//  Copyright (c) 2015年 bdcluster. All rights reserved.
//

#import "Handler.h"
#include <sys/types.h>
#include <sys/sysctl.h>


@implementation Handler

+ (NSString *)hardwareIdentifier {
    static dispatch_once_t once;
    static NSString * hardware;
    dispatch_once(&once, ^ {
        size_t size = 100;
        char *hw_machine = malloc(size);
        int name[] = {CTL_HW,HW_MACHINE};
        sysctl(name, 2, hw_machine, &size, NULL, 0);
        hardware = [NSString stringWithUTF8String:hw_machine];
        free(hw_machine);
    });
    return hardware;
}

@end
