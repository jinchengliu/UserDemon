//
//  PackagingScrollView.h
//  ScrollView
//
//  Created by 新闻 on 15-4-30.
//  Copyright (c) 2015年 Adways. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol PackagingScrollViewDelegate;

@interface PackagingScrollView : UIView <UIScrollViewDelegate>

{
    __unsafe_unretained id <PackagingScrollViewDelegate> _delegate;
}

@property (nonatomic, assign) id <PackagingScrollViewDelegate> delegate;

@property (nonatomic, assign) NSInteger currentPage;

@property (nonatomic, strong) NSMutableArray *imageViewAry;

@property (nonatomic, readonly) UIScrollView *scrollView;

@property (nonatomic, readonly) UIPageControl *pageControl;

-(void)shouldAutoShow:(BOOL)shouldStart;

//addMethod
-(void)setImageViewAry:(NSMutableArray *)imageViewAry withCurrentIndex:(int)index;
-(void)reloadData;

-(void)autoShowNextImage;
-(void)showLastImage;

@end

@protocol PackagingScrollViewDelegate <NSObject>

@optional
- (void)didClickPage:(PackagingScrollView *)view atIndex:(NSInteger)index;

@end